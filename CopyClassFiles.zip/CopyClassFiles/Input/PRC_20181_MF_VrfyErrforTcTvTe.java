package xtam.test;

import java.util.Map;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class PRC_20181_MF_VrfyErrforTcTvTe {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;
	private String strApplicationDate,strDropValue1,strDropValue2;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateToMF;
	// TODO: Declare test-data variables for other data-parameters
	private String strMsg;
	private String strNavigateToAdmin;
	private String AllPrc;
	private String TkOutPrc, EatingPrc, OthPrc,message,taxtype,texchanin;

	public PRC_20181_MF_VrfyErrforTcTvTe(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);
		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateToMF = mcd.GetTestData("DT_NAVIGATE_TO");
		
		// TODO: GetTestData for other data-parameters
		strMsg = mcd.GetTestData("DT_MSG");
		AllPrc = mcd.GetTestData("AllPrcValue");
		strNavigateToAdmin = mcd.GetTestData("DT_NAVIGATE_TO_ADMIN");
		TkOutPrc = mcd.GetTestData("TakeOut");
		EatingPrc = mcd.GetTestData("Eatin");
		OthPrc = mcd.GetTestData("Other");
		message=mcd.GetTestData("DT_MSSSAGE");
		strDropValue1=mcd.GetTestData("DT_VALUE1");
		strDropValue2=mcd.GetTestData("DT_VALUE2");
		taxtype=mcd.GetTestData("DT_TAXTYPE");
		texchanin=mcd.GetTestData("DT_TAXCHAIN");
	}

	@Test
	public void test_PRC_20181_MF_VrfyErrforTcTvTe() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			/** Get Test case Description */
			actions.setTestcaseDescription(
					"PRC_20180 & PRC_20181-Verify error message for Tax Value field, Take Out Tax Code, Tax Rule, Tax Entry when it is expanded,PRC_20182-Verify error message for Tax Value field Other Tax Code, Tax Rule, Tax Entry when it is expanded and if the Tax Rule selected is Tax Chain, then the tax entry must be a Tax Chain entry. ");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateToAdmin);
			actions.select_menu("RFMHome.Navigation", strNavigateToAdmin);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// Aotomating the Pre - Req
			rfm.RFM_Admin_Update_PricingTags("false", "Restrict price type attribute from expanding");
			rfm.RFM_Admin_Update_PricingTags("false", "Display price type attribute as expanded by default");
			rfm.RFM_Admin_Update_PricingTags("0", "Automatically fill price type attribute option price value");

			// Navigating to Master Fee
			actions.waitForPageToLoad(120);
			System.out.println("> Navigate to :: " + strNavigateToMF);
			actions.select_menu("RFMHome.Navigation", strNavigateToMF);
			Thread.sleep(2000);
			actions.waitForPageToLoad(180);

			mcd.SwitchToWindow("#Title");
			actions.waitForPageToLoad(120);
			String[] Msg = strMsg.split("#");

			// Verifying Search with Status DropDown is Present
			if (actions.isElementEnabled("PermissionReportbyRole.SearchDDL")) {
				actions.reportCreatePASS("Verify Search with Status DropDown ",
						"Search with Status DropDown should be Present", "Search with Status DropDown is Present",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify Search with Status DropDown ",
						"Search with Status DropDown should be Present", "Search with Status DropDown is not Present",
						"FAIL");
			}

			// Verifying Search Full List by Fee Name text box
			String str = driver.findElement(By.xpath(actions.getLocator("MasterFee.SearchBox"))).getAttribute("type");
			if (str.equals("text")) {
				actions.reportCreatePASS("Verifying Search Full List by Fee Name text box ",
						"Search Full List by Fee Name text box should display",
						"Search Full List by Fee Name text box is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying Search Full List by Fee Name text box ",
						"Search Full List by Fee Name text box should display",
						"Search Full List by Fee Name text box is NOT displayed", "FAIL");
			}

			// Verify Search button
			if (actions.isElementPresent("SetAssignmentReport.SearchButton")) {
				actions.reportCreatePASS("Verify Search button", "Search button should display",
						"Search button is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Search button", "Search button should display",
						"Search button is not displayed", "FAIL");
			}

			Boolean resultStatus;
			Select selObj = new Select(driver.findElement(By.xpath(actions.getLocator("ProductionRouting.Status"))));
			resultStatus = selObj.getFirstSelectedOption().getText().trim().equalsIgnoreCase("All");
			reporting_Pass_Fail("Verify whether Status All is selected by default for Status DDL",
					"Status All should be selected by default", "Status All is selected by default",
					"Status All is not selected by default", resultStatus);

			// Verifying New fee button
			if (actions.isElementPresent("MasterFee.NewFeeBtn")) {
				actions.reportCreatePASS("Verify New fee button", "New fee button should display",
						"New fee button is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify New fee button", "New fee button should display",
						"New fee button is not displayed", "FAIL");
			}

			// Verifying columns
			verifyTablecolumnsPresent("FieldPermissions.Table", "Fee ID");
			verifyTablecolumnsPresent("FieldPermissions.Table", "Fee Name");
			verifyTablecolumnsPresent("FieldPermissions.Table", "Status");
			verifyTablecolumnsPresent("FieldPermissions.Table", "Future Settings");
			verifyTablecolumnsPresent("FieldPermissions.Table", "Delete");

			// Click on new fee button
			actions.WaitForElementPresent("MasterFee.NewFeeBtn");
			actions.keyboardEnter("MasterFee.NewFeeBtn");
			actions.smartWait(20);
			actions.WaitForElementPresent("MasterFee.FeeId");
			actions.clear("MasterFee.FeeId");

			// Entering unique ID
			Random rand_num = new Random();
			int strNewFeeiD = rand_num.nextInt((99) + 5);
			System.out.println(strNewFeeiD);
			actions.setValue("MasterFee.FeeId", Integer.toString(strNewFeeiD));

			// Entering unique Name
			actions.WaitForElementPresent("MasterFee.FeeName");
			String strNewFeeName = mcd.fn_GetRndName("ATS");
			actions.setValue("MasterFee.FeeName", strNewFeeName);

			// Select fee type from the dropdown
			actions.WaitForElementPresent("MasterFee.FeeType");
			actions.setValue("MasterFee.FeeType", "Rate");

			// Setting all price field
			actions.WaitForElementPresent("FeeSet.AllPrc");
			actions.clear("FeeSet.AllPrc");
			actions.setValue("FeeSet.AllPrc", AllPrc);
			actions.waitForPageToLoad(120);

			// Selecting eatin ddl from tax code
			actions.javaScriptClick("DepositSet.TaxPlusIcon");
			actions.smartWait(180);
			actions.setValue("ManageFee.eatinTaxCode", "Always");
			actions.smartWait(180);
			actions.keyboardEnter("ApplyChangesDetails.Save");
			Thread.sleep(1000);
			
			// Verify alert message for Eatin tax rule
			boolean warn0 = mcd.VerifyAlertMessageDisplayed("Warning", Msg[0], true, AlertPopupButton.OK_BUTTON);

			if (warn0) {
				actions.reportCreatePASS("Verify 'Please select Eatin Tax Rule' Alert",
						"'Please select Eatin Tax Rule' Alert sholud be displayed.",
						"'Please select Eatin Tax Rule' Alert is displayed.", "Pass");

			} else {
				actions.reportCreateFAIL("Verify 'Please select Eatin Tax Rule' Alert",
						"'Please select Eatin Tax Rule' Alert sholud be displayed.",
						"'Please select Eatin Tax Rule' Alert is not displayed.", "Fail");
			}

			// Selecting data from eatin textule
			actions.WaitForElementPresent("DepositSet.EatinTaxRule");
			actions.setValue("DepositSet.EatinTaxRule", "GST");
			actions.smartWait(180);
			actions.keyboardEnter("ApplyChangesDetails.Save");
			Thread.sleep(1000);
			
			// Verify alert message for eatin tax entry
			boolean warn1 = mcd.VerifyAlertMessageDisplayed("Warning", Msg[1], true, AlertPopupButton.OK_BUTTON);
			if (warn1) {
				actions.reportCreatePASS("Verify 'Please select Eatin Tax Entry' Alert",
						"'Please select Eatin Tax Entry' Alert sholud be displayed.",
						"'Please select Eatin Tax Entry' Alert is displayed.", "Pass");

			} else {
				actions.reportCreateFAIL("Verify 'Please select Eatin Tax Entry' Alert",
						"'Please select Eatin Tax Entry' Alert sholud be displayed.",
						"'Please select Eatin Tax Entry' Alert is not displayed.", "Fail");
			}

			// Selecting data from eatin tax entry ddl
			actions.WaitForElementPresent("DepositSet.EatinTaxEntry");
			Select select = new Select(actions.getWebElement("DepositSet.EatinTaxEntry"));
			select.selectByIndex(1);
			actions.keyboardEnter("ApplyChangesDetails.Save");
			actions.smartWait(180);

			// To verify your changes have been saved by entering a unique fee
			// ID
			boolean flag = false, flagFeeId = false;
			try {
				flag = mcd.VerifyOnscreenMessage("ManageFee.SSMsg", Msg[4], true);

			} catch (Exception e) {

				do {
					try {
						flagFeeId = mcd.VerifyOnscreenMessage("MasterFee.Header", Msg[5], true);
						if (flagFeeId) {
							actions.clear("MasterFee.FeeId");
							// Entering unique Fee ID
							rand_num = new Random();
							strNewFeeiD = rand_num.nextInt((99) + 5);
							System.out.println(strNewFeeiD);
							actions.setValue("MasterFee.FeeId", Integer.toString(strNewFeeiD));
							actions.keyboardEnter("ApplyChangesDetails.Save");
							actions.smartWait(180);
						}
					} catch (Exception ee) {
						actions.WaitForElementPresent("ManageFee.SSMsg", 180);
						flag = mcd.VerifyOnscreenMessage("ManageFee.SSMsg", Msg[4], true);
						flagFeeId = false;
					}
				} while (flagFeeId);
			}

			// Selecting data from eatintaxcode and eatinTaxRULE ddl
			actions.WaitForElementPresent("ManageFee.eatinTaxCode");
			actions.setValue("ManageFee.eatinTaxCode", "Optional");
			actions.smartWait(180);
			actions.WaitForElementPresent("DepositSet.EatinTaxRule");
			actions.setValue("DepositSet.EatinTaxRule", "GST");
			actions.smartWait(180);
			actions.WaitForElementPresent("DepositSet.EatinTaxEntry");
			actions.setValue("DepositSet.EatinTaxEntry", "Select");
			actions.smartWait(180);
			actions.keyboardEnter("ManageFee.Applybtn");
			
			// Verify alert message
			boolean msg = mcd.VerifyAlertMessageDisplayed("Warning", Msg[1], true, AlertPopupButton.OK_BUTTON);
			if (msg) {
				actions.reportCreatePASS("Verify 'Please select Eatin Tax Entry' Alert",
						"'Please select Eatin Tax Entry' Alert sholud be displayed.",
						"'Please select Eatin Tax Entry' Alert is displayed.", "Pass");

			} else {
				actions.reportCreateFAIL("Verify 'Please select Eatin Tax Entry' Alert",
						"'Please select Eatin Tax Entry' Alert sholud be displayed.",
						"'Please select Eatin Tax Entry' Alert is not displayed.", "Fail");
			}

			// Selecting data from eatinTaxCode and eatinTaxCode ddl
			actions.WaitForElementPresent("ManageFee.eatinTaxCode");
			actions.setValue("ManageFee.eatinTaxCode", "Optional");
			actions.smartWait(180);
			actions.WaitForElementPresent("DepositSet.EatinTaxRule");
			actions.setValue("DepositSet.EatinTaxRule", "Select");
			actions.smartWait(180);
			actions.WaitForElementPresent("DepositSet.EatinTaxEntry");
			Select select1 = new Select(actions.getWebElement("DepositSet.EatinTaxEntry"));
			select1.selectByIndex(1);
			
			// Verify alert message
			boolean warn6 = mcd.VerifyAlertMessageDisplayed("Warning", Msg[6], true, AlertPopupButton.OK_BUTTON);
			if (warn6) {
				actions.reportCreatePASS("Verify 'Please select Tax Rule' Alert",
						"'Please select Tax Rule' Alert sholud be displayed.",
						"'Please select Tax Rule' Alert is displayed.", "Pass");

			} else {
				actions.reportCreateFAIL("Verify 'Please select Tax Rule' Alert",
						"'Please select Tax Rule' Alert sholud be displayed.",
						"'Please select Tax Rule' Alert is not displayed.", "Fail");
			}

			
			// Selecting data from EatinTaxRule and eatinTaxCode ddl
			actions.WaitForElementPresent("ManageFee.eatinTaxCode");
			actions.setValue("ManageFee.eatinTaxCode", "Select");
			
			actions.smartWait(180);
			actions.WaitForElementPresent("DepositSet.EatinTaxRule");
			actions.setValue("DepositSet.EatinTaxRule", "VAT");
			
			// Verify alert message
			boolean warn7 = mcd.VerifyAlertMessageDisplayed("Warning", Msg[7], true, AlertPopupButton.OK_BUTTON);

			if (warn7) {
				actions.reportCreatePASS("Verify 'Please select Tax Code' Alert",
						"'Please select Tax Code' Alert sholud be displayed.",
						"'Please select Tax Code' Alert is displayed.", "Pass");

			} else {
				actions.reportCreateFAIL("Verify 'Please select Tax Code' Alert",
						"'Please select Tax Code' Alert sholud be displayed.",
						"'Please select Tax Code' Alert is not displayed.", "Fail");
			}
			
			
			//Selecting Tax chain from drop down
			actions.WaitForElementPresent("ManageFee.eatinTaxCode");
			actions.setValue("ManageFee.eatinTaxCode", "Optional");
			actions.smartWait(180);
			actions.WaitForElementPresent("DepositSet.EatinTaxRule");
			actions.setValue("DepositSet.EatinTaxRule", "TAX_CHAIN");
			actions.smartWait(180);
			actions.WaitForElementPresent("ManageFee.TaxChain");
			
			 Select obj= new Select(driver.findElement(By.xpath(actions.getLocator("ManageFee.TaxChain"))));
			 obj.selectByIndex(2);  
			String ddlele1=obj.getFirstSelectedOption().getText();
			 actions.smartWait(100);
	    	   
			//Verifying pop up message
			actions.keyboardEnter("RFM.CancelBtn");
			boolean warmsg = mcd.VerifyAlertMessageDisplayed("Warning", message, true, AlertPopupButton.OK_BUTTON);

			if (warmsg) {
				actions.reportCreatePASS("Verify  Alert message",
						"'Unsaved data will be lost. Are you sure you want to proceed?' Alert sholud be displayed.",
						"'Unsaved data will be lost. Are you sure you want to proceed?' Alert is displayed.", "Pass");

			} else {
				actions.reportCreateFAIL("Verify 'Please select Tax Code' Alert",
						"'Unsaved data will be lost. Are you sure you want to proceed?' Alert sholud be displayed.",
						"'Unsaved data will be lost. Are you sure you want to proceed?' Alert is not displayed.", "Fail");
			}
			
			mcd.SwitchToWindow("@Fee");
								
			//Pricing>taxes>tax type
			System.out.println("> Navigate to :: " + taxtype);
			actions.select_menu("RFMHome.Navigation", taxtype);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			
			//Searching for seleced node
			actions.setValue("ProductionRouting.SearchTextField", ddlele1);
			actions.keyboardEnter("SetAssignmentReport.SearchButton");
			mcd.smartsync(180);
			actions.verifyTextPresence("Search returned no matching results.", true);
			actions.smartWait(100);
			
			//Pricing>taxes>tax chain
			System.out.println("> Navigate to :: " + texchanin);
			actions.select_menu("RFMHome.Navigation", texchanin);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			
			//Searching for seleced node
			actions.setValue("ProductionRouting.SearchTextField", ddlele1);
			actions.keyboardEnter("SetAssignmentReport.SearchButton");
			mcd.smartsync(180);
			
			
			
			

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}

	// VERIFYING TABLE COLUMS CODE
	public void verifyTablecolumnsPresent(String tableLocator, String colName) {

		boolean iscolPresent = mcd.RFM_VerifyTableColumns(tableLocator, colName);

		if (iscolPresent) {
			actions.reportCreatePASS("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is present in table", "Pass");
		} else {
			actions.reportCreateFAIL("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is NOT present in table",
					"Fail");
		}
	}

	// Function for Reporting Pass/Fail
	public void reporting_Pass_Fail(String Desc, String ExpRes, String ActRes_Pass, String ActRes_Fail,
			Boolean status) {
		if (status) {
			actions.reportCreatePASS(Desc, ExpRes, ActRes_Pass, "PASS");
		}

		if (!status) {
			actions.reportCreateFAIL(Desc, ExpRes, ActRes_Fail, "FAIL");
		}
	}

}