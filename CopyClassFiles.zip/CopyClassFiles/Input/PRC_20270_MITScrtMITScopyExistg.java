/**
 * 
 */
package xtam.test;

/**
 * @author akrani
 *
 */
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class PRC_20270_MITScrtMITScopyExistg {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private String strNewMenuIteamTaxSetName, Err, ErrSplit[];
	private String restNum, strExpectlevel[], strExpectLevelDetails[];
	private String StrWm, ExceptWm[];
	boolean flag = false;
	private String strDBName, strUserID, strOperation, strActivity, strLevel, strleveldetails;

	public PRC_20270_MITScrtMITScopyExistg(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters
		Err = mcd.GetTestData("DT_ERROR");

		strDBName = mcd.GetTestData("DT_DB_NAME");
		strUserID = mcd.GetTestData("DT_USER_NAME");
		strOperation = mcd.GetTestData("DT_OPERATION");
		strActivity = mcd.GetTestData("DT_ACTIVITY");
		strLevel = mcd.GetTestData("DT_LEVEL");
		restNum = mcd.GetTestData("DT_RestNum");
		strleveldetails = mcd.GetTestData("DT_LevelDetails");
		StrWm = mcd.GetTestData("DT_WarningMessage");

		strExpectlevel = strLevel.split("#");
		strExpectLevelDetails = strleveldetails.split("#");
		ExceptWm = StrWm.split("#");
		ErrSplit = Err.split("#");
	}

	@Test
	public void test_PRC_20270_MITScrtMITScopyExistg() throws InterruptedException {
		String strPageTitle = ""; //
		String strPageSubHeading = "Menu Item Tax Set"; // TODO: Page Heading

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription(
					"Create new menu item tax set by Copying Settings From Existing Menu Item Tax Set");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			/** Verify Page Header */
			System.out.println("> Verify Page Heading");
			mcd.VerifyPageHeading(strPageSubHeading, "SubHeading");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();
			// ------------------------------------------------------------------------
			// Click on New Menu Item Tax Set Button and Enter unique name and Select node
			actions.keyboardEnter("MenuItemTaxSet.NewMenuItemTaxSetButton");
			mcd.SwitchToWindow("Add New Menu Item Tax Set");
			strNewMenuIteamTaxSetName = mcd.fn_GetRndName("AMITS");
			actions.clear("NewTaxType.TaxTypeNameField");
			actions.setValue("NewTaxType.TaxTypeNameField", strNewMenuIteamTaxSetName);
			System.out.println("strNewMenuIteamTaxSetName" + strNewMenuIteamTaxSetName);
			actions.keyboardEnter("Deposit.DSSelectNode");
			mcd.waitAndSwitch("Select Node");
			mcd.Selectrestnode_JavaScriptClk("RFMSelectNode.SelectNodeTable", restNum);
			
			

			// Click Yes Radio Button and verify next Button
			mcd.SwitchToWindow("Add New Menu Item Tax Set");
			actions.javaScriptClick("FeeSet.CopyExistingYes");
			actions.click("AddNewTenderSet.NextButton");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExceptWm[0], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExceptWm[0] + " 'is Present or not",
						ExceptWm[0] + " should be present", ExceptWm[0] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExceptWm[0] + " 'is Present or not",
						ExceptWm[0] + " should be present", ExceptWm[0] + " is not present", "Fail");
			}
			
			

			// verify the Search Button
			actions.keyboardEnter("AddNewTenderSet.SelectCopyExistingButton");
			mcd.SwitchToWindow(" Select Menu Item Tax Set to Copy");
			actions.click("TaxType.SearchButton");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExceptWm[1], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExceptWm[1] + " 'is Present or not",
						ExceptWm[1] + " should be present", ExceptWm[1] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExceptWm[1] + " 'is Present or not",
						ExceptWm[1] + " should be present", ExceptWm[1] + " is not present", "Fail");
			}
			
			

			// Select the Existing Menu Item Tax Set
			actions.keyboardEnter("TaxType.ViewFullListButton");
			actions.smartWait(100);
			WebElement ElementMenuIteam = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1, "Name", "a");
			actions.click(ElementMenuIteam);
			mcd.SwitchToWindow("Add New Menu Item Tax Set");
			actions.keyboardEnter("AddNewTenderSet.NextButton");
			mcd.SwitchToWindow("@Manage Menu Item Tax Set");
			
			

			// Verify the On - Screen Message
			actions.WaitForElementPresent("RestaurantProfile.DeletedActionMessage", 180);
			flag = mcd.VerifyOnscreenMessage("RestaurantProfile.DeletedActionMessage", ErrSplit[0], true);

			if (flag) {
				actions.reportCreatePASS(
						"Verify Your changes have been saved successfully. Please verify the tax entry data as not all Menu Item Tax Settings may have been replaced / copied from the existing Menu Item Tax Set. is displaying",
						"Your changes have been saved successfully. Please verify the tax entry data as not all Menu Item Tax Settings may have been replaced / copied from the existing Menu Item Tax Set. should display",
						"Your changes have been saved successfully. Please verify the tax entry data as not all Menu Item Tax Settings may have been replaced / copied from the existing Menu Item Tax Set. is displaying",
						"Pass");
			} else {
				actions.reportCreateFAIL(
						"Verify Your changes have been saved successfully. Please verify the tax entry data as not all Menu Item Tax Settings may have been replaced / copied from the existing Menu Item Tax Set. is displaying",
						"Your changes have been saved successfully. Please verify the tax entry data as not all Menu Item Tax Settings may have been replaced / copied from the existing Menu Item Tax Set. should display",
						"Your changes have been saved successfully. Please verify the tax entry data as not all Menu Item Tax Settings may have been replaced / copied from the existing Menu Item Tax Set. is not displaying",
						"Fail");
			}
			actions.keyboardEnter("NewScript.CancleButton");
			mcd.SwitchToWindow("#Title");
			
			

			// Verify The Audit log Details
			boolean AuditlogCorrectValuesDisplayed = rfm.VerifyAuditLog_Entry(strOperation, strActivity,
					strExpectlevel[0]);

			if (AuditlogCorrectValuesDisplayed) {
				actions.reportCreatePASS("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation," + "ActivityValue,Level",
						"Correct values are displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation," + "ActivityValue,Level",
						"Correct values are not displayed", "Fail");
			}
			

			String AuditDesc = "Menu Item Tax Set " + strNewMenuIteamTaxSetName + " has been created" + " " + "at Node"
					+ " " + strExpectLevelDetails[1] + ".";
			

			boolean isAuditlogCorrectValuesDisplayed = rfm.RFM_VerifyAuditLog_Details(strDBName, strUserID,
					strOperation, strActivity, strExpectlevel[1], strExpectLevelDetails[0], AuditDesc);

			if (isAuditlogCorrectValuesDisplayed) {
				actions.reportCreatePASS("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "Activities,Level & description ",
						"Correct values are displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "Activities,Level & description ",
						"Correct values are not displayed", "Fail");
			}

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			// actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}