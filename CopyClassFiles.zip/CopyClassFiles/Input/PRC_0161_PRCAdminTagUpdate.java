package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;

public class PRC_0161_PRCAdminTagUpdate {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;
	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters

	private String strTagValue;
	private String strTagName1;
	private String strTagName2;
	private String strPriceSetType;
	private String strNewPrice;
	private String strsetPrice;
	private String strPrcNavigateTo;
	private String strPopUpMsg1;
	private String strPopUpMsg2;

	public PRC_0161_PRCAdminTagUpdate(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters

		strTagValue = mcd.GetTestData("TagValue");
		strTagName1 = mcd.GetTestData("TagName1");
		strTagName2 = mcd.GetTestData("TagName2");
		strPriceSetType = mcd.GetTestData("PriceSetType");
		strNewPrice = mcd.GetTestData("NewPrice");
		strsetPrice = mcd.GetTestData("setPrice");
		strPrcNavigateTo = mcd.GetTestData("PrcNavigateTo");
		strPopUpMsg1 = mcd.GetTestData("PopUpMsg1");
		strPopUpMsg2 = mcd.GetTestData("PopUpMsg2");
	}

	@Test
	public void PRC_0161_PRCAdminTagUpdate() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription(
					"Verify the Impact at Price Set when value of <automatically-fill-price-type-attribute-option-price-value> tag and <automatically-fill-price-type-attribute-option-tax-value> is set to 3");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------

			// Pre-Requisites : Update fields in Admin > Update Settings
			PriceActions.RFM_Admin_Update_PricingTags(strTagValue, strTagName1, strTagName2);

			// Navigate to Pricing > Price sets
			System.out.println("> Navigate to :: " + strPrcNavigateTo);
			actions.select_menu("RFMHome.Pricing", strPrcNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			// Verify the effect of Admin changes on Pricing > Price sets
			PriceActions.RFM_PRC_PS_VerifyTaxSettingAttribute(strPriceSetType, strNewPrice, strNavigateTo, strsetPrice,
					strTagValue, strPrcNavigateTo, strPopUpMsg1, strPopUpMsg2, strTagName1, strTagName2);

			// Validation is Completed in PRC_0160

			// Click on Price Set
			String strPriceSet = driver.findElement(By.xpath(actions.getLocator("PriceSets.Pricetable"))).getText();
			actions.clear("RFMPriceSets.MainSearchbox");
			actions.keyboardEnter("RFMPriceSets.MainSearch");
			actions.smartWait(20);
			actions.setValue("RFMPriceSets.MainSearchbox", strPriceSet);
			actions.keyboardEnter("RFMPriceSets.MainSearch");
			actions.smartWait(20);
			actions.click("PriceSets.Pricetable");
			actions.smartWait(20);

			// Click on 'Future Changes by Menu Item' tab
			actions.click("PriceSets.SBFutureChngMITab");
			actions.smartWait(20);
			Thread.sleep(2000);
			if (actions.isElementPresent("PriceSets.Pulse")) {
				actions.click("PriceSets.Pulse");

			}

			// Update value of price type Eat in ,Verify Updated value should be
			// Reflected.
			actions.clear("PriceSets.futureEatinPrice");
			Thread.sleep(2000);
			actions.clear("PriceSets.futureOtherPrice");
			Thread.sleep(2000);
			int num = mcd.fn_GetRndNumInRange(10, 99);
			actions.setValue("PriceSets.futureEatinPrice", num);
			Thread.sleep(2000);
			actions.setValue("PriceSets.futureEatinTax", "Default");
			Thread.sleep(2000);
			actions.setValue("PriceSets.futureTakeoutTax", "Never");
			Thread.sleep(2000);

			String strEatinPrice = driver.findElement(By.xpath(actions.getLocator("PriceSets.futureEatinPrice")))
					.getAttribute("value");
			String strOtherPrice = driver.findElement(By.xpath(actions.getLocator("PriceSets.futureOtherPrice")))
					.getAttribute("value");
			if (strEatinPrice.equals(strOtherPrice)) {

				actions.reportCreatePASS("Verify Eatin in & 'other' price",
						"  Eating Price should be copied to other price only, not take out",
						" Eating Price copied to other fields, not take out price", "PASS");

			} else {

				actions.reportCreateFAIL("Verify Eatin in & 'other' price setting",
						"Eating Price should be copied to other price only, not take out",
						" Eating Price copied to other fields and take out price", "FAIL");
			}

			String strTaxcodeEatin = driver.findElement(By.xpath(actions.getLocator("PriceSets.futureEatinTax")))
					.getText();
			String strTaxcodeOthers = driver.findElement(By.xpath(actions.getLocator("PriceSets.futureOtherTax")))
					.getText();
			if (strTaxcodeEatin.equals(strTaxcodeOthers)) {
				actions.reportCreatePASS("Verify Tax Code", "Tax Code should be displayed as expected",
						"Tax Code is displayed as expected", "PASS");

			} else {
				actions.reportCreateFAIL("Verify Tax Code", "Tax Code should be displayed as expected",
						"Tax Code is not displayed as expected", "FAIL");
			}

			// Click on Apply Button & Verify Test Message
			actions.keyboardEnter("PriceSets.Applybtn");
			actions.smartWait(20);
			actions.verifyTextPresence("Your changes have been saved.", true);

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			// Reporter.log("Test Failed :: " + e.getCause() + " - " +
			// e.getMessage());
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

}