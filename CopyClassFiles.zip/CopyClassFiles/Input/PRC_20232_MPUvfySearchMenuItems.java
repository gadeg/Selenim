/**
 * 
 */
package xtam.test;

/**
 * @author akrani
 *
 */
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class PRC_20232_MPUvfySearchMenuItems {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private String strPopup, Err, ErrSplit[], strPopupSplit[], strMPUheading, strTablefirstValue;

	public PRC_20232_MPUvfySearchMenuItems(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters
		strPopup = mcd.GetTestData("DT_POPUP");
		Err = mcd.GetTestData("DT_ERROR");
	}

	@Test
	public void test_PRC_20232_MPUvfySearchMenuItems() throws InterruptedException {
		String strTestDescription = "Verify the search functionality for Menu Items"; // TODO:
																						// Test
																						// Case
																						// Description

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Verify Page Header */
			// System.out.println("> Verify Page Heading");
			// mcd.VerifyPageTitle(strPageTitle);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			/** Get application time */
			actions.setTestcaseDescription(strTestDescription);

			// ------------------------------------------------------------------------
			// Actions specific to test-flow
			strPopupSplit = strPopup.split("#");
			ErrSplit = Err.split("#");

			// Verifying Multiple Menu Items in Multiple Price Sets : Menu Items
			// is displaying
			strMPUheading = driver.findElement(By.xpath(actions.getLocator("DrinkVolume.subHeading"))).getText();

			if (strMPUheading.equals(ErrSplit[0])) {
				actions.reportCreatePASS(
						"Verify Update Multiple Menu Items in Multiple Price Sets : Menu Items is displaying",
						"Update Multiple Menu Items in Multiple Price Sets : Menu Items should display",
						"Update Multiple Menu Items in Multiple Price Sets : Menu Items is displaying", "Pass");
			} else {
				actions.reportCreateFAIL(
						"Verify Update Multiple Menu Items in Multiple Price Sets : Menu Items is displaying",
						"Update Multiple Menu Items in Multiple Price Sets : Menu Items should display",
						"Update Multiple Menu Items in Multiple Price Sets : Menu Items is not displaying", "Fail");
			}

			// Validating Pop up error message: �Please enter a search
			// criteria.� is displayed with �Ok� button
			actions.keyboardEnter("CopySettingsFromExistingTaxType.SearchButton");
			mcd.VerifyAlertMessageDisplayed("Warning Message", strPopupSplit[0], true, AlertPopupButton.OK_BUTTON);

			// Validating Pop up error message: �Please enter a search
			// criteria.� is displayed with �Ok� button when entering spaces in
			// search text and Click on Search button
			actions.setValue("RFMMassUpdatePrice.SearchMenuItem", "");
			actions.keyboardEnter("CopySettingsFromExistingTaxType.SearchButton");
			mcd.VerifyAlertMessageDisplayed("Warning Message", strPopupSplit[0], true, AlertPopupButton.OK_BUTTON);

			// Validating Entered data is displayed in text box Keep �Begins
			// With� radio button selected and enter search criteria
			actions.click("RestaurantMenuItemList.BeginwithRadiobtn");
			actions.clear("RFMMassUpdatePrice.SearchMenuItem");
			actions.setValue("RFMMassUpdatePrice.SearchMenuItem", "a");
			actions.keyboardEnter("CopySettingsFromExistingTaxType.SearchButton");
			actions.smartWait(100);
			strTablefirstValue = mcd.GetTableCellValue("SelectNode.Tree", 1, "|  Name", "", "");
			strTablefirstValue = strTablefirstValue.toLowerCase();

			if (strTablefirstValue.contains("a")) {
				actions.reportCreatePASS("Verify Entered data is displayed in textbox ",
						"Entered data should displayed in textbox", "Entered data is displayed in textbox", "Pass");
			} else {
				actions.reportCreateFAIL("Verify Entered data is displayed in textbox ",
						"Entered data should displayed in textbox", "Entered data is not displayed in textbox", "Fail");
			}

			// Checking for more than 150 characters in search field
			String strVal3;
			strVal3 = generateString('c', 151);
			System.out.println(strVal3.length());
			actions.clear("RFMMassUpdatePrice.SearchMenuItem");
			actions.setValue("RFMMassUpdatePrice.SearchMenuItem", strVal3);
			actions.smartWait(50);
			String strQuestionfield = driver
					.findElement(By.xpath(actions.getLocator("RFMMassUpdatePrice.SearchMenuItem")))
					.getAttribute("value");
			System.out.println(strQuestionfield.length());
			if (strQuestionfield.length() >= 150) {
				actions.reportCreatePASS("verify the whether search box accepts more than 150 Characters",
						"search box should be accepecting more than 150 Characters",
						"Question search box should not be accept more than 150 Characters", "PASS");
			} else {
				actions.reportCreateFAIL("verify the whether Search box accepts 150 characters",
						"search box should be accepecting more than 150 Characters ",
						"Question search box should be accepecting more than 250 Characters", "FAIL");
			}

			// Verify Select Post search �Family Group� value
			actions.setValue("MultipleMenuIteam.FamilyGroupDropDown", "FRIES");
			actions.smartWait(100);

			driver.findElement(By.xpath(actions.getLocator("RecipeReport.EndsWithRadioBtn"))).click();
			actions.clear("RFMMassUpdatePrice.SearchMenuItem");
			actions.setValue("RFMMassUpdatePrice.SearchMenuItem", "a+b");
			actions.keyboardEnter("CopySettingsFromExistingTaxType.SearchButton");
			actions.smartWait(100);
			strTablefirstValue = mcd.GetTableCellValue("SelectNode.Tree", 1, "|  Name", "", "");
			strTablefirstValue = strTablefirstValue.toLowerCase();

			if (strTablefirstValue.contains("a") || strTablefirstValue.contains("+")
					|| strTablefirstValue.contains("b")) {
				actions.reportCreatePASS("Verify Entered data is displayed in textbox ",
						"Entered data should displayed in textbox",
						"Entered data is displayed in textbox" + strTablefirstValue, "Pass");
			} else {
				actions.reportCreateFAIL("Verify Entered data is displayed in textbox ",
						"Entered data should displayed in textbox",
						"Entered data is not displayed in textbox" + strTablefirstValue, "Fail");
			}

			// Verifying Click on radio button corresponding to Exact Match
			actions.click("RecipeReport.ExactMatchBtn");
			actions.clear("RFMMassUpdatePrice.SearchMenuItem");
			actions.setValue("RFMMassUpdatePrice.SearchMenuItem", strTablefirstValue);
			actions.keyboardEnter("CopySettingsFromExistingTaxType.SearchButton");
			actions.smartWait(160);
			strTablefirstValue = mcd.GetTableCellValue("SelectNode.Tree", 1, "|  Name", "", "");

			if (!strTablefirstValue.equals("")) {
				actions.reportCreatePASS("Verify Entered data is displayed in textbox ",
						"Entered data should displayed in textbox",
						"Entered data is displayed in textbox" + strTablefirstValue, "Pass");
			} else {
				actions.reportCreateFAIL("Verify Entered data is displayed in textbox ",
						"Entered data should displayed in textbox",
						"Entered data is not displayed in textbox" + strTablefirstValue, "Fail");
			}

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
	// To generate the string of specific size

	public static String generateString(char c, Integer n) {
		StringBuilder b = new StringBuilder();
		for (Integer x = 0; x < n; x++)
			b.append(c);
		return b.toString();
	}

}