package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class PRC_20172_VrfySrchFeeFnct {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;

	// TODO: Declare test-data variables for other data-parameters
	private String strWM1;
	private String testdata;
	private String Value;
	private String ValueString, strApplicationDate;

	public PRC_20172_VrfySrchFeeFnct(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");

		// TODO: GetTestData for other data-parameters
		strWM1 = mcd.GetTestData("DT_WARN");
		testdata = mcd.GetTestData("NotExisted");
	}

	@Test
	public void PRC_20172_VrfySrchFeeFnct() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			/** Get Test case Description */
			actions.setTestcaseDescription("Verify the Search Fee Functionality");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			actions.smartWait(20);
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------

			String[] WarnMsg = strWM1.split("#");
			// Click on search button, Enter Invalid Fee Name& Verify OnScreen
			// Message
			actions.keyboardEnter("PriceSet.SearchBtn");
			actions.smartWait(20);
			actions.setValue("MasterFee.SearchBox", testdata);
			actions.click("PriceSet.SearchBtn");
			actions.verifyTextPresence(WarnMsg[2], true);

			// Enter Fee Name ,Click On Search Button& Verify result Grid
			actions.clear("MasterFee.SearchBox");
			actions.WaitForElementPresent("ScreenSet.Table");
			actions.click("PriceSet.SearchBtn");
			WebElement element = mcd.GetTableCellElement("ScreenSet.Table", 1, "Fee Name", " ");
			Value = element.getText();
			ValueString = Value.substring(0, 4);
			actions.WaitForElementPresent("MasterFee.SearchBox");
			actions.setValue("MasterFee.SearchBox", Value);
			actions.click("PriceSet.SearchBtn");
			actions.smartWait(30);
			String ele = driver.findElement(By.xpath(actions.getLocator("DepositSet.FirstData"))).getText();
			if (ele.equalsIgnoreCase(Value)) {
				actions.reportCreatePASS("Verify Fee Name is Displayed", "Fee Name should be Displayed",
						"Fee Name is Displayed as Expected", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Fee Name is Displayed", "Fee Name should be Displayed",
						"Fee Name is not Displayed as Expected", "FAIL");
			}
			// Enter SubString Fee Name ,Click On Search Button& Verify result
			// Grid
			actions.clear("MasterFee.SearchBox");
			actions.setValue("MasterFee.SearchBox", ValueString);
			actions.click("PriceSet.SearchBtn");
			actions.smartWait(30);
			String ele1 = driver.findElement(By.xpath(actions.getLocator("DepositSet.FirstData"))).getText();
			if (ele1.contains(ValueString)) {
				actions.reportCreatePASS("Verify Fee Name is Displayed", "Fee Names should be Displayed",
						"Fee Names is Displayed as Expected", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Fee Name is Displayed", "Fee Names should be Displayed",
						"Fee Names is not Displayed as Expected", "FAIL");
			}

			// SetValue to Active from the DropDown,Enter SubString Fee Name
			// ,Click On Search Button& Verify result Grid
			actions.setValue("ProductionRouting.SearchWithinStatus", "Active");
			actions.clear("MasterFee.SearchBox");
			actions.smartWait(60);
			actions.setValue("MasterFee.SearchBox", ValueString);
			actions.click("PriceSet.SearchBtn");
			actions.smartWait(60);
			if (!actions.isElementEnabled("RestaurantSet.FilterByStatus")) {
				actions.reportCreatePASS("Verify Status Fliter", "Status Filter should be disabled",
						"Status Filter is disabled", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Status Fliter", "Status Filter should be disabled",
						"Status Filter is not disabled", "FAIL");
			}
			int rowCount=mcd.GetTableRowCount("RefreshSettings.Table");
			if(rowCount<=1)
			{
				actions.reportCreatePASS("Master Fee table having insufficent data", "Master Fee table Should be insufficent data", "Master Fee table is insufficent data", "PASS");
			}
			else
			{
			// Verify Sorting Order for Fee ID
			List<WebElement> eleRws = driver
					.findElements(By.xpath(actions.getLocator("MassStatusUpdate.ComponentMINumber")));
			int iNewMIRwCnt = eleRws.size();
			Boolean flag1 = false;
			for (int i = 1; i <= iNewMIRwCnt - 1; i++) {
				int MI_Num1 = Integer
						.parseInt(driver.findElement(By.xpath("//*[@id='Sess1']/tbody/tr[" + i + "]/td[1]")).getText());
				int j = i + 1;
				int MI_Num2 = Integer
						.parseInt(driver.findElement(By.xpath("//*[@id='Sess1']/tbody/tr[" + j + "]/td[1]")).getText());
				if (MI_Num1 <= MI_Num2) {
					flag1 = true;

				} else {
					flag1 = false;
					break;

				}

			}
			if (flag1) {
				actions.reportCreatePASS("Verify Sorting according to Fee ID", "List should be sorted correctly",
						"List is sorted correctly", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Sorting according to Fee ID", "List should be sorted correctly",
						"List is not sorted correctly", "FAIL");
			}
		}
			// SetValue to Inactive from the dropdown,Enter SubString Fee Name
			// ,Click On Search Button& Verify result Grid
			actions.WaitForElementPresent("ProductionRouting.SearchWithinStatus");
			actions.setValue("ProductionRouting.SearchWithinStatus", "Inactive");
			actions.WaitForElementPresent("MasterFee.SearchBox");
			actions.clear("MasterFee.SearchBox");
			actions.setValue("MasterFee.SearchBox", ValueString);
			actions.click("PriceSet.SearchBtn");
			actions.smartWait(60);
			if (!actions.isElementEnabled("RestaurantSet.FilterByStatus")) {
				actions.reportCreatePASS("Verify Status Fliter", "Status Filter should be disabled",
						"Status Filter is disabled", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Status Fliter", "Status Filter should be disabled",
						"Status Filter is not disabled", "FAIL");
			}
			int rowCount1=mcd.GetTableRowCount("RefreshSettings.Table");
			if(rowCount1<=1)
			{
				actions.reportCreatePASS("Master Fee table having insufficent data", "Master Fee table Should be insufficent data", "Master Fee table is insufficent data", "PASS");
			}
			else{
			List<WebElement> eleRws1 = driver
					.findElements(By.xpath(actions.getLocator("MassStatusUpdate.ComponentMINumber")));
			int iNewMIRwCnt1 = eleRws1.size();
			Boolean flag2 = false;
			for (int i = 1; i <= iNewMIRwCnt1 - 1; i++) {
				int MI_Num1 = Integer
						.parseInt(driver.findElement(By.xpath("//*[@id='Sess1']/tbody/tr[" + i + "]/td[1]")).getText());
				int j = i + 1;
				int MI_Num2 = Integer
						.parseInt(driver.findElement(By.xpath("//*[@id='Sess1']/tbody/tr[" + j + "]/td[1]")).getText());
				if (MI_Num1 <= MI_Num2) {
					flag2 = true;

				} else {
					flag2 = false;
					break;

				}

			}
			if (flag2) {
				actions.reportCreatePASS("Verify Sorting according to Fee ID", "List should be sorted correctly",
						"List is sorted correctly", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Sorting according to Fee ID", "List should be sorted correctly",
						"List is not sorted correctly", "FAIL");
			}
		}
			// SetValue to Suspended from the dropdown,Enter SubString Fee Name
			// ,Click On Search Button& Verify result Grid
			actions.WaitForElementPresent("ProductionRouting.SearchWithinStatus");
			actions.setValue("ProductionRouting.SearchWithinStatus", "Suspended");
			actions.WaitForElementPresent("MasterFee.SearchBox");
			actions.clear("MasterFee.SearchBox");
			actions.setValue("MasterFee.SearchBox", ValueString);
			actions.click("PriceSet.SearchBtn");
			actions.smartWait(60);
			int rowCount2=mcd.GetTableRowCount("RefreshSettings.Table");
			if(rowCount2<=1)
			{
				actions.reportCreatePASS("Master Fee table having insufficent data", "Master Fee table Should be insufficent data", "Master Fee table is insufficent data", "PASS");
			}
			else
			{
			List<WebElement> eleRws2 = driver
					.findElements(By.xpath(actions.getLocator("MassStatusUpdate.ComponentMINumber")));
			int iNewMIRwCnt2 = eleRws2.size();
			Boolean flag3 = false;
			for (int i = 1; i <= iNewMIRwCnt2 - 1; i++) {
				int MI_Num1 = Integer
						.parseInt(driver.findElement(By.xpath("//*[@id='Sess1']/tbody/tr[" + i + "]/td[1]")).getText());
				int j = i + 1;
				int MI_Num2 = Integer
						.parseInt(driver.findElement(By.xpath("//*[@id='Sess1']/tbody/tr[" + j + "]/td[1]")).getText());
				if (MI_Num1 <= MI_Num2) {
					flag3 = true;

				} else {
					flag3 = false;
					break;

				}

			}
			if (flag3) {
				actions.reportCreatePASS("Verify Sorting according to Fee ID", "List should be sorted correctly",
						"List is sorted correctly", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Sorting according to Fee ID", "List should be sorted correctly",
						"List is not sorted correctly", "FAIL");
			}
		}
			// Enter string more than 60 characters in search field
			String strVal2;
			strVal2 = mcd.generateString('c', 61);
			System.out.println(strVal2.length());
			actions.clear("MasterFee.SearchBox");
			actions.setValue("MasterFee.SearchBox", strVal2);
			actions.smartWait(20);
			String charc = driver.findElement(By.xpath(actions.getLocator("MasterFee.SearchBox")))
					.getAttribute("value");
			System.out.println(charc.length());
			if (charc.length() >= 60) {
				actions.reportCreatePASS("verify the whether group name text box accepected 60 Characters",
						"group name text box should be accepected 60 Characters",
						"group name text box should not  be accepected more than 60 Characters", "PASS");
			} else {
				actions.reportCreateFAIL("verify the whether group name text box accepected 60 characters",
						"group name text box should be accepected 50 Characters ",
						"group name text box should be accepected more than 60 Characters", "FAIL");
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

}
