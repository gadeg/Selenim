package xtam.test;

import java.util.Map;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class PRC_20269_MITScrtWithotCopyExis {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;
	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strRestNum;

	// TODO: Declare test-data variables for other data-parameters
	private String strNode, ErroMsg, Status, strNewMenuIteamTaxSetName, strTitle;

	public PRC_20269_MITScrtWithotCopyExis(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strRestNum = mcd.GetTestData("DT_REST_NUM");
	}

	@Test
	public void test_PRC_20269_MITScrtWithotCopyExis() throws InterruptedException {
		try {

			/** Get application time */
			actions.setTestcaseDescription(
					"Create a new menu item tax set without Copying Settings From Existing Menu Item Tax Set/Covering PRC_20274-Verify that an inactive set cannot  have future settings");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			// Select the inactive Menu Item Tax Set form the table
			WebElement ElementTaxSetNm = null;
			actions.keyboardEnter("TaxType.ViewFullListButton");
			actions.smartWait(20);
			actions.setValue("TenderSet.StatusDropDown", "Inactive");
			actions.smartWait(20);

			boolean flag_NewManuItemTaxSet = false;

			int rc = 0;
			rc = mcd.GetTableRowCount("ScriptManagement.TableNameValue");
			if (rc < 1) {
				flag_NewManuItemTaxSet = true;
				// Click on 'New Item Tax set' button
				actions.click("MenuItemTaxSet.NewTaxSetBtn");

				// Switch to new 'Add New Fee Set' window
				mcd.SwitchToWindow("Add New Menu Item Tax Set");
				do {
					// To generate Random name
					Random rand_num = new Random();
					String strRand_Num = Integer.toString(rand_num.nextInt(999));

					// Enter New Tax set Name
					actions.WaitForElementPresent("AddNewMenuItemTaxSet.SetNameTextBox", 25);
					actions.setValue("AddNewMenuItemTaxSet.SetNameTextBox", "SetName_" + strRand_Num + "");

					// Click on 'Select' button
					actions.WaitForElementPresent("AddNewMenuItemTaxSet.SelectNodeBtn", 20);
					actions.click("AddNewMenuItemTaxSet.SelectNodeBtn");
					Thread.sleep(3000);

					// Switch to 'Select Node' window
					mcd.SwitchToWindow("Select Node");
					actions.WaitForElementPresent("SelectNodeRest.SearchTextField");
					actions.setValue("SelectNodeRest.SearchTextField", strRestNum);
					actions.keyboardEnter("SelectNode.SearchButton");
					actions.waitForPageToLoad(120);
					mcd.Selectrestnode("SelectNode.NodeTable", strRestNum);

				} while (actions.isElementPresent("ManagePriceSet.InfoMsg"));

				// Switch to previous window
				mcd.SwitchToWindow("Add New Menu Item Tax Set");
				actions.keyboardEnter("AddNewMenuItemTaxSet.NextBtn");
				mcd.waitAndSwitch("@Menu Item Tax Set : Common Menu Item Selector");
				System.out.println(driver.getTitle());
				actions.click("AddRemoveMenu.ViewFullList");
				actions.smartWait(10);
				actions.click("MenuItemTaxSet.AddMneuItem_Checkbox");
				actions.click("RFMQueueRoutingPopupPage.SaveButton");
				actions.smartWait(10);
				actions.setValue("ManageMenuItemTaxSet.StatusDropDown", "Inactive");
				actions.setValue("MenuItemTaxSet.TaxSetDetailsTaxCodeDDL", "Never");
				actions.keyboardEnter("ManageMenuItemTaxSet.ApplyButton");
				actions.smartWait(10);
				actions.click("NewScript.CancleButton");

			} else {
				ElementTaxSetNm = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1, "Name", "a");
				actions.keyboardEnter(ElementTaxSetNm);
				actions.smartWait(20);
			}

			if (flag_NewManuItemTaxSet) {
				actions.WaitForElementPresent("TaxType.ViewFullListButton");
				actions.keyboardEnter("TaxType.ViewFullListButton");
				actions.smartWait(20);
				actions.setValue("TenderSet.StatusDropDown", "Inactive");
				actions.smartWait(20);
				ElementTaxSetNm = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1, "Name", "a");
				actions.keyboardEnter(ElementTaxSetNm);
				actions.smartWait(20);
			}

			// To handle apply changes window
			try {
				mcd.SwitchToWindow("Apply Changes Details");
				actions.click("ApplyChangesDetails.Save");
			} catch (Exception e2) {
				actions.waitForPageToLoad(120);
			}

			String str_MnuItmTaxSetName = null;
			str_MnuItmTaxSetName = driver.findElement(By.xpath(actions.getLocator("MenuItemTaxSet.MITSName")))
					.getAttribute("value");
			str_MnuItmTaxSetName = str_MnuItmTaxSetName.substring(0, str_MnuItmTaxSetName.length() - 5) + "_New";
			actions.clear("MenuItemTaxSet.MITSName");
			actions.setValue("MenuItemTaxSet.MITSName", str_MnuItmTaxSetName);
			actions.click("Restaurant Profile.Applybtn");
			actions.smartWait(10);
			if (actions.isElementPresent("ManageMenuItemTaxSet.ErrorMsg")) {
				actions.reportCreatePASS("Verify the save changes message on screen",
						"Your changes have been saved message should display",
						"Your changes have been saved message is display", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the save changes message on screen",
						"Your changes have been saved message should display",
						"Your changes have been saved message is not display", "FAIL");
			}

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			actions.waitForPageToLoad(120);

			actions.keyboardEnter("TaxType.ViewFullListButton");
			actions.smartWait(20);
			actions.setValue("TenderSet.StatusDropDown", "Inactive");
			actions.smartWait(20);
			ElementTaxSetNm = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1, "Delete", "a/img");
			actions.click(ElementTaxSetNm);

			boolean VerifyPopUpMsg;
			VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error",
					"Are you sure you want to delete the selected item?", true, AlertPopupButton.CANCEL_BUTTON);
			if (VerifyPopUpMsg) {
				actions.reportCreatePASS("Verify the alert message for cancle button",
						"Alert message should display with cancle button",
						"Alert message is displayed with cancle button", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the alert message", "Alert message should display with cancle button",
						"Failed to display alert message with cancle button", "FAIL");
			}

			ElementTaxSetNm = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1, "Delete", "a/img");
			actions.click(ElementTaxSetNm);
			VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error",
					"Are you sure you want to delete the selected item?", true, AlertPopupButton.OK_BUTTON);
			if (VerifyPopUpMsg) {
				actions.reportCreatePASS("Verify the alert message for OK button",
						"Alert message should display with OK button", "Alert message is displayed with OK button",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify the alert message for OK button",
						"Alert message should display with OK button", "Failed to display alert message with OK button",
						"FAIL");
			}

			String strPageTitle = "Menu Item Tax Set";
			if (rfm.VerifyAuditLog_Entry(strPageTitle, "Delete", "Restaurant [950003, SANS SOUCI NSW]")) {
				actions.reportCreatePASS("Verify the Audit Log", "Audit Log should display correct Values",
						"Audit Log displayed correct values", "Pass");
			} else {
				actions.reportCreateFAIL("Verify the Audit Log", "Audit Log should display correct Values",
						"Audit Log displayed incorrect values", "Fail");
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			// reporting the Fail condition
			actions.catchException(e);
		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}

}