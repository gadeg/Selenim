/**
 * 
 */
package xtam.test;

/**
 * @author akrani
 *
 */
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class PRC_20271_MITSupdFrCurrSetg {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;
	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private String Err, ErrSplit[], strNode, ErroMsg, Status, strNewMenuIteamTaxSetName, strMenuItemTaxSet, strPopup,
			strPopupSplit[], strMenuItemTaxSetUpdated, strTaxedDropDownValue;
	Integer tablecount, i;
	boolean flag = false;
	private String strDBName, strUserID, strOperation, strActivity, strLevel, strNodeName;
	private String strNavigateToST;

	public PRC_20271_MITSupdFrCurrSetg(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);
		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters
		strNode = mcd.GetTestData("DT_NODE");
		ErroMsg = mcd.GetTestData("DT_ERROR_MITS");
		Status = mcd.GetTestData("DT_STATUS");
		strPopup = mcd.GetTestData("DT_POPUP");
		Err = mcd.GetTestData("DT_ERROR");
		strDBName = mcd.GetTestData("DT_DB_NAME");
		strUserID = mcd.GetTestData("DT_USER_ID");
		strOperation = mcd.GetTestData("DT_OPERATION");
		strActivity = mcd.GetTestData("DT_ACTIVITY");
		strLevel = mcd.GetTestData("DT_LEVEL");
		strNodeName = mcd.GetTestData("DT_NODE_NAME");
		strNavigateToST = mcd.GetTestData("DT_NAVIGATE_TO_ST");

	}

	@Test
	public void test_PRC_20271_MITSupdFrCurrSetg() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			/** Get application time */
			actions.setTestcaseDescription("Update menu item tax set for current settings");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateToST);
			actions.select_menu("RFMHome.Navigation", strNavigateToST);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Actions specific to test-flow
			strPopupSplit = strPopup.split("#");
			ErrSplit = Err.split("#");

			rfm.RFM_Admin_Update_PricingTags("false", "Display price type attribute as expanded by default");
			/** Select Menu Option */
			actions.waitForPageToLoad(120);
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			// Creating new MenuIteamTaxSet
			strNewMenuIteamTaxSetName = PriceActions.RFM_PRC_CreateNewMenuIteamTaxSet(strNode, "Hierarchies", "", "",
					"", "", "", Status, ErroMsg);

			actions.keyboardEnter("NewScript.CancleButton");
			// actions.smartWait(10);
			mcd.SwitchToWindow("#Title");

			// strNewMenuIteamTaxSetName="AMITS_744413314ch";
			actions.setValue("TenderSet.SearchTextBox", strNewMenuIteamTaxSetName);
			actions.keyboardEnter("TaxType.SearchButton");
			actions.smartWait(20);
			WebElement ElementTaxSetNm = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1, "Name", "a");
			actions.keyboardEnter(ElementTaxSetNm);

			// switching to "Manage Menu Item Tax Set"
			mcd.SwitchToWindow("#Title");

			// switch to "Apply Changes Details"
			mcd.SwitchToWindow("Apply Changes Details");
			actions.keyboardEnter("ApplyChangesDetails.MDSaveButton");
			Thread.sleep(2000);
			mcd.SwitchToWindow("Manage Menu Item Tax Set");
			strMenuItemTaxSet = driver
					.findElement(By.xpath(actions.getLocator("ManageMenuItemTaxSet.MenuItemTaxSetTexBox")))
					.getAttribute("value");
			strMenuItemTaxSet = strMenuItemTaxSet.concat("ch");
			actions.clear("ManageMenuItemTaxSet.MenuItemTaxSetTexBox");
			actions.setValue("ManageMenuItemTaxSet.MenuItemTaxSetTexBox", strMenuItemTaxSet);
			actions.keyboardEnter("ManageMenuItemTaxSet.ApplyButton");

			// Validating Update of Menu Item Tax Set Name will affect both
			// current and future settings (if present).
			mcd.VerifyAlertMessageDisplayed("Warning Message", strPopupSplit[0], true, AlertPopupButton.OK_BUTTON);
			actions.smartWait(10);
			strMenuItemTaxSetUpdated = driver
					.findElement(By.xpath(actions.getLocator("ManageMenuItemTaxSet.MenuItemTaxSetTexBox")))
					.getAttribute("value");

			//Verify the set name Newly edited set name should be displayed for both current and future settings(if any)
			if (strMenuItemTaxSetUpdated.equals(strMenuItemTaxSet)) {
				actions.reportCreatePASS(
						"Verify Newly edited set name should be displayed for both current and future settings(if any)",
						"Newly edited set name should be displayed for both current and future settings(if any)",
						"Newly edited set name is displayed for both current and future settings(if any)"
								+ strMenuItemTaxSetUpdated,
						"Pass");
			} else {
				actions.reportCreateFAIL(
						"Verify Newly edited set name should be displayed for both current and future settings(if any)",
						"Newly edited set name should be displayed for both current and future settings(if any)",
						"Newly edited set name is displayed for both current and future settings(if any)"
								+ strMenuItemTaxSetUpdated,
						"Fail");
			}

			// Verify the default value for "Taxed" DDL contains "Not Taxed/Taxed value"
			Select select = new Select(
					driver.findElement(By.xpath(actions.getLocator("ManageMenuItemTaxSet.TaxedDropDown"))));
			strTaxedDropDownValue = select.getFirstSelectedOption().getText();
			if (strTaxedDropDownValue.equals("Not Taxed/Taxed")) {
				actions.reportCreatePASS("Verify the default value for 'Taxed' DDL contains 'Not Taxed/Taxed value'",
						"The default value for 'Taxed' DDL should contains 'Not Taxed/Taxed value'",
						"The default value for 'Taxed' DDL is 'Not Taxed/Taxed value'", "Pass");
			} else {
				actions.reportCreateFAIL("Verify the default value for 'Taxed' DDL contains 'Not Taxed/Taxed value'",
						"The default value for 'Taxed' DDL should contains 'Not Taxed/Taxed value'",
						"The default value for 'Taxed' DDL is not 'Not Taxed/Taxed value'", "Fail");
			}
			
			//Verify the functionality of 'Taxed' DDL
			actions.setValue("ManageMenuItemTaxSet.TaxedDropDown", "Taxed");
			actions.smartWait(20);
			actions.keyboardEnter("ManageMenuItemTaxSet.AddRemoveButton");
			mcd.SwitchToWindow("Menu Item Tax Set : Common Menu Item Selector");
			actions.keyboardEnter("TaxType.ViewFullListButton");
			actions.smartWait(30);
			actions.setValue("ManageMenuItemTaxSet.AvailabilityDropdown", "Available");
			actions.smartWait(10);
			WebElement ElementMenuIteam = mcd.GetTableCellElement("AddTenderType.Table", 1, 1, "input[1]");
			actions.click(ElementMenuIteam);
			actions.keyboardEnter("AddTaxType.SaveButton");
			mcd.SwitchToWindow("Manage Menu Item Tax Set");

			
			// Verifying Menu Items have been Added/Removed successfully to/from
			// the Menu Item Tax Set.
			mcd.VerifyOnscreenMessage("ManageTenderType.SaveMessage", ErrSplit[0], true);

			//Select 'Tax code' as Select.
			WebElement ElementMenuIteam1 = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1, "Tax Code",
					"select");
			Select select1 = new Select(ElementMenuIteam1);
			select1.selectByVisibleText("Select");
			WebElement ele_TaxRule = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1, "Tax Rule",
					"select");
			Select ele_TaxRule_1 = new Select(ele_TaxRule);
			ele_TaxRule_1.selectByIndex(1);
			
			//A message: "Please select Tax code"  should pop up with 'Ok' button.
			if (mcd.VerifyAlertMessageDisplayed("Warning Message", "Please select Tax Code.", true,
					AlertPopupButton.OK_BUTTON)) {

				actions.reportCreatePASS("Verify Alert Message",
						"Alert message 'Please select Tax Code.' should display",
						"Alert message 'Please select Tax Code.' is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify Alert Message",
						"Alert message 'Please select Tax Code.' should display",
						"Alert message 'Please select Tax Code.' is not displayed", "Fail");
			}

			//Select 'Tax Rule' as Select.
			WebElement ele_TaxEntry = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1, "Tax Rule",
					"select");
			Select ele_TaxEntry_1 = new Select(ele_TaxEntry);
			select1.selectByVisibleText("Select");
			ele_TaxRule_1.selectByVisibleText("Select");
			ele_TaxEntry_1.selectByIndex(1);
			
			//A message: "Please select Tax Rule"  should pop up with 'Ok' button.
			if (mcd.VerifyAlertMessageDisplayed("Warning Message", "Please select Tax Rule.", true,
					AlertPopupButton.OK_BUTTON)) {

				actions.reportCreatePASS("Verify Alert Message",
						"Alert message 'Please select Tax Rule.' should display",
						"Alert message 'Please select Tax Rule.' is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify Alert Message",
						"Alert message 'Please select Tax Rule.' should display",
						"Alert message 'Please select Tax Rule.' is not displayed", "Fail");
			}

			//Select 'Tax code' as Never.
			select1.selectByVisibleText("Never");
			try {
				driver.findElement(By.xpath(actions.getLocator("ManageMenuItemTaxSet.AllTexRuleDropDown")))
						.getAttribute("disabled");
				driver.findElement(By.xpath(actions.getLocator("ManageMenuItemTaxSet.TaxEntryDropdown")))
						.getAttribute("disabled");
				actions.reportCreatePASS("Verify TexRuleDropDown and TaxEntryDropdown DDL should show 'Select'",
						"TexRuleDropDown and TaxEntryDropdown DDL should show 'Select'",
						"TexRuleDropDown and TaxEntryDropdown DDL is showing 'Select'", "Pass");
			} catch (Exception e) {
				actions.reportCreateFAIL("Verify TexRuleDropDown and TaxEntryDropdown DDL should show 'Select'",
						"TexRuleDropDown and TaxEntryDropdown DDL should show 'Select'",
						"TexRuleDropDown and TaxEntryDropdown DDL is not showing 'Select'", "Fail");
			}												
			actions.keyboardEnter("ManageMenuItemTaxSet.ApplyButton");
			actions.smartWait(20);
			actions.keyboardEnter("NewScript.CancleButton");
			mcd.SwitchToWindow("#Title");

			// mcd.VerifyAlertMessageDisplayed("Warning Message",strPopupSplit[1], true, AlertPopupButton.OK_BUTTON);

			// Verify Audit Log
			boolean AuditEntry = rfm.VerifyAuditLog_Entry(strOperation, strActivity, strLevel);
			System.out.println(AuditEntry);
			String AuditDesc = "Queue Side [" + strMenuItemTaxSetUpdated + "] has been created.";
			boolean AuditDetail = rfm.RFM_VerifyAuditLog_Details(strDBName, strUserID, strOperation, strActivity,
					strLevel, strNodeName, AuditDesc);
			
			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}