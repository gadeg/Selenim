package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import io.netty.util.internal.SystemPropertyUtil;
import crossbrowser.library.lib_RFM2;

public class PRC_0001_VerifyPageDepositSet {

	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private lib_MCD mcd;
	private lib_RFM2 rfm;
	// Varibales and Objects for URL,username and Market
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strApplicationDate, strCountry;

	private SoftAssert softAssert = new SoftAssert();

	public PRC_0001_VerifyPageDepositSet(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();
		// Initialize
		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strCountry = mcd.GetTestData("DT_Country");

	}

	@Test
	public void PRC_0001_VerifyPageDepositSet() throws InterruptedException {

		try {
			System.out.println("**************************************************** Start Test-Steps executions");

			actions.setTestcaseDescription(
					"Verify the fields on Deposit Sets page and also verify functionality of : i)search, ii)pagination and iii)sorting .");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// Enter invalid Deposit set name and Click on 'Search'
			// button,verify msg
			String ele = mcd.generateString('c', 5);
			actions.setValue("DimensionNameSets.Searchtxt", ele);
			actions.click("MassStatusUpdate.SearchBtn");
			actions.smartWait(20);
			actions.verifyTextPresence("Search returned no matching results.", true);

			// Enter valid Deposit set name and Click on 'Search' button
			actions.clear("DimensionNameSets.Searchtxt");
			actions.click("MassStatusUpdate.SearchBtn");
			actions.smartWait(20);
			String element = driver.findElement(By.xpath(actions.getLocator("MasterMenuItemList.tableFirstElement")))
					.getText();
			actions.setValue("DimensionNameSets.Searchtxt", element);
			actions.click("MassStatusUpdate.SearchBtn");
			actions.smartWait(20);
			Thread.sleep(2000);
			String element1 = driver.findElement(By.xpath(actions.getLocator("MasterMenuItemList.tableFirstElement")))
					.getText();
			if (element.equalsIgnoreCase(element1)) {
				actions.reportCreatePASS("Verify Deposit Name is Present", "Deposit Name Should be Present as Expected",
						"Deposit Name is Present as Expected", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Deposit Name is Present", "Deposit Name Should be Present as Expected",
						"Deposit Name is not Present as Expected", "FAIL");
			}

			// Enter valid Deposit set name ,Click on 'Search' button & Select
			// 'Active' from the 'Search within status' DDL
			actions.clear("DimensionNameSets.Searchtxt");
			actions.keyboardEnter("MassStatusUpdate.SearchBtn");
			actions.smartWait(20);
			actions.waitForPageToLoad(80);

			if (actions.isElementEnabled("ScreenSet.StatusFilter")) {
				actions.setValue("ScreenSet.StatusFilter", "Active");
				actions.smartWait(20);
				int row = mcd.GetTableRowCount("RefreshSettings.Table");
				if (row == 0) {
					actions.reportCreatePASS("Deposit Sets  table having insufficent data",
							"Deposit Sets table Should be No Active Deposite Set",
							"Deposit Sets table is No Active Deposite Set", "PASS");
				} else {

					String element8 = driver
							.findElement(By.xpath(actions.getLocator("MasterMenuItemList.tableFirstElement")))
							.getText();
					actions.keyboardEnter("MassStatusUpdate.SearchBtn");
					actions.smartWait(20);
					actions.setValue("DimensionNameSets.Searchtxt", element8);
					actions.setValue("FlavorSet.Status", "Active");
					actions.keyboardEnter("MassStatusUpdate.SearchBtn");
					actions.smartWait(20);
					String element2 = driver
							.findElement(By.xpath(actions.getLocator("MenuItemSet.SelectMenuItemSetNode"))).getText();
					if (element2.equalsIgnoreCase("Active")) {
						actions.reportCreatePASS("Verify Active Deposit is Present",
								"Active Deposit Should be Present as Expected", "Active Deposit is Present as Expected",
								"PASS");
					} else {
						actions.reportCreateFAIL("Verify Active Deposit is Present",
								"Active Deposit Should be Present as Expected",
								"Active Deposit is not Present as Expected", "FAIL");
					}
				}
			} else {
				actions.reportCreateFAIL("Verify application is having Deposi Sets",
						"Application should be having more than one Deposit Sets",
						"Application is not having more than one Deposit Set", "Fail");
			}
			// Select 'Inactive' from the 'Search within status' DDL & Click on
			// 'Search' button
			actions.clear("DimensionNameSets.Searchtxt");
			actions.keyboardEnter("MassStatusUpdate.SearchBtn");
			actions.smartWait(20);
			if (actions.isElementEnabled("ScreenSet.StatusFilter")) {
				actions.setValue("PMIGImageSet.StatusDDL", "Inactive");
				actions.smartWait(20);
				int row1 = mcd.GetTableRowCount("RefreshSettings.Table");
				if (row1 == 0) {
					actions.reportCreatePASS("Deposit Sets  table having insufficent data",
							"Deposit Sets table Should be No Inactive Deposite Set",
							"Deposit Sets table is No Inactive Deposite Set", "PASS");
				} else {
					String element9 = driver
							.findElement(By.xpath(actions.getLocator("MasterMenuItemList.tableFirstElement")))
							.getText();
					actions.setValue("DimensionNameSets.Searchtxt", element9);
					actions.setValue("FlavorSet.Status", "Inactive");
					actions.keyboardEnter("MassStatusUpdate.SearchBtn");
					actions.smartWait(20);
					Thread.sleep(2000);
					String element3 = driver
							.findElement(By.xpath(actions.getLocator("MenuItemSet.SelectMenuItemSetNode"))).getText();
					if (element3.equalsIgnoreCase("Inactive")) {
						actions.reportCreatePASS("Verify Inactive Deposit is Present",
								"Inactive Deposit Should be Present as Expected",
								"Inactive Deposit is Present as Expected", "PASS");
					} else {
						actions.reportCreateFAIL("Verify Inactive Deposit is Present",
								"Inactive Deposit Should be Present as Expected",
								"Inactive Deposit is not Present as Expected", "FAIL");
					}
				}
			} else {
				actions.reportCreateFAIL("Verify application is having Deposi Sets",
						"Application should be having more than one Deposit Sets",
						"Application is not having more than one Deposit Set", "Fail");
			}
			// Select a country/province from 'Country' DDL under 'Filter List'
			// & Click on 'Filter' button
			actions.clear("DimensionNameSets.Searchtxt");
			actions.keyboardEnter("MassStatusUpdate.SearchBtn");
			actions.smartWait(20);
			actions.setValue("PriceSet.Filter1", strCountry);
			actions.keyboardEnter("MenuItempriceByPriceSetReport.FilterBtn");
			actions.smartWait(20);
			int row2 = mcd.GetTableRowCount("RefreshSettings.Table");
			if (row2 == 0) {
				actions.reportCreatePASS("Selected Country have any Deposit Sets", "Deposit Sets Should be Present",
						"No Deposit Sets is Present", "PASS");
			} else {
				String element4 = driver.findElement(By.xpath(actions.getLocator("DepositSet.FirstData"))).getText();
				if (element4.equalsIgnoreCase(strCountry)) {
					actions.reportCreatePASS("Verify Country Deposit is Present",
							"Country Deposit Should be Present as Expected", "Country Deposit is Present as Expected",
							"PASS");
				} else {
					actions.reportCreateFAIL("Verify Country Deposit is Present",
							"Country Deposit Should be Present as Expected",
							"Country Deposit is not Present as Expected", "FAIL");
				}
			}
			// Select 'Active' from the 'Status' DDL
			actions.keyboardEnter("MassStatusUpdate.SearchBtn");
			actions.smartWait(20);
			actions.waitForPageToLoad(20);
			actions.setValue("ScreenSet.StatusFilter", "Active");
			actions.smartWait(20);
			int row3 = mcd.GetTableRowCount("RefreshSettings.Table");
			if (row3 == 0) {
				actions.reportCreatePASS("Deposit Sets  table having insufficent data",
						"Deposit Sets table Should be No Active Deposite Set",
						"Deposit Sets table is No Active Deposite Set", "PASS");
			} else {
				String element5 = driver.findElement(By.xpath(actions.getLocator("MenuItemSet.SelectMenuItemSetNode")))
						.getText();
				if (element5.equalsIgnoreCase("Active")) {
					actions.reportCreatePASS("Verify Active Deposit is Present",
							"Active Deposit Should be Present as Expected", "Active Deposit is Present as Expected",
							"PASS");
				} else {
					actions.reportCreateFAIL("Verify Active Deposit is Present",
							"Active Deposit Should be Present as Expected", "Active Deposit is not Present as Expected",
							"FAIL");
				}
			}
			// Select 'Inactive' from the 'Status' DDL
			actions.setValue("ScreenSet.StatusFilter", "Inactive");
			actions.smartWait(20);
			Thread.sleep(1000);
			int row4 = mcd.GetTableRowCount("RefreshSettings.Table");
			if (row4 == 0) {
				actions.reportCreatePASS("Deposit Sets  table having insufficent data",
						"Deposit Sets table Should be No Inactive Deposite Set",
						"Deposit Sets table is No Inactive Deposite Set", "PASS");
			} else {
				String element6 = driver.findElement(By.xpath(actions.getLocator("MenuItemSet.SelectMenuItemSetNode")))
						.getText();
				if (element6.equalsIgnoreCase("Inactive")) {
					actions.reportCreatePASS("Verify Inactive Deposit is Present",
							"Inactive Deposit Should be Present as Expected", "Inactive Deposit is Present as Expected",
							"PASS");
				} else {
					actions.reportCreateFAIL("Verify Inactive Deposit is Present",
							"Inactive Deposit Should be Present as Expected",
							"Inactive Deposit is not Present as Expected", "FAIL");
				}
			}
			// Click on next hyperlink & Click on previous hyperlink
			/*
			actions.keyboardEnter("MassStatusUpdate.SearchBtn");
			actions.smartWait(20);
			actions.clickAndVerify("POSLayout.NextBtn", "MenuItempriceByPriceSetReport.Previous");
			// actions.click("POSLayout.NextBtn");
			actions.smartWait(20);
			actions.clickAndVerify("MenuItempriceByPriceSetReport.Previous", "POSLayout.NextBtn");
			actions.smartWait(20);
			mcd.verifyPagination();
*/
			// Verify the Sorting of the 'Name'
			int getRowCount_ForVisibleData = 0;
			List<WebElement> eleRws1 = driver
					.findElements(By.xpath(actions.getLocator("MassStatusUpdate.ComponentMINumber")));
			String str = null;
			boolean flag;
			int j = 0;
			do {
				getRowCount_ForVisibleData = j;
				str = eleRws1.get(j).getText();

				if (str.isEmpty()) {
					flag = false;
					break;
				} else {
					flag = true;
				}
				j = j + 1;
			} while (flag);

			String strSortOrderValue1 = driver.findElement(By.xpath(actions.getLocator("MasterDeposit.NameLinkArrow")))
					.getAttribute("src");
			if (strSortOrderValue1.contains("up")) {
				Boolean flag2 = false;
				for (int i = 1; i <= getRowCount_ForVisibleData - 1; i++) {
					String MI_Num3 = driver.findElement(By.xpath("//*[@id='Sess1']/tbody/tr[" + i + "]/td[1]"))
							.getText();
					int n = i + 1;
					String MI_Num4 = driver.findElement(By.xpath("//*[@id='Sess1']/tbody/tr[" + n + "]/td[1]"))
							.getText();

					if ((MI_Num3.toLowerCase().compareTo(MI_Num4.toLowerCase())) <= 0) {
						flag2 = true;

					} else {
						flag2 = false;
						break;

					}

				}
				if (flag2) {
					actions.reportCreatePASS("Verify Sorting according to Deposit Name",
							"List should be sorted asscending order", "List is sorted asscending order", "PASS");
				} else {
					actions.reportCreateFAIL("Verify Sorting according to Deposit Name",
							"List should be sorted asscending order", "List is not sorted asscending order", "FAIL");
				}
			}
			actions.keyboardEnter("MasterDeposit.NameLink");
			actions.smartWait(180);
			if (strSortOrderValue1.contains("down")) {

				Boolean flag3 = false;
				for (int i = 1; i <= getRowCount_ForVisibleData - 1; i++) {
					String MI_Num3 = driver.findElement(By.xpath("//*[@id='Sess1']/tbody/tr[" + i + "]/td[1]"))
							.getText();
					int n = i + 1;
					String MI_Num4 = driver.findElement(By.xpath("//*[@id='Sess1']/tbody/tr[" + n + "]/td[1]"))
							.getText();

					if ((MI_Num3.toLowerCase().compareTo(MI_Num4.toLowerCase())) >= 0) {
						flag3 = true;

					} else {
						flag3 = false;
						break;

					}

				}
				if (flag3) {
					actions.reportCreatePASS("Verify Sorting according to Deposit Name",
							"List should be sorted descending order", "List is sorted  descending order", "PASS");
				} else {
					actions.reportCreateFAIL("Verify Sorting according to Deposit Name",
							"List should be sorted  descending order", "List is not sorted  descending order", "FAIL");
				}

			}
			actions.keyboardEnter("DepositSet.Node");
			actions.smartWait(180);
			String strSortOrderValue2 = driver.findElement(By.xpath(actions.getLocator("DepositSet.NodeArrow")))
					.getAttribute("src");
			if (strSortOrderValue2.contains("up")) {

				Boolean flag3 = false;
				for (int i = 1; i <= getRowCount_ForVisibleData - 1; i++) {
					String MI_Num3 = driver.findElement(By.xpath("//*[@id='Sess1']/tbody/tr[" + i + "]/td[2]"))
							.getText();
					int n = i + 1;
					String MI_Num4 = driver.findElement(By.xpath("//*[@id='Sess1']/tbody/tr[" + n + "]/td[2]"))
							.getText();

					if ((MI_Num3.toLowerCase().compareTo(MI_Num4.toLowerCase())) <= 0) {
						flag3 = true;

					} else {
						flag3 = false;
						break;

					}

				}
				if (flag3) {
					actions.reportCreatePASS("Verify Sorting according to Deposit Node",
							"List should be sorted asscending order", "List is sorted asscending order", "PASS");
				} else {
					actions.reportCreateFAIL("Verify Sorting according to Deposit Node",
							"List should be sorted asscending order", "List is not sorted asscending order", "FAIL");
				}
			}
			actions.keyboardEnter("DepositSet.Node");
			actions.smartWait(180);
			String strSortOrderValue3 = driver.findElement(By.xpath(actions.getLocator("DepositSet.NodeArrow")))
					.getAttribute("src");
			if (strSortOrderValue3.contains("down")) {

				Boolean flag3 = false;
				for (int i = 1; i <= getRowCount_ForVisibleData - 1; i++) {
					String MI_Num3 = driver.findElement(By.xpath("//*[@id='Sess1']/tbody/tr[" + i + "]/td[2]"))
							.getText();
					int n = i + 1;
					String MI_Num4 = driver.findElement(By.xpath("//*[@id='Sess1']/tbody/tr[" + n + "]/td[2]"))
							.getText();

					if ((MI_Num3.toLowerCase().compareTo(MI_Num4.toLowerCase())) >= 0) {
						flag3 = true;

					} else {
						flag3 = false;
						break;

					}

				}
				if (flag3) {
					actions.reportCreatePASS("Verify Sorting according to Deposit Node",
							"List should be sorted descending order", "List is sorted  descending order", "PASS");
				} else {
					actions.reportCreateFAIL("Verify Sorting according to Deposit Node",
							"List should be sorted  descending order", "List is not sorted  descending order", "FAIL");
				}

			}
			rfm.Logout();
		} catch (Exception e) {
			actions.catchException(e);
		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}
}
