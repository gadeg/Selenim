package xtam.test;


import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD.AlertPopupButton;


public class PRC_0244_MPU_ActivateMI {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();
	
	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;
	
	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	
	// TODO: Declare test-data variables for other data-parameters
	private String strNewPrice;
	private String strMessageBeforeSave;
	private String strResultMessage;
	private String strDate;
	private String strNumOfDays;
	private String strPriceSet;
	private String strPriceSetNavigation;
	private String strApplicationDate,restNum;
	private String strDBName, strUserID, strOperation, strActivity, strLevel, strleveldetails,strExpectlevel[],strExpectLevelDetails[];
	
	public PRC_0244_MPU_ActivateMI (WebDriver nodeDriver, Map inputData, Object or){
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();
		
		mcd = new lib_MCD (driver, actions, uiActions, inputData);
		rfm = new lib_RFM2 (driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);
		
		// Read input Test-Data
		strURL 			= mcd.GetTestData("DT_URL");
		strUserName 	= mcd.GetTestData("DT_USER_NAME");
		strPassword 	= mcd.GetTestData("DT_PASSWORD");
		strMarket 		= mcd.GetTestData("DT_MARKET");
		strNavigateTo 	= mcd.GetTestData("DT_NAVIGATE_TO");
		restNum			= mcd.GetTestData("DT_RestNum");
		// TODO: GetTestData for other data-parameters
		
		strNewPrice 			= mcd.GetTestData("NewPrice");
		strMessageBeforeSave	= mcd.GetTestData("MessageBeforeSave");
		strResultMessage 		= mcd.GetTestData("ResultMessage");
		strDate					= mcd.GetTestData("Date");
		strNumOfDays			= mcd.GetTestData("NumOfDays");
		strPriceSetNavigation 	= mcd.GetTestData("PriceSetNavigation");
		strDBName = mcd.GetTestData("DT_DB_NAME");
		strUserID = mcd.GetTestData("DT_USER_NAME");
		strOperation = mcd.GetTestData("DT_OPERATION");
		strActivity = mcd.GetTestData("DT_ACTIVITY");
		strLevel = mcd.GetTestData("DT_LEVEL");
		strleveldetails = mcd.GetTestData("DT_LevelDetails");
		
		strExpectlevel = strLevel.split("#");
		strExpectLevelDetails = strleveldetails.split("#");
	}
	
	@Test
	public void PRC_0244_MPU_ActivateMI() throws InterruptedException {
		String strPageTitle = "Update Multiple Menu Items in Multiple Price Sets : Menu Items";			// TODO: Exact page-title
		String strPageSubHeading = "Update Multiple Menu Items in Multiple Price Sets : Menu Items";		// TODO: Page Heading
		String strTestDescription = "Verify the working of Mass Update Prices functionality when �All Prices� are entered with Activate menu item checkbox checked";		// TODO: Test Case Description
		try {
			System.out.println("********************************************************************** Test execution starts");

			 /** set test case description*/
			 actions.setTestcaseDescription(strTestDescription);
						
			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);
			
			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);
			
			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strPriceSetNavigation);
			actions.select_menu("RFMHome.Navigate", strPriceSetNavigation);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");
			
		
		
			// ------------------------------------------------------------------------ Actions specific to test-flow
			
			//strPriceSet = PriceActions.Get_PriceSet(strPriceSetNavigation);
			
			//Create Active price Set
			actions.click("PriceSets.NewPriceSetBtn");
			mcd.waitAndSwitch("New Price Sets");
			strPriceSet = mcd.fn_GetRndName("PriceSet");
			actions.clear("NewPriceSets.TextBox");
			actions.setValue("NewPriceSets.TextBox", strPriceSet);
			actions.click("AddNewDayPartSet.SelectBtn");
			mcd.waitAndSwitch("Select Node");
			actions.WaitForElementPresent("SelectNodeRest.SearchTextField", 180);
			mcd.Selectrestnode_JavaScriptClk("RFMSelectNode.SelectNodeTable", restNum);
			mcd.waitAndSwitch("New Price Sets");
			actions.click("MassSetAssignment.MASelectRestNextbtn");
			
			mcd.SwitchToWindow("@Price Sets : Common Menu Item Selector");
			actions.keyboardEnter("TaxType.ViewFullListButton");
			actions.smartWait(100);
			WebElement ElementMenuIteamNm = mcd.GetTableCellElement("AddTenderType.Table", 1, "Add", "input[1]");
			ElementMenuIteamNm.click();
			actions.click("AddTaxType.SaveButton");
			actions.smartWait(100);
			mcd.SwitchToWindow("#Title");
			actions.setValue("ManagePS.Status", "Active");
			actions.keyboardEnter("PackageSchedule.NBSaveButton");
			actions.smartWait(10);
			
            /** Select Menu Option */
            System.out.println("> Navigate to :: " + strNavigateTo);
            actions.select_menu("RFMHome.Navigation",strNavigateTo);
            Thread.sleep(2000);
            actions.waitForPageToLoad(120);
            mcd.SwitchToWindow("#Title");
			
			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();
            
			// Mass Update Prices
			RFM_PRC_MUP_MassUpdtPrices(strDate, strNumOfDays, strNewPrice, strPriceSet, strApplicationDate.trim());
			
			// Activate Menu Item
			RFM_PRC_MUP_ActivateMI(strMessageBeforeSave, strResultMessage, strNewPrice);
			actions.smartWait(50);
			
			//Verify Audit log details
			boolean AuditlogCorrectValuesDisplayed = rfm.VerifyAuditLog_Entry(strOperation, strActivity,
					strExpectlevel[0]);
			
			
			if (AuditlogCorrectValuesDisplayed) {
				actions.reportCreatePASS("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation," + "ActivityValue,Level",
						"Correct values are displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation," + "ActivityValue,Level",
						"Correct values are not displayed", "Fail");
			}
			
			
			String AuditDesc = "Price Set has been updated by User " + strUserID + " by Mass Update Prices " ;
			
			
					
			boolean isAuditlogCorrectValuesDisplayed = rfm.RFM_VerifyAuditLog_Details(strDBName, strUserID,
					strOperation, strActivity, strExpectlevel[1], strExpectLevelDetails[0], AuditDesc);

			if (isAuditlogCorrectValuesDisplayed) {
				actions.reportCreatePASS("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "Activities,Level & description ",
						"Correct values are displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "Activities,Level & description ",
						"Correct values are not displayed", "Fail");
			}
			
			
			
			// ------------------------------------------------------------------------ 
			
			/** Logout the application */
			rfm.Logout();
			

		}catch(Exception e) {
			//Reporter.log("Test Failed :: " + e.getCause() + " - " +  e.getMessage());
			System.out.println("Test Failed :: " + e.getCause() + " - " +  e.getMessage());
			actions.catchException(e);
			
		        } finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
	public void RFM_PRC_MUP_MassUpdtPrices(String strDate, String strNumOfDays, String strNewPrice, String strPriceSet,
			String app_date) throws InterruptedException {

		// Menu Item

		actions.click("UpdateSet.VwFullList");
		Thread.sleep(1000);
		actions.smartWait(120);
		mcd.select_row("UpdateSet.MenuItemTable", 0);
		actions.click("UpdateSet.AddRow");
		actions.click("UpdateSet.NextBtn");
		Thread.sleep(1000);
		actions.waitForPageToLoad(120);

		// Price Sets - Select a Price Set that is assigned to a restaurant
		actions.setValue("UpdatePrcSet.SearchBox", strPriceSet);
		Thread.sleep(500);
		actions.click("UpdatePrcSet.SearchButton");
		Thread.sleep(1000);
		actions.smartWait(120);
		mcd.select_row("UpdatePrcSet.PriceSetTable", 0);
		actions.click("UpdatePrcSet.AddRow");
		actions.click("UpdatePrcSet.NextBtn");
		Thread.sleep(1000);
		actions.waitForPageToLoad(120);

		// Updating Prices
		if (strDate.equals("Today")) {
			// Selecting Today's date (Today Button)
			Thread.sleep(1000);
			actions.click("UpdtMultipleSet.TodayBtn");
			Thread.sleep(2000);
			// Reporter.log("Today's date selected - PASS");

		} else if (strDate.equals("Future")) {

			// Calendar Icon check
			actions.verifyPresence("UpdtMultipleSet.CalenderIcon", true);
			actions.click("UpdtMultipleSet.CalenderIcon");
			mcd.Get_future_date(Integer.parseInt(strNumOfDays), "close", app_date);
			// mcd.Get_future_date(Integer.parseInt(strNumOfDays),
			// "UpdtMultipleSet.CalenderIcon", app_date);
			Thread.sleep(500);
			// Reporter.log("Future Date selected - PASS");
			actions.reportCreatePASS("Verify future date selection", "Date should be selected", "Date Selected",
					"PASS");

		} else {
			actions.reportCreateFAIL("Verify future date selection", "Date should be selected", "Date Selected",
					"FAIL");
			// Reporter.log("Date selection - FAIL");
		}

		// Mass Updating Prices

		actions.setValue("UpdtMultipleSet.AllPrc", strNewPrice);

		actions.click("UpdtMultipleSet.Apply");
		Thread.sleep(1000);
		actions.smartWait(120);

		// Verifying Date & Prices entered are updated correctly.
		String InputDate = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.StartDate")))
				.getAttribute("value");
		String AppliedDate = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewDate")))
				.getAttribute("value");

		String ALL_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewAllPrc")))
				.getAttribute("value");

		if (InputDate.equals(AppliedDate)) {
			// Reporter.log("Start Date entered is updated against for all
			// prices correctly - PASS");
			actions.reportCreatePASS("Verify Start Date displayed", "Start date should be correctly updated",
					"Start date correctly updated", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Start Date displayed", "Start date should be correctly updated",
					"Start date not correctly updated", "FAIL");
		}

		Thread.sleep(1000);
		try {
			driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.ExpandImg"))).click();
		} catch (Exception e4) {
			System.out.println("Already expanded");
		}
		Thread.sleep(1000);

		// Reading Eating/take out/other prices
		String Eating_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewEatingPrc")))
				.getAttribute("value");
		String TakeOut_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewTkOutPrc")))
				.getAttribute("value");
		String Other_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewOtherPrc")))
				.getAttribute("value");

		if ((ALL_Price.equals(strNewPrice)) && (Eating_Price.equals(strNewPrice)) && (TakeOut_Price.equals(strNewPrice))
				&& (Other_Price.equals(strNewPrice))) {
			// Reporter.log("All Prices/Eating/Take out/Other Prices updated
			// correctly - PASS");
			actions.reportCreatePASS("Verify Price fields",
					"All Prices/Eating/Take out/Other Prices should be updated correctly",
					"All Prices/Eating/Take out/Other Prices updated correctly", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Price fields",
					"All Prices/Eating/Take out/Other Prices should be updated correctly",
					"All Prices/Eating/Take out/Other Prices not updated correctly", "FAIL");
			// Reporter.log("All Prices/Eating/Take out/Other Prices not updated
			// correctly - FAIL");
		}

	}
	public void RFM_PRC_MUP_ActivateMI(String strMessageBeforeSave, String strResultMessage, String strNewPrice)
			throws Exception {
		
		if (strMarket.equals("US Country Office")){
		
			actions.javaScriptClick("UpdtMultipleSet.ActivateMIChkBx");
		}

		actions.waitForPageToLoad(120);
		// Save & Apply Changes
		RFM_PRC_MUP_SaveAndApply(strMessageBeforeSave, strResultMessage);

		// Verifying correct prices are saved

		try {
			driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.ExpandImg"))).click();
			Thread.sleep(1000);
		} catch (Exception e4) {
			System.out.println("Already expanded");
		}

		String ALL_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewAllPrc")))
				.getAttribute("value");
		String Eating_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewEatingPrc")))
				.getAttribute("value");
		String TakeOut_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewTkOutPrc")))
				.getAttribute("value");
		String Other_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewOtherPrc")))
				.getAttribute("value");

		if ((ALL_Price.equals(strNewPrice)) && (Eating_Price.equals(strNewPrice)) && (TakeOut_Price.equals(strNewPrice))
				&& (Other_Price.equals(strNewPrice))) {
			actions.reportCreatePASS("Verify Price fields",
					"All Prices/Eating/Take out/Other Prices should be saved correctly",
					"All Prices/Eating/Take out/Other Prices saved correctly", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Price fields",
					"All Prices/Eating/Take out/Other Prices should be saved correctly",
					"All Prices/Eating/Take out/Other Prices not saved correctly", "FAIL");
		}
		Thread.sleep(1000);
	}
	
	public void RFM_PRC_MUP_SaveAndApply(String strMessageBeforeSave, String strResultMessage) throws Exception {
		// Click Save
		Thread.sleep(2000);
		actions.click("UpdtMultipleSet.Save");
		
		

		// Check Alert message
		try {
			Boolean VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strMessageBeforeSave, true,
					AlertPopupButton.OK_BUTTON);
			if (VerifyPopUpMsg) {
				actions.reportCreatePASS("Verify Alert message before save", "Alert message should be given",
						"Alert message is given", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Alert message before save", "Alert message should be given",
						"Alert message is not given", "FAIL");
				
			}
		} catch (Exception err) {
			System.out.println("No alerts");
		}
		
		mcd.waitAndSwitch("@Mass Update Prices");
		actions.WaitForElementPresent("OutputWindow.OutputMsg", 180);
		
		// Check Success Message
		String Result = driver.findElement(By.xpath(actions.getLocator("OutputWindow.OutputMsg"))).getText();
		if (Result.equals(strResultMessage)) {
			actions.reportCreatePASS("Verify Mass update of prices", "Should be done successfully", "Done successfully",
					"PASS");
		} else {
			actions.reportCreateFAIL("Verify Mass update of prices", "Should be done successfully",
					"Not done successfully", "PASS");
			
		}
		
		// Click OK button
		actions.click("OutputWindow.OkBtn");
		actions.smartWait(50);
		
		

		// Window navigated back to main window
		if (driver.getTitle().equals("Mass Update Prices")) {
			actions.reportCreatePASS("Verify navigation after final output",
					"Window should be navigated back after updating prices",
					"Window navigated back after updating prices", "PASS");
			
		} else {
			actions.reportCreateFAIL("Verify navigation after final output",
					"Window should be navigated back after updating prices",
					"Window not navigated back after updating prices", "FAIL");
			
		}

	}
}
