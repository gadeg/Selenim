/**
 * 
 */
package xtam.test;

/**
 * @author akrani
 *
 */
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;


public class PRC_20272_MITSupdtFutureSetting {
       private Keywords actions;
       private WebDriver driver;
       private Map input;
       private UIValidations uiActions;
       private SoftAssert softAssert = new SoftAssert();
       
       private lib_MCD mcd;
       private lib_RFM2 rfm;
       
       private String strApplicationDate;
       
       // Test-Data Variables
       private Object strURL;
       private Object strUserName;
       private Object strPassword;
       private String strMarket;
       private String strNavigateTo;
       // TODO: Declare test-data variables for other data-parameters
       private String strMenuItemFut,strMenuItem,strTaxCodeFirstDropDown,strMenuItemTaxSet,strMenuItemTaxSetUpdated,strPopup,Err,ErrSplit[],strPopupSplit[],strTaxedDropDownValue,strTaxedDropDownValueCurntSett,FutureSettings;
       Integer rowCount=0,rowCountmenu=0,count=0;
       boolean flag=false;
       
       public PRC_20272_MITSupdtFutureSetting (WebDriver nodeDriver, Map inputData, Object or){
              driver = nodeDriver;
              input = inputData;
              actions = new Keywords(driver, or);
              uiActions = new UIValidations();
              
              mcd = new lib_MCD (driver, actions, uiActions, inputData);
              rfm = new lib_RFM2 (driver, actions, uiActions, inputData, mcd);

              // Read input Test-Data
              strURL                     = mcd.GetTestData("DT_URL");
              strUserName   = mcd.GetTestData("DT_USER_NAME");
              strPassword   = mcd.GetTestData("DT_PASSWORD");
              strMarket            = mcd.GetTestData("DT_MARKET");
              strNavigateTo        = mcd.GetTestData("DT_NAVIGATE_TO");
              // TODO: GetTestData for other data-parameters
              strPopup            = mcd.GetTestData("DT_POPUP");
              Err                = mcd.GetTestData("DT_ERROR");
              String dtForm = mcd.GetTestData("DT_DATE_FORMAT");
       }
       
       @Test
       public void test_PRC_20272_MITSupdtFutureSetting() throws InterruptedException {
//              String strPageTitle = "Menu Item Tax Set";				// TODO: Exact page-title
//              String strPageSubHeading = "Menu Item Tax Set";		// TODO: Page Heading
              String strTestDescription = " Update menu item tax set for future settings";		// TODO: Test Case Description
              
              try {
                     System.out.println("********************************************************************** Test execution starts");

                     /** Launch and Login RFM */
                     System.out.println("> Launch and Login RFM");
                     rfm.LaunchAndLogin(strURL, strUserName, strPassword);
                     
                     /** Select Market (Node) */
                     System.out.println("> Select Market (Node)");
                     rfm.SelectMarket(strMarket);
              
                     /** Select Menu Option */
                     System.out.println("> Navigate to :: " + strNavigateTo);
                     actions.select_menu("RFMHome.Navigation",strNavigateTo);
                     Thread.sleep(2000);
                     actions.waitForPageToLoad(120);

                     /** Verify Page Header */
                     // System.out.println("> Verify Page Heading");
                    //  mcd.VerifyPageTitle(strPageTitle);

                     /** Update title of new Page  */
                     mcd.SwitchToWindow("#Title");
                     
                     /** Get application time */
                     WebElement apptime = mcd.getdate();
                     strApplicationDate = apptime.getText();

					 /** Get application time */
					 actions.setTestcaseDescription(strTestDescription);

                     // ------------------------------------------------------------------------ Actions specific to test-flow
					 strPopupSplit=strPopup.split("#");
					 ErrSplit=Err.split("#");
					 
				//Applying Future setting to Menu Item Tax Set	
					 actions.keyboardEnter("TaxType.ViewFullListButton");
                     actions.smartWait(180);
                     actions.setValue("TenderSet.StatusDropDown", "Active");
                     actions.smartWait(180);
                     
                     //Validating whether Future Settings already present or not
                     rowCount=mcd.GetTableRowCount("ScriptManagement.TableNameValue");
                     if(rowCount>1){
                    	 for(int i=1;i<=rowCount;i++){
    						 FutureSettings = mcd.GetTableCellValue("ScriptManagement.TableNameValue",i, "Future Settings", "", "");
    							if (FutureSettings.equals("")) {			
    								// Retrieving Tender Type Name of table
    									//TenderTypeSetName = mcd.GetTableCellValue("ScriptManagement.TableNameValue",i,"Name", "","");
    									WebElement ElementTaxSetNm = mcd.GetTableCellElement("ScriptManagement.TableNameValue",i,"Name", "a");
    									actions.keyboardEnter(ElementTaxSetNm);  									
    									break;
    							}  
    					 } 
                     }else if(rowCount==1){
                    	 WebElement ElementTaxSetNm = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1,"Name","a");
             			 actions.keyboardEnter(ElementTaxSetNm);
                     }else{
                    	 System.out.println("No Active Menu Item Tax Set Available ");
                     }
                   	 
                                          
         			 //switch to "Apply Changes Details"
 	     			mcd.SwitchToWindow("Apply Changes Details");
 	     			actions.click("ApplyChangesDetails.futureDateRadioButton");
 	     			actions.click("ApplyChangesDetails.CalendarIcon");
 					mcd.Get_future_date(2, "Close", strApplicationDate);
 					actions.keyboardEnter("ApplyChangesDetails.MDSaveButton");
 					//actions.smartWait(10);
 					actions.waitForPageToLoad(180);
 					mcd.SwitchToWindow("@Manage Menu Item Tax Set");
                    actions.WaitForElementPresent("ManageMenuItemTaxSet.MenuItemTaxSetTexBox");
 					//Retrieving value from MenuItemTaxSetTexBox
         			strMenuItemTaxSet=driver.findElement(By.xpath(actions.getLocator("ManageMenuItemTaxSet.MenuItemTaxSetTexBox"))).getAttribute("value");
					strMenuItemTaxSet=strMenuItemTaxSet.concat("ch");	
					
					//Updating Menu Item Tax Set Name
					actions.clear("ManageMenuItemTaxSet.MenuItemTaxSetTexBox");
					actions.setValue("ManageMenuItemTaxSet.MenuItemTaxSetTexBox",strMenuItemTaxSet);
					actions.keyboardEnter("ManageMenuItemTaxSet.ApplyButton");
					
					if (mcd.VerifyAlertMessageDisplayed("Information", strPopupSplit[0], true, AlertPopupButton.OK_BUTTON)) {
						actions.reportCreatePASS("Veriyfing the '" + strPopupSplit[0] + " 'is Present or not",
								strPopupSplit[0] + " should be present", strPopupSplit[0] + " is present", "Pass");
					} else {
						actions.reportCreateFAIL("Veriyfing the '" + strPopupSplit[0] + " 'is Present or not",
								strPopupSplit[0] + " should be present", strPopupSplit[0] + " is not present", "Fail");
					}
					//mcd.VerifyAlertMessageDisplayed("Warning Message", strPopupSplit[0], true, AlertPopupButton.OK_BUTTON);
					actions.smartWait(30);
					strMenuItemTaxSetUpdated=driver.findElement(By.xpath(actions.getLocator("ManageMenuItemTaxSet.MenuItemTaxSetTexBox"))).getAttribute("value");
					
					System.out.println("strMenuItemTaxSetUpdated"+strMenuItemTaxSetUpdated);
					if(strMenuItemTaxSetUpdated.equals(strMenuItemTaxSet)){
						actions.reportCreatePASS("Verify Newly edited set name should be displayed for both current and future settings.",
           						"Newly edited set name should be displayed for both current and future settings.",
           						"Newly edited set name is displayed for both current and future settings.",
           						"Pass");
           			} else {
           				actions.reportCreateFAIL("Verify Newly edited set name should be displayed for both current and future settings.",
           						"Newly edited set name should be displayed for both current and future settings.",
           						"Newly edited set name is displayed for both current and future settings.",
           						"Fail"); 
					}
                     
					//Verify the default value for "Taxed" DDL contains "Not Taxed/Taxed value"
					Select select = new Select(driver.findElement(By.xpath(actions.getLocator("ManageMenuItemTaxSet.TaxedDropDown"))));     				
     				strTaxedDropDownValue=select.getFirstSelectedOption().getText();
     			
     				if(strTaxedDropDownValue.equals("Not Taxed/Taxed")){
     					actions.reportCreatePASS("Verify the default value for 'Taxed' DDL contains 'Not Taxed/Taxed value'",
								"The default value for 'Taxed' DDL should contains 'Not Taxed/Taxed value'",
								"The default value for 'Taxed' DDL is 'Not Taxed/Taxed value'",
								"Pass");
					} else {
						actions.reportCreateFAIL("Verify the default value for 'Taxed' DDL contains 'Not Taxed/Taxed value'",
								"The default value for 'Taxed' DDL should contains 'Not Taxed/Taxed value'",
								"The default value for 'Taxed' DDL is not 'Not Taxed/Taxed value'",
								"Fail"); 
     				}
     				
     				actions.setValue("ManageMenuItemTaxSet.TaxedDropDown","Taxed");
     				actions.smartWait(180);
     				
     			/*	Select select3 = new Select(driver.findElement(By.xpath(actions.getLocator("ManageMenuItemTaxSet.TaxCodeFirstDropDown"))));     				
     				strTaxCodeFirstDropDown=select3.getFirstSelectedOption().getText();
     				if(!strTaxCodeFirstDropDown.equals("Never")){
     					actions.setValue("ManageMenuItemTaxSet.TaxCodeFirstDropDown","Never");
     				}
     				*/
     				actions.keyboardEnter("ManageMenuItemTaxSet.AddRemoveButton");
     				
     				Thread.sleep(3000);
     				actions.waitForPageToLoad(120);
     				mcd.SwitchToWindow("Menu Item Tax Set : Common Menu Item Selector");
     				
     				actions.keyboardEnter("TaxType.ViewFullListButton");
     				actions.smartWait(180);
     				
     				actions.setValue("ManageMenuItemTaxSet.AvailabilityDropdown","Available");
     				actions.smartWait(180);	     	
		     				
 					WebElement ElementMenuIteam = mcd.GetTableCellElement("AddTenderType.Table", 1, 1, "input[1]");    					
 					//ElementMenuIteam.click();   
 					ElementMenuIteam.sendKeys(Keys.SPACE);
 					
                    actions.keyboardEnter("AddTaxType.SaveButton");				
     				
     				mcd.waitAndSwitch("Manage Menu Item Tax Set");
     				Thread.sleep(1000);
     				//Verifying Menu Items have been Added/Removed successfully to/from the Menu Item Tax Set.
     				//mcd.VerifyOnscreenMessage("ManageTenderType.SaveMessage",ErrSplit[0], true);    			
     				actions.verifyTextPresence(ErrSplit[0], true);
     				WebElement ElementMenuIteam1 = GetTableCellElement("ScriptManagement.TableNameValue",1,"Tax Code","select");
     				Select select1 = new Select(ElementMenuIteam1);
     				System.out.println("--------------------------------------------------------------------------------------------------------------------");
     				select1.selectByVisibleText("Never");
     				
     				Thread.sleep(1000);
     				actions.keyboardEnter("ManageMenuItemTaxSet.ApplyButton");			
     				actions.smartWait(180);     				
     				actions.keyboardEnter("NewScript.CancleButton");
     				mcd.SwitchToWindow("#Title");
				
     		//Clicking on Menu Item Tax Set name having current setting		
     				actions.setValue("TenderSet.SearchTextBox", strMenuItemTaxSetUpdated);
     				actions.keyboardEnter("TaxType.SearchButton");
     				actions.smartWait(180);
     				
     				 WebElement ElementTaxSetNm1 = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1,"Name","a");
         			 actions.keyboardEnter(ElementTaxSetNm1);
         			 
         			 //Switching to Manage Menu Item Tax Set
         			 actions.waitForPageToLoad(120);
         			
         			 try{
         			mcd.SwitchToWindow("Apply Changes Details");
 	     			actions.click("ApplyChangesDetails.futureDateRadioButton");
 	     			actions.click("ApplyChangesDetails.CalendarIcon");
 					mcd.Get_future_date(2, "Close", strApplicationDate);
 					actions.keyboardEnter("ApplyChangesDetails.MDSaveButton");
 					//actions.smartWait(10);
 					actions.waitForPageToLoad(180);
 					mcd.SwitchToWindow("@Manage Menu Item Tax Set");
         			 }
         			 catch(Exception e){
         				 mcd.SwitchToWindow("#Title");
         			 }
         			 
         			 
         			
         			 
	       //Covering-PRC_20283 To Verify the Current Settings and Future Settings pop-up for Active Menu Item Tax Sets when future settings exists and user saves changes for current date.  			 
	         		String	strHedingmsgCur=driver.findElement(By.xpath(actions.getLocator("ManageMenuItemTaxSet.HeadingMsg"))).getText();
	         		if(strHedingmsgCur.contains(strMenuItemTaxSetUpdated)){
	         			actions.reportCreatePASS("Verify updated name should be reflected in the Header",
	    						"Updated name should be reflected in the Header",
	    						"Updated name is reflected in the Header",
	    						"Pass");
	    			} else {
	    				actions.reportCreateFAIL("Verify updated name should be reflected in the Header",
	    						"Updated name should be reflected in the Header",
	    						"Updated name is reflected in the Header",
	    						"Fail"); 
	         		}
	   //----------------------------------End-PRC_20283-----------------------------------------------------------
	         		
         			Select select2 = new Select(driver.findElement(By.xpath(actions.getLocator("ManageMenuItemTaxSet.TaxedDropDown"))));     				
     				strTaxedDropDownValueCurntSett=select2.getFirstSelectedOption().getText();
     				
     				if(!strTaxedDropDownValueCurntSett.equals("Taxed")){
     					actions.reportCreatePASS("Verify that the changes that have been made for future settings do not effect current settings.",
     							"The changes that have been made for future settings should not effect current settings.",
     							"The changes that have been made for future settings is not effect current settings.",
     							"Pass");
     				} else {
     					actions.reportCreateFAIL("Verify that the changes that have been made for future settings do not effect current settings.",
     							"The changes that have been made for future settings should not effect current settings.",
     							"The changes that have been made for future settings is effect current settings.",
     							"Fail"); 
     				}
     				
     	//Covering-PRC_0277- Menu Items added to the current tax set are also added to the future tax set			
     				actions.keyboardEnter("ManageMenuItemTaxSet.AddRemoveButton");  				
     				Thread.sleep(3000);
     				actions.waitForPageToLoad(120);
     				mcd.SwitchToWindow("Menu Item Tax Set : Common Menu Item Selector");
     				
     				actions.keyboardEnter("TaxType.ViewFullListButton");
     				actions.smartWait(180);
     				
     				actions.setValue("ManageMenuItemTaxSet.AvailabilityDropdown","Available");
     				actions.smartWait(180);	     	
		     		     				
     				WebElement ElementMenuIteams =mcd.GetTableCellElement("AddTenderType.Table",1,1,"input");  			
 					ElementMenuIteams.sendKeys(Keys.SPACE);
     				
 					//Retrieving MenuIteam Name
     				strMenuItem=mcd.GetTableCellValue("AddTenderType.Table", 1, "Name", "", "");
     				System.out.println("strMenuItem"+strMenuItem);
     				
 					//ElementMenuIteams.click();       					
                    actions.keyboardEnter("AddTaxType.SaveButton");				
                	actions.waitForPageToLoad(120);	    				
     				mcd.SwitchToWindow("Manage Menu Item Tax Set");
     	//-----------------------End-PRC_0277----------------------------------------
     				
     				//Covering PRC_20273-Verify Change date and Remove date functionality of Menu item tax set for future settings.   				
                     // ------------------------------------------------------------------------                     
     				actions.WaitForElementPresent("NewScript.CancleButton");
     				actions.keyboardEnter("NewScript.CancleButton");
     				actions.waitForPageToLoad(120);
     				mcd.SwitchToWindow("#Title");
     				
     				//Clicking on Menu Item Tax Set name having Future setting			
     				actions.clear("TenderSet.SearchTextBox");
     				actions.setValue("TenderSet.SearchTextBox", strMenuItemTaxSetUpdated);
     				actions.keyboardEnter("TaxType.SearchButton");
     				actions.smartWait(180);
     				
     				WebElement ElementFuturSetting = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1,"Future Settings","a");
         			actions.keyboardEnter(ElementFuturSetting);
         			 
         			//Switching to Manage Menu Item Tax Set
         			actions.waitForPageToLoad(120);
         			mcd.SwitchToWindow("#Title");
         			
         			/*//Covering-PRC_0277- Menu Items added to the current tax set are also added to the future tax set			
	     				//Retrieving MenuIteam Name
         				rowCountmenu=mcd.GetTableRowCount("ScriptManagement.TableNameValue");
         				
         				if(rowCountmenu>=1){
         					for(int i=1;i<=rowCountmenu;i++){
         						strMenuItemFut=mcd.GetTableCellValue("ScriptManagement.TableNameValue",i,1, "", "");
         						if(strMenuItemFut.contains(strMenuItem)){
         							actions.reportCreatePASS("Verify Menu Items added to the current tax set are also added to the future tax set",
         									"Menu Items added to the current tax set should also added to the future tax set",
         									"Menu Items added to the current tax set are also added to the future tax set",
         									"Pass");
         									
         							count=count+1;
         							break;
         						} 
         					}				
         				}
         				if(count<1){
 							actions.reportCreateFAIL("Verify Menu Items added to the current tax set are also added to the future tax set",
 									"Menu Items added to the current tax set should also added to the future tax set",
 									"Menu Items added to the current tax set are not added to the future tax set",
								"Fail");       	
         				}*/
	     				
     				//-----------------------End-PRC_0277----------------------------------------
     				
         				//Covering-PRC_20283 To Verify the Current Settings and Future Settings pop-up for Active Menu Item Tax Sets when future settings exists and user saves changes for current date.  			 
	         		String	strHedingmsgFut=driver.findElement(By.xpath(actions.getLocator("ManageMenuItemTaxSet.HeadingMsg"))).getText();
	         		if(strHedingmsgFut.contains(strMenuItemTaxSetUpdated)){
	         			actions.reportCreatePASS("Verify updated name should be reflected in the Header",
	    						"Updated name should be reflected in the Header",
	    						"Updated name is reflected in the Header",
	    						"Pass");
	    			} else {
	    				actions.reportCreateFAIL("Verify updated name should be reflected in the Header",
	    						"Updated name should be reflected in the Header",
	    						"Updated name is reflected in the Header",
	    						"Fail"); 
	         		}
	   //----------------------------------End-PRC_20283-----------------------------------------------------------
	         		
         			actions.keyboardEnter("ManageMenuItemTaxSet.ChangeDateButton");
         			
         			//validating A message'Are you sure you want to change the date of future settings?' 
         			if (mcd.VerifyAlertMessageDisplayed("Information", strPopupSplit[1], true, AlertPopupButton.OK_BUTTON)) {
        				actions.reportCreatePASS("Veriyfing the '" + strPopupSplit[1] + " 'is Present or not",
        						strPopupSplit[1] + " should be present", strPopupSplit[1] + " is present", "Pass");
        			} else {
        				actions.reportCreateFAIL("Veriyfing the '" + strPopupSplit[1] + " 'is Present or not",
        						strPopupSplit[1] + " should be present", strPopupSplit[1] + " is not present", "Fail");
        			}
         			//mcd.VerifyAlertMessageDisplayed("Warning Message",strPopupSplit[1], true, AlertPopupButton.OK_BUTTON);
        			
         			//switch to "Apply Changes Details"
         			actions.waitForPageToLoad(120);
	     			mcd.SwitchToWindow("Apply Changes Details");	     			
	     			actions.click("ApplyChangesDetails.CalendarIcon");
					mcd.Get_future_date(1, "Close", strApplicationDate);
					actions.keyboardEnter("ApplyChangesDetails.RPSaveButton");
					//actions.smartWait(10);
					Thread.sleep(2000);
					actions.waitForPageToLoad(120);
					mcd.SwitchToWindow("@Manage Menu Item Tax Set");
					
					//Validating Future settings date has been successfully changed.
					flag = mcd.VerifyOnscreenMessage("ManageMenuItemTaxSet.ErrorMsg", ErrSplit[1], true);
					if(flag){
						actions.reportCreatePASS("Verify Future settings date has been successfully changed is displaying.",
								"Future settings date has been successfully changed should displaying.",
								"Future settings date has been successfully changed is displaying.",
								"Pass");
					} else {
						actions.reportCreateFAIL("Verify Future settings date has been successfully changed is displaying.",
								"Future settings date has been successfully changed should displaying.",
								"Future settings date has been successfully changed is not displaying.",
								"Fail"); 
					}
					
					//Clicking on RemoveAll Button
					actions.keyboardEnter("ManageTenderType.RemoveButton");
					
					//validating A message'Are you sure you want to change the date of future settings?'
					if (mcd.VerifyAlertMessageDisplayed("Information", strPopupSplit[2], true, AlertPopupButton.OK_BUTTON)) {
						actions.reportCreatePASS("Veriyfing the '" + strPopupSplit[2] + " 'is Present or not",
								strPopupSplit[2] + " should be present", strPopupSplit[2] + " is present", "Pass");
					} else {
						actions.reportCreateFAIL("Veriyfing the '" + strPopupSplit[2] + " 'is Present or not",
								strPopupSplit[2] + " should be present", strPopupSplit[2] + " is not present", "Fail");
					}
         			//mcd.VerifyAlertMessageDisplayed("Warning Message",strPopupSplit[2], true, AlertPopupButton.OK_BUTTON);
        			actions.smartWait(180);
        			
        			//Verify Future settings have been successfully removed.
        			flag = mcd.VerifyOnscreenMessage("TaxType.ErrorMsg", ErrSplit[2], true);
					if(flag){
						actions.reportCreatePASS("Verify Future settings have been successfully removed is displaying.",
								"Future settings have been successfully removed should displaying.",
								"Future settings have been successfully removed is displaying.",
								"Pass");
					} else {
						actions.reportCreateFAIL("Verify Future settings have been successfully removed is displaying.",
								"Future settings have been successfully removed should displaying.",
								"Future settings have been successfully removed is not displaying.",
								"Fail"); 
					}
                    /** Logout the application */
                    rfm.Logout();
                     
              } catch(Exception e) {
                     
                     //reporting the Fail condition
                     actions.catchException(e);
                     
              } finally {
            	  
                     actions.quitBrowser();
                     actions.verifyTestCase(this.getClass());
                                                
              }
       }

       public WebElement GetTableCellElement(String strTableElement, int intRow, String strColumnName,
   			String strColumnElementType) {
   		WebElement strReturn = null;
   		int intCol = mcd.GetTableColumnNumber(strTableElement, strColumnName);
   		strReturn = GetTableCellElement(strTableElement, intRow, intCol, strColumnElementType);
   		return strReturn;
   	}

       public WebElement GetTableCellElement(String strTableElement, int intRow, int intCol, String strColumnElementType) {
   		WebElement strReturn = null;
   		WebElement eleTable = actions.getwebDriverLocator(actions.getLocator(strTableElement));

   		try {
   			try {
   				strReturn = eleTable.findElement(
   						By.xpath(".//tbody/tr[" + intRow + "]/td[" + intCol + "]/" + strColumnElementType));
   			} catch (Exception e) {
   				strReturn = eleTable.findElement(
   						By.xpath(".//thead/tr[" + intRow + "]/td[" + intCol + "]/" + strColumnElementType));
   			}
   		} catch (Exception err) {
   			// To handle : extra '/' when strColumnElementType = "".
   			try {
   				strReturn = eleTable.findElement(By.xpath(".//tbody/tr[" + intRow + "]/td[" + intCol + "]"));
   			} catch (Exception e) {
   				strReturn = eleTable.findElement(By.xpath(".//thead/tr[" + intRow + "]/td[" + intCol + "]"));
   			}
   		}
   		return strReturn;
   	}

}

