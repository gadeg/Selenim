
package xtam.test;

import java.util.List;
import java.util.Map;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class PRC_20208_UpdateAMasterFee {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strRestauratName;
	private String strMasterFeesetName;
	private boolean blnAudit = false;
	private String strLevel, strDBName, strUserID, strOperation, strActivity, strNodeName;
	private String strRest, strNavigate;

	public PRC_20208_UpdateAMasterFee(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strNavigate = mcd.GetTestData("DT_NAVIGATE_TO_ADMIN");
		strRest = mcd.GetTestData("DT_Rest");
		strOperation= mcd.GetTestData("DT_Operation");
	}

	@Test
	public void test_PRC_20208_UpdateAMasterFee() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription(
					"Verify the Audit log for when user updates the Fee and reset it to default value in Restaurant Profile");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigate);
			actions.select_menu("RFMHome.Navigation", strNavigate);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			rfm.RFM_Admin_Update_PricingTags("false", "Restrict price type attribute from expanding");
			rfm.RFM_Admin_Update_PricingTags("false", "Display price type attribute as expanded by default");

			// Navigate to Rest Profile
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			// Select Restaurant Number hyperlink to which fee set is assigned
			actions.clear("RestaurantUpdt.SearchRestro");
			actions.setValue("RestaurantUpdt.SearchRestro", strRest);
			actions.click("MenuItemPriceandTaxByRestaurant.NBSearchButton");
			actions.smartWait(180);
			String strRestName = mcd.GetTableCellValue("AccessControlbyUser(s).DataGrid", 1, 2, "", "");
			WebElement Element = mcd.GetTableCellElement("AccessControlbyUser(s).DataGrid", 1, 1, "a");
			actions.click(Element);
			actions.smartWait(180);

			// Click on Operational Details tab & Click on the View /Edit
			// setting button against the Fee set field.
			actions.click("RestaurantProfile.OperationalDetailTab");
			actions.smartWait(180);
			actions.WaitForElementPresent("RestProfile.FeeSet");
			String DefaultValue = actions.getValue("RestProfile.FeeSet");
			String DDLValue = mcd.getdropdownvalues("RestProfile.FeeSet");
			String[] DDLList = DDLValue.split(",");
			if (DefaultValue.equals("Select")) {
				actions.setValue("RestProfile.FeeSet", DDLList[0]);
			}
			DefaultValue = actions.getValue("RestProfile.FeeSet");
			actions.click("RestProfile.FeeSetCustomize");
			mcd.waitAndSwitch("Fee Set");

			// Select a fee name i.e. fee1 by clicking on the fee name
			// hyperlink.
			List<WebElement> webEleFeeSet = driver.findElements(By.xpath(actions.getLocator("FeeSet.NameLink")));
			String strFeeSet = webEleFeeSet.get(0).getText();
			actions.click(webEleFeeSet.get(0));
			mcd.waitAndSwitch("Manage Fee");

			// Click on Customize Settings Button & Change value in value field
			if (actions.isElementPresent("TaxChainVerify.Customize")) {
				actions.click("TaxChainVerify.Customize");
			} else if (actions.isElementPresent("TaxChainVerify.ResetToDefault")) {
				actions.click("TaxChainVerify.ResetToDefault");
				mcd.VerifyAlertMessageDisplayed("Warning Message", "Are you sure you want to Reset to Default?", true,
						AlertPopupButton.OK_BUTTON);
				if (actions.isElementPresent("TaxChainVerify.Customize")) {
					actions.click("TaxChainVerify.Customize");
				}
			}

			int num = mcd.fn_GetRndNumInRange(0, 9);
			actions.clear("FeeSets.AllValue");
			actions.setValue("FeeSets.AllValue", num);

			// Click on Apply button & Switch to Restaurant Profile
			actions.click("RFMHome.Apply");
			actions.smartWait(20);
			try {
				mcd.SwitchToWindow("Apply Changes Details");
				actions.smartWait(20);
				actions.click("POSLayout.NBSaveButton");
				actions.waitForPageToLoad(120);
				mcd.waitAndSwitch("Manage Fee");
			} catch (Exception e) {
				System.out.println("Apply Changes Details is not dispalyed");
			}
			actions.keyboardEnter("DayPartSet.cancel");
			actions.waitForPageToLoad(120);
			mcd.waitAndSwitch("Fee Set");
			actions.click("DayPartSet.cancel");
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("Restaurant Profile");

			// Navigate to home page and check the audit log for update
			actions.select_menu("RFMHomePage.MainMenu", "HOME");
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");
			actions.setValue("RFMHomePage.AuditLogDuration", "Today");
			actions.WaitForElementPresent("RFMAuditLog.PPFirstRecord", 180);
			mcd.GetTableCellElement("RFMHomePage.AuditLog", "Operations", strOperation, "", "", "Id", "a")
					.sendKeys(Keys.ENTER);
			mcd.waitAndSwitch("Manage Audit Log");
			String ele = driver.findElement(By.xpath(actions.getLocator("PromotionManagement.TableFirstRow")))
					.getText();
			if (Double.parseDouble(ele.split("    ")[2]) == (num)) {
				actions.reportCreatePASS("Verify Price Value is Present", "Price Value should be Present",
						"Price Value is Present", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Price Value is Present", "Price Value should not be Present",
						"Price Value is not Present", "FAIL");
			}
			actions.keyboardEnter("RFMHomePage.AuditLogDetailsOKButton");
			mcd.SwitchToWindow("RFM - Home");

			// Navigate to ADMIN > Restaurant Profile
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			// Select Restaurant Number hyperlink to which fee set is assigned
			actions.clear("RestaurantUpdt.SearchRestro");
			actions.setValue("RestaurantUpdt.SearchRestro", strRest);
			actions.click("MenuItemPriceandTaxByRestaurant.NBSearchButton");
			actions.smartWait(120);
			strRestName = mcd.GetTableCellValue("AccessControlbyUser(s).DataGrid", 1, 2, "", "");
			Element = mcd.GetTableCellElement("AccessControlbyUser(s).DataGrid", 1, 1, "a");
			actions.click(Element);
			actions.smartWait(120);

			// Click on Operational Details tab & Click on the View /Edit
			// setting button against the Fee set field.
			actions.keyboardEnter("RestaurantProfile.OperationalDetailTab");
			actions.smartWait(180);
			String DefaultValue_2 = actions.getValue("RestProfile.FeeSet");
			String DDLValue_2 = mcd.getdropdownvalues("RestProfile.FeeSet");
			String[] DDLList_2 = DDLValue.split(",");
			if (DefaultValue_2.equals("Select")) {
				actions.setValue("RestProfile.FeeSet", DDLList_2[1]);
			}
			DefaultValue_2 = actions.getValue("RestProfile.FeeSet");

			// Select a fee name i.e. fee1 by clicking on the fee name
			// hyperlink.
			actions.click("RestProfile.FeeSetCustomize");
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("Fee Set");
			List<WebElement> webEleFeeSet_2 = driver.findElements(By.xpath(actions.getLocator("FeeSet.NameLink")));
			String strFeeSet_2 = webEleFeeSet_2.get(0).getText();
			actions.click(webEleFeeSet_2.get(0));
			actions.smartWait(20);
			mcd.waitAndSwitch("Manage Fee");

			// Click on Reset to Default button & Switch to Restaurant Profile
			if (actions.isElementPresent("TaxChainVerify.Customize")) {
				actions.click("TaxChainVerify.Customize");
			} else if (actions.isElementPresent("TaxChainVerify.ResetToDefault")) {
				actions.click("TaxChainVerify.ResetToDefault");
				mcd.VerifyAlertMessageDisplayed("Warning Message", "Are you sure you want to Reset to Default?", true,
						AlertPopupButton.OK_BUTTON);
			}
			actions.click("DayPartSet.cancel");
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("Fee Set");
			actions.click("DayPartSet.cancel");
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("Restaurant Profile");

			// Navigate to home page and check the audit log for Reset activity
			actions.select_menu("RFMHomePage.MainMenu", "HOME");
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");
			actions.setValue("RFMHomePage.AuditLogDuration", "Today");
			actions.WaitForElementPresent("RFMAuditLog.PPFirstRecord", 180);
			mcd.GetTableCellElement("RFMHomePage.AuditLog", "Operations", strOperation, "", "", "Id", "a")
					.sendKeys(Keys.ENTER);
			mcd.waitAndSwitch("Manage Audit Log");
			WebElement ele1 = null;
			ele1 = driver.findElement(By.xpath(actions.getLocator("PromotionManagement.TableFirstRow")));
			if (ele1.getText().equals("-")) {
				actions.reportCreatePASS("Verify Price Value is Present", "Price Value should be Present",
						"Price Value is not Present", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Price Value is Present", "Price Value should not be Present",
						"Price Value is Present", "FAIL");
			}
			actions.keyboardEnter("RFMHomePage.AuditLogDetailsOKButton");
			mcd.SwitchToWindow("RFM - Home");

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}
