/**
 * 
 */
package xtam.test;

/**
 * @author akrani
 *
 */
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class PRC_20279_MITSverfyMassUpdateTS {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private String FutureSettings;
	Integer rowCount = 0;
	boolean flag = false, flag1 = false;

	public PRC_20279_MITSverfyMassUpdateTS(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters
	}

	@Test
	public void test_PRC_20279_MITSverfyMassUpdateTS() throws InterruptedException {
		try {
			
			
			// Set Test Case Description
			actions.setTestcaseDescription("Verify the functionality of 'Mass Update Tax Settings' button");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			actions.keyboardEnter("TaxType.ViewFullListButton");
			actions.smartWait(10);
			actions.setValue("TenderSet.StatusDropDown", "Active");
			actions.smartWait(10);

			// Select the menu item tax set and validating whether Future
			// Settings already present or not
			rowCount = mcd.GetTableRowCount("ScriptManagement.TableNameValue");
			if (rowCount > 1) {
				for (int i = 1; i <= rowCount; i++) {
					FutureSettings = mcd.GetTableCellValue("ScriptManagement.TableNameValue", i, "Future Settings", "",
							"");
					if (FutureSettings.equals("")) {
						// Retrieving Tender Type Name of table
						WebElement ElementTaxSetNm = mcd.GetTableCellElement("ScriptManagement.TableNameValue", i,
								"Name", "a");
						actions.keyboardEnter(ElementTaxSetNm);
						break;
					}
				}
			} else if (rowCount == 1) {
				WebElement ElementTaxSetNm = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1, "Name", "a");
				actions.keyboardEnter(ElementTaxSetNm);
			} else {
				System.out.println("No Active Menu Item Tax Set Available ");
			}

			// switch to "Apply Changes Details" and switch to manage menu item
			// tax set
			mcd.SwitchToWindow("Apply Changes Details");
			actions.WaitForElementPresent("ApplyChangesDetails.MDSaveButton");
			actions.keyboardEnter("ApplyChangesDetails.MDSaveButton");
			mcd.SwitchToWindow("@Manage Menu Item Tax Set");
			actions.WaitForElementPresent("ManageMenuItemTaxSet.MassUpdateTaxSettings");

			// To click on MassUpdateTaxSettings button and switch to Manage Tax
			// Set window
			actions.keyboardEnter("ManageMenuItemTaxSet.MassUpdateTaxSettings");
			mcd.SwitchToWindow("Manage Tax Set");

			/* Verify the values TaxCode DDL on Manage Tax Set window */
			String exptectedValues_TaxCode = "Select#Always#Never#Optional";
			String str = null;
			Select ele_TaxCode;	
			boolean flag_TaxCode = false;
			ele_TaxCode = new Select(driver.findElement(By.xpath(actions.getLocator("ManageTaxSet.TaxCodeDropdown"))));
			
			//TaxCode DDL values Validation 
			for (int i = 0; i < ele_TaxCode.getAllSelectedOptions().size(); i++) {
				str = ele_TaxCode.getAllSelectedOptions().get(i).getText();
				if(exptectedValues_TaxCode.toLowerCase().contains(str.toLowerCase())){
					flag_TaxCode=true;
				}else{
					flag_TaxCode=false;
				}				
				if(!flag_TaxCode){				
					break;
				}				
			}						
			if(flag_TaxCode){
				actions.reportCreatePASS("Verify DDL values for TaxCode", exptectedValues_TaxCode+": values in DDL should present", "Values in Tax Code DDL are as Expected ", "PASS");
			}else{
				actions.reportCreateFAIL("Verify DDL values for TaxCode", exptectedValues_TaxCode+": values in DDL should present",  str+ ": Value in Tax Code DDL is not as expected", "FAIL");
			}
			
			
			/* Verify the values TaxCode DDL on Manage Tax Set window */
			String exptectedValues_TaxRule = "Select#BREAK_TABLE#EXCISE#FISCAL_PRINTER#FLAT#GST#PST#TAX_CHAIN#VAT";			
			Select TaxRule;	
			boolean flag_TaxRule = false;
			ele_TaxCode = new Select(driver.findElement(By.xpath(actions.getLocator("ManageTaxSet.TaxRuleDropdown"))));
			
			//TaxCode DDL values Validation 
			for (int i = 0; i < ele_TaxCode.getAllSelectedOptions().size(); i++) {
				str = ele_TaxCode.getAllSelectedOptions().get(i).getText();
				if(exptectedValues_TaxRule.toLowerCase().contains(str.toLowerCase())){
					flag_TaxCode=true;
				}else{
					flag_TaxCode=false;
				}				
				if(!flag_TaxCode){				
					break;
				}				
			}						
			if(flag_TaxCode){
				actions.reportCreatePASS("Verify DDL values for TaxRule", exptectedValues_TaxRule+": values in DDL should present", "Values in Tax Code DDL are as Expected ", "PASS");
			}else{
				actions.reportCreateFAIL("Verify DDL values for TaxRule", exptectedValues_TaxRule+": values in DDL should present",  str+ ": Value in Tax Code DDL is not as expected", "FAIL");
			}
			

			//Verify the alert popup
			actions.setValue("ManageTaxSet.TaxCodeDropdown", "Never");
			actions.click("RFMPresentationRoutingSetPage.CancelButton");
			boolean msgFlag1 = mcd.VerifyAlertMessageDisplayed("Warning message", "Unsaved data will be lost. Are you sure you want to proceed?", true, AlertPopupButton.CANCEL_BUTTON);
			if(msgFlag1){
				actions.reportCreatePASS("Verify the alert message", "Alert message should display", "Alert message is displayed as expected", "PASS");
			}else{
				actions.reportCreateFAIL("Verify the alert message", "Alert message should display", "Alert message is displayed is not as expected", "FAIL");
			}
			
			/*
			 * Select 'Tax code' as Never and click on apply button The DDL
			 * should show 'Never' and 'Tax Rule' and 'Tax Entry' Should be
			 * disabled.
			 */
			flag = driver.findElement(By.xpath(actions.getLocator("ManageTaxSet.TaxRuleDropdown"))).isEnabled();
			flag1 = driver.findElement(By.xpath(actions.getLocator("ManageTaxSet.TaxEntryDropdown"))).isEnabled();

			if (!(flag && flag1)) {
				actions.reportCreatePASS(
						"Verify The DDL should show 'Never' and 'Tax Rule' and 'Tax Entry' Should be disabled.",
						"The DDL should show 'Never' and 'Tax Rule' and 'Tax Entry' Should be disabled.",
						"The DDL should show 'Never' and 'Tax Rule' and 'Tax Entry' is disabled.", "Pass");
			} else {
				actions.reportCreateFAIL(
						"Verify The DDL should show 'Never' and 'Tax Rule' and 'Tax Entry' Should be disabled.",
						"The DDL should show 'Never' and 'Tax Rule' and 'Tax Entry' Should be disabled.",
						"The DDL should show 'Never' and 'Tax Rule' and 'Tax Entry' is disabled.", "Fail");
			}

			actions.keyboardEnter("ManageMenuItemTaxSet.ApplyButton");
			mcd.SwitchToWindow("Manage Menu Item Tax Set");

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}