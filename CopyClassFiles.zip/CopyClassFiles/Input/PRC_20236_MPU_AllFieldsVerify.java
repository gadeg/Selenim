package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class PRC_20236_MPU_AllFieldsVerify {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// Declare test-data variables for other data-parameters
	private String strMessageBeforeSave;
	private String strResultMessage;

	private String strEatingPrc;
	private String strTakeOutPrc;
	private String strOtherPrice;

	public PRC_20236_MPU_AllFieldsVerify(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// GetTestData for other data-parameters
		strMessageBeforeSave = mcd.GetTestData("MessageBeforeSave");
		strResultMessage = mcd.GetTestData("ResultMessage");
		strEatingPrc = mcd.GetTestData("EatingPrc");
		strTakeOutPrc = mcd.GetTestData("TakeOutPrc");
		strOtherPrice = mcd.GetTestData("OtherPrice");
	}

	@Test
	public void test_PRC_20236_MPU_AllFieldsVerify() throws InterruptedException {
		String strTestDescription = "Verify the error messages of Mass Update Prices functionality when �Eatin Prices�, �Takeout Prices� and �Other Prices� are entered";

		try {
			actions.setTestcaseDescription(strTestDescription);
			System.out.println("******************* Test execution starts*******************");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			// Verify Eating/Take-out/Other prices
			PriceActions.RFM_MUP_Eating_TO_Other_ErrCheck(strEatingPrc, strTakeOutPrc, strOtherPrice,
					strMessageBeforeSave, strResultMessage);

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);
		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}

	public boolean RFM_MUP_Eating_TO_Other_ErrCheck(String strEatingPrc, String strTakeOutPrc, String strOtherPrice,
			String strMessageBeforeSave, String strResultMessage) throws Exception {

		Boolean blnResult = false;
		Boolean test_AllStatus;
		String strAll_RadioValue, strRest_Value, strEating_Chkbx, strTO_Chkbx, strOther_Chkbx;

		// After navigating to Mass Update Price Page, adding Menu Items from
		// left to right, and Next adding Price sets from left to right
		PriceActions.RFM_PRC_MUP_Prerquisite();

		// Selecting Today's date (Today Button)
		Thread.sleep(1000);
		actions.click("UpdtMultipleSet.TodayBtn");
		Thread.sleep(1000);

		// Check default values/status of All Price Fields
		// All - default checked & enabled, Rest - disabled
		strAll_RadioValue = actions.getValue("VerifyFields.AllRadio");
		test_AllStatus = this.get_Field_Status("VerifyFields.AllRadio");
		strRest_Value = actions.getValue("VerifyFields.RestPrcRadio");

		strEating_Chkbx = actions.getValue("VerifyFields.EatingChkBx");
		strTO_Chkbx = actions.getValue("VerifyFields.TkOutChkBx");
		strOther_Chkbx = actions.getValue("VerifyFields.OtherChkBx");

		// Checking and validating for All price radio button
		if ((strAll_RadioValue.equals("true")) && (test_AllStatus)) {
			actions.reportCreatePASS("Verify All Price radio button", "Should be enabled & selected by default",
					"All Price radio button is enabled & selected by default", "PASS");
		} else {
			actions.reportCreateFAIL("Verify All Price radio button", "Should be enabled & selected by default",
					"All Price radio button is not enabled & selected by default", "FAIL");
		}

		// Check for the rest radio buttons of prices except all price field
		if (strRest_Value.equals("false")) {
			actions.reportCreatePASS("Verify rest of the price radio button", "Should be unchecked by default",
					"Rest of the price radio button not selected by default", "PASS");
		} else {
			actions.reportCreateFAIL("Verify rest of the price radio button", "Should be unchecked by default",
					"Rest of the price radio button selected by default", "FAIL");
		}

		// Checking Eating Price/ TO / Other radio buttons unchecked
		if ((strEating_Chkbx.equals("false")) && (strTO_Chkbx.equals("false")) && (strOther_Chkbx.equals("false"))) {
			actions.reportCreatePASS("Verify Eating Prc/TO/Other price radio button", "Should be unchecked by default",
					"Not selected by default", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Eating Prc/TO/Other price radio button", "Should be unchecked by default",
					"Selected by default", "FAIL");
		}

		// Eating price / TO / Other fields disabled
		if (!((this.get_Field_Status("VerifyFields.EatingPrc")) && this.get_Field_Status("VerifyFields.TkOutPrc")
				&& this.get_Field_Status("VerifyFields.OtherPrc"))) {
			actions.reportCreatePASS("Verify Eating Prc/TO/Other price fields", "Should be disabled by default",
					"Disabled by default", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Eating Prc/TO/Other price fields", "Should be disabled by default",
					"Enabled by default", "FAIL");
		}

		// Check Rest Prices Radio button
		// All Prices - disabled, Other Enabled
		actions.click("VerifyFields.RestPrcRadio");
		Thread.sleep(1000);

		strAll_RadioValue = actions.getValue("VerifyFields.AllRadio");
		test_AllStatus = this.get_Field_Status("VerifyFields.AllRadio");
		strRest_Value = actions.getValue("VerifyFields.RestPrcRadio");

		strEating_Chkbx = actions.getValue("VerifyFields.EatingChkBx");
		strTO_Chkbx = actions.getValue("VerifyFields.TkOutChkBx");
		strOther_Chkbx = actions.getValue("VerifyFields.OtherChkBx");

		if ((strAll_RadioValue.equals("true")) && (test_AllStatus)) {
			actions.reportCreateFAIL("Verify All radio button after, other price radio button is selected",
					"Should get unchecked & disabled", "Not unchecked or disabled", "FAIL");
		} else {
			actions.reportCreatePASS("Verify All radio button after, other price radio button is selected",
					"Should get unchecked & disabled", "Gets unchecked & disabled", "PASS");
		}

		if (strRest_Value.equals("true")) {
			actions.reportCreatePASS("Verify Rest prices radio button after being selected",
					"Should get checked & enabled", "Gets checked & enabled", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Rest prices radio button after being selected",
					"Should get checked & enabled", "Gets unchecked or is disabled", "FAIL");
		}

		// Eating Price / TO / Other radio button checked
		if ((strEating_Chkbx.equals("true")) && (strTO_Chkbx.equals("true")) && (strOther_Chkbx.equals("true"))) {
			actions.reportCreatePASS(
					"Verify Eating Prc/TO/Other price radio button after rest price check box is clicked",
					"Should remain unchecked", "Not yet selected", "PASS");
		} else {
			actions.reportCreateFAIL(
					"Verify Eating Prc/TO/Other price radio button after rest price check box is clicked",
					"Should remain unchecked", "Get Checked", "FAIL");
		}

		// Eating Price / TO / Other fields enabled
		if ((this.get_Field_Status("VerifyFields.EatingPrc")) && this.get_Field_Status("VerifyFields.TkOutPrc")
				&& this.get_Field_Status("VerifyFields.OtherPrc")) {
			actions.reportCreatePASS(
					"Verify Eating Prc/TO/Other price text fields after rest price check box is clicked",
					"Should get enabled", "Fields gets enabled", "PASS");
		} else {
			actions.reportCreateFAIL(
					"Verify Eating Prc/TO/Other price text fields after rest price check box is clicked",
					"Should get enabled", "Fields remain disabled", "FAIL");
		}

		// Validating input in Eating/TO/Other Price fields
		actions.setValue("VerifyFields.EatingPrc", "test1");
		actions.setValue("VerifyFields.TkOutPrc", "test2");
		actions.setValue("VerifyFields.OtherPrc", "test3");
		actions.click("UpdtMultipleSet.Apply");
		Thread.sleep(4000);

		Boolean VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", "Please enter a valid price.", true,
				AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg) {
			actions.reportCreatePASS("Verify numeric validation for Eating/TO/Other Price fields",
					"Only Numeric values should be allowed", "Only numeric values are allowed", "PASS");
			blnResult = true;
		} else {
			actions.reportCreateFAIL("Verify numeric validation for Eating/TO/Other Price fields",
					"Only Numeric values should be allowed", "Non-numeric values are allowed", "FAIL");
			blnResult = false;
		}
		
		// Clearing all the test values
		actions.clear("VerifyFields.EatingPrc");
		actions.clear("VerifyFields.EatingPrc");
		actions.clear("VerifyFields.TkOutPrc");
		actions.clear("VerifyFields.TkOutPrc");
		actions.clear("VerifyFields.OtherPrc");
		actions.clear("VerifyFields.OtherPrc");

		// Enter valid input in Eating/TO/Other Price fields
		actions.setValue("VerifyFields.EatingPrc", strEatingPrc);
		actions.setValue("VerifyFields.TkOutPrc", strTakeOutPrc);
		actions.setValue("VerifyFields.OtherPrc", strOtherPrice);
		actions.click("UpdtMultipleSet.Apply");
		Thread.sleep(2000);

		// Save & Apply Changes
		PriceActions.RFM_PRC_MUP_SaveAndApply(strMessageBeforeSave, strResultMessage);

		// Verifying correct prices are saved
		String Eating_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewEatingPrc")))
				.getAttribute("value");
		String TakeOut_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewTkOutPrc")))
				.getAttribute("value");
		String Other_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewOtherPrc")))
				.getAttribute("value");

		if ((Eating_Price.equals(strEatingPrc)) && (TakeOut_Price.equals(strTakeOutPrc))
				&& (Other_Price.equals(strOtherPrice))) {
			actions.reportCreatePASS("Verify Price Update",
					"All Prices/Eating/Take out/Other Prices should be saved correctly", "Updated Correctly", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Price Update",
					"All Prices/Eating/Take out/Other Prices should be saved correctly", "Not Updated Correctly",
					"FAIL");
		}
		return blnResult;
	}
	// function to check enabled or disabled
	public boolean get_Field_Status(String strLocator) {
		Boolean Field_Status;
		Field_Status = driver.findElement(By.xpath(actions.getLocator(strLocator))).isEnabled();
		return Field_Status;
	}
}
