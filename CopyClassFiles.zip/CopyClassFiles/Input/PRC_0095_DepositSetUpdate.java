package xtam.test;

import java.util.Map;

import org.apache.poi.poifs.property.Parent;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.thoughtworks.selenium.Selenium;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class PRC_0095_DepositSetUpdate {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private String strRegion;
	private String strAuditUser,strSucessmsg;
	

	public PRC_0095_DepositSetUpdate(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strRegion = mcd.GetTestData("REGION");
		strAuditUser = mcd.GetTestData("AUDIT_USER");
		strSucessmsg = mcd.GetTestData("SUCESSMSG");

	}

	@Test
	public void PRC_0095_DepositSetUpdate() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription(
					"Update Deposit set for current settings and verify that System does not compare customized values with master values and verify the audit log.");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();
			// ------------------------------------------------------------------------

			// Search Deposit set which is to be updated & Click on the 'Name'
			// link
			actions.click("PriceSet.SearchBtn");
			actions.smartWait(180);
			WebElement eleDSNm = mcd.GetTableCellElement("RFM.WebTable", 2, "Name", "a");
			String ele = eleDSNm.getText();
			actions.clear("Deposit.DSSearchBox");
			actions.setValue("Deposit.DSSearchBox", ele);
			actions.keyboardEnter("PriceSet.SearchBtn");
			actions.smartWait(180);
			WebElement eleDSNm1 = mcd.GetTableCellElement("RFM.WebTable", 1, "Name", "a");
			actions.click(eleDSNm1);
			actions.smartWait(20);
			actions.WaitForElementPresent("RFM.Apply", 20);

			// Click on 'Add Deposit' button & Select deposit 'Dep1' by checking
			// the check box
			String elem = driver.findElement(By.xpath(actions.getLocator("DepositSet.TableFirstValue"))).getText();
			actions.click("Deposit.AddDeposit");
			mcd.waitAndSwitch("Add Deposit");
			WebElement eleChkDS = mcd.GetTableCellElement("Deposit.AddDepositTable", 1, 1, "input");
			eleChkDS.sendKeys(Keys.SPACE);

			// Click on 'Continue' button & Click on 'Apply' button
			actions.keyboardEnter("Deposit.AddDepositContinue");
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("@Deposit Sets");
			actions.keyboardEnter("RFM.Apply");
			actions.smartWait(120);
			actions.verifyTextPresence("Your changes have been saved.", true);

			// Click on 'Advance Settings' icon under 'View/Edit settings' &
			// Verify all fileds are present
			actions.click("ManagePackagesPackagesReport.sort");
			mcd.waitAndSwitch("Manage Deposit");
			actions.waitForPageToLoad(80);
			if (actions.isElementPresent("DepositSet.AllPrices")) {
				actions.reportCreatePASS("Verify Price Value is Present", "Price Value should be Present",
						"Price Value is Present", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Price Value is Present", "Price Value should be Present",
						"Price Value is not Present", "FAIL");
			}
			if (actions.isElementPresent("DepositSet.TaxCode")) {
				actions.reportCreatePASS("Verify Tax Code is Present", "Tax Code should be Present",
						"Tax Code is Present", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Tax Code is Present", "Tax Code should be Present",
						"Tax Code is not Present", "FAIL");
			}
			if (actions.isElementPresent("DepositSet.TaxRule")) {
				actions.reportCreatePASS("Verify Tax Rule is Present", "Tax Rule should be Present",
						"Tax Rule is Present", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Tax Rule is Present", "Tax Rule should be Present",
						"Tax Rule is not Present", "FAIL");
			}
			if (actions.isElementPresent("DepositSet.AllTaxEntry")) {
				actions.reportCreatePASS("Verify Tax Entry is Present", "Tax Entry should be Present",
						"Tax Entry is Present", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Tax Entry is Present", "Tax Entry should be Present",
						"Tax Entry is not Present", "FAIL");
			}

			// Click on 'Customize Settings' button & All disabled fields get
			// enabled except 'Deposit ID' and 'Deposit Name'.
			String ele1 = driver.findElement(By.xpath(actions.getLocator("FeeSets.CustomizeBtn"))).getText();
			if (ele1.equalsIgnoreCase("Reset to Default"))
			{
				actions.click("SmartReminderSets.ResetDefaultBtn");
				actions.acceptAlert();
			}
			actions.WaitForElementPresent("TaxChainVerify.Customize");
			actions.keyboardEnter("TaxChainVerify.Customize");

			if (!(actions.isElementEnabled("DepositSet.DepositId"))) {
				actions.reportCreatePASS("Verify Deposit Id is Present", "Deposit Id should be disabled",
						"Deposit Id is disabled", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Deposit Id is Present", "Deposit Id should be disabled",
						"Deposit Id is not disabled", "FAIL");
			}
			if (!(actions.isElementEnabled("DepositSet.DepositName"))) {
				actions.reportCreatePASS("Verify Deposit Name is Present", "Deposit Name should be disabled",
						"Deposit Name is disabled", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Deposit Name is Present", "Deposit Name should be disabled",
						"Deposit Name is not disabled", "FAIL");
			}

			actions.click("MassStatusUpdateUMMIS.CancelBtn");
			actions.waitForPageToLoad(80);
			mcd.SwitchToWindow("@Deposit Sets");

			// Change 'Deposit Type' to 'Select' & Click on 'Apply'
			// button,Verify Alert Msg
			actions.click("ManagePackagesPackagesReport.sort");
			mcd.waitAndSwitch("Manage Deposit");
			actions.waitForPageToLoad(80);
			actions.keyboardEnter("TaxChainVerify.Customize");
			actions.setValue("DepositSet.DepositType", "Select");
			actions.keyboardEnter("RestProfile.FSApplyBtn");
			Boolean blMessage = mcd.VerifyAlertMessageDisplayed("Waring Message", "Please select Deposit Type", true,
					AlertPopupButton.OK_BUTTON);
			if (blMessage) {
				actions.reportCreatePASS("Verify the Alert Message",
						"Message Please select Deposit Type should be displayed",
						"Message Please select Deposit Type is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the Alert Message",
						"Message Please select Deposit Type should be displayed",
						"Message Please select Deposit Type is not displayed", "FAIL");
			}

			// Change 'Deposit Type' to 'Rate' & Click on 'Apply' button,Verify
			// Alert Msg
			actions.setValue("DepositSet.DepositType", "Rate");
			actions.click("RestProfile.FSApplyBtn");
			actions.smartWait(20);
			actions.verifyTextPresence("Your changes have been saved.", true);
			boolean value = mcd.fn_VerifyWebObjectsDisplayed("DepositSet.RedAstrixSymbol");
			actions.smartWait(20);
			if (value) {
				actions.reportCreatePASS("Verify the Red Astrik Symbol",
						"Red Astrik Symbol should be displayed for Deposit Type", "Red Astrik symbol is displayed",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify the Red Astrik Symbol",
						"Red Astrik Symbol should be displayed for Deposit Type", "Red Astrik symbol is not displayed",
						"FAIL");
			}

			actions.click("MassStatusUpdateUMMIS.CancelBtn");
			actions.waitForPageToLoad(80);
			mcd.SwitchToWindow("@Deposit Sets");

			// Change 'Deposit Type' to 'Amount'& Click on 'Apply' button,Verify
			// Alert Msg
			actions.click("ManagePackagesPackagesReport.sort");
			mcd.waitAndSwitch("Manage Deposit");
			actions.waitForPageToLoad(80);
			actions.WaitForElementPresent("RestProfile.FSApplyBtn");
			actions.setValue("DepositSet.DepositType", "Amount");
			actions.click("RestProfile.FSApplyBtn");
			actions.smartWait(20);
			actions.verifyTextPresence("Your changes have been saved.", true);
			actions.click("MassStatusUpdateUMMIS.CancelBtn");
			actions.waitForPageToLoad(80);
			mcd.SwitchToWindow("@Deposit Sets");
			actions.click("ManagePackagesPackagesReport.sort");
			mcd.waitAndSwitch("Manage Deposit");
			actions.waitForPageToLoad(80);
			
			//Click on 'Reset to default' button & Dismiss Alert,Accept Alert
			actions.click("SmartReminderSets.ResetDefaultBtn");
			actions.dismissAlert();
			actions.click("SmartReminderSets.ResetDefaultBtn");
			actions.acceptAlert();
			actions.WaitForElementPresent("MassStatusUpdateUMMIS.CancelBtn", 50);
			Thread.sleep(20000);
			actions.click("MassStatusUpdateUMMIS.CancelBtn");
			actions.waitForPageToLoad(80);
			mcd.SwitchToWindow("@Deposit Sets");
			
			// Verify Audit log
			Boolean blnAudit = false;
			blnAudit = rfm.VerifyAuditLog_Entry("Deposit Set", "Update", strRegion);
			if (blnAudit) {
				actions.reportCreatePASS("Verify Audit Log Entry for Update Deposit Set",
						"Audit log should be generated for Update Deposit Set",
						"Audit log generated for Update Deposit Set succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Entry for Update Deposit Set",
						"Audit log should be generated for Update Deposit Set",
						"Audit log not generated for Update Deposit Set succesfully", "FAIL");
			}

			blnAudit = rfm.RFM_VerifyAuditLog_Details("RFM2", strAuditUser, "Deposit Set", "Update", strRegion,
					strMarket, "Deposit " + elem + " in the Current Settings of DepositSet " + ele
							+ " has been reset to default.");
			if (blnAudit) {
				actions.reportCreatePASS("Verify Audit Log Details for Update Deposit Set",
						"Audit log details should be generated for Update Deposit Set",
						"Audit log details generated for Deposit Set item succesfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Details for Update Deposit Set",
						"Audit log details should be generated for Update Deposit Set",
						"Audit log details not generated for Deposit Set item succesfully", "FAIL");
			}

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}