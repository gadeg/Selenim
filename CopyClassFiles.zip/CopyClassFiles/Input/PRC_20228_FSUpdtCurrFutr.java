package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class PRC_20228_FSUpdtCurrFutr {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private String strSuccessMsg;
	private String strUpdateMsg;
	private String[] strFields;

	public PRC_20228_FSUpdtCurrFutr(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters

		strSuccessMsg = mcd.GetTestData("SUCCESS_MSG");
		strUpdateMsg = mcd.GetTestData("UPDATE_MSG");
		strFields = mcd.GetTestData("FIELD_LOCATORS").split("#");
	}

	@Test
	public void test_PRC_20228FSUpdtCurrFutr() throws InterruptedException {

		try {
			actions.setTestcaseDescription(
					"To verify the Current Settings and Future Settings pop-up for Inactive Fee Sets.");

			System.out.println(
					"********************************************************************** Test execution starts");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------Actions
			// specific to test-flow

			// View Full List
			actions.click("RFM.SearchBtn");
			Thread.sleep(1000);
			actions.smartWait(120);
			// Adding a new fee set
			actions.click("MasterFee.NewFeeBtn");
			mcd.SwitchToWindow("Add New Fee Set");
			String Newfeeset = mcd.fn_GetRndName("feeset");
			actions.setValue("FeeSet.NewFeeSetName", Newfeeset);
			actions.click("Deposit.DSSelectNode");
			// selecting node
			mcd.SwitchToWindow("Select Node");
			mcd.Selectrestnode_JavaScriptClk("RFMSelectNode.SelectNodeTable", strMarket);
			mcd.SwitchToWindow("Add New Fee Set");
			actions.click("UpdateSet.NextBtn");
			// Creating new fee set
			mcd.SwitchToWindow("@Create Fee Set ");
			actions.click("ManageTenderTypeSet.AddTenderTypeBtn");
			mcd.SwitchToWindow("Add Fee");
			// Adding a fee
			int RN = mcd.GetTableRowNumber("RFMManageTenderType.TenderTypeTable", "Status", "Active", "", "");
			actions.click(mcd.GetTableCellElement("RFMManageTenderType.TenderTypeTable", RN, 1, "Input"));
			actions.click("Deposit.AddDepositContinue");
			mcd.SwitchToWindow("@Title");
			actions.click("RFMQueueRoutingPopupPage.SaveButton");
			//Clicking cancel button 
			actions.click("WorkflowsUpdateWorkflow.cancel");
			actions.click("RFMProductionRoutingSetPage.searchRouteIDButton");
			actions.smartWait(10);
			actions.setValue("ParameterSet.Name", Newfeeset);
			actions.click(mcd.GetTableCellElement("ScreenSet.dataTable", 1, 1, "a"));
			//Changing the status to inactive
			actions.setValue("Fee.FSStatus", "Inactive");
			actions.smartWait(200);
			actions.click("RFMQueueRoutingPopupPage.SaveButton");
			
			actions.click("RFMQueueRoutingPopupPage.SaveButton");
			
			
			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}