package xtam.test;

import java.util.Map;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import org.openqa.selenium.WebElement;

import crossbrowser.library.Keywords;
import crossbrowser.library.PackageValidation;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.XMLValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class PRC_1037Roles_MasterFee {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private XMLValidations xmlValidation;
	private PackageValidation pkg;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo, Feetype, strErrMsg, strScsMsg, strwm, Expectfeetype[];
	private boolean flag1;
	// TODO: Declare test-data variables for other data-parameters

	public PRC_1037Roles_MasterFee(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		pkg = new PackageValidation(driver, actions, uiActions, inputData, mcd, rfm);
		xmlValidation = new XMLValidations();

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		Feetype = mcd.GetTestData("DT_DropDown");
		strErrMsg = mcd.GetTestData("DT_ErrMsg");
		strScsMsg = mcd.GetTestData("DT_SuccessMsg");
		strwm		= mcd.GetTestData("DT_WarningMessage");
		// TODO: GetTestData for other data-parameters
		Expectfeetype = Feetype.split("#");
	}

	@Test
	public void test_PRC_1037Roles_MasterFee() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription(
					"Verify that user is able to create and update the master fee when Full Access permission is assigned to user through Role");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Actions specific to test-flow

			// Create Master Fee
			actions.click("MasterFee.NewFeeBtn");
			actions.smartWait(50);

			String MasterFee = mcd.fn_GetRndName("Master");
			System.out.println(MasterFee);

			actions.clear("MasterFee.FeeName");
			actions.setValue("MasterFee.FeeName", MasterFee);
			actions.setValue("MasterFee.FeeType", Expectfeetype[0]);
			actions.smartWait(50);
			actions.setValue("FeeSets.AllValue", "5");

			int randomNum = mcd.fn_GetRndNumInRange(0, 99);
			System.out.println(randomNum);
			String strI = "" + randomNum;
			System.out.println(strI);
			actions.setValue("MasterFee.FeeId", strI);
			actions.click("ApplyChangePopup.SaveButton");
			actions.smartWait(50);
			boolean flag = false, flagFeeId = false;
			do {
				try {
					// Verify Error Messsage
					flagFeeId = mcd.VerifyOnscreenMessage("MasterFee.Header", strErrMsg, true);
					if (flagFeeId) {
						actions.clear("MasterFee.FeeId");
						// Enetr Unique Fee Id
						Random rand_num = new Random();
						int strNewFeeiD = rand_num.nextInt((99) + 5);
						System.out.println(strNewFeeiD);
						actions.setValue("MasterFee.FeeId", Integer.toString(strNewFeeiD));
						actions.keyboardEnter("ApplyChangePopup.SaveButton");
						actions.smartWait(10);
					}
				} catch (Exception ee) {
					actions.WaitForElementPresent("ManageFee.SSMsg", 180);
					flag = mcd.VerifyOnscreenMessage("ManageFee.SSMsg", strScsMsg, true);
					flagFeeId = false;
				}
			} while (flagFeeId);

			boolean SuccessMsg = mcd.VerifyOnscreenMessage("ManageFee.SSMsg", strScsMsg, true);
			if (SuccessMsg) {
				actions.reportCreatePASS("Verify Master Fee is created", "Master Fee should be created",
						"Master Fee Created", "Pass");
			} else {
				actions.reportCreateFAIL("Verify Master Fee is created", "Master Fee should be created",
						"Master Fee not created", "Fail");
			}

			// Updated the master fee
			actions.smartWait(30);
			actions.click("MasterFee.CancelBtn");
			mcd.SwitchToWindow("@Title");
			actions.clear("MasterFee.SearchBox");
			actions.setValue("MasterFee.SearchBox", MasterFee);
			actions.click("MasterFee.SearchBtn");
			actions.smartWait(30);
			WebElement fistValue = mcd.GetTableCellElement("RFM.WebTable", 1, "Fee Name", "a/pre");
			actions.click(fistValue);
			actions.smartWait(50);
			/*String FeeName = driver.findElement(By.xpath(actions.getLocator("MasterFee.FeeName")))
					.getAttribute("value");
			String newFeeName;
			newFeeName = mcd.fn_GetRndAlphabaticString(3);
			FeeName = FeeName.substring(0, FeeName.length() - 2) + newFeeName;
			actions.clear("MasterFee.FeeName");
			actions.setValue("MasterFee.FeeName", FeeName);*/
			actions.setValue("MasterFee.FeeType", Expectfeetype[1]);
			actions.smartWait(50);

			// Click on Save Button
			actions.smartWait(30);
			actions.click("ManageDeposit.ApplyButton");
			/*mcd.waitAndSwitch("Apply Changes Details");
			actions.javaScriptClick("ApplyChangePopup.SaveButton");*/

			/*try {
				driver.switchTo().window("");
			} catch (Exception e) {

			}
			mcd.VerifyAlertMessageDisplayed("Warning", strwm, true, AlertPopupButton.OK_BUTTON);*/
			/*mcd.SwitchToWindow("@Title");*/
			actions.smartWait(30);

			flag1 = mcd.VerifyOnscreenMessage("ManageFee.SSMsg", "Your changes have been saved.", true);

			if (flag1) {
				actions.reportCreatePASS("Verify the on-screen message", "Message 'Your changes have been saved'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message", "Message 'Your changes have been saved.'",
						"Expected Message is not displayed", "FAIL");
			}
			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}
