package xtam.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class PRC_0120_UpdtPrcSet_CopyTax {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters

	private String strApplicationDate;
	private String strNewPrice;
	private String strTaxCode;
	private String strTaxRule;
	private String strAlertMsg, strNavigateToAdmin;

	public PRC_0120_UpdtPrcSet_CopyTax(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters

		strNewPrice = mcd.GetTestData("FuturePrice");
		strTaxCode = mcd.GetTestData("TaxCode");
		strTaxRule = mcd.GetTestData("TaxRule");
		strAlertMsg = mcd.GetTestData("AlertMsg");
		strNavigateToAdmin = mcd.GetTestData("DT_NAVIGATE_TO_ADMIN");
	}

	@Test
	public void PRC_0120_UpdtPrcSet_CopyTax() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			/** Get Test case Description */
			actions.setTestcaseDescription("Verify Update Price Set Details (Copy Tax) functionality of price set");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateToAdmin);
			actions.select_menu("RFMHome.Navigation", strNavigateToAdmin);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// Aotomating the Pre - Req
			rfm.RFM_Admin_Update_PricingTags("false", "Restrict price type attribute from expanding");
			rfm.RFM_Admin_Update_PricingTags("false", "Display price type attribute as expanded by default");
			actions.waitForPageToLoad(120);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(180);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			Actions builder = new Actions(driver);
			builder.moveByOffset(0, 500).click().perform();

			// Updating price set details
			RFM_PRC_UpdatePriceSet_CopyTax(strNewPrice, strTaxCode, strTaxRule, strAlertMsg);

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	
	public void RFM_PRC_UpdatePriceSet_CopyTax(String strNewPrice, String strTaxCode, String strTaxRule,
			String strAlertMsg) throws InterruptedException {

		String Future_Date = null;
		String Price_Set_Name;

		// Taking row count of price set and checking price set is assigned to
		// restaurant or not
		int rw_cnt = mcd.GetTableRowCount("Price.PriceSets");
		for (int i = 1; i < rw_cnt; i++) {
			try {
				Boolean temp = driver.findElement(By.xpath("//*[@id='priceSetData']/tr[" + i + "]/td[1]/span/img"))
						.isDisplayed();
				if (temp) {
					Price_Set_Name = driver.findElement(By.xpath("//*[@id='priceSetData']/tr[" + i + "]/td[1]/a"))
							.getText();

					driver.findElement(By.xpath("//*[@id='priceSetData']/tr[" + i + "]/td[1]/a")).click();
					Thread.sleep(5000);
					break;
				}
			} catch (Exception e) {
				System.out.println("This price set is not attached to any restaurant");
			}
		}

		// Verify that Copy Tax button is disabled
		if (!actions.isElementEnabled("ManagePS.CpyTaxBtn")) {
			actions.reportCreatePASS("Verify Copy Tax button", "Copy Tax button should be DISABLE by default",
					"Copy Tax button is DISABLE by default", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Copy Tax button", "Copy Tax button should be DISABLE by default",
					"Copy Tax button is  NOT DISABLE by default", "FAIL");
		}

		// Verifying search text box is editable
		String search_text = driver.findElement(By.xpath(actions.getLocator("ProductionRouting.SearchTextField")))
				.getAttribute("type");
		if (search_text.equals("text")) {
			actions.reportCreatePASS("Verify Search text box", "Search text box should be editable",
					"Search text box is editable", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Search text box", "Search text box should be editable",
					"Search text box is not editable", "FAIL");
		}

		// Verifying Change by date link enable
		if (actions.isElementEnabled("PriceSets.Changesbydate")) {

			actions.reportCreatePASS("Verify Change by date link", "Change by date link should be enable",
					"Change by date link is enable", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Change by date link", "Change by date link should be enable",
					"Change by date link is not enable", "FAIL");
		}

		// Verifying Future Changes by menu item
		if (actions.isElementEnabled("PriceSets.SBFutureChngMITab")) {

			actions.reportCreatePASS("Verify Future Changes by menu item link",
					"Future Changes by menu item should be enable", "Future Changes by menu item is enable", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Future Changes by menu item link",
					"Future Changes by menu item should be enable", "Future Changes by menu item is not enable",
					"FAIL");
		}
		// Verifying Add/Remove Menu Item button
		if (actions.isElementEnabled("ManageMenuItemTaxSet.AddRemoveMenuItem")) {

			actions.reportCreatePASS("Verify Add/Remove Menu Item button",
					"Add/Remove Menu Item button should be enable", "Add/Remove Menu Item button is enable", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Add/Remove Menu Item button",
					"Add/Remove Menu Item button should be enable", "Add/Remove Menu Item button is not enable",
					"FAIL");
		}

		// Verifying Pricing dropdown enable
		if (actions.isElementEnabled("PriceSets.PricingDropDown")) {

			actions.reportCreatePASS("Verify Pricing dropdown", "Pricing dropdown should be enable",
					"Pricing dropdown is enable", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Pricing dropdown", "Pricing dropdown should be enable",
					"Pricing dropdown is not enable", "FAIL");
		}

		/*
		 * //Verifying Mass Update Tax Settings button is disable
		 * if(!actions.isElementEnabled("ManagePS.UpdtTaxBtn2")){
		 * 
		 * actions.reportCreatePASS("Verify Mass Update Tax Settings",
		 * "Mass Update Tax Settings should be disable",
		 * "Mass Update Tax Settings is disable", "PASS"); }else{
		 * actions.reportCreateFAIL("Verify Mass Update Tax Settings",
		 * "Mass Update Tax Settings should be disable",
		 * "Mass Update Tax Settings is not disable", "FAIL"); }
		 * 
		 * 
		 * 
		 * //Verifying Copy Tax button Disabled
		 * if(!actions.isElementEnabled("ManagePS.CpyTaxStatus")){
		 * 
		 * actions.reportCreatePASS("Verify Copy Tax button",
		 * "Copy Tax button should be disable", "Copy Tax button is disable",
		 * "PASS"); }else{ actions.reportCreateFAIL("Verify Copy Tax button",
		 * "Copy Tax button should be disable", "Copy Tax button is not disable"
		 * , "FAIL"); }
		 */

		// Verifying Apply button enable
		if (actions.isElementEnabled("PriceSet.ApplyButton")) {

			actions.reportCreatePASS("Verify Apply button", "Apply button should be enable", "Apply button is enable",
					"PASS");
		} else {
			actions.reportCreateFAIL("Verify Apply button", "Apply button should be enable",
					"Apply button is not enable", "FAIL");
		}

		// Verifying Cancel button enable
		if (actions.isElementEnabled("RFM.CancelBtn")) {

			actions.reportCreatePASS("Verify Cancel button", "Cancel button should be enable",
					"Cancel button is enable", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Cancel button", "Cancel button should be enable",
					"Cancel button is not enable", "FAIL");
		}

		// Verifying Activate All Menu Items check box Enabled
		String check_en = driver.findElement(By.xpath(actions.getLocator("RFMPRC.ActivateMenuItemChk")))
				.getAttribute("value");
		if (check_en.equals("true")) {
			actions.reportCreatePASS("Verifying Activate All Menu Items check box ",
					"Activate All Menu Items check box should be enable", "Activate All Menu Items check box is enable",
					"PASS");
		} else {
			actions.reportCreateFAIL("Verifying Activate All Menu Items check box ",
					"Activate All Menu Items check box should be enable",
					"Activate All Menu Items check box is NOT enable", "FAIL");
		}

		/*
		 * //Activate Selected Menu Items (Disabled) String
		 * check_dis=driver.findElement(By.xpath(actions.getLocator(
		 * "PriceSets.Disablecheck"))).getAttribute("disable");
		 * if(check_dis.equals("disable")) { actions.reportCreatePASS(
		 * "Verifying Activate Selected Menu Itemss check box ",
		 * "Activate Selected Menu Items check box should be disable",
		 * "Activate Selected Menu Items check box is disable", "PASS"); }else{
		 * actions.reportCreateFAIL(
		 * "Verifying Activate Selected Menu Items check box ",
		 * "Activate Selected Menu Items check box should be disable",
		 * "Activate Selected Menu Items check box is NOT disable", "FAIL"); }
		 */

		

		// Click on future date to click on view tax details
		driver.findElement(By.xpath(actions.getLocator("ManagePS.FutureDate"))).click();
		actions.smartWait(100);
		try {

			if (mcd.fn_VerifyWebObjectsDisplayed("ManagePS.ViewTxDetails")) {
				actions.click("ManagePS.ViewTxDetails");
				Thread.sleep(3000);
				actions.smartWait(180);

			} else {
				actions.click("ManagePS.ViewPrcDetails");
				actions.smartWait(100);
				actions.smartWait(180);
				actions.javaScriptClick("ManagePS.ViewTxDetails");
				actions.smartWait(100);
				System.out.println("Clicked on View Tax Details button");
			}
		} catch (Exception e) {

		}

		// Click on View Price Details button
		actions.click("ManagePS.ViewPrcDetails");
		actions.smartWait(180);
		mcd.SelectDate_OpenCalender("17", "next");
		actions.smartWait(180);
		String Date_displayed = driver.findElement(By.xpath(actions.getLocator("ManagePS.DateSelected"))).getText();
		actions.click("ManagePS.ViewTxDetails");
		Thread.sleep(15000);

		// Verification : Tax Code - Never ; Tax Rule & Tax Entry are
		// automatically set to None Enter any valid price
		actions.clear("PriceTypes.All");
		actions.setValue("PriceTypes.All", "5.00");
		actions.setValue("PriceTypes.TaxCode", "Never");
		actions.smartWait(180);

		Boolean VerifyPopUpMsg = false;
		// String VerifyPopUpMsg;
		// Pop Up message verification in case any
		try {
			
			VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error",
					"Tax cannot be applied to Menu Item as they are not priced.", true, AlertPopupButton.OK_BUTTON);
		} catch (Exception e) {
			System.out.println(e);
		}

		actions.setValue("PriceTypes.TaxCode", "Never");
		actions.smartWait(180);
		Select select1 = new Select(driver.findElement(By.xpath(actions.getLocator("PriceTypes.TaxEntry"))));
		Select select2 = new Select(driver.findElement(By.xpath(actions.getLocator("PriceTypes.TaxRule"))));
		actions.smartWait(180);


		// Verify tax rule & entry becomes none & disabled
		if (select1.getFirstSelectedOption().getText().equals("None")
				&& (select2.getFirstSelectedOption().getText().equals("None"))) {
			if (!(driver.findElement(By.xpath(actions.getLocator("PriceTypes.TaxEntry"))).isEnabled())
					&& !(driver.findElement(By.xpath(actions.getLocator("PriceTypes.TaxRule"))).isEnabled())) {

				actions.reportCreatePASS("Verify Tax fields",
						"For tax code as Never, tax entry and tax rule should be set to None",
						"For tax code as Never, tax entry and tax rule is set to None", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Tax fields",
						"For tax code as Never, tax entry and tax rule should be set to None",
						"For tax code as Never, tax entry and tax rule is not set to None", "FAIL");

			}
		}

		// To verify COPY TAX Make some tax settings to verify copy tax
		actions.setValue("PriceTypes.TaxCode", strTaxCode);
		actions.setValue("PriceTypes.TaxRule", strTaxRule);
		Select select = new Select(driver.findElement(By.xpath(actions.getLocator("PriceTypes.TaxEntry"))));
		select.selectByIndex(2);
		actions.smartWait(180);

		// Apply changes
		actions.click("FutureSettings.Apply");
		actions.smartWait(180);
		actions.verifyTextPresence("Your changes have been saved.", true);

		// Get Previous setting tax values for code/rule/entry
		String Curr_TaxCode = driver.findElement(By.xpath(actions.getLocator("ManagePS.PrevTaxCode"))).getText();
		if (Curr_TaxCode.equals("N/A")) {
			Curr_TaxCode = "Never";
		}
		String Curr_TaxRule = driver.findElement(By.xpath(actions.getLocator("ManagePS.PrevTaxRule"))).getText();
		if (Curr_TaxRule.equals("N/A")) {
			Curr_TaxRule = "None";
		}
		String Curr_TaxEntry = driver.findElement(By.xpath(actions.getLocator("ManagePS.PrevTaxEntry"))).getText();
		if (Curr_TaxEntry.equals("N/A")) {
			Curr_TaxEntry = "None";
		}

		System.out.println(Curr_TaxCode + ";" + Curr_TaxRule + ";" + Curr_TaxEntry);
		actions.smartWait(180);

		// Select future date link in the future price changes part
		List<WebElement> FutureDate_list = driver.findElements(By.xpath("//*[@id='futureEffectiveDate']/option"));
		int dt_row = FutureDate_list.size();
		int Temp_count = 0;

		for (int a = 1; a <= dt_row; a++) {

			try {
				Thread.sleep(2000);
				WebElement FDate = driver.findElement(By.xpath("//*[@id='futureEffectiveDate']/option[" + a + "]"));
				Future_Date = FDate.getText();
				Thread.sleep(1000);

				if (Date_displayed.equals(Future_Date)) {
					System.out.println("desired future date");
					Temp_count++;
					break;
				} else {
					System.out.println("not desired future date");
				}

			} catch (Exception e) {
				System.out.println("Not able to find date : " + e);
			}
		}

		if (Temp_count > 0) {
			actions.reportCreatePASS("Verify date",
					"Correct future date should be displayed on future price changes area",
					"Correct future date is displayed on future price changes area", "PASS");
		} else {
			actions.reportCreateFAIL("Verify date",
					"Correct future date should be displayed on future price changes area",
					"Incorrect future date is not displayed on future price changes area", "FAIL");

		}

		// Verify that Mass Update Tax Settings button is displayed & enabled

		try {
			if (driver.findElement(By.xpath(actions.getLocator("ManagePS.MassTaxUpdateBtn"))).isDisplayed()) {
				if ((driver.findElement(By.xpath(actions.getLocator("ManagePS.MassTaxUpdateBtn"))).isEnabled())) {
					actions.reportCreatePASS("Verify Future Settings Applied : Mass Update Tax Settings button",
							"Mass Update Tax Settings button should be displayed & enabled",
							"Mass Update Tax Settings button is displayed & enabled", "PASS");

				} else {
					actions.reportCreateFAIL("Verify Future Settings Applied : Mass Update Tax Settings button",
							"Mass Update Tax Settings button should be displayed & enabled",
							"Mass Update Tax Settings button is displayed but disabled", "FAIL");

				}
			}
		} catch (Exception e) {
			actions.reportCreateFAIL("Verify Future Settings Applied : Mass Update Tax Settings button",
					"Mass Update Tax Settings button should be displayed & enabled",
					"Mass Update Tax Settings button is not displayed", "FAIL");

		}

		// Verify that Change Date button is displayed & enabled
		try {
			if (driver.findElement(By.xpath(actions.getLocator("ManagePS.ChngeDateBtn"))).isDisplayed()) {
				if ((driver.findElement(By.xpath(actions.getLocator("ManagePS.ChngeDateBtn"))).isEnabled())) {

					actions.reportCreatePASS("Verify Future Settings Applied : Change Date button",
							"Change Date button should be displayed & enabled",
							"Change Date button is displayed and enabled", "PASS");
				} else {

					actions.reportCreateFAIL("Verify Future Settings Applied : Change Date button",
							"Change Date button should be displayed & enabled",
							"Change Date button is displayed but disabled", "FAIL");
				}
			}
		} catch (Exception e) {
			actions.reportCreateFAIL("Verify Future Settings Applied : Change Date button",
					"Change Date button should be displayed & enabled", "Change Date button is not displayed", "FAIL");

		}

		// Verify that Copy Tax button is displayed & enabled
		try {
			if (driver.findElement(By.xpath(actions.getLocator("ManagePS.CpyTaxBtn"))).isDisplayed()) {
				if ((driver.findElement(By.xpath(actions.getLocator("ManagePS.CpyTaxBtn"))).isEnabled())) {
					actions.reportCreatePASS("Verify Future Settings Applied : Copy Tax button",
							"Copy Tax button should be displayed & enabled", "Copy Tax button is displayed and enabled",
							"PASS");
				} else {
					actions.reportCreateFAIL("Verify Future Settings Applied : Copy Tax button",
							"Copy Tax button should be displayed & enabled",
							"Copy Tax button is displayed but disabled", "FAIL");
				}
			}
		} catch (Exception e) {

			actions.reportCreateFAIL("Verify Future Settings Applied : Copy Tax button",
					"Copy Tax button should be displayed & enabled", "Copy Tax button is not displayed", "FAIL");

		}

		// Verify that Add Menu button is displayed & enabled

		try {
			if (driver.findElement(By.xpath(actions.getLocator("ManagePS.FutureAddMI"))).isDisplayed()) {
				if ((driver.findElement(By.xpath(actions.getLocator("ManagePS.FutureAddMI"))).isEnabled())) {
					actions.reportCreatePASS("Verify Future Settings Applied : Add Menu button",
							"Add Menu button should be displayed & enabled", "Add Menu button is displayed and enabled",
							"PASS");
				} else {
					actions.reportCreateFAIL("Verify Future Settings Applied : Add Menu button",
							"Add Menu button should be displayed & enabled",
							"Add Menu button is displayed but disabled", "FAIL");
				}
			}
		} catch (Exception e) {

			actions.reportCreateFAIL("Verify Future Settings Applied : Add Menu button",
					"Add Menu button should be displayed & enabled", "Add Menu button is not displayed", "FAIL");
		}

		// Set a new price to the menu item, to verify that price changes remain
		// unchanged while performing copy tax
		actions.clear("PriceTypes.All");
		Thread.sleep(500);
		actions.clear("PriceTypes.All");
		Thread.sleep(1000);
		actions.setValue("PriceTypes.All", strNewPrice);
		Thread.sleep(2000);

		// Apply changes
		actions.click("FutureSettings.Apply");
		actions.smartWait(180);
		actions.verifyTextPresence("Your changes have been saved.", false);
		actions.reportCreatePASS("Verify future setting for new price set",
				"Future settings for new price set should be done successfully",
				"Future settings for new price set done successfully", "PASS");

		// Click on Copy Tax and verify pop up message clicking cancel button
		actions.click("ManagePS.CpyTaxBtn");
		boolean VerifyPopUpMsg2 = mcd.VerifyAlertMessageDisplayed("Error",
				"This will override existing tax setting for all the priced menu items on this page.", true,
				AlertPopupButton.CANCEL_BUTTON);
		if (VerifyPopUpMsg2) {
			actions.reportCreatePASS("Verify warning message", "Warning message should be displayed",
					"Warning message displayed as expected", "PASS");
		} else {
			actions.reportCreateFAIL("Verify warning message", "Warning message should be displayed",
					"Warning message not displayed as expected", "FAIL");
		}

		// Click on Copy Tax and verify pop up message clicking Ok button
		actions.click("ManagePS.CpyTaxBtn");

		boolean VerifyPopUpMsg1 = mcd.VerifyAlertMessageDisplayed("Error", strAlertMsg, true,
				AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg1) {
			actions.reportCreatePASS("Verify warning message", "Warning message should be displayed",
					"Warning message displayed as expected", "PASS");
		} else {
			actions.reportCreateFAIL("Verify warning message", "Warning message should be displayed",
					"Warning message not displayed as expected", "FAIL");
		}

	

		// Verify that - Immediate tax settings will be copied and Price will
		// not be copied

		String Copied_TaxCode = actions.getValue("PriceTypes.TaxCode");
		String Copied_TaxRule = actions.getValue("PriceTypes.TaxRule");
		String Copied_TaxEntry = actions.getValue("PriceTypes.TaxEntry");

		String Curr_Price = driver.findElement(By.xpath("//*[@name='priceSetList[0].futureAllPrice']"))
				.getAttribute("value");

		if ((Curr_TaxCode.equals(Copied_TaxCode)) && (Curr_TaxRule.equals(Copied_TaxRule))
				&& (Curr_TaxEntry.equals(Copied_TaxEntry)) && (Curr_Price.equals(strNewPrice))) {
			actions.reportCreatePASS("Verify Copy Tax Functionality",
					"Copy Tax Functionality should work as expected for Menu Items with previous settings",
					"Copy Tax Functionality is working as expected for Menu Items with previous settings", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Copy Tax Functionality",
					"Copy Tax Functionality is working as expected for Menu Items with previous settings",
					"Copy Tax Functionality not working as expected for Menu Items with previous settings", "FAIL");

		}

		Boolean blnFlag = false;
	

		// Verification for Menu Items with No previous settings

		actions.click("ManagePS.FutureAddMI");
		try {
			driver.switchTo().alert().accept();
		} catch (Exception e) {
			System.out.println("No Alert");
		}
	    actions.smartWait(180);
		mcd.waitAndSwitch("Price Sets : Common Menu Item Selector");
		actions.click("CommonSelector.ViewFullBtn");
		actions.smartWait(180);
		actions.setValue("CommonSelector.AvailabilityDrpDwn", "Available");
		actions.smartWait(180);

		
		List<WebElement> Add_Chkbox = driver.findElements(By.xpath(actions.getLocator("PriceSet.AddMICheckBox")));
		int Item_Counts = Add_Chkbox.size();

		// Check items and add accordingly
		int i_temp = 0;
		String TXpath = null;
		List<String> MnuItem_Names = new ArrayList<String>();

		for (int n = 0; n < Item_Counts; n++) {
			if ((Add_Chkbox.get(n).isEnabled())) {
				Add_Chkbox.get(n).sendKeys(Keys.SPACE);
				String p = Integer.toString(n + 1);
				String e = driver.findElement(By.xpath("//*[@id='commonTableBody']/tr[" + p + "]/td[4]")).getText();
				MnuItem_Names.add(e);
				i_temp++;

			} else {
				System.out.println("This MI is already added");
			}

			if (i_temp == 1) {

				break;
			}
		}

		// Save the updates
		actions.click("CommonSelector.Save");
		actions.smartWait(180);
		mcd.waitAndSwitch("@Price Sets");

		// Get the list of items displayed
		List<WebElement> Added_Items = driver.findElements(By.xpath(actions.getLocator("ManagePS.ListofAddedMI")));
		int AddItem_check = 0;
		for (int k = 0; k < Added_Items.size(); k++) {
			String Added_ItemName = Added_Items.get(k).getText().split("-")[1].trim();
			if (Added_ItemName.equals(MnuItem_Names.get(k))) {
				AddItem_check++;
			} else {
				System.out.println("Check " + Added_ItemName);
				System.out.println("Check " + MnuItem_Names.get(k));
			}
		}

		if (AddItem_check == 1) {
			actions.reportCreatePASS("Verify menu items displayed", "Only newly added items should be displayed",
					"Only newly added items are displayed", "PASS");
		} else {
			actions.reportCreateFAIL("Verify menu items displayed", "Only newly added items should be displayed",
					"Items are incorrectly displayed", "FAIL");
		}

		// Verify Previous & Future tax setting values for newly added menu item

		String Prev_TaxCode = driver.findElement(By.xpath(actions.getLocator("ManagePS.PrevTaxCode"))).getText();
		String Prev_TaxRule = driver.findElement(By.xpath(actions.getLocator("ManagePS.PrevTaxRule"))).getText();
		String Prev_TaxEntry = driver.findElement(By.xpath(actions.getLocator("ManagePS.PrevTaxEntry"))).getText();

		String Future_TaxCode = actions.getValue("PriceTypes.TaxCode");
		String Future_TaxRule = actions.getValue("PriceTypes.TaxRule");
		String Future_TaxEntry = actions.getValue("PriceTypes.TaxEntry");

		if ((Prev_TaxCode.equals("N/A")) && (Prev_TaxRule.equals("N/A")) && (Prev_TaxEntry.equals("N/A"))) {
			blnFlag = true;
			actions.reportCreatePASS("Verify Previous Settings",
					"Previous Settings should be set as N/A for Menu Items without previous settings",
					"Previous Settings are set as N/A for Menu Items without previous settings", "PASS");

		} else {
			blnFlag = false;
			actions.reportCreateFAIL("Verify Previous Settings",
					"Previous Settings should be set as N/A for Menu Items without previous settings",
					"Previous Settings are not set as N/A for Menu Items without previous settings", "FAIL");
		}

		if ((Future_TaxCode.equals("Default")) && (Future_TaxRule.equals("Default"))
				&& (Future_TaxEntry.equals("Default"))) {
			blnFlag = true;
			actions.reportCreatePASS("Verify future settings",
					"Future Settings should be set as Default for Menu Items without previous settings",
					"Future Settings are set as Default for Menu Items without previous settings", "PASS");

		} else {
			blnFlag = false;
			actions.reportCreateFAIL("Verify future settings",
					"Future Settings should be set as Default for Menu Items without previous settings",
					"Future Settings are not set as Default for Menu Items without previous settings", "FAIL");

		}

		if (blnFlag) {
			actions.reportCreatePASS("Verify Previous & Future Settings",
					"Should be displayed correctly for Menu Items without previous settings",
					"Displayed correctly for Menu Items without previous settings", "PASS");

		} else {
			actions.reportCreateFAIL("Verify Previous & Future Settings",
					"Should be displayed correctly for Menu Items without previous settings",
					"Displayed incorrectly for Menu Items without previous settings", "FAIL");

		}

	}

}
