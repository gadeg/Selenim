/**
 * 
 */
package xtam.test;

import java.util.List;

/**
 * @author akrani
 *
 */

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class PRC_20235_MPUvfyPriceSetTransfr {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private String strPopup, strPopupSplit[], strLeftTableValue, strRightTableValue;
	Integer RightTableRowCount, lftTableRowCount, lftTableRowCountAfterDoubleLeftToRightButtonClick,
			RightTableRowCountAfterDoubleRightToLeftButton;

	public PRC_20235_MPUvfyPriceSetTransfr(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters
		strPopup = mcd.GetTestData("DT_POPUP");
	}

	@Test
	public void test_PRC_20235_MPUvfyPriceSetTransfr() throws InterruptedException {
		String strTestDescription = "Verify the working of Price Sets Transfer box";

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			/** set Test case Description */
			actions.setTestcaseDescription(strTestDescription);
			
			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			// ------------------------------------------------------------------------
			// Actions specific to test-flow
			strPopupSplit = strPopup.split("#");

			actions.keyboardEnter("RestaurantSet.Searchbtn");
			actions.smartWait(100);

			actions.keyboardEnter("MenuItemTaxReport.DoubleLeftToRightButton");

			// Writing below code to handle market setting error message"The
			// number of assigned Price Sets cannot exceed"
			boolean Alertpopupvalue = false;

			try {
				String Alertvalue = driver.switchTo().alert().getText();
				if (Alertvalue.contains("The number of assigned Price Sets cannot exceed")
						|| Alertvalue.contains("The number of selected Menu Items cannot exceed 10")) {
					driver.switchTo().alert().accept();
					Alertpopupvalue = true;

					WebElement ElementTaxTypNm = mcd.GetTableCellElement("RecipeReport.AvailableMenuTable", 1,
							"|  Name", "");
					ElementTaxTypNm.click();
				}
			} catch (Exception e) {
				System.out.println("Alert is not displaying");
			}
			actions.keyboardEnter("MenuItemTaxReport.TransferBtn1");
			actions.keyboardEnter("AddNewTenderSet.NextButton");

			mcd.waitAndSwitch("#Title");
			actions.keyboardEnter("MenuItemTaxReport.SingleLeftToRightButton");
			// validating A message'No Price Set in Selected List' should be
			// displayed.
			mcd.VerifyAlertMessageDisplayed("Warning Message", strPopupSplit[0], true, AlertPopupButton.OK_BUTTON);

			actions.keyboardEnter("MenuItemTaxReport.DoubleLeftToRightButton");
			// validating A message'No Price Set in Selected List' should be
			// displayed.
			mcd.VerifyAlertMessageDisplayed("Warning Message", strPopupSplit[0], true, AlertPopupButton.OK_BUTTON);

			actions.keyboardEnter("AddTenderType.ApplyButton");
			mcd.VerifyAlertMessageDisplayed("Warning Message", strPopupSplit[1], true, AlertPopupButton.OK_BUTTON);

			actions.keyboardEnter("RestaurantSet.Searchbtn");
			actions.smartWait(100);

			// Verifying Pagination Next
			// actions.click("MenuItems.PeginationNext");
			// actions.smartWait(100);

			// Verifying Pagination Previous
			// actions.click("MenuItems.PeginationPrevious");
			// actions.smartWait(100);

			actions.keyboardEnter("MenuItemTaxReport.SingleLeftToRightButton");
			// validating A message'Please select data from Available Price Set
			// List.' should be displayed.
			mcd.VerifyAlertMessageDisplayed("Warning Message", strPopupSplit[2], true, AlertPopupButton.OK_BUTTON);

			actions.keyboardEnter("MenuItemTaxReport.SingleRightToLeftButton");
			// validating A message'No data to transfer.' should be displayed.
			mcd.VerifyAlertMessageDisplayed("Warning Message", strPopupSplit[0], true, AlertPopupButton.OK_BUTTON);

			actions.keyboardEnter("MenuItemTaxReport.DoubleRightToLeftButton");
			// validating A message'No data to transfer.' should be displayed.
			mcd.VerifyAlertMessageDisplayed("Warning Message", strPopupSplit[0], true, AlertPopupButton.OK_BUTTON);

			strLeftTableValue = mcd.GetTableCellValue("SelectNode.Tree", 1, "Name", "", "");
			WebElement ElementTaxTypNm = mcd.GetTableCellElement("SelectNode.Tree", 1, "Name", "");
			ElementTaxTypNm.click();

			// Retrieving left table row count
			lftTableRowCount = mcd.GetTableRowCount("SelectNode.Tree");

			actions.keyboardEnter("MenuItemTaxReport.SingleLeftToRightButton");

			List<WebElement> eleRightTblRow1 = driver
					.findElements(By.xpath(actions.getLocator("MassPriceUpdate.RightTable")));
			strRightTableValue = eleRightTblRow1.get(0).getText();

			if (strRightTableValue.contains(strLeftTableValue)) {
				actions.reportCreatePASS(
						"Verify Selected Price Set gets moved from �Available Price Set(s)� to �Selected Price Set(s)� column- and it is removed from �Available Price Set(s)�",
						"Selected Price Set should gets moved from �Available Price Set(s)� to �Selected Price Set(s)� column- and it should removed from �Available Price Set(s)�",
						"Selected Price Set gets moved from �Available Price Set(s)� to �Selected Price Set(s)� column- and it is removed from �Available Price Set(s)�",
						"Pass");
			} else {
				actions.reportCreateFAIL(
						"Verify Selected Price Set gets moved from �Available Price Set(s)� to �Selected Price Set(s)� column- and it is removed from �Available Price Set(s)�",
						"Selected Price Set should gets moved from �Available Price Set(s)� to �Selected Price Set(s)� column- and it should removed from �Available Price Set(s)�",
						"Selected Price Set not gets moved from �Available Price Set(s)� to �Selected Price Set(s)� column- and it is not removed from �Available Price Set(s)�",
						"Fail");
			}
			// Writing below code to handel market setting error message"The
			// number of assigned Price Sets cannot exceed"
			Alertpopupvalue = false;
			actions.keyboardEnter("MenuItemTaxReport.DoubleLeftToRightButton");
			try {
				String Alertvalue = driver.switchTo().alert().getText();
				if (Alertvalue.contains("The number of assigned Price Sets cannot exceed")) {
					driver.switchTo().alert().accept();
					Alertpopupvalue = true;
					actions.reportCreatePASS("Verify 'The number of assigned Price Sets cannot exceed'is displaying",
							"'The number of assigned Price Sets cannot exceed'should display",
							"'The number of assigned Price Sets cannot exceed'is displaying", "Pass");
				}
			} catch (Exception e) {
				System.out.println("Alert is not displaying");
			}
			// --------------------------------------------- code to handel
			// market setting error message"The number of assigned Price Sets
			// cannot exceed" end
			if (!Alertpopupvalue) {
				// Retrieving Right Table count
				List<WebElement> eleRightTblRow = driver
						.findElements(By.xpath(actions.getLocator("MassPriceUpdate.RightTable")));
				RightTableRowCount = eleRightTblRow.size();

				lftTableRowCountAfterDoubleLeftToRightButtonClick = mcd.GetTableRowCount("SelectNode.Tree");

				if ((lftTableRowCount == RightTableRowCount)
						&& lftTableRowCountAfterDoubleLeftToRightButtonClick == 0) {
					actions.reportCreatePASS(
							"Verify Selected Menu Item gets moved from �Available Menu Items� to �Selected Menu Items� column",
							"Selected Menu Item should gets moved from �Available Menu Items� to �Selected Menu Items� column",
							"Selected Menu Item gets moved from �Available Menu Items� to �Selected Menu Items� column",
							"Pass");
				} else {
					actions.reportCreateFAIL(
							"Verify Selected Menu Item gets moved from �Available Menu Items� to �Selected Menu Items� column",
							"Selected Menu Item should gets moved from �Available Menu Items� to �Selected Menu Items� column",
							"Selected Menu Item not gets moved from �Available Menu Items� to �Selected Menu Items� column",
							"Fail");
				}

				actions.keyboardEnter("MenuItemTaxReport.DoubleRightToLeftButton");
				lftTableRowCount = mcd.GetTableRowCount("SelectNode.Tree");

				// RightTableRowCountAfterDoubleRightToLeftButton=mcd.GetTableRowCount("UpdateTaxChain.AssignedTaxTypeTable");
				// Retrieving Right Table count
				List<WebElement> elementRightTblRow = driver
						.findElements(By.xpath(actions.getLocator("MassPriceUpdate.RightTable")));
				RightTableRowCountAfterDoubleRightToLeftButton = elementRightTblRow.size();

				if ((lftTableRowCount == RightTableRowCount) && RightTableRowCountAfterDoubleRightToLeftButton == 0) {
					actions.reportCreatePASS(
							"Verify Selected Menu Item gets moved from �Selected Menu Items� to �Available Menu Items� column",
							"Selected Menu Item should gets moved from �Selected Menu Items� to �Available Menu Items� column",
							"Selected Menu Item gets moved from �Selected Menu Items� to �Available Menu Items� column",
							"Pass");
				} else {
					actions.reportCreateFAIL(
							"Verify Selected Menu Item gets moved from �Selected Menu Items� to �Available Menu Items� column",
							"Selected Menu Item should gets moved from �Selected Menu Items� to �Available Menu Items� column",
							"Selected Menu Item not gets moved from �Selected Menu Items� to �Available Menu Items� column",
							"Fail");
				}
			}
			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}