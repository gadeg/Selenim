/*************************
 * Jira ID: RFM-4951 - Verify the Creation of New Promotional Price Set by copying settings from existing price set
 * 
****************************/

package xtam.test;


import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD.AlertPopupButton;


public class PRC_0107_CreateBasePromotionPS {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();
	
	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;
	
	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strApplicationDate;
	// TODO: Declare test-data variables for other data-parameters
	
	private String strNewPrcSet;
	private String strPrcSet_copy;
	private String strResMessage;
	private String[] strPrcSetType;
	private String strTestPrc;
	private String strError_Eating;
	private String strError_Msg2;
	private String strFuturePrc;
	private String strNodeNum;
	private String strNavigateToST;
	
	public PRC_0107_CreateBasePromotionPS (WebDriver nodeDriver, Map inputData, Object or){
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();
		
		mcd = new lib_MCD (driver, actions, uiActions, inputData);
		rfm = new lib_RFM2 (driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);

		// Read input Test-Data
		strURL 			= mcd.GetTestData("DT_URL");
		strUserName 	= mcd.GetTestData("DT_USER_NAME");
		strPassword 	= mcd.GetTestData("DT_PASSWORD");
		strMarket 		= mcd.GetTestData("DT_MARKET");
		strNavigateTo 	= mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters
		
		strNewPrcSet	= mcd.GetTestData("PriceSet_Name");
		strPrcSet_copy	= mcd.GetTestData("CopyFromPS_Name");
		strResMessage	= mcd.GetTestData("Result_Message");
		strPrcSetType	= mcd.GetTestData("PriceSetType").split("#");
		strTestPrc		= mcd.GetTestData("TestPrc");
		strError_Eating	= mcd.GetTestData("Error_Eating");
		strError_Msg2	= mcd.GetTestData("Error_Msg2");
		strFuturePrc	= mcd.GetTestData("FuturePrc");
		strNodeNum		= mcd.GetTestData("NodeNum");
		strNavigateToST	= mcd.GetTestData("DT_NAVIGATE_TO_ST");
	}
	
	@Test
	public void PRC_0107_CreateBasePromotionPS() throws InterruptedException {
		//String strPageTitle = "Manage Price Sets";			// TODO: Exact page-title
		//String strPageSubHeading = "Manage Price Sets";		// TODO: Page Heading
		String strTestDescription = "Verify the Creation of New Promotional Price Set by copying settings from existing price set";		// TODO: Test Case Description
		
		try {
			System.out.println("********************************************************************** Test execution starts");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);
			
			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);
		
            /** Select Menu Option */
            System.out.println("> Navigate to :: " + strNavigateToST);
            actions.select_menu("RFMHome.Navigation",strNavigateToST);
            Thread.sleep(2000);
            actions.waitForPageToLoad(120);

            /** Update title of new Page  */
            mcd.waitAndSwitch("#Title");
            
            /** Get application time */
            WebElement apptime = mcd.getdate();
            strApplicationDate = apptime.getText();

			 /** Get application time */
			 actions.setTestcaseDescription(strTestDescription);
			
			// ------------------------------------------------------------------------ Actions specific to test-flow
			 rfm.RFM_Admin_Update_PricingTags("true", "Display price type attribute as expanded by default");
			 rfm.RFM_Admin_Update_PricingTags("0", "Automatically fill price type attribute option price value");
			
			 
			 //** Select Menu Option *//*
	            System.out.println("> Navigate to :: " + strNavigateTo);
	            actions.select_menu("RFMHome.Navigation",strNavigateTo);
	            Thread.sleep(2000);
	            actions.waitForPageToLoad(120);

	          //** Update title of new Page  *//*
	            mcd.waitAndSwitch("#Title");
	            
			String strBasePrcSet = RFM_PRC_Create_PromotionalBase_PrcSet_New(strNewPrcSet, strPrcSet_copy, strPrcSetType[1], strResMessage, strTestPrc, strError_Eating, strError_Msg2, strFuturePrc, strNodeNum, strNavigateTo);
			System.out.println(strBasePrcSet+" created successfully");
			
			// > > > > Verifying Audit Log Entry > > > 
			if (mcd.GetGlobalData("Instance").contains("US"))
				rfm.VerifyAuditLog_Entry("Price Sets", " Update", "Store [33853, EASTERN / KANE]");
			else
				rfm.VerifyAuditLog_Entry("Price Sets", " Update", "Restaurant [950003, SANS SOUCI NSW]");
			
			
			// ------------------------------------------------------------------------ 
			
			/** Logout the application */
			rfm.Logout();
			
		} catch(Exception e) {
			System.out.println("Test Failed :: " + e.getCause() + " - " +  e.getMessage());
			actions.catchException(e);
			
		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
				
		}
	}
	
	//We have created this new function to handle switch to window 
		public String RFM_PRC_Create_PromotionalBase_PrcSet_New(String strNewPrcSet, String strPrcSet_copy,
				String strPrcSetType, String strResMessage, String strTestPrc, String strError_Eating, String strError_Msg2,
				String strFuturePrc, String strNodeNum, String strNavigateTo) throws Exception {

			actions.WaitForElementPresent("PriceSet.NewBtn", 180);
			/** Get application time */
			WebElement apptime = mcd.getdate();
			String strApplicationDate = apptime.getText();

			int iTemp = 0;

			actions.click("PriceSet.NewBtn");
			Thread.sleep(2000);

			// Switch to New Price Sets
			mcd.waitAndSwitch("New Price Sets");

			// Generate unique strNewPrcSet for Base/Promotion Price Set

			switch (strPrcSetType) {
			case "Base":
				// Base Price
				strNewPrcSet = mcd.fn_GetRndName("Base");
				break;
			case "Promotion":
				strNewPrcSet = mcd.fn_GetRndName("Prom");
				break;
			default:
				// System.out.println("Please enter correct Price Set Type
				// (Base/Promotion)");
				actions.reportCreateFAIL("Verfiy data", "Enter correct price set name", "Incorrect data", "FAIL");
				break;
			}

			// Enter new price set name :
			actions.setValue("NewPriceSet.Name", strNewPrcSet);
			Thread.sleep(500);

			actions.click("NewPriceSet.SelectNode");
			Thread.sleep(1000);
			
			// Switch to Select Node Window - Title - Select Node
			mcd.waitAndSwitch("Select Node");

			actions.click("SelectNode.ExactMtchRadiobtn");
			Thread.sleep(500);
//			actions.setValue("SelectNode.SearchBox", strNodeNum);
			driver.findElement(By.xpath(actions.getLocator("SelectNode.SearchBox"))).sendKeys(strNodeNum);
			Thread.sleep(500);

			actions.keyboardEnter("SelectNode.SearchButton");
			Thread.sleep(1000);
			actions.waitForPageToLoad(120);

//			Boolean Node_chk = mcd.Selectrestnode("SelectNode.NodeTable", strNodeNum);
			if (mcd.GetGlobalData("Instance").toLowerCase().contains("eu")) {			
				Boolean Node_chk=mcd.Selectrestnode_JavaScriptClk("SelectNode.CPTable", strNodeNum);
			} else {
				Boolean Node_chk=mcd.Selectrestnode("SelectNode.NodeTable", strNodeNum);

			}
			Thread.sleep(2000);

			mcd.waitAndSwitch("New Price Sets");

			switch (strPrcSetType) {
			case "Base":

				// Base Price
				actions.keyboardEnter("NewPriceSet.BaseRadioBtn");
				Thread.sleep(1000);

				break;
			case "Promotion":

				// Promotion Price
				// actions.keyboardEnter("NewPriceSet.PromRadioBtn");
				actions.javaScriptClick("NewPriceSet.PromRadioBtn");
				Thread.sleep(1000);

				driver.findElement(By.xpath(actions.getLocator("NewPriceSet.StartDate"))).click();
				// mcd.select_date("25", "current", "NewPriceSet.StartDate");
				mcd.sel_current_date("NewPriceSet.StartDate", strApplicationDate);

				// driver.findElement(By.xpath("//*[@id='endDateAnchor'][@src='/rfm2OnlineApp/images/cal.jpg'][@name='endDateAnchor']")).click();
				driver.findElement(By.xpath(actions.getLocator("NewPriceSet.EndDate"))).click();
				// mcd.select_date("30", "current", "NewPriceSet.EndDate");
				mcd.Get_future_date(3, "close", strApplicationDate);

				break;
			default:
				System.out.println("Please enter correct Price Set Type (Base/Promotion)");
				break;
			}

			// actions.click("NewPriceSet.CopyYesRadioBtn");
			actions.javaScriptClick("NewPriceSet.CopyYesRadioBtn");

			Thread.sleep(1000);

			// Select Price Set to copy
			actions.keyboardEnter("NewPriceSet.SelectPrcSet");

			Thread.sleep(1000);

			// Switch to price sets
			mcd.waitAndSwitch("Price Sets");

			actions.keyboardEnter("PriceSetList.ViewFullList");
			Thread.sleep(1000);
			actions.smartWait(120);

			try {
				// Select the first price set
				mcd.GetTableCellElement("RFM.WebTable", 1, "Name", "a").click();
				Thread.sleep(1000);

				/// Switch back
				mcd.waitAndSwitch("New Price Sets");
			} catch (Exception err) {
				actions.reportCreateFAIL("No Price Sets present to copy", "No Price Sets present to copy",
						"No Price Sets present to copy", "FAIL");
			}

			// Click Next
			actions.keyboardEnter("NewPriceSet.Next");
			
			//Switch to updated window -
			//driver.switchTo().window("");
			
			
			
			//mcd.waitAndSwitch("@Price Sets");
			
			
			//Based on instance >> Switch to Manage Price set window. Applicable to US
			
//			if(mcd.GetGlobalData("Instance").trim().toLowerCase().contains("us")){
			try{
				
				mcd.SwitchToWindow("Manage Price Set");
				// mcd.waitAndSwitch("Manage Price Set");
				actions.keyboardEnter("RFM.Okbtn");
				
				mcd.waitAndSwitch("@Price Sets");
			}
//			}else{
				catch(Exception err){
//					try{
//						mcd.waitAndSwitch("Manage Price Set");
//					}catch(Exception err){
						System.out.println("No window - Manage Price Set");
				
				}
//			}
			
			actions.WaitForElementPresent("ManagePS.QuickToolApply", 180);

			//Verify result message
			actions.verifyTextPresence(strResMessage, true);

			//Verify Screen header
			String CreatedPS_msg = null;
			CreatedPS_msg = "Manage Price Set : " + strNewPrcSet;
			actions.verifyTextPresence(CreatedPS_msg, true);

			
			// Validations - Common to Base / Promotional

			//For all price field
			driver.findElement(By.xpath(actions.getLocator("ManagePS.AllPrice"))).clear();
			actions.clear("ManagePS.AllPrice");
			Thread.sleep(500);
			actions.setValue("ManagePS.AllPrice", strTestPrc);
			Thread.sleep(500);
			actions.click("ManagePS.QuickToolApply");
			Thread.sleep(2000);

			Boolean VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strError_Msg2, true,
					AlertPopupButton.OK_BUTTON);
			if (VerifyPopUpMsg) {
				actions.reportCreatePASS("Verify price fields",
						"All Prices fields should accept values upto 2 decimal places only.",
						"All Prices fields accepts values upto 2 decimal places only.", "PASS");
			} else {
				actions.reportCreatePASS("Verify price fields",
						"All Prices fields should accept values upto 2 decimal places only.",
						"All Prices fields accepts values more than 2 decimal places.", "FAIL");
			}

			//For Eating/TO/Other price field
			actions.click("ManagePS.RestRadio");
			Thread.sleep(1000);

			actions.clear("ManagePS.EatPrice");
			actions.setValue("ManagePS.EatPrice", strTestPrc);

			actions.clear("ManagePS.TkOutPrice");
			actions.setValue("ManagePS.TkOutPrice", strTestPrc);

			actions.clear("ManagePS.OtherPrice");
			actions.setValue("ManagePS.OtherPrice", strTestPrc);
			actions.click("ManagePS.QuickToolApply");
			Thread.sleep(3000);

			VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strError_Msg2, true, AlertPopupButton.OK_BUTTON);
			if (VerifyPopUpMsg) {
				actions.reportCreatePASS("Verify price fields",
						"All Eating/TO/Other fields should accept values upto 2 decimal places only.",
						"All Eating/TO/Other fields accepts values upto 2 decimal places only.", "PASS");
			} else {
				actions.reportCreatePASS("Verify price fields",
						"All Eating/TO/Other fields should accept values upto 2 decimal places only.",
						"All Eating/TO/Other fields accepts values more than 2 decimal places.", "FAIL");
			}
			
			
			//Handled the situation where in based on the price value >> the price fields can be displayed as expanded or collapsed.
			//So the validations are done accordingly
			try{
				WebElement eleItemExpand = driver.findElement(By.xpath(actions.getLocator("PriceSet.FrstMIExpandIcon")));
				System.out.println("Whether expand/collapse = "+ eleItemExpand.getAttribute("style").trim());
				//if style = "" , Price fields are expanded
				if(!(eleItemExpand.getAttribute("style").trim().equalsIgnoreCase(""))){
					actions.smartWait(180);
	 
					actions.clear("ManagePS.ItemEatPrice");
					actions.setValue("ManagePS.ItemEatPrice", strTestPrc);

					actions.clear("ManagePS.ItemTOPrice");
					actions.setValue("ManagePS.ItemTOPrice", strTestPrc);

					actions.clear("ManagePS.ItemOtherPrice");
					actions.setValue("ManagePS.ItemOtherPrice", strTestPrc);
					
					actions.click("ManagePS.ALLApply");
					Thread.sleep(2000);
					
					VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strError_Msg2, true, AlertPopupButton.OK_BUTTON);
					if (VerifyPopUpMsg) {
						actions.reportCreatePASS("Verify price fields",
								"All Eating/TO/Other fields should accept values upto 2 decimal places only.",
								"All Eating/TO/Other fields accepts values upto 2 decimal places only.", "PASS");
					} else {
						actions.reportCreatePASS("Verify price fields",
								"All Eating/TO/Other fields should accept values upto 2 decimal places only.",
								"All Eating/TO/Other fields accepts values more than 2 decimal places.", "FAIL");
					}

				}else{
					//if style = "display:none" , Price fields are collapsed	
				actions.smartWait(180);
				actions.clear("ManagePS.ItemAllPriceTextBox");
				actions.clear("ManagePS.ItemAllPriceTextBox");
				actions.setValue("ManagePS.ItemAllPriceTextBox", strTestPrc);
				
				
				actions.click("ManagePS.ALLApply");
				Thread.sleep(2000);
				
				VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strError_Msg2, true, AlertPopupButton.OK_BUTTON);
				if (VerifyPopUpMsg) {
					actions.reportCreatePASS("Verify price fields",
							"All Prices fields should accept values upto 2 decimal places only.",
							"All Prices fields accepts values upto 2 decimal places only.", "PASS");
				} else {
					actions.reportCreatePASS("Verify price fields",
							"All Prices fields should accept values upto 2 decimal places only.",
							"All Prices fields accepts values more than 2 decimal places.", "FAIL");
				}
				}
			}catch(Exception err){
				//if style = "display:none" , Price fields are collapsed
				actions.smartWait(180);

				actions.clear("ManagePS.ItemEatPrice");
				actions.setValue("ManagePS.ItemEatPrice", strTestPrc);

				actions.clear("ManagePS.ItemTOPrice");
				actions.setValue("ManagePS.ItemTOPrice", strTestPrc);

				actions.clear("ManagePS.ItemOtherPrice");
				actions.setValue("ManagePS.ItemOtherPrice", strTestPrc);
				
				actions.click("ManagePS.ALLApply");
				Thread.sleep(2000);
				
				VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strError_Msg2, true, AlertPopupButton.OK_BUTTON);
				if (VerifyPopUpMsg) {
					actions.reportCreatePASS("Verify price fields",
							"All Eating/TO/Other fields should accept values upto 2 decimal places only.",
							"All Eating/TO/Other fields accepts values upto 2 decimal places only.", "PASS");
				} else {
					actions.reportCreatePASS("Verify price fields",
							"All Eating/TO/Other fields should accept values upto 2 decimal places only.",
							"All Eating/TO/Other fields accepts values more than 2 decimal places.", "FAIL");
				}

			}
			actions.smartWait(10);
			


			// Click on cancel to close the page
			actions.click("NewPriceSet.Cancel");
			Thread.sleep(3000);
			VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error",
					"Unsaved data will be lost. Are you sure you want to proceed?", true, AlertPopupButton.CANCEL_BUTTON);
			if (VerifyPopUpMsg) {
				// Reporter.log("Unsaved record message PASS");
				actions.reportCreatePASS("Verify Unsaved warning", "Unsaved warning should be displayed",
						"Unsaved warning is displayed", "PASS");
			} else {
				// Reporter.log("Unsaved record message FAILED");
				actions.reportCreateFAIL("Verify Unsaved warning", "Unsaved warning should be displayed",
						"Unsaved warning is not displayed", "FAIL");
			}

			//enter correct price and save
			actions.smartWait(180);
			actions.WaitForElementPresent("ManagePS.EatPrice", 180);
			actions.clear("ManagePS.EatPrice");
			actions.setValue("ManagePS.EatPrice", Integer.toString(Integer.parseInt(strFuturePrc)));

			actions.clear("ManagePS.TkOutPrice");
			actions.setValue("ManagePS.TkOutPrice", Integer.toString(Integer.parseInt(strFuturePrc)));

			actions.clear("ManagePS.OtherPrice");
			actions.setValue("ManagePS.OtherPrice", Integer.toString(Integer.parseInt(strFuturePrc)));
			actions.click("ManagePS.QuickToolApply");
			Thread.sleep(3000);
			actions.smartWait(120);
			actions.click("ManagePS.ALLApply");
			Thread.sleep(3000);
			actions.smartWait(120);
			
			// Click on cancel to close the page
			//actions.click("NewPriceSet.Cancel");
			actions.javaScriptClick("NewPriceSet.Cancel");
			Thread.sleep(7000);
			
			// mcd.smartsync(60);
			actions.waitForPageToLoad(120);
			// Creating Future Settings for newly created price set
			driver.switchTo().window("");		
			//mcd.waitAndSwitch("@Manage Price Sets");
			actions.smartWait(180);

			// Enter Price Set name to search
			actions.setValue("PriceSet.SearchBox", strNewPrcSet);
			Thread.sleep(500);
			actions.keyboardEnter("PriceSet.SearchBtn");
			Thread.sleep(1000);
			actions.smartWait(120);

			// Click on fetched PS
			mcd.GetTableCellElement("RFM.WebTable", 1, "Name", "a").click();
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			//driver.switchTo().window("");	
			mcd.waitAndSwitch("@Price Sets");

			if (strPrcSetType.equals("Base")) {
				mcd.SelectDate_OpenCalender("10", "next");
				Thread.sleep(1000);
				actions.smartWait(120);
			} else {
				int d = 10;

				mcd.SelectDate_OpenCalender(Integer.toString(d), "next");
				Thread.sleep(1000);
				actions.smartWait(120);
				mcd.SelectDate_OpenCalender(Integer.toString(d + 2), "current");
				Thread.sleep(1000);
				actions.smartWait(120);
			}

			//Enter future price setting
			actions.clear("ManagePS.AllPrice");
			Thread.sleep(500);
			actions.setValue("ManagePS.AllPrice", strFuturePrc);
			Thread.sleep(500);
			actions.click("ManagePS.QuickToolApply");
			Thread.sleep(2000);

			actions.click("FutureSettings.Apply");
			
			
			try{
				String Alertvalue=driver.switchTo().alert().getText();
					if(Alertvalue.contains("You have specified incomplete tax information")){
						driver.switchTo().alert().accept();
						
						//Verify Success message
						try {			
							Thread.sleep(5000);
							actions.smartWait(120);
							driver.switchTo().window("");	
							actions.verifyTextPresence("Your changes have been saved.", false);			
							}
						catch (Exception err1){
							System.out.println("Alert is not displaying");
						}
						
					}
					else{
						driver.switchTo().alert().dismiss();
					}
				  }catch(Exception e) {	                     
					System.out.println("Alert is not displaying");
			}
		
			
			
			return strNewPrcSet;
		}

	
}
