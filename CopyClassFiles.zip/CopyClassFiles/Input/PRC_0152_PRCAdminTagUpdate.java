package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;

public class PRC_0152_PRCAdminTagUpdate {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// Declare test-data variables for other data-parameters
	private String strNavigateAdm;
	private String strFuturePrc;

	public PRC_0152_PRCAdminTagUpdate(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// GetTestData for other data-parameters
		strNavigateAdm = mcd.GetTestData("NavigateAdm");
		strFuturePrc = mcd.GetTestData("FuturePrc");
	}

	@Test
	public void test_PRC_0152_PRCAdminTagUpdate() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription(
					"Verify that in price set price attributes are displayed as expanded by default and user cannot collapse it when value of <display-price-type-attribute-as-expanded-by-default> and <restrict-price-type-attribute-from-expanding> tag are set to true  ");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Navigating to Admin */
			System.out.println("> Navigate to :: " + strNavigateAdm);
			actions.select_menu("RFMHome.Pricing", strNavigateAdm);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			mcd.SwitchToWindow("#Title");
			
			// Setting below two price attributes to 'true'
			rfm.RFM_Admin_Update_PricingTags("true", "Restrict price type attribute from expanding");
			rfm.RFM_Admin_Update_PricingTags("true", "Display price type attribute as expanded by default");

			/** Navigating to Price Sets */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Pricing", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			// Select the first price set to verify the price attributes
			try {
				WebElement FirstPS = mcd.GetTableCellElement("PackageReport.Table", 1, 1, "a");
				actions.click(FirstPS);
				mcd.smartsync(180);
			} catch (Exception e) {
				actions.reportCreateFAIL("Verify Price Sets are present", "At least one price set must be present",
						"Not a single price set is present in the Application", "Fail");
			}
			mcd.SwitchToWindow("#Title");

			// Number of future settings date present
			List<WebElement> FutDates = driver.findElements(By.xpath(actions.getLocator("PriceSets.SBFutureSetting")));
			actions.click(FutDates.get(0));
			mcd.smartsync(180);
			
			// Verifying pricing attributes for current date 
			VerifyPriceAttributes();

			// Creating future date if not present
			if (FutDates.size() < 2) {
				mcd.SelectDate_OpenCalender("10", "next");
				mcd.smartsync(180);
				// Enter future price setting
				actions.WaitForElementPresent("ManagePS.AllPrice", 120);
				actions.clear("ManagePS.AllPrice");
				actions.setValue("ManagePS.AllPrice", strFuturePrc);
				actions.click("AddTenderType.ApplyButton");
				Thread.sleep(2000);
				try {
					if (mcd.GetGlobalData("Instance").trim().toLowerCase().contains("us")) {
						actions.click("FutureSettings.Apply");
						
						driver.switchTo().alert().accept();
					}else{
						actions.keyboardEnter("DimensionGroup.SaveButton");
					}
				} catch (Exception e1) {
				}
				mcd.smartsync(120);
			} else {
				actions.click(FutDates.get(1));
				mcd.smartsync(180);
			}

			// Verifying pricing attributes for future date
			VerifyPriceAttributes();

			// Adding available Menu Items
			actions.keyboardEnter("SubstitutionGroups.AddMenuItemButton");
			mcd.waitAndSwitch("Price Sets : Common Menu Item Selector");
			actions.keyboardEnter("RecipeReport.ViewFullListBtn");
			mcd.smartsync(180);
			actions.setValue("CMIS.Availabilitydrpdwn", "Available");
			mcd.smartsync(180);
			WebElement chkbox = mcd.GetTableCellElement("CommonMenuItemSelector.MenuItemList", 1, 1, "input");
			actions.click(chkbox);
			actions.keyboardEnter("CommonSelector.Save");
			mcd.SwitchToWindow("Price Sets");

			// Verifying pricing attributes after adding menu items
			VerifyPriceAttributes();

			actions.click("RFM.Cancelbtn");
			mcd.smartsync(180);
			mcd.SwitchToWindow("#Title");
			actions.WaitForElementPresent("PackageReport.Table", 120);
			WebElement FirstPS = mcd.GetTableCellElement("PackageReport.Table", 1, 1, "a");
			actions.click(FirstPS);
			mcd.smartsync(180);
			mcd.SwitchToWindow("#Title");
			Thread.sleep(2000);
			// Verifying pricing attributes again for current date 
			VerifyPriceAttributes();

			// Resetting the pre-req automated for setting the price attributes
			/** Navigating to Admin */
			System.out.println("> Navigate to :: " + strNavigateAdm);
			actions.select_menu("RFMHome.Pricing", strNavigateAdm);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			mcd.SwitchToWindow("#Title");

			rfm.RFM_Admin_Update_PricingTags("false", "Restrict price type attribute from expanding");
			rfm.RFM_Admin_Update_PricingTags("false", "Display price type attribute as expanded by default");

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);
		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}
	// Function to verify the pricing attributes 
	// 1.Expanded by default
	// 2.Cannot be collapsed
	public void VerifyPriceAttributes() {
		List<WebElement> Minus_Icons = driver.findElements(By.xpath(actions.getLocator("ManagePriceSet.MinusIcon")));
		if (Minus_Icons.get(0).isDisplayed()) {
			actions.reportCreatePASS("Verify Price attributes are expanded by default",
					"Price attributes should be expanded by default", "Price attributes are expanded by default",
					"Pass");
		} else {
			actions.reportCreateFAIL("Verify Price attributes are expanded by default",
					"Price attributes should be expanded by default", "Price attributes are not expanded by default",
					"Fail");
		}

		try {
			actions.click(Minus_Icons.get(0));
			if (!Minus_Icons.get(0).isDisplayed()) {
				actions.reportCreateFAIL("Verify Price attributes cannot collapse",
						"Price attributes cannot be collapsed", "Price attributes are collapsed", "Fail");
			} else {
				actions.reportCreatePASS("Verify Price attributes cannot collapse",
						"Price attributes cannot be collapsed", "Price attributes are not collapsed", "Pass");
			}
		} catch (Exception e) {
		}
	}
}
