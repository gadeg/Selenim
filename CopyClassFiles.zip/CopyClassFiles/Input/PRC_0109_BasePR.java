/**
   [Class description.  This Test Script covers the below Test Cases:
		PRC_0109_BasePR
	]  
	
   @author Anubhuti
   @version 1.0

**/

package xtam.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class PRC_0109_BasePR {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strApplicationDate;
	// TODO: Declare test-data variables for other data-parameters

	private String strMessage;
	private String strAddRemoveMsg;
	private String strNavigateAdm;
	private String strPriceSetName;
	private String strNewPrcSet;
	private String strPrcSet_copy;
	private String strResMessage;
	private String strPrcSetType;
	private String strTestPrc;
	private String strError_Eating;
	private String strError_Msg2;
	private String strFuturePrc, struserid;
	private String strNodeNum, strActivity, strLevelUpdate, strDBName, strUserName_string, strOperation,
			strleveldetails, strexpectlevel[];

	public PRC_0109_BasePR(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters

		strMessage = mcd.GetTestData("Message");
		strAddRemoveMsg = mcd.GetTestData("AddRemoveMsg");

		strNavigateAdm = mcd.GetTestData("NavigateAdm");
		strPriceSetName = mcd.GetTestData("PriceSetName");
		strNewPrcSet = mcd.GetTestData("PriceSet_Name");
		strPrcSet_copy = mcd.GetTestData("CopyFromPS_Name");
		strResMessage = mcd.GetTestData("Result_Message");
		strPrcSetType = mcd.GetTestData("PriceSetType");
		strTestPrc = mcd.GetTestData("TestPrc");
		strError_Eating = mcd.GetTestData("Error_Eating");
		strError_Msg2 = mcd.GetTestData("Error_Msg2");
		strFuturePrc = mcd.GetTestData("FuturePrc");
		strNodeNum = mcd.GetTestData("NodeNum");

		strActivity = mcd.GetTestData("DT_ACTIVITY");
		strLevelUpdate = mcd.GetTestData("DT_LEVEL_Update");
		strDBName = mcd.GetTestData("DT_DB_NAME");
		strUserName_string = strUserName.toString();
		strOperation = mcd.GetTestData("DT_OPERATION");
		strleveldetails = mcd.GetTestData("DT_LEVELDETAILS");
		struserid = mcd.GetTestData("DT_USER_NAME");
		strexpectlevel = strLevelUpdate.split("#");
	}

	@Test
	public void PRC_0109_BasePR() throws InterruptedException {
		String strPageTitle = " Price Sets";

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			/** Get application time */
			actions.setTestcaseDescription("Verify Add/Remove Menu Items functionality of base price set");

			
			// Verifying Search with type drop down default value
			Boolean resultStatus;
			Select selObj = new Select(
					driver.findElement(By.xpath(actions.getLocator("MenuItempriceByPriceSetReport.PriceTypeDDL"))));
			resultStatus = selObj.getFirstSelectedOption().getText().trim().equalsIgnoreCase("All");
			reporting_Pass_Fail("Verify whether Status All is selected by default for Status DDL",
					"Status All should be selected by default", "Status All is selected by default",
					"Status All is not selected by default", resultStatus);

			
			
			// Creating new base price set
			String strPriceSetName = PriceActions.RFM_PRC_Create_PromotionalBase_PrcSet(strNewPrcSet, strPrcSet_copy,
					strPrcSetType, strResMessage, strFuturePrc, strNodeNum, strNavigateTo);

			
			// ** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			
			// ** Update title of new Page *//*
			mcd.SwitchToWindow("#Title");

			// Enter Price Set name to search
			actions.setValue("PriceSet.SearchBox", strPriceSetName);
			Thread.sleep(500);
			actions.keyboardEnter("PriceSet.SearchBtn");
			Thread.sleep(1000);
			actions.smartWait(180);

			// Get row count of number of price sets fetched
			int rw_cnt = mcd.GetTableRowCount("PriceSet.Table");
			int iTemp = 0;
			List<WebElement> PrcSet_List = driver.findElements(By.xpath(actions.getLocator("RFMPriceSets.PriceSet1")));

			// Click on desired Price set
			for (int i = 0; i <= rw_cnt; i++) {
				try {

					String temp_str = PrcSet_List.get(i).getText();
					if (temp_str.equals(strPriceSetName)) {
						PrcSet_List.get(i).sendKeys(Keys.ENTER);
						iTemp = 0;
						break;
					} else {
						iTemp = iTemp + 1;
					}
				} catch (Exception e) {
				}
			}

			Thread.sleep(2000);
			mcd.SwitchToWindow("#Title");

			// Verify price set name and type on screen and click on add/remove
			// button
			actions.click("ManagePriceSet.AddRemoveButton");
			Thread.sleep(2000);
			mcd.SwitchToWindow("Price Sets : Common Menu Item Selector");

			// GUI Verification for Price Sets : Common Menu Item Selector
			String search_text = driver
					.findElement(By.xpath(actions.getLocator("CommonMenuItemSelector.SearchTextBox")))
					.getAttribute("type");
			if (search_text.equals("text")) {
				actions.reportCreatePASS("Verify Search text box", "Search text box should be editable",
						"Search text box is editable", "PASS");

			} else {
				actions.reportCreateFAIL("Verify Search text box", "Search text box should be editable",
						"Search text box is NOT editable", "FAIL");
			}

			Boolean resultStatus2;
			Select fam_grop_ddl = new Select(
					driver.findElement(By.xpath(actions.getLocator("CopyComponents.FamilyGrp"))));
			resultStatus2 = fam_grop_ddl.getFirstSelectedOption().getText().trim().equalsIgnoreCase("All");
			reporting_Pass_Fail("Verify whether Status All is selected by default for Status DDL",
					"Status All should be selected by default", "Status All is selected by default",
					"Status All is not selected by default", resultStatus2);

			Boolean resultStatus3;
			Select status_ddl = new Select(driver.findElement(By.xpath(actions.getLocator("CopyComponents.Status"))));
			resultStatus3 = status_ddl.getFirstSelectedOption().getText().trim().equalsIgnoreCase("Active/Inactive");
			reporting_Pass_Fail("Verify whether Status Active/Inactive is selected by default for Status DDL",
					"Status Active/Inactive should be selected by default",
					"Status Active/Inactive is selected by default",
					"Status Active/Inactive is not selected by default", resultStatus3);

			if(strMarket.equals("Australasia")) 
			{

				// Verifying Search within status drop down default value
				Boolean resultStatus1;
				Select selObj1 = new Select(
						driver.findElement(By.xpath(actions.getLocator("ManageDimensionGroups.SearchWithinStatus"))));
				resultStatus1 = selObj1.getFirstSelectedOption().getText().trim().equalsIgnoreCase("Active/Inactive");
				reporting_Pass_Fail("Verify whether Status Active/Inactive is selected by default for Status DDL",
						"Status Active/Inactive should be selected by default",
						"Status Active/Inactive is selected by default",
						"Status Active/Inactive is not selected by default", resultStatus1);

		}else{
			

				Boolean resultStatus4;
				Select selObj_approved = new Select(
						driver.findElement(By.xpath(actions.getLocator("CopyComponents.Status"))));
				resultStatus4 = selObj_approved.getFirstSelectedOption().getText().trim().equalsIgnoreCase("Approved & Not Approved");
				reporting_Pass_Fail("Verify whether Status Approved & Not Approved is selected by default for Status DDL",
						"Status Approved & Not Approved should be selected by default",
						"Status Approved & Not Approved is selected by default",
						"Status Approved & Not Approved is not selected by default", resultStatus4);

			}

			
			// Verify Availability ddl disable
			if (!actions.isElementEnabled("CommonMenuItemSelector.Availability")) {
				actions.reportCreatePASS("Verify Availability ddl", "Availability ddl should disable",
						"Availability ddl is disable", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Availability ddl", "Availability ddl should disable",
						"Availability ddl is NOT disable", "FAIL");
			}

			
			// Click on View Full List and Select Available from Availability
			// drop down
			actions.keyboardEnter("CommonSelector.ViewFullBtn");
			Thread.sleep(1000);
			actions.smartWait(180);

			// Select Availability from Availability ddl and verify results are
			// dispayed
			actions.setValue("CommonSelector.AvailabilityDrpDwn", "Available");
			Thread.sleep(1000);
			actions.smartWait(180);

			int availabe_rc = mcd.GetTableRowCount("RFMManageTenderType.TenderTypeTable");
			if (availabe_rc > 0) {
				actions.reportCreatePASS("Verify results ", "Search results should display",
						"Search results is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify results ", "Search results should display",
						"Search results is NOT  displayed", "FAIL");
			}

			// Click Search button and select one from family group ddl and
			// verify resuls
			actions.keyboardEnter("SetAssignmentReport.SearchButton");
			actions.smartWait(180);
			actions.setValue("CopyComponents.AvailableMenu", "BREAKFAST_DRINK");
			int familygroup_rc = mcd.GetTableRowCount("RFMManageTenderType.TenderTypeTable");
			if (familygroup_rc > 0) {
				actions.reportCreatePASS("Verify results ", "Search results should display",
						"Search results is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify results ", "Search results should display",
						"Search results is NOT  displayed", "FAIL");
			}

			// Click on search button ,select availabe from ddl and without
			// adding menu items click save button
			actions.setValue("CommonSelector.AvailabilityDrpDwn", "Available");
			Thread.sleep(1000);
			actions.smartWait(180);
			actions.keyboardEnter("CommonSelector.Save");
			Boolean VerifyPopUpMsg1 = mcd.VerifyAlertMessageDisplayed("Error", "No changes have been made", true,
					AlertPopupButton.OK_BUTTON);
			if (VerifyPopUpMsg1) {
				actions.reportCreatePASS("Verify Error message without adding a menu item to  price set",
						"Pop Up alert with correct error message should be displayed",
						"Pop Up alert with correct error message is displayed", "PASS");
			} else {
				actions.reportCreatePASS("Verify Error message without adding a menu item to  price set",
						"Pop Up alert with correct error message should be displayed",
						"Pop Up alert with correct error message is not displayed", "FAIL");
			}

			// Click on search button ,select availabe from ddl
			actions.setValue("CommonSelector.AvailabilityDrpDwn", "Available");
			actions.smartWait(180);

			// Get Row Count check box if it is enable add menu items and click save button
			List<WebElement> Add_Chkbox = driver.findElements(By.xpath(actions.getLocator("PriceSet.AddMICheckBox")));
			int Item_Counts = Add_Chkbox.size();
			List<String> MnuItem_Names = new ArrayList<String>();

			int i_temp = 0;

			for (int n = 0; n < Item_Counts; n++) {
				if ((Add_Chkbox.get(n).isEnabled())) {
					Add_Chkbox.get(n).sendKeys(Keys.SPACE);
					String p = Integer.toString(n + 1);
					String e = driver.findElement(By.xpath("//*[@id='commonTableBody']/tr[" + p + "]/td[4]")).getText();
					System.out.println("Data1 : " + e);
					MnuItem_Names.add(e);
					i_temp++;

				} else {
					System.out.println("This MI is already added");
				}
				if (i_temp == 3) {
					break;
				}
            actions.smartWait(180);
			}

			actions.keyboardEnter("CommonSelector.Save");
			actions.smartWait(180);

			mcd.SwitchToWindow("Price Sets");
			actions.WaitForElementPresent("ManagePS.AddRemoveMsg", 180);

			// Menu Items have been Added/Removed successfully from the Price
			// Set.
			String OutputMsg = driver.findElement(By.xpath(actions.getLocator("ManagePS.AddRemoveMsg"))).getText();
			if (OutputMsg.equals(strAddRemoveMsg)) {
				actions.reportCreatePASS("Verify Menu item addition", "Menu Items should be added", "Menu Items added",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify Menu item addition", "Menu Items should be added",
						"Menu Items not added", "FAIL");
			}

			actions.smartWait(180);

			// Verify that the added items are same as displayed items
			List<WebElement> Added_Items = driver.findElements(By.xpath(actions.getLocator("ManagePS.ListofAddedMI")));
			int AddItem_check = 0;
			for (int k = 0; k < Added_Items.size(); k++) {
				String Added_ItemName = Added_Items.get(k).getText().trim();
				System.out.println("Added_Items " + Added_Items.get(k).getText().split("-")[1].trim());
				System.out.println("Added_ItemName " + Added_ItemName);
				System.out.println(MnuItem_Names.get(k));
				if (Added_ItemName.contains(MnuItem_Names.get(k))) {
					AddItem_check++;
				} else {
					System.out.println("Check " + Added_ItemName);
					System.out.println("Check " + MnuItem_Names.get(k));
				}
			}

			if (AddItem_check == 3) {
				actions.reportCreatePASS("Verify menu items displayed", "Only newly added items should be displayed",
						"Only newly added items are displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify menu items displayed", "Only newly added items should be displayed",
						"Items are incorrectly displayed", "FAIL");
			}

			// Remove Menu Item

			// Click on Add/Remove for removing menu item 
			actions.keyboardEnter("ManagePriceSet.AddRemoveButton");
			//Thread.sleep(2000);
			mcd.SwitchToWindow("Price Sets : Common Menu Item Selector");
			actions.keyboardEnter("CommonSelector.ViewFullBtn");
			actions.smartWait(180);

			// Select Available from Availability drop down for removing menu
			// item and save
			actions.setValue("CommonSelector.AvailabilityDrpDwn", "Assigned");
			actions.smartWait(180);
			String remove_menuitem_name = driver.findElement(By.xpath("//*[@id='commonTableBody']/tr[1]/td[4]")).getText();
			actions.click("AddRemoveMenuItems.RemoveFirstVal");

			
			//Verify removed menu item color
			String colour = driver.findElement(By.xpath(actions.getLocator("CommonMenuItemSelector.FirstName")))
					.getAttribute("style");
			if (colour.equals("color: red;")) {
				actions.reportCreatePASS("Verifying Menu item colour", "Menu item colour should be Red",
						"Menu item colour is Red", "PASS");

			} else {
				actions.reportCreateFAIL("Verifying Menu item colour", "Menu item colour should be Red",
						"Menu item colour is NOT Red", "FAIL");
			}

			
			
			
			
			
			
			//Click on view current setting button
			actions.keyboardEnter("CommonMenuItemSelector.ViewCurrentChanges");
			mcd.SwitchToWindow("View Current Changes");
			actions.click("ViewCurrentChanges.Checkbox");
			actions.keyboardEnter("RFMQueueRoutingPopupPage.SaveButton");
			mcd.SwitchToWindow("Price Sets : Common Menu Item Selector");
			actions.click("AddRemoveMenuItems.RemoveFirstVal");
			
			
			
			
			
			
			
			
			
			

			actions.keyboardEnter("CommonSelector.Save");
			Thread.sleep(2000);

			
			// Verify pop up message while removing menu item
			Boolean VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error",
					"One or more restaurant might lose the price information on removing the menu item from this set. Do you want to continue?",
					true, AlertPopupButton.OK_BUTTON);
			if (VerifyPopUpMsg) {
				actions.reportCreatePASS("Verify Error message before removing a menu item from price set",
						"Pop Up alert with correct error message should be displayed",
						"Pop Up alert with correct error message is displayed", "PASS");
			} else {
				actions.reportCreatePASS("Verify price fields",
						"All Eating/TO/Other fields should accept values upto 2 decimal places only.",
						"All Eating/TO/Other fields accepts values more than 2 decimal places.", "FAIL");
			}
			mcd.SwitchToWindow("Price Sets");
			actions.smartWait(180);
			

			// Menu Items have been Added/Removed successfully from the Price
			// Set.
			OutputMsg = driver.findElement(By.xpath(actions.getLocator("ManagePS.AddRemoveMsg"))).getText();
			if (OutputMsg.equals(strAddRemoveMsg)) {
				actions.reportCreatePASS("Verify Menu item addition", "Menu Items should be added", "Menu Items added",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify Menu item addition", "Menu Items should be added",
						"Menu Items not added", "FAIL");
			}

			actions.smartWait(180);

			/*// Checking for removed menu item
			mcd.SwitchToWindow("Price Sets");
			actions.WaitForElementPresent("ProductionRouting.SearchTextField", 180);
			actions.setValue("ProductionRouting.SearchTextField", remove_menuitem_name);
			actions.keyboardEnter("SetAssignmentReport.SearchButton");
			actions.smartWait(180);
			actions.verifyTextPresence("Search returned no matching results.", true);*/

			// AUDIT LOG RELATED CODE

			if (mcd.GetGlobalData("Instance").toLowerCase().contains("us")) {
				strLevelUpdate = "Store[33853,EASTERN/KANE]";
			}
			String strDescription = ("Current Setting for Price Set " + strPriceSetName + " has been updated.");

			// Verify Audit log
			boolean blnAudit = false;
			blnAudit = rfm.VerifyAuditLog_Entry(strPageTitle, strActivity, strexpectlevel[0]);
			if (blnAudit) {
				actions.reportCreatePASS("Verify Audit Log Entry.", "Audit log should be generated.",
						"Audit log generated.", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Audit Log Entry", "Audit log should be generated.",
						"Audit log not generated.", "FAIL");
			}

			// Verify Audit log details
			blnAudit = rfm.RFM_VerifyAuditLog_Details(strDBName, struserid, strOperation, strActivity,
					strexpectlevel[1], strleveldetails, strDescription);
			if (blnAudit) {
				actions.reportCreatePASS("Verify the fields in the Audit log", "All the fields should be as expected",
						"All fields are as expected", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the fields in the Audit log", "All the fields should be as expected",
						"All fields are not as expected", "FAIL");
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	public void reporting_Pass_Fail(String Desc, String ExpRes, String ActRes_Pass, String ActRes_Fail,
			Boolean status) {
		if (status) {
			actions.reportCreatePASS(Desc, ExpRes, ActRes_Pass, "PASS");
		}

		if (!status) {
			actions.reportCreateFAIL(Desc, ExpRes, ActRes_Fail, "FAIL");
		}
	}
}
