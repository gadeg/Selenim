package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class PRC_0160_PRCAdminTagUpdate {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;
	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters

	private String strTagValue;
	private String strTagName1;
	private String strTagName2;
	private String strPriceSetType;
	private String strNewPrice;
	private String strsetPrice;
	private String strPrcNavigateTo;
	private String strPopUpMsg1;
	private String strPopUpMsg2;

	public PRC_0160_PRCAdminTagUpdate(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters

		strTagValue = mcd.GetTestData("TagValue");
		strTagName1 = mcd.GetTestData("TagName1");
		strTagName2 = mcd.GetTestData("TagName2");
		strPriceSetType = mcd.GetTestData("PriceSetType");
		strNewPrice = mcd.GetTestData("NewPrice");
		strsetPrice = mcd.GetTestData("setPrice");
		strPrcNavigateTo = mcd.GetTestData("PrcNavigateTo");
		strPopUpMsg1 = mcd.GetTestData("PopUpMsg1");
		strPopUpMsg2 = mcd.GetTestData("PopUpMsg2");
	}

	@Test
	public void PRC_0160_PRCAdminTagUpdate() throws InterruptedException {
	
	

		try {
			
			actions.setTestcaseDescription("Verify the Impact at Price Set screen when no value of <automatically-fill-price-type-attribute-option-price-value> and <automatically-fill-price-type-attribute-option-tax-value> tag is set.");
			System.out.println(
					"********************************************************************** Test execution starts");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			

			// ------------------------------------------------------------------------
	
			// Pre-requisites : Update fields in Admin > Update Settings

			PriceActions.RFM_Admin_Update_PricingTags(strTagValue, strTagName1, strTagName2);

			
			// Navigate to Pricing > Price sets.
			System.out.println("> Navigate to :: " + strPrcNavigateTo);
			actions.select_menu("RFMHome.Pricing", strPrcNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			
			// Verify the effect of admin changes on Pricing > Price sets
			PriceActions.RFM_PRC_PS_VerifyTaxSettingAttribute(strPriceSetType, strNewPrice, strNavigateTo, strsetPrice,
					strTagValue, strPrcNavigateTo, strPopUpMsg1, strPopUpMsg2, strTagName1, strTagName2);

			//Click on Price Set and Verify All fileds are Present or not
			String strPriceSet = driver.findElement(By.xpath(actions.getLocator("PriceSets.Pricetable"))).getText();
			actions.clear("RFMPriceSets.MainSearchbox");
			actions.keyboardEnter("RFMPriceSets.MainSearch");
			actions.smartWait(20);
			actions.setValue("RFMPriceSets.MainSearchbox", strPriceSet);
			actions.keyboardEnter("RFMPriceSets.MainSearch");
			actions.smartWait(20);
			actions.click("PriceSets.Pricetable");
			actions.smartWait(20);
			
			Boolean flag=actions.isElementPresent("ManagePriceSet.AddRemoveButton");
			reporting_Pass_Fail("Verify Add/Remove Menu Item Button is Present", "Add/Remove Menu Item Button Should be Present",
					"Add/Remove Menu Item Button is Present", "Add/Remove Menu Item Button is not Present", flag);
    
			Boolean flag1=actions.isElementPresent("ManagePS.CpyTaxStatus");
			reporting_Pass_Fail("Verify Copy Tax Button is Present", "Copy Tax Button Should be Present",
					"Copy Tax Button is Present", "Copy Tax Button is not Present", flag1);
			Boolean flag2=actions.isElementPresent("ManagePS.Status");
			reporting_Pass_Fail("Verify Status Drop Down is Present", "Status Drop Down Should be Present",
					"Status Drop Down is Present", "Status Drop Down is not Present", flag2);
			Boolean flag3=actions.isElementPresent("ManagePS.PricingFilter");
			reporting_Pass_Fail("Verify Pricing Drop Down is Present", "Pricing Drop Down Should be Present",
					"Pricing Drop Down is Present", "Pricing Drop Down is not Present", flag3);
			Boolean flag4=actions.isElementPresent("PriceSets.ChangeByDay");
			reporting_Pass_Fail("Verify Changes by Day is Present", "Changes by Day Should be Present",
					"Changes by Day is Present", "Changes by Day is not Present", flag4);
			Boolean flag5=!(actions.isElementEnabled("PriceSets.SelectedAllMenu"));
			reporting_Pass_Fail("Verify Activate Selected Menu Items is Present", "Activate Selected Menu Items Should be Present",
					"Activate Selected Menu Items is Present", "Activate Selected Menu Items is not Present", flag5);
			Boolean flag6=actions.isElementEnabled("PriceSets.ActivateAllMenu");
			reporting_Pass_Fail("Verify Activate All Menu Item  is Present", "Activate All Menu Item  Should be Present",
					"Activate All Menu Item  is Present", "Activate All Menu Item  is not Present", flag6);
			
			// Click on 'Future Changes by Menu Item' tab & Update value of
			// price type Eat in ,Verify Updated value should be Reflected.
			actions.click("PriceSets.SBFutureChngMITab");
			actions.smartWait(20);
			Thread.sleep(2000);
		
			if (actions.isElementPresent("PriceSets.Pulse")) {
				
				actions.click("PriceSets.Pulse");

			}
			actions.clear("PriceSets.futureEatinPrice");
		
			//Update value of price type Eat in and leave other two price type as blank.
			int num = mcd.fn_GetRndNumInRange(10, 99);
			actions.setValue("PriceSets.futureEatinPrice", num);
			actions.setValue("PriceSets.futureEatinTax", "Never");
			actions.setValue("PriceSets.futureEatinTax", "Never");
			Thread.sleep(1000);
			actions.setValue("PriceSets.futureTakeoutTax", "Default");
			Thread.sleep(2000);
			actions.setValue("PriceSets.FutureOtherTaxEntry", "Default");
			actions.setValue("PriceSets.futureOtherTax", "Default");

			//Click on Apply Button And Verify Alert Msg
			actions.javaScriptClick("PriceSets.Applybtn");
			actions.smartWait(20);
			actions.verifyTextPresence("Your changes have been saved.", true);

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			// Reporter.log("Test Failed :: " + e.getCause() + " - " +
			// e.getMessage());
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
	public void reporting_Pass_Fail(String Desc, String ExpRes, String ActRes_Pass, String ActRes_Fail,
			Boolean status) {
		if (status) {
			actions.reportCreatePASS(Desc, ExpRes, ActRes_Pass, "PASS");
		}

		if (!status) {
			actions.reportCreateFAIL(Desc, ExpRes, ActRes_Fail, "FAIL");
		}
	}

}