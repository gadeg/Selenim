/**
 * 
 */
package xtam.test;

/**
 * @author akrani
 *
 */
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class PRC_20275_MITSsetNtMadeInactive {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;
	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private String strNavigateTo_RP, strNode, ErroMsg, Status, strNavigateTo_Report;
	private String strMITS, strMenuIteamTaxSetDropdownValue, strPopup, Err, ErrSplit[], strPopupSplit[],
			strNewMenuIteamTaxSetName, strMenuItemTaxSet, strRestaurentNo, strNavigateTo_SetAssig;
	boolean flag = false;
	private String FutureSettings;
	Integer rowCount = 0;
	private String strwms, Expectms[], StrWMsg;

	public PRC_20275_MITSsetNtMadeInactive(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);
		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters
		strNavigateTo_RP = mcd.GetTestData("DT_NAVIGATE_TO_RP");
		strNode = mcd.GetTestData("DT_NODE");
		ErroMsg = mcd.GetTestData("DT_ERROR_MITS");
		Status = mcd.GetTestData("DT_STATUS");
		Err = mcd.GetTestData("DT_ERROR");
		strPopup = mcd.GetTestData("DT_POPUP");
		strPopupSplit = strPopup.split("#");
		ErrSplit = Err.split("#");
	}

	@Test
	public void test_PRC_20275_MITSsetNtMadeInactive() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription(
					"Verify that set cannot be made inactive if it is assigned to one or more restaurants.");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();
			// ------------------------------------------------------------------------
			// Create Menu Item Tax Set
			strNewMenuIteamTaxSetName = RFM_PRC_CreateNewMenuIteamTaxSet(strNode, "Hierarchies", "", "", "", "", "",
					Status, ErroMsg);
			actions.keyboardEnter("NewScript.CancleButton");
			mcd.waitAndSwitch("#Title");

			// Navigate Restaurant Profile
			System.out.println("> Navigate to :: " + strNavigateTo_RP);
			actions.select_menu("RFMHome.Navigation", strNavigateTo_RP);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			// Select the Active From DDL
			actions.setValue("RestaurantProfile.ARStatusDropDown", "Active");
			actions.smartWait(150);

			// Validating whether Future Settings already present or not
			rowCount = mcd.GetTableRowCount("ScriptManagement.TableNameValue");
			if (rowCount > 1) {
				for (int i = 1; i <= rowCount; i++) {
					FutureSettings = mcd.GetTableCellValue("ScriptManagement.TableNameValue", i, "Future Settings", "",
							"");
					if (FutureSettings.equals("")) {
						// Retrieving Tender Type Name of table
						strRestaurentNo = mcd.GetTableCellValue("ScriptManagement.TableNameValue", 1, "Number", "", "");
						WebElement ElementTaxTypNm = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1,
								"Number", "a");
						actions.keyboardEnter(ElementTaxTypNm);
						break;
					}
				}
			} else if (rowCount == 1) {
				strRestaurentNo = mcd.GetTableCellValue("ScriptManagement.TableNameValue", 1, "Number", "", "");
				WebElement ElementTaxTypNm = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1, "Number",
						"a");
				actions.keyboardEnter(ElementTaxTypNm);
			} else {
				System.out.println("No Active Resturent No Available ");
			}

			// Click on Operation details Tab and Select the menu item tax set
			// ddl value
			actions.smartWait(100);
			actions.keyboardEnter("RestaurantProfile.OperationsDetails");
			actions.smartWait(100);
			actions.setValue("RestaurantProfile.MenuIteamTaxSetDropdown", strNewMenuIteamTaxSetName);
			actions.keyboardEnter("RestaurantProfile.ApplyButton");
			try {
				mcd.waitAndSwitch("Apply Changes Details");
				actions.keyboardEnter("ApplyChangesDetails.Save");
			} catch (Exception e) {

			}
			try {
				mcd.waitAndSwitch("Run Validation Report");
				actions.keyboardEnter("PromotionReport.OkBtn");
				mcd.waitAndSwitch("@Restaurant Profile");
			} catch (Exception e) {

			}
			// Navigate to Menu item tax set
			actions.smartWait(50);
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			// Select newly create Menu item tax set
			actions.clear("TenderSet.SearchTextBox");
			actions.setValue("TenderSet.SearchTextBox", strNewMenuIteamTaxSetName);
			actions.keyboardEnter("TaxType.SearchButton");
			actions.smartWait(30);
			WebElement ElementCurrentSetting = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1, "Name",
					"a");
			actions.keyboardEnter(ElementCurrentSetting);
			mcd.waitAndSwitch("Apply Changes Details");
			actions.keyboardEnter("ApplyChangesDetails.RPSaveButton");
			mcd.waitAndSwitch("@Manage Menu Item Tax Set");

			// Change the Status Active to inactive
			actions.setValue("ManageMenuItemTaxSet.StatusDropDown", "Inactive");
			actions.keyboardEnter("ManageMenuItemTaxSet.ApplyButton");
			actions.smartWait(50);

			// Verify the on-screen message
			flag = mcd.VerifyOnscreenMessage("ManageMenuItemTaxSet.ErrMsg",
					"The Menu Item Tax Set you have chosen to deactivate is assigned to one or more Restaurants. You must remove the Set assignment from all the Restaurants in order to deactivate this Set",
					true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message",
						"Message 'The Menu Item Tax Set you have chosen to deactivate is assigned to one or more Restaurants. You must remove the Set assignment from all the Restaurants in order to deactivate this Set'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message",
						"Message 'The Menu Item Tax Set you have chosen to deactivate is assigned to one or more Restaurants. You must remove the Set assignment from all the Restaurants in order to deactivate this Set'",
						"Expected Message is not displayed", "FAIL");
			}

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}

	public String RFM_PRC_CreateNewMenuIteamTaxSet(String strNode, String strSearchBy, String MenuIteamSearchBy,
			String Data, String TaxCode, String TaxRule, String TaxEntry, String Status, String ErroMsg)
			throws Exception {

		String strNewMenuIteamTaxSetName, Datasplit[], ErroMsgSplit[];
		boolean flag = false;
		Datasplit = Data.split("#");
		ErroMsgSplit = ErroMsg.split("#");

		actions.keyboardEnter("MenuItemTaxSet.NewMenuItemTaxSetButton");

		// Switching to "Add New Menu Item Tax Set"
		mcd.SwitchToWindow("Add New Menu Item Tax Set");

		actions.keyboardEnter("AddNewMenuItemTaxSet.SelectButton");

		Thread.sleep(5000);
		// actions.smartWait(10);
		mcd.SwitchToWindow("Select Node");

		if (strSearchBy.equals("RestaurantNumber")) {
			// actions.click("SelectNode.RestaurantNumberRadioButton");
		} else if (strSearchBy.equals("Hierarchies")) {
			actions.click("SelectNode.HierarchiesRadioButton");
		}
		actions.setValue("SelectNode.SearchTextTreeTextBox", strNode);
		actions.click("SelectNode.ExactMatchRadioButton");

		// Clicking on Search button
		driver.findElement(By.xpath(actions.getLocator("RFMAuditLog.SearchRestaurant"))).click();
		// actions.smartWait(15);
		actions.WaitForElementPresent("SelectNode.ARTableFirstValue", 5);
		// mcd.Selectrestnode("SelectNode.MITSTree", strNode);
		if (mcd.GetGlobalData("Instance").toLowerCase().contains("eu")) {
			mcd.Selectrestnode_JavaScriptClk("SelectNode.CPTable", strNode);
		} else {
			mcd.Selectrestnode("SelectNode.MITSTree", strNode);

		}
		mcd.SwitchToWindow("Add New Menu Item Tax Set");

		do {

			strNewMenuIteamTaxSetName = mcd.fn_GetRndName("AMITS");
			actions.clear("NewTaxType.TaxTypeNameField");
			actions.setValue("NewTaxType.TaxTypeNameField", strNewMenuIteamTaxSetName);
			System.out.println("strNewMenuIteamTaxSetName" + strNewMenuIteamTaxSetName);

			actions.keyboardEnter("AddNewTenderSet.NextButton");
			// actions.smartWait(15);
			try {
				Thread.sleep(4000);
				flag = mcd.VerifyOnscreenMessage("NewScript.ResultMsg", ErroMsgSplit[0], true);
			} catch (Exception e) {
				System.out.println("Menu Item Tax Set Name accepted successfully");

				flag = false;
			}

		} while (flag);

		mcd.SwitchToWindow("@Menu Item Tax Set : Common Menu Item Selector");
		actions.click("AddRemoveMenu.Searchbtn2");
		actions.smartWait(30);
		WebElement ElementMenuIteamNm = mcd.GetTableCellElement("AddTenderType.Table", 1, "Add", "input[1]");
		actions.click(ElementMenuIteamNm);
		WebElement ElementMenuIteamNm1 = mcd.GetTableCellElement("AddTenderType.Table", 2, "Add", "input[1]");
		actions.click(ElementMenuIteamNm1);
		actions.click("AddTaxType.SaveButton");
		actions.smartWait(10);

		// Switching to Manage Menu Item Tax Set
		mcd.SwitchToWindow("#Title");

		switch (TaxCode) {
		case "Always":
			actions.setValue("ManageMenuItemTaxSet.TaxCodeDropDown", "Always");
			break;
		case "Never":
			actions.setValue("ManageMenuItemTaxSet.TaxCodeDropDown", "Never");
			break;
		case "Optional":
			actions.setValue("ManageMenuItemTaxSet.TaxCodeDropDown", "Optional");
			break;
		default:
			actions.setValue("ManageMenuItemTaxSet.TaxCodeDropDown", "Never");
		}

		switch (Status) {
		case "Active":
			actions.setValue("ManageMenuItemTaxSet.StatusDropDown", "Active");
			break;
		case "Inactive":
			actions.setValue("ManageMenuItemTaxSet.StatusDropDown", "Inactive");
			break;
		}

		actions.keyboardEnter("ManageMenuItemTaxSet.ApplyButton");
		actions.smartWait(10);
		flag = mcd.VerifyOnscreenMessage("UpdateTaxType.SvMessage", ErroMsgSplit[2], true);

		if (flag) {
			actions.reportCreatePASS("Verify Your changes have been saved. message is displaying",
					"Your changes have been saved. message should display",
					"Your changes have been saved. message is displaying", "Pass");
		} else {
			actions.reportCreateFAIL("Verify Your changes have been saved. message is displaying",
					"Your changes have been saved. message should display",
					"Your changes have been saved. message is not displaying", "Fail");
		}
		System.out.println("strNewMenuIteamTaxSetName" + strNewMenuIteamTaxSetName);
		return strNewMenuIteamTaxSetName;
	}

}