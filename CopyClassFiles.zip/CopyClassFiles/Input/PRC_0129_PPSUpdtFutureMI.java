package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class PRC_0129_PPSUpdtFutureMI {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo,struserid;
	// TODO: Declare test-data variables for other data-parameters

	private String strPriceSetType;
	private String strApplicationDate;
	private String strVal;
	private String strNavigateToST,strActivity,strLevelUpdate,strDBName,strUserName_string,strOperation,strleveldetails,strexpectlevel[];

	public PRC_0129_PPSUpdtFutureMI(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		struserid=mcd.GetTestData("DT_USER_NAME");

		// TODO: GetTestData for other data-parameters
		strPriceSetType = mcd.GetTestData("PriceSetType");
		strVal = mcd.GetTestData("DT_VAL");
		strNavigateToST = mcd.GetTestData("DT_NAVIGATE_TO_ST");
		strActivity = mcd.GetTestData("DT_ACTIVITY");
		strLevelUpdate = mcd.GetTestData("DT_LEVEL_Update");
		strDBName = mcd.GetTestData("DT_DB_NAME");
		strUserName_string = strUserName.toString();
		strOperation = mcd.GetTestData("DT_OPERATION");
		strleveldetails=mcd.GetTestData("DT_LEVELDETAILS");
		
		strexpectlevel=strLevelUpdate.split("#");
	}

	@Test
	public void PRC_0129_PPSUpdtFutureMI() throws InterruptedException {
		String strPageTitle = "Price Sets";
		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription(
					"Verify Update Price Set Details (Future Changes by Menu Item) functionality  of Promotion price set ");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateToST);
			actions.select_menu("RFMHome.Navigate", strNavigateToST);
			Thread.sleep(5000);
			actions.waitForPageToLoad(120);

			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Actions specific to test-flow
			// Update Settings in Admin
			rfm.RFM_Admin_Update_PricingTags("false", "Restrict price type attribute from expanding");
			rfm.RFM_Admin_Update_PricingTags("0", "Automatically fill price type attribute option price value");
			rfm.RFM_Admin_Update_PricingTags("0", "Automatically fill price type attribute option tax value");
			rfm.RFM_Admin_Update_PricingTags("false", "Display price type attribute as expanded by default");

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigate", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			actions.WaitForElementPresent("MenuItempriceByPriceSetReport.PriceTypeDDL");
			String[] msg = strVal.split("#");

			// Select Promotional option in Search with Type DDL and Click on
			// Search Button
			actions.setValue("MenuItempriceByPriceSetReport.PriceTypeDDL", strPriceSetType);
			actions.setValue("SetAssignmentReport.SearchTextBox", "p");
			actions.keyboardEnter("SetAssignmentReport.SearchButton");
			actions.smartWait(180);

			// Clicking on 1st MI
			Actions builder = new Actions(driver);
			builder.moveByOffset(0, 500).click().perform();
			String promotionset_Name = driver.findElement(By.xpath(actions.getLocator("MasterMenuItemList.NumberLink")))
					.getText();
			WebElement ele = mcd.GetTableCellElement("PackageSchedule.Table", 1, "Name", "a");
			actions.click(ele);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			// Verifying Change by date tab is enable
			if (actions.isElementEnabled("PriceSets.Changesbydate")) {
				actions.reportCreatePASS("Verify Change by date tab", "Change by date tab should enable",
						"Change by date tab is enable", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Change by date tab", "Change by date tab should enable",
						"Change by date tab is not enable", "FAIL");

			}

			// Verifying Price DDL is enable
			if (actions.isElementEnabled("PriceSets.Changesbydate")) {
				actions.reportCreatePASS("Verify Price DDL", "Price DDL should enable", "Price DDL is enable", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Price DDL", "Price DDL should enable", "Price DDL is not enable",
						"FAIL");

			}

			/*// Verifying Mass update tax settings is disable
			if (!actions.isElementEnabled("ManagePS.UpdtTaxBtn2")) {
				actions.reportCreatePASS("Verify Mass update tax settings button",
						"Mass update tax settings button should disable", "Mass update tax settings button is disable",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify Mass update tax settings button",
						"Mass update tax settings button should disable",
						"Mass update tax settings button is not disable", "FAIL");

			}

			// Verifying Copy tax is disable
			if (!actions.isElementEnabled("ManagePS.CpyTaxStatus")) {
				actions.reportCreatePASS("VerifyCopy tax button", "Copy tax button should disable",
						"Copy tax button is disable", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Copy tax button", "Copy tax button should disable",
						"Copy tax button is not disable", "FAIL");

			}*/

			// Click on Future Changes By Menu Item tab for future date setting
			try {
				driver.findElement(By.xpath(actions.getLocator("ManagePS.FutureDate"))).isDisplayed();
				actions.click("ManagePS.FutureDate");
				actions.smartWait(180);
			} catch (Exception e) {
				if (strPriceSetType.equals("Base")) {
					mcd.SelectDate_OpenCalender("10", "next");
					Thread.sleep(1000);
					actions.smartWait(120);
				} else {
					int d = 10;

					mcd.SelectDate_OpenCalender(Integer.toString(d), "next");
					Thread.sleep(1000);
					actions.smartWait(120);
					mcd.SelectDate_OpenCalender(Integer.toString(d + 2), "current");
					Thread.sleep(1000);
					actions.smartWait(120);
				}

				// Entering future price in All price text boxs
				actions.clear("ManagePS.AllPrice");
				String price = mcd.fn_GetRndNumericString(2);
				actions.setValue("ManagePS.AllPrice", price);
				actions.click("ManagePS.QuickToolApply");
				actions.smartWait(180);
				try {
					driver.findElement(By.xpath(actions.getLocator("ManagePS.PPALLSave"))).isDisplayed();
					actions.click("ManagePS.PPALLSave");
					actions.smartWait(120);
				} catch (Exception e2) {
					actions.click("FutureSettings.Apply");
					Thread.sleep(1000);
					actions.smartWait(120);
				}
				try {
					String Alertvalue = driver.switchTo().alert().getText();
					if (Alertvalue.contains("You have specified incomplete tax information")) {
						driver.switchTo().alert().accept();
					}

				} catch (Exception e1) {

				}
				actions.smartWait(120);

				// Verify on screen message
				actions.verifyTextPresence("Your changes have been saved.", true);
				}

			// Click on future changes by menu item tab and click on search
			// without entering any data
			actions.click("PriceSets.CPFutrChngsTab");
			actions.waitForPageToLoad(180);
			mcd.SwitchToWindow("#Title");
			actions.WaitForElementPresent("ManageMenuItemPriceSet.CPSrchBtn");
			actions.keyboardEnter("ManageMenuItemPriceSet.CPSrchBtn");

			// Verify "Please enter a search criteria" Pop-up Message
			boolean popup = mcd.VerifyAlertMessageDisplayed("Warning", msg[0], true, AlertPopupButton.OK_BUTTON);
			if (popup) {
				actions.reportCreatePASS("Verify that popup is displayed", "Popup should be displayed",
						"Popup is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify that popup is displayed", "Popup should be displayed",
						"Popup is not displayed", "Fail");
			}

			// Enter menu item name in search text box and click on search
			// button
			actions.WaitForElementPresent("SetAssignmentReport.SearchTextBox", 20);
			String miname = mcd.GetTableCellValue("UpdateSet.MenuItemTable", 1, "| Name", "", "");
			actions.setValue("SetAssignmentReport.SearchTextBox", miname);
			actions.click("SetAssignmentReport.SearchButton");

			// Handling pop-up message
			mcd.VerifyAlertMessageDisplayed("Warning", "Unsaved data will be lost.Are you sure you want to proceed?",
					true, AlertPopupButton.CANCEL_BUTTON);

			actions.WaitForElementPresent("ManageMenuItemPriceSet.CPTxCd", 30);

			// Select Always from Tax Code DDL and click on apply button
			actions.setValue("ManageMenuItemPriceSet.CPTxCd", msg[7]);
			actions.keyboardEnter("PromotionMgmt.ApplyButton");

			// Click on pop- up message
			mcd.VerifyAlertMessageDisplayed("Warning", msg[1], true, AlertPopupButton.OK_BUTTON);
			actions.smartWait(180);

			// Select ALways from Tax Code DDL and Select VAT from Tax Rule DDL
			// and click on apply button
			Select SubGrpDDL2 = new Select(
					driver.findElement(By.xpath(actions.getLocator("ManageMenuItemPriceSet.CPTxCd"))));
			SubGrpDDL2.selectByIndex(0);

			Select SubGrpDDL3 = new Select(
					driver.findElement(By.xpath(actions.getLocator("ManageMenuItemPriceSet.CPTxRule"))));
			SubGrpDDL3.selectByIndex(8);
			actions.click("PromotionMgmt.ApplyButton");

			// Verify "Tax Entry is mandatory if a Tax Rule is selected" pop-up
			// message
			boolean popup1 = mcd.VerifyAlertMessageDisplayed("Warning", msg[2], true, AlertPopupButton.OK_BUTTON);
			if (popup1) {
				actions.reportCreatePASS("Verify that popup is displayed", "Popup should be displayed",
						"Popup is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify that popup is displayed", "Popup should be displayed",
						"Popup is not displayed", "Fail");
			}

			// Select default from Tax Rule DDL and Select 1 from Tax Entry DDL
			Select SubGrpDDLr = new Select(
					driver.findElement(By.xpath(actions.getLocator("ManageMenuItemPriceSet.CPTxRule"))));
			SubGrpDDLr.selectByIndex(1);

			Select SubGrpDDL4 = new Select(
					driver.findElement(By.xpath(actions.getLocator("ManageMenuItemPriceSet.CPTxEntry"))));
			SubGrpDDL4.selectByIndex(1);

			// Verify "Please select Tax Rule" popup message
			boolean popup2 = mcd.VerifyAlertMessageDisplayed("Warning", msg[3], true, AlertPopupButton.OK_BUTTON);
			if (popup2) {
				actions.reportCreatePASS("Verify that popup is displayed", "Popup should be displayed",
						"Popup is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify that popup is displayed", "Popup should be displayed",
						"Popup is not displayed", "Fail");
			}

			// Select Default from Tax Code DDL and Select VAT from Tax Rule DDL
			Select SubGrpDDL5 = new Select(
					driver.findElement(By.xpath(actions.getLocator("ManageMenuItemPriceSet.CPTxCd"))));
			SubGrpDDL5.selectByIndex(1);

			Select SubGrpDDL6 = new Select(
					driver.findElement(By.xpath(actions.getLocator("ManageMenuItemPriceSet.CPTxRule"))));
			SubGrpDDL6.selectByIndex(8);

			// Verify "Please select Tax Code" pop-up message
			boolean popup3 = mcd.VerifyAlertMessageDisplayed("Warning", msg[4], true, AlertPopupButton.OK_BUTTON);
			if (popup3) {
				actions.reportCreatePASS("Verify that popup is displayed", "Popup should be displayed",
						"Popup is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify that popup is displayed", "Popup should be displayed",
						"Popup is not displayed", "Fail");
			}

			// click on cancel button
			actions.click("RFMRoutingPopupPage.CancelButton");

			// Verify "Unsaved data will be lost. Are you sure you want to
			// proceed" popup message
			boolean popup4 = mcd.VerifyAlertMessageDisplayed("Warning", msg[5], true, AlertPopupButton.CANCEL_BUTTON);
			if (popup4) {
				actions.reportCreatePASS("Verify that popup is displayed", "Popup should be displayed",
						"Popup is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify that popup is displayed", "Popup should be displayed",
						"Popup is not displayed", "Fail");
			}

			// Select Never from Tax Code DDL and Click on Apply Button
			Select SubGrpDDL7 = new Select(
					driver.findElement(By.xpath(actions.getLocator("ManageMenuItemPriceSet.CPTxCd"))));
			SubGrpDDL7.selectByIndex(2);
			actions.click("PromotionMgmt.ApplyButton");
			actions.smartWait(180);

			// Verify the OnScreen Message
			boolean is_displayed = mcd.VerifyOnscreenMessage("ManageMenuItemPriceSet.CPmsg", msg[6], true);
			if (is_displayed) {
				actions.reportCreatePASS("Verify that Onscreen Message is Displayed",
						"Onscreen Message should be Displayed", "Onscreen Message is Displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify that Onscreen Message is Displayed",
						"Onscreen Message should be Displayed", "Onscreen Message is not Displayed", "Fail");
			}
			actions.setValue("ManageMenuItemPriceSet.CPTxCd", msg[7]);

			// Select Tax chain from Tax Rule DDL and Select tax chain from Tax
			// Entry DDL
			Select SubGrpDDLt = new Select(
					driver.findElement(By.xpath(actions.getLocator("ManageMenuItemPriceSet.CPTxRule"))));
			SubGrpDDLt.selectByIndex(7);

			actions.WaitForElementPresent("ManageMenuItemPriceSet.CPTxchnEntry");
			Select SubGrpDDLe = new Select(
					driver.findElement(By.xpath(actions.getLocator("ManageMenuItemPriceSet.CPTxchnEntry"))));
			SubGrpDDLe.selectByIndex(2);

			// Click on Apply Button
			actions.click("PromotionMgmt.ApplyButton");
			actions.smartWait(180);
			actions.verifyTextPresence("Your changes have been saved.", true);

			// For updated menu item having Tax Rule as Tax chain select another
			// option in Tax entry DDL
			// Select Tax_Chain option in Tax Entry DDL
			actions.WaitForElementPresent("ManageMenuItemPriceSet.CPTxchnEntry");
			Select SubGrpDDLtc2 = new Select(
					driver.findElement(By.xpath(actions.getLocator("ManageMenuItemPriceSet.CPTxchnEntry"))));
			SubGrpDDLtc2.selectByIndex(3);

			// Click on Apply Button
			actions.click("PromotionMgmt.ApplyButton");
			actions.smartWait(180);
			actions.verifyTextPresence("Your changes have been saved.", true);

			
			//AUDIT LOG RELATED CODE


			if (mcd.GetGlobalData("Instance").toLowerCase().contains("us")) {
							strLevelUpdate = "Store[33853,EASTERN/KANE]";
						}
						String strDescription = ("Future Setting 10/05/2017 for Price Set " + promotionset_Name + " has been updated.");
						
						
						// Verify Audit log
						boolean blnAudit = false;
						blnAudit = rfm.VerifyAuditLog_Entry(strPageTitle, strActivity, strexpectlevel[0]);
						if (blnAudit) {
							actions.reportCreatePASS("Verify Audit Log Entry.", "Audit log should be generated.",
									"Audit log generated.", "PASS");
						} else {
							actions.reportCreateFAIL("Verify Audit Log Entry", "Audit log should be generated.",
									"Audit log not generated.", "FAIL");
						}

						
						// Verify Audit log details
						blnAudit = rfm.RFM_VerifyAuditLog_Details(strDBName, struserid, strOperation, strActivity,
								strexpectlevel[1], strleveldetails, strDescription);
						if (blnAudit) {
							actions.reportCreatePASS("Verify the fields in the Audit log", "All the fields should be as expected",
									"All fields are as expected", "PASS");
						} else {
							actions.reportCreateFAIL("Verify the fields in the Audit log", "All the fields should be as expected",
									"All fields are not as expected", "FAIL");
						}
			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}