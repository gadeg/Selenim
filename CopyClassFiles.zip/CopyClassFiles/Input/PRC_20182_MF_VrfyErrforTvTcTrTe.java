package xtam.test;

import java.util.Map;
import java.util.Random;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class PRC_20182_MF_VrfyErrforTvTcTrTe {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private String strMsg;
	private String strNavigateToAdmin;
	private String AllPrc;

	public PRC_20182_MF_VrfyErrforTvTcTrTe(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters
		strMsg = mcd.GetTestData("DT_MSG");
		AllPrc = mcd.GetTestData("AllPrcValue");
		strNavigateToAdmin = mcd.GetTestData("DT_NAVIGATE_TO_ADMIN");
	}

	@Test
	public void test_PRC_20182_MF_VrfyErrforTvTcTrTe() throws InterruptedException {
		// String strPageTitle = "Fee"; // TODO: Exact page-title
		// String strPageSubHeading = ""; // TODO: Page Heading
		// TODO: Test Case Description
		String strTestDescription = "Verify error message for Tax Value field, Take Out Tax Code, Tax Rule, Tax Entry when it is expanded";

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			/** Get Test case Description */
			actions.setTestcaseDescription(strTestDescription);

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateToAdmin);
			actions.select_menu("RFMHome.Navigation", strNavigateToAdmin);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Verify Page Header */
			// System.out.println("> Verify Page Heading");
			// mcd.VerifyPageTitle(strPageTitle);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Actions specific to test-flow
			// Aotomating the Pre - Req
			rfm.RFM_Admin_Update_PricingTags("false", "Restrict price type attribute from expanding");
			rfm.RFM_Admin_Update_PricingTags("false", "Display price type attribute as expanded by default");
			rfm.RFM_Admin_Update_PricingTags("0", "Automatically fill price type attribute option price value");
			rfm.RFM_Admin_Update_PricingTags("0", "Automatically fill price type attribute option tax value");

			actions.waitForPageToLoad(120);
			/** Navigate to Master Fee */
			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(180);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");
			actions.waitForPageToLoad(120);

			String[] Msg = strMsg.split("#");

			// Click on new fee button
			actions.WaitForElementPresent("MasterFee.NewFeeBtn");
			actions.keyboardEnter("MasterFee.NewFeeBtn");
			actions.smartWait(30);

			// clear fee id field
			actions.WaitForElementPresent("MasterFee.FeeId");
			actions.clear("MasterFee.FeeId");

			// Entering unique ID
			Random rand_num = new Random();
			int iFeeId = rand_num.nextInt((99) + 5);
			System.out.println(iFeeId);
			actions.setValue("MasterFee.FeeId", Integer.toString(iFeeId));

			// Selct value from Fee Type Dropdown
			actions.WaitForElementPresent("MasterFee.FeeType");
			actions.setValue("MasterFee.FeeType", "Rate");

			// Entering unique Name
			actions.WaitForElementPresent("MasterFee.FeeName");
			String strNewFeeName = mcd.fn_GetRndName("ATS");
			actions.setValue("MasterFee.FeeName", strNewFeeName);

			actions.WaitForElementPresent("FeeSet.AllPrc");
			actions.clear("FeeSet.AllPrc");
			actions.setValue("FeeSet.AllPrc", AllPrc);
			Thread.sleep(2000);

			// clicking on TaxvalueExpand
			actions.javaScriptClick("DepositSet.TaxPlusIcon");

			// Verifying one box at a time
			// Take out tax code
			actions.WaitForElementPresent("DepositSet.TOTaxCode");
			actions.setValue("DepositSet.TOTaxCode", "Always");
			actions.click("ApplyChangesDetails.Save");

			// Verify Alert message
			boolean msg0 = mcd.VerifyAlertMessageDisplayed("Warning", Msg[0], true, AlertPopupButton.OK_BUTTON);

			if (msg0) {
				actions.reportCreatePASS("Verify 'Please select Takeout Tax Rule' Alert",
						"'Please select Takeout Tax Rule' Alert should be displayed",
						"'Please select Takeout Tax Rule' Alert is displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Verify 'Please select Takeout Tax Rule' Alert",
						"'Please select Takeout Tax Rule' Alert should be displayed",
						"'Please select Takeout Tax Rule' Alert is not displayed", "Fail");
			}

			// Take out tax rule
			actions.WaitForElementPresent("DepositSet.TOTaxRule");
			actions.setValue("DepositSet.TOTaxRule", "GST");
			actions.click("ApplyChangesDetails.Save");

			// Verify Alert message
			boolean msg1 = mcd.VerifyAlertMessageDisplayed("Warning", Msg[1], true, AlertPopupButton.OK_BUTTON);

			if (msg1) {
				actions.reportCreatePASS("Verify 'Please select Takeout Tax Entry' Alert",
						"'Please select Takeout Tax Entry' Alert should be displayed",
						"'Please select Takeout Tax Entry' Alert is displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Verify 'Please select Takeout Tax Entry' Alert",
						"'Please select Takeout Tax Entry' Alert should be displayed",
						"'Please select Takeout Tax Entry' Alert is not displayed", "Fail");
			}

			// Take out tax entry
			// actions.setValue("DepositSet.TOTaxEntry", "1");
			actions.WaitForElementPresent("DepositSet.TOTaxEntry");
			Select select = new Select(actions.getWebElement("DepositSet.TOTaxEntry"));
			select.selectByIndex(1);

			Thread.sleep(1000);
			actions.click("ApplyChangesDetails.Save");
			actions.smartWait(180);

			boolean flag = false, flagFeeId = false;
			try {
				actions.WaitForElementPresent("ManageFee.SSMsg");
				flag = mcd.VerifyOnscreenMessage("ManageFee.SSMsg", Msg[6], true);

			} catch (Exception e) {

				do {
					try {
						flagFeeId = mcd.VerifyOnscreenMessage("MasterFee.Header", Msg[7], true);
						if (flagFeeId) {
							actions.clear("MasterFee.FeeId");
							// Entering unique Fee ID
							rand_num = new Random();
							iFeeId = rand_num.nextInt((99) + 5);
							System.out.println(iFeeId);
							actions.setValue("MasterFee.FeeId", Integer.toString(iFeeId));
							actions.keyboardEnter("ApplyChangesDetails.Save");
							actions.smartWait(180);
						}
					} catch (Exception ee) {
						actions.WaitForElementPresent("ManageFee.SSMsg");
						flag = mcd.VerifyOnscreenMessage("ManageFee.SSMsg", Msg[6], true);
						flagFeeId = false;
					}
				} while (flagFeeId);
			}
			actions.verifyTextPresence("Your changes have been saved.", true);

			// Verifying two boxes at a time
			actions.WaitForElementPresent("DepositSet.TOTaxCode");
			actions.setValue("DepositSet.TOTaxCode", "Always");
			actions.setValue("DepositSet.TOTaxRule", "GST");
			actions.setValue("DepositSet.TOTaxEntry", "Select");
			actions.click("ManageFee.Applybtn");
			mcd.VerifyAlertMessageDisplayed("Warning", Msg[1], true, AlertPopupButton.OK_BUTTON);

			actions.WaitForElementPresent("DepositSet.TOTaxCode");
			actions.setValue("DepositSet.TOTaxCode", "Always");
			// actions.setValue("DepositSet.TOTaxEntry", "1");
			Select select1 = new Select(actions.getWebElement("DepositSet.TOTaxEntry"));
			select1.selectByIndex(1);
			actions.click("ManageFee.Applybtn");

			// Verify Alert message
			boolean msg3 = mcd.VerifyAlertMessageDisplayed("Warning", Msg[3], true, AlertPopupButton.OK_BUTTON);

			if (msg3) {
				actions.reportCreatePASS("Verify 'No changes have been made' Alert",
						"'No changes have been made' Alert should be displayed",
						"'No changes have been made' Alert is displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Verify 'No changes have been made' Alert",
						"'No changes have been made' Alert should be displayed",
						"'No changes have been made' Alert is not displayed", "Fail");
			}

			actions.WaitForElementPresent("DepositSet.TOTaxCode");
			actions.setValue("DepositSet.TOTaxCode", "Select");
			actions.setValue("DepositSet.TOTaxRule", "GST");

			// Verify Alert message
			boolean msg4 = mcd.VerifyAlertMessageDisplayed("Warning", Msg[4], true, AlertPopupButton.OK_BUTTON);

			if (msg4) {
				actions.reportCreatePASS("Verify 'Please select Tax Code' Alert",
						"'Please select Tax Code' Alert should be displayed",
						"'Please select Tax Code' Alert is displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Verify 'Please select Tax Code' Alert",
						"'Please select Tax Code' Alert should be displayed",
						"'Please select Tax Code' Alert is not displayed", "Fail");
			}

			// actions.setValue("DepositSet.TOTaxEntry", "1");
			actions.WaitForElementPresent("DepositSet.TOTaxEntry");
			Select select2 = new Select(actions.getWebElement("DepositSet.TOTaxEntry"));
			select2.selectByIndex(1);

			// Verify Alert message
			boolean msg5 = mcd.VerifyAlertMessageDisplayed("Warning", Msg[5], true, AlertPopupButton.OK_BUTTON);

			if (msg5) {
				actions.reportCreatePASS("Verify 'Please select Tax Rule' Alert",
						"'Please select Tax Rule' Alert should be displayed",
						"'Please select Tax Rule' Alert is displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Verify 'Please select Tax Rule' Alert",
						"'Please select Tax Rule' Alert should be displayed",
						"'Please select Tax Rule' Alert is not displayed", "Fail");
			}

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}