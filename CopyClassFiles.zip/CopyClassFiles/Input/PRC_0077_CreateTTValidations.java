package xtam.test;

import java.util.Date;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class PRC_0077_CreateTTValidations {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strApplicationDate;
	// TODO: Declare test-data variables for other data-parameters

	private String strTenderName;
	private String strTenderId;
	private String strLegacyId;
	private String strFiscalIndex;
	private String strDefSkimAmt;
	private String strDefHaloAmt;
	private String strCurrencyDecimal;
	private String strChgMaxAllwd;

	private String strPaymentType;
	private String strTaxOption;
	private String strTaxSubTotalOption;
	private String strChangeName;
	private String strStatus;
	private String strForeignCurrency;
	private String strExchangeRate;
	private String strOrientation;
	private String strPrecision;
	private String strRounding;
	private String strExchMode;
	private String strAmount, STenderName;
	private String[] strMessages;

	public PRC_0077_CreateTTValidations(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters

		strTenderName = mcd.GetTestData("TenderName");
		strTenderId = mcd.GetTestData("TenderId");
		strLegacyId = mcd.GetTestData("LegacyId");
		strFiscalIndex = mcd.GetTestData("FiscalIndex");
		strDefSkimAmt = mcd.GetTestData("DefSkimAmt");
		strDefHaloAmt = mcd.GetTestData("DefHaloAmt");
		strCurrencyDecimal = mcd.GetTestData("CurrencyDecimal");
		strChgMaxAllwd = mcd.GetTestData("ChgMaxAllwd");

		strPaymentType = mcd.GetTestData("PaymentType");
		strTaxOption = mcd.GetTestData("TaxOption");
		strTaxSubTotalOption = mcd.GetTestData("TaxSubTotalOption");
		strChangeName = mcd.GetTestData("ChangeName");
		strStatus = mcd.GetTestData("Status");
		strForeignCurrency = mcd.GetTestData("ForeignCurrency");
		strExchangeRate = mcd.GetTestData("ExchangeRate");
		strOrientation = mcd.GetTestData("Orientation");
		strPrecision = mcd.GetTestData("Precision");
		strRounding = mcd.GetTestData("Rounding");
		strExchMode = mcd.GetTestData("ExchMode");
		strAmount = mcd.GetTestData("Amount");
		strMessages = mcd.GetTestData("Messages").split("#");

	}

	@Test
	public void PRC_0077_CreateTTValidations() throws InterruptedException {
		String strPageTitle = "Tender Type List"; // TODO: Exact page-title
		String strPageSubHeading = "Tender Type List"; // TODO: Page Heading

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			String strTestDescription = "Verify the error messages when mandatory fields are left blank and clicked on save."; // TODO:
																																// Test
																																// Case
																																// Description

			/** Get application time */
			actions.setTestcaseDescription(strTestDescription);

			// ------------------------------------------------------------------------
			// Actions specific to test-flow

			// Tender Type Verification
			RFM_PRC_ValidationsCreateTenderType(strTenderName, strTenderId, strLegacyId, strFiscalIndex, strDefSkimAmt,
					strDefHaloAmt, strCurrencyDecimal, strChgMaxAllwd, strMessages);

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	public void RFM_PRC_ValidationsCreateTenderType(String strTenderName, String strTenderId, String strLegacyId,
			String strFiscalIndex, String strDefSkimAmt, String DefHaloAmt, String strCurrencyDecimal,
			String ChgMaxAllwd, String[] strMessages) {
		try {

			actions.click("TenderTypeList.NewTenderType");
			actions.WaitForElementPresent("NewTenderType.TenderName", 10000);

			// Text box capacity verification

			actions.setValue("NewTenderType.TenderName", strTenderName);
			Thread.sleep(500);
			actions.setValue("NewTenderType.TenderId", strTenderId);
			Thread.sleep(500);
			actions.setValue("NewTenderType.LegacyId", strLegacyId);
			Thread.sleep(500);
			actions.setValue("NewTenderType.FiscalIndex", strFiscalIndex);
			Thread.sleep(500);
			actions.setValue("NewTenderType.DefSkimAmt", strDefSkimAmt);
			Thread.sleep(500);
			actions.setValue("NewTenderType.DefHaloAmt", DefHaloAmt);
			Thread.sleep(500);
			actions.setValue("NewTenderType.CurrencyDecimal", strCurrencyDecimal);

			if (Integer.parseInt(strCurrencyDecimal) > 6) {
				actions.click("NewTenderType.Save");
				Boolean VerifyErr = mcd.VerifyAlertMessageDisplayed("Error", strMessages[0].trim(), true,
						AlertPopupButton.OK_BUTTON);
				if (VerifyErr) {
					actions.reportCreatePASS("Verify Currency Decimal (less than 6)", "Should be less than 6",
							"Working as expected", "PASS");
					// Reporter.log("Currency Decimal (less than 6) Validation
					// PASS");
					actions.clear("NewTenderType.CurrencyDecimal");
					actions.setValue("NewTenderType.CurrencyDecimal", 4);
				} else {
					actions.reportCreateFAIL("Verify Currency Decimal (less than 6)", "Should be less than 6",
							"Not working as expected", "PASS");
					// Reporter.log("Currency Decimal (less than 6) Validation
					// FAILED");
				}

			}

			actions.setValue("NewTenderType.ChgMaxAllwd", ChgMaxAllwd);

			// Enter more than 40 characters and Unique Tender Name
			actions.clear("NewTenderType.TenderName");
			String strVal2;
			strVal2 = generateString('c', 41);
			System.out.println(strVal2.length());
			actions.setValue("NewTenderType.TenderName", strVal2);
			String charc = driver.findElement(By.xpath(actions.getLocator("NewTenderType.TenderName")))
					.getAttribute("value");
			System.out.println(charc.length());
			if (charc.length() >= 40) {
				actions.reportCreatePASS("verify the whether Tender Name search box accepts more than 40 Characters",
						"Tender Name search box should be accepts more than 40 Characters",
						"Tender Name search box should not  be accepts more than 40 Characters", "PASS");
			} else {
				actions.reportCreateFAIL("verify the whether Tender Name box accepts 40 characters",
						"Tender Name search box should be accepts more than 40 Characters ",
						"Tender Name search box should be accepts more than 40 Characters", "FAIL");
			}

			// Unique name
			STenderName = Get_Unique_ID_Name("Tender Name");
			actions.clear("NewTenderType.TenderName");

			actions.click("NewTenderType.Save");
			Thread.sleep(2000);
			Boolean VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strMessages[1].trim(), true,
					AlertPopupButton.OK_BUTTON);
			if (VerifyPopUpMsg) {
				actions.reportCreatePASS("Tender Name Mandatory Validation", "Tender Name should be mandatory",
						"Tender Name is mandatory", "PASS");
				// Reporter.log("Tender Name Validation PASS");
			} else {
				actions.reportCreateFAIL("Tender Name Mandatory Validation", "Tender Name should be mandatory",
						"Tender Name is not mandatory", "FAIL");
				// Reporter.log("Tender Name Validation FAILED");
			}
			Thread.sleep(1000);
			actions.setValue("NewTenderType.TenderName", STenderName);
			Thread.sleep(1000);

			// Tender Id Non-decimal Verification

			actions.clear("NewTenderType.TenderId");
			actions.click("NewTenderType.Save");
			Thread.sleep(1000);
			VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strMessages[2].trim(), true,
					AlertPopupButton.OK_BUTTON);
			if (VerifyPopUpMsg) {
				actions.reportCreatePASS("Tender Id Mandatory Validation", "Tender Id should be mandatory",
						"Tender Id is mandatory", "PASS");
				// Reporter.log("Tender Id Validation PASS");
			} else {
				actions.reportCreateFAIL("Tender Id Mandatory Validation", "Tender Id should be mandatory",
						"Tender Id is not mandatory", "FAIL");
				// Reporter.log("Tender Id Validation FAILED");
			}

			actions.setValue("NewTenderType.TenderId", 12.15);
			Thread.sleep(1000);
			actions.click("NewTenderType.Save");
			Thread.sleep(1000);

			VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strMessages[3].trim(), true,
					AlertPopupButton.OK_BUTTON);
			if (VerifyPopUpMsg) {
				actions.reportCreatePASS("Tender Id Non-decimal Validation", "Decimal value should not be allowed",
						"Decimal value is not allowed", "PASS");
				// Reporter.log("Tender Id Non-decimal Validation PASS");
			} else {
				actions.reportCreateFAIL("Tender Id Non-decimal Validation", "Decimal value should not be allowed",
						"Decimal value is allowed", "FAIL");
				// Reporter.log("Tender Id Non-decimal Validation FAILED");
			}

			// Enter Tender ID more than 6 numbers
			actions.clear("NewTenderType.TenderId");
			String strVal3;
			strVal3 = generateString('c', 7);
			System.out.println(strVal3.length());
			actions.setValue("NewTenderType.TenderId", strVal3);
			String charc1 = driver.findElement(By.xpath(actions.getLocator("NewTenderType.TenderId")))
					.getAttribute("value");
			System.out.println(charc1.length());
			if (charc1.length() >= 6) {
				actions.reportCreatePASS("verify the whether Tender type field accepts more than 6 Characters",
						"Tender type field should be accepts more than 6 Characters",
						"Tender type field should not  be accepts more than 6 Characters", "PASS");
			} else {
				actions.reportCreateFAIL("verify the whether Tender type field accepts 6 characters",
						"Tender type field should accept more than 6 Characters ",
						"Tender type field should accept more than 6 Characters", "FAIL");
			}

			// Enter Tender ID
			// Getting unique Tender ID
			String STenderID = Get_Unique_ID_Name("Tender ID");
			actions.clear("NewTenderType.TenderId");
			actions.setValue("NewTenderType.TenderId", STenderID);
			Thread.sleep(1000);

			// Enter fiscal index more than 6 values
			actions.clear("NewTenderType.FiscalIndex");
			String strVal5;
			strVal5 = generateString('c', 7);
			System.out.println(strVal5.length());
			actions.setValue("NewTenderType.FiscalIndex", strVal5);
			String charc3 = driver.findElement(By.xpath(actions.getLocator("NewTenderType.FiscalIndex")))
					.getAttribute("value");
			System.out.println(charc3.length());
			if (charc3.length() >= 6) {
				actions.reportCreatePASS("verify the whether Fiscal Index accepts more than 6 Characters",
						"Fiscal Index should accept more than 6 Characters",
						"Fiscal Index should not  be accept more than 6 Characters", "PASS");
			} else {
				actions.reportCreateFAIL("verify the whether Fiscal Index accepts 6 characters",
						"Fiscal Index should be accept more than 6 Characters ",
						"Fiscal Index should be accepting more than 6 Characters", "FAIL");
			}
			// Enter Default Halo amount more than 11 numeric values
			actions.clear("NewTenderType.DefHaloAmt");
			String strVal6;
			strVal6 = generateString('c', 12);
			System.out.println(strVal6.length());
			actions.setValue("NewTenderType.DefHaloAmt", strVal6);
			String charc5 = driver.findElement(By.xpath(actions.getLocator("NewTenderType.DefHaloAmt")))
					.getAttribute("value");
			System.out.println(charc5.length());
			if (charc5.length() >= 11) {
				actions.reportCreatePASS("verify the whether Halo amount accepts more than 11 Characters",
						"Halo amount should accept more than 11 Characters",
						"Halo amount should not  be accept more than 11 Characters", "PASS");
			} else {
				actions.reportCreateFAIL("verify the whether Halo amount accepts 11 characters",
						"Halo amount should be accept more than 11 Characters ",
						"Halo amount should be accepting more than 11 Characters", "FAIL");
			}
			// enter Skim amount more than 6 values
			actions.clear("NewTenderType.DefSkimAmt");
			String strVal7;
			strVal7 = generateString('c', 12);
			System.out.println(strVal7.length());
			actions.setValue("NewTenderType.DefSkimAmt", strVal7);
			String charc6 = driver.findElement(By.xpath(actions.getLocator("NewTenderType.DefSkimAmt")))
					.getAttribute("value");
			System.out.println(charc6.length());
			if (charc6.length() >= 11) {
				actions.reportCreatePASS("verify the whether Skim amount accepts more than 11 Characters",
						"Skim amount should accept more than 11 Characters",
						"Skim amount should not  be accept more than 11 Characters", "PASS");
			} else {
				actions.reportCreateFAIL("verify the whether Skim amount accepts 11 characters",
						"Skim amount should be accept more than 11 Characters ",
						"Skim amount should be accepting more than 11 Characters", "FAIL");
			}

			// Enter Min value more than 6 values
			actions.clear("NewTenderType.ChgMaxAllwdd");
			String strVal8;
			strVal8 = generateString('c', 12);
			System.out.println(strVal8.length());
			actions.setValue("NewTenderType.ChgMaxAllwdd", strVal8);
			String charc8 = driver.findElement(By.xpath(actions.getLocator("NewTenderType.ChgMaxAllwdd")))
					.getAttribute("value");
			System.out.println(charc8.length());
			if (charc8.length() >= 11) {
				actions.reportCreatePASS("verify the whether change maximum allowed accepts more than 11 Characters",
						"change maximum allowed should accept more than 11 Characters",
						"change maximum allowed should not  be accept more than 11 Characters", "PASS");
			} else {
				actions.reportCreateFAIL("verify the whether change maximum allowed accepts 11 characters",
						"change maximum allowed should be accept more than 11 Characters ",
						"change maximum allowed should be accepting more than 11 Characters", "FAIL");
			}

			// Enter Legacy ID more than 50 characters
			actions.clear("NewTenderType.LegacyId");
			String strVal4;
			strVal4 = generateString('c', 51);
			System.out.println(strVal4.length());
			actions.setValue("NewTenderType.LegacyId", strVal4);
			String charc2 = driver.findElement(By.xpath(actions.getLocator("NewTenderType.LegacyId")))
					.getAttribute("value");
			System.out.println(charc2.length());
			if (charc2.length() >= 50) {
				actions.reportCreatePASS("verify the whether Legacy ID field accepts more than 50 Characters",
						"Legacy ID field should be accepting more than 50 Characters",
						"Legacy ID field should not accept more than 50 Characters", "PASS");
			} else {
				actions.reportCreateFAIL("verify the whether Legacy ID field accepts 50 characters",
						"Legacy ID field should accept more than 50 Characters ",
						"Legacy ID field should accept more than 50 Characters", "FAIL");
			}

			// Enter Legacy ID
			String SLeagcyID = Get_Unique_ID_Name("Legacy ID");
			actions.clear("NewTenderType.LegacyId");
			actions.click("NewTenderType.Save");
			Thread.sleep(1000);
			VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strMessages[4].trim(), true,
					AlertPopupButton.OK_BUTTON);
			if (VerifyPopUpMsg) {
				actions.reportCreatePASS("Legacy Id Mandatory Validation", "Legacy Id should be mandatory",
						"Legacy Id is mandatory", "PASS");
				// Reporter.log("Legacy Id Validation PASS");
			} else {
				actions.reportCreateFAIL("Legacy Id Mandatory Validation", "Legacy Id should be mandatory",
						"Legacy Id is not mandatory", "FAIL");
				// Reporter.log("Legacy Id Validation FAILED");
			}
			actions.setValue("NewTenderType.LegacyId", SLeagcyID);
			Thread.sleep(1000);

			// Amount Field blank validation
			// For Payment Type"TENDER_GIFT_COUPON"

			Select select = new Select(driver.findElement(By.xpath(actions.getLocator("NewTenderType.PaymentType"))));
			select.selectByVisibleText("TENDER_GIFT_COUPON");
			Thread.sleep(1000);

			// Click Save
			actions.click("NewTenderType.Save");
			VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strMessages[5].trim(), true,
					AlertPopupButton.OK_BUTTON);
			if (VerifyPopUpMsg) {
				actions.reportCreatePASS("Amount Field Mandatory Validation", "Amount should be mandatory",
						"Amount is mandatory", "PASS");
				// Reporter.log("Amount Field Blank Validation PASS");
			} else {
				actions.reportCreateFAIL("Amount Field Mandatory Validation", "Amount should be mandatory",
						"Amount is not mandatory", "FAIL");
				// Reporter.log("Amount Field Blank Validation FAILED");
			}

			// Enter any alphabetic value in amount field to validate error
			actions.setValue("NewTenderType.Amount", "Auto123");

			actions.click("NewTenderType.Save");
			Thread.sleep(500);
			VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strMessages[6].trim(), true,
					AlertPopupButton.OK_BUTTON);
			if (VerifyPopUpMsg) {
				actions.reportCreatePASS("Amount Field Numeric Validation", "Amount should accept only numeric value",
						"Amount field accepts only numeric value", "PASS");
				// Reporter.log("Amount Field Numeric Validation PASS");
			} else {
				actions.reportCreateFAIL("Amount Field Numeric Validation", "Amount should accept only numeric value",
						"Amount field accepts non-numeric value", "FAIL");
				// Reporter.log("Amount Field Numeric Validation FAILED");
			}

			actions.smartWait(10);
			actions.click("NewTenderType.Cancel");
			Thread.sleep(2000);
			VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strMessages[7].trim(), true,
					AlertPopupButton.OK_BUTTON);
			if (VerifyPopUpMsg) {
				actions.reportCreatePASS("Verify Unsaved data warning message",
						"Unsaved data warning message should come", "Unsaved data warning message found", "PASS");
				// Reporter.log("Unsaved record message PASS");
			} else {
				actions.reportCreateFAIL("Verify Unsaved data warning message",
						"Unsaved data warning message should come", "Unsaved data warning message not found", "FAIL");
				// Reporter.log("Unsaved record message FAILED");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String Get_Unique_ID_Name(String FieldName) {
		String s = null;
		switch (FieldName) {
		case "Tender Name":
			s = mcd.fn_GetRndName("Auto");
			break;
		case "Tender ID":
			// Getting unique Tender ID

			Date d = new Date();
			int i = (int) d.getTime();
			String temp = Integer.toString(i).substring(1);
			s = "" + d.getSeconds() + "" + temp;
			break;
		case "Legacy ID":
			s = mcd.fn_GetRndName("").split("_")[1];
			break;

		default:
			break;
		}
		return s;
	}
	// To generate the string of specific size

	public static String generateString(char c, Integer n) {
		StringBuilder b = new StringBuilder();
		for (Integer x = 0; x < n; x++)
			b.append(c);
		return b.toString();
	}

}
