
package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class PRC_0165_UpdatePSTaxSettings {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strNavigateTo_1;
	private String strPOPmsg, strPOP;

	public PRC_0165_UpdatePSTaxSettings(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strNavigateTo_1 = mcd.GetTestData("DT_NAVIGATE_TO_1");
		strPOPmsg = mcd.GetTestData("DT_POP_Message");
		strPOP = mcd.GetTestData("DT_PopMsg");

	}

	@Test
	public void test_PRC_0165_UpdatePSTaxSettings() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription("Verify that user is able to save updated tax setting");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			// ADMIN>Update Setting>General Setting
			System.out.println("> Navigate to :: " + strNavigateTo_1);
			actions.select_menu("RFMNavigation.Main", strNavigateTo_1);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/**
			 * Prerequisites need to be done Navigate to ADMIN > Application
			 * Settings > Update Settings Set "Display Tax " to False
			 **/

			rfm.RFM_Admin_Update_PricingTags("0", "Automatically fill price type attribute option price value");
			rfm.RFM_Admin_Update_PricingTags("0", "Automatically fill price type attribute option tax value");
			rfm.RFM_Admin_Update_PricingTags("false", "Restrict price type attribute from expanding");

			// Navigate to Pricing>PriceSet
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMNavigation.Main", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			// Click any Price set & Click on view tax details button Expand
			// menu item which is priced and not taxed.
			actions.click("RestaurantDBDefinitions.TableFirstData");
			actions.smartWait(20);
			actions.click("PriceSets.ViewTaxDetailsButton");
			actions.smartWait(180);
			if (actions.isElementPresent("PriceSets.STPlusButtonMI")) {
				actions.click("PriceSets.STPlusButtonMI");
			}

			// Expand menu item which is priced and not taxed.
			actions.setValue("PriceSets.STTaxCodeTakeOut", "Never");
			actions.setValue("PriceSets.OtherTaxCode", "Never");
			actions.click("PriceSet.ApplyButton");
			try {
				mcd.VerifyAlertMessageDisplayed("Warning Message", strPOP, true, AlertPopupButton.OK_BUTTON);
			} catch (Exception e) {
				System.out.println("Alert is not Present");
			}

			actions.smartWait(20);
			// Enter tax setting for �Take Out� price type such that Tax Code
			// Always, tax rule is �FISCAL PRINTER� & Update TaxEntry Value
			actions.setValue("PriceSets.STTaxCodeTakeOut", "Always");
			actions.setValue("PriceSets.STTaxRuleTakeOut", "FISCAL_PRINTER");

			Select taxEntry = new Select(
					driver.findElement(By.xpath(actions.getLocator("PriceSets.TakeOutEntryValue"))));
			taxEntry.selectByIndex(1);

			// Enter tax setting for �Other� price type such that Tax Code
			// Always ,tax rule is �Tax Chain� & Update TaxEntry Value

			actions.setValue("PriceSets.OtherTaxCode", "Always");
			actions.setValue("PriceSets.OtherTaxRule1", "TAX_CHAIN");

			Select taxEntry1 = new Select(driver.findElement(By.xpath(actions.getLocator("PriceSets.OtherTaxEntry1"))));
			taxEntry1.selectByIndex(1);

			// Click on apply button & Verifying Alert Message
			actions.click("PriceSet.ApplyButton");
			try {
				mcd.VerifyAlertMessageDisplayed("Warning Message", strPOP, true, AlertPopupButton.OK_BUTTON);
			} catch (Exception e) {
				System.out.println("Alert is not Present");
			}
			actions.smartWait(20);
			boolean blMessage;
			actions.isTextPresence("Your changes have been saved.", true);

			// Verify Collapse price attribute
			actions.click("PriceSets.STMinusButtonMI");
			Thread.sleep(4000);
			blMessage = mcd.VerifyAlertMessageDisplayed("Warning Message", strPOPmsg, true, AlertPopupButton.OK_BUTTON);

			if (blMessage) {
				actions.reportCreatePASS("Verify the Alert Message", "Message '" + strPOPmsg + "' should be displayed",
						"Message '" + strPOPmsg + "' is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the Alert Message", "Message '" + strPOPmsg + "' should be displayed",
						"Message '" + strPOPmsg + "' is not displayed", "FAIL");
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}
