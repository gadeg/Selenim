package xtam.test;

import java.util.Map;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Keywords.DialogType;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class PRC_20065_TTVerifySrchLimit {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private String strInput;
	private String strNode;
	private String strWm;

	public PRC_20065_TTVerifySrchLimit(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters
		strInput = mcd.GetTestData("DT_INPUT");
		strNode = mcd.GetTestData("NodeNum");
		strWm = mcd.GetTestData("DT_Warn");
	}

	@Test
	public void test_PRC_20065_TTVerifySrchLimit() throws InterruptedException {

		String strTestDescription = "Verify the Size limit of Search Text Box.";

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			/** Get application time */
			actions.setTestcaseDescription(strTestDescription);

			// ------------------------------------------------------------------------
			// Actions specific to test-flow

			/** Click on New taxType Button */
			actions.keyboardEnter("TaxType.NewTaxTypeButton");

			/** Switc to Add New Tax Type Window */
			mcd.SwitchToWindow("Add New Tax Type");

			/** Set value in Search Box */
			actions.setValue("AddTenderTypeSet.SearchTextBox", "abc");

			/** Click on Select Button */
			actions.click("NewTaxType.SelectButton");

			/** Switch to Select Node Window */
			mcd.waitAndSwitch("Select Node");

			/** Set value in Search Box */
			actions.setValue("SelectNode.SearchTextTreeTextBox", strInput);
			String strEnteredString = driver
					.findElement(By.xpath(actions.getLocator("SelectNode.SearchTextTreeTextBox"))).getAttribute("value")
					.trim();
			int StringLength = strEnteredString.length();
			if (StringLength == 900) {
				actions.reportCreatePASS("Verify the Size limit of Search Text Box.",
						"Text should be allowed for less than 900 characters",
						"Text in Search tax type is allowed for less/equal than 900 characters", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the Size limit of Search Text Box.",
						"Text should be allowed for less than 900 characters",
						"Text in Search tax type is allowed for less/more than 900 characters", "FAIL");
			}

			actions.clear("SelectNode.SearchTextTreeTextBox");

			/** Set value in Search Box */
			actions.setValue("SelectNode.SearchTextTreeTextBox", strInput + 'i');
			String strEnteredString1 = driver
					.findElement(By.xpath(actions.getLocator("SelectNode.SearchTextTreeTextBox"))).getAttribute("value")
					.trim();
			int StringLength1 = strEnteredString1.length();
			if (StringLength1 == 900) {
				actions.reportCreatePASS("Verify the Size limit of Search Text Box.",
						"Text should not be allowed for more than 900 characters",
						"Text in Search tax type is not allowed for more than 900 characters", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the Size limit of Search Text Box.",
						"Text should not be allowed for more than 900 characters",
						"Text in Search tax type is allowed for more than 900 characters", "FAIL");
			}

			actions.clear("SelectNode.SearchTextTreeTextBox");
			/** Set value in Search Box */
			actions.setValue("SelectNode.SearchTextTreeTextBox", strNode);
			/** Click on Search button */
			actions.click("RFM.SearchButton");
		
			/** select Restaurant from table */
			if (mcd.GetGlobalData("Instance").toLowerCase().contains("eu")) {
				mcd.Selectrestnode("SelectNode.CPTable", strNode);
			} else {
				mcd.Selectrestnode("PMSelectNode.PCTable", strNode);

			}
			actions.waitForPageToLoad(120);

			mcd.SwitchToWindow("Add New Tax Type");

			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);

			actions.keyboardEnter("NewPMIGImageSet.Cancel");

			// Boolean flag = mcd.VerifyAlertMessageDisplayed("Warning", strWm,
			// true, AlertPopupButton.OK_BUTTON);

			Alert flag = driver.switchTo().alert();
			flag.accept();

			try {
				driver.switchTo().window("");
			} catch (Exception e) {

			}
			if (flag != null) {
				actions.reportCreatePASS("Verify Alert Message", "Alert Message should be displayed",
						"Alert Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Alert Message", "Alert Message should be displayed",
						"Alert Message is not displayed", "FAIL");
			}

			mcd.SwitchToWindow("@Tax Type");

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}