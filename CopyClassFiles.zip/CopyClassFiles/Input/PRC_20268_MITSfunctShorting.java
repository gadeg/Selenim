package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;

public class PRC_20268_MITSfunctShorting {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo, strStatus;
	// TODO: Declare test-data variables for other data-parameters

	public PRC_20268_MITSfunctShorting(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strStatus = mcd.GetTestData("DT_STATUS");
		// TODO: GetTestData for other data-parameters

	}

	@Test
	public void test_PRC_20268_MITSfunctShorting() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription(
					"Verify the fields on Menu Item Tax page,pagination functionality and sorting functionality.");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			//PRICING> Taxes>Menu Item Tax Set
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Actions specific to test-flow

			// Verify GUI on Menu Item Tax Set Page
			if (actions.isElementPresent("MenuItemTaxSet.NewMenuItemTaxSetButton")) {
				actions.reportCreatePASS("Verify New Menu Item Tax Set Button",
						"New Menu Item Tax Set Button Should be Present", "New Menu Item Tax Set Button is Present",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify New Menu Item Tax Set Button",
						"New Menu Item Tax Set Button Should be Present", "New Menu Item Tax Set Button is not Present",
						"FAIL");
			}

			if (!actions.isElementEnabled("ScreenSet.NBScreenSetStatus")) {
				actions.reportCreatePASS("Verify Status Fliter", "Status Fliter Should be Disabled",
						"Status Fliter is Disabled", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Status Fliter", "Status Fliter Should be Disabled",
						"Status Fliter is not Disabled", "FAIL");
			}

			// Verify Page Heading
			verifyTablecolumnsPresent("ViewGeneratedReport.ReportTable", "Name");
			verifyTablecolumnsPresent("ViewGeneratedReport.ReportTable", "Node");
			verifyTablecolumnsPresent("ViewGeneratedReport.ReportTable", "Status");
			verifyTablecolumnsPresent("ViewGeneratedReport.ReportTable", "Future Settings");
			verifyTablecolumnsPresent("ViewGeneratedReport.ReportTable", "Delete");

			// Verify Search with Status DropDown Values
			String strDDVal1 = mcd.getdropdownvalues("AccessControlbyUser(s).StatusDDL");
			String[] status = strDDVal1.split(",");
			Boolean flag = false;
			for (int i = 0; i < status.length; i++) {
				if (strStatus.contains(status[i])) {
					flag = true;
				} else {
					flag = false;
					break;
				}
			}
			if (flag == true) {
				actions.reportCreatePASS("Verify Status Drop Down",
						"Status Drop Down should be Present(Active/InActive)",
						"Status Drop Down is Present(Active/InActive)", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Status Drop Down",
						"Status  Drop Down should be Present(Active/InActive)",
						"Status Drop Down is not Present(Active/InActive)", "FAIL");
			}
			String selectedOption1 = new Select(
					driver.findElement(By.xpath(actions.getLocator("AccessControlbyUser(s).StatusDDL"))))
							.getFirstSelectedOption().getText();
			if (selectedOption1.equals("Active/Inactive")) {
				actions.reportCreatePASS("Verify Status Drop Down",
						"Status Drop Down should be Active/Inactive(default)",
						"Status Drop Down is Active/Inactive(default)", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Status Drop Down",
						"Status Drop Down should be Active/Inactive(default)",
						"Status Drop Down is Active/Inactive(default)", "FAIL");
			}

			// Verify Filter List Section
			String filter = driver.findElement(By.xpath(actions.getLocator("RFMParameterSet.FilterButton")))
					.getAttribute("class");
			if (filter.contains("disableButton")) {
				actions.reportCreatePASS("Verify Filter Button", "Filter Button Should be Disabled",
						"Filter Button is Disabled", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Filter Button", "Filter Button Should be Disabled",
						"Filter Button is not Disabled", "FAIL");
			}
			if (!actions.isElementEnabled("RFMExportOptions.Market")) {
				actions.reportCreatePASS("Verify Market Text Box", "Market Text Box Should be Disabled",
						"Market Text Box is Disabled", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Market Text Box", "Market Text Box Should be Disabled",
						"Market Text Box is Disabled", "FAIL");
			}
			if (!actions.isElementEnabled("RFMExportOptions.CountryList")) {
				actions.reportCreatePASS("Verify Country DropDown", "Country DropDown Should be Disabled",
						"Country DropDown is Disabled", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Country DropDown", "Country DropDown Should be Disabled",
						"Country DropDown is not Disabled", "FAIL");
			}
			if (actions.isElementPresent("RFMExportOptions.Searchbutton")) {
				actions.reportCreatePASS("Verify Search Button", "Search Button Should be Present",
						"Search Button is Present", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Search Button", "Search Button Should be Present",
						"Search Button is not Present", "FAIL");
			}

			// Verify Text
			String text = driver.findElement(By.xpath("//*[@class='hintText']")).getText();
			if (text.trim().equalsIgnoreCase("Search Full List by Set Name")) {
				actions.reportCreatePASS("Verify Menu Item Tax Set Text", "Menu Item Tax Set Text should be Present",
						"Menu Item Tax Set Text is Present", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Menu Item Tax Set Text", "Menu Item Tax Set Text should be Present",
						"Menu Item Tax Set Text is not Present", "FAIL");
			}

			actions.keyboardEnter("TaxType.ViewFullListButton");
			actions.smartWait(30);

			// Sort the records or result by Menu Item Tax Set Name
			int iColumnNum = mcd.GetTableColumnNumber("ScriptManagement.TableNameValue", "Name");
			Verify_Sorting_String("ScriptManagement.TableRow", "MenuItemTaxSet.TableNameShorting",
					"TenderSet.TablesortName", "Name", iColumnNum, "String");

			// Sort the records or result by Menu Item Tax Set Node
			iColumnNum = mcd.GetTableColumnNumber("ScriptManagement.TableNameValue", "Node");
			Verify_Sorting_String("ScriptManagement.TableRow", "MenuItemTaxSet.TableNodeShorting",
					"MenuItemTaxSet.TablesortNode", "Node", iColumnNum, "String");

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	// Verify List should be sorted in ascending order/descending order by Name
	// and Node.
	public void Verify_Sorting_String(String elemTableRow, String elemSortOrder, String elemHeader,
			String strColumnName, int iColumnNum, String strDataType) throws InterruptedException {

		String strSortOrderValue = "";
		String TableXpath = actions.getLocator(elemTableRow);
		if (!(mcd.ISAttributePresent(elemSortOrder, "src"))) {
			actions.keyboardEnter(elemHeader);
			Thread.sleep(2000);
			actions.smartWait(120);
		} else {
			System.out.println("Default sort is present");
		}

		// Verify SORTING
		List<WebElement> eleRws = driver.findElements(By.xpath(TableXpath));
		int iNewMIRwCnt = eleRws.size();
		// Take 1st two elements for comparison by Name
		String MI_Num1 = eleRws.get(0).findElement(By.xpath("./td[" + iColumnNum + "]")).getText();
		String MI_Num2 = eleRws.get(1).findElement(By.xpath("./td[" + iColumnNum + "]")).getText();
		String strSortOrder = null;
		strSortOrderValue = driver.findElement(By.xpath(actions.getLocator(elemSortOrder))).getAttribute("src");
		if (strSortOrderValue.contains("up")) {
			strSortOrder = "Ascending";
			Verify_Sort_Ascending(MI_Num1, MI_Num2, strColumnName, strDataType);
		} else if (strSortOrderValue.contains("down")) {
			strSortOrder = "Descending";
			Verify_Sort_Descending(MI_Num1, MI_Num2, strColumnName, strDataType);
		} else {
			actions.reportCreateFAIL("Verify Sorting", "Sorting direction (Ascending/Descing) should be displayed",
					"Sorting direction (Ascending/Descing) is displayed", "PASS");
		}
		// Click again to verify next sorting order
		actions.keyboardEnter(elemHeader);
		Thread.sleep(2000);
		actions.smartWait(120);
		List<WebElement> eleRws1 = driver.findElements(By.xpath(TableXpath));
		int iNewMIRwCnt1 = eleRws.size();
		String MI_Num3 = eleRws1.get(0).findElement(By.xpath("./td[" + iColumnNum + "]")).getText();
		String MI_Num4 = eleRws1.get(1).findElement(By.xpath("./td[" + iColumnNum + "]")).getText();
		strSortOrderValue = driver.findElement(By.xpath(actions.getLocator(elemSortOrder))).getAttribute("src");
		if (strSortOrderValue.contains("up")) {
			strSortOrder = "Ascending";
			Verify_Sort_Ascending(MI_Num3, MI_Num4, strColumnName, strDataType);
		} else if (strSortOrderValue.contains("down")) {
			strSortOrder = "Descending";
			Verify_Sort_Descending(MI_Num3, MI_Num4, strColumnName, strDataType);
		} else {
			actions.reportCreateFAIL("Verify Sorting", "Sorting direction (Ascending/Descing) should be displayed",
					"Sorting direction (Ascending/Descing) is displayed", "PASS");
		}

	}

	public void Verify_Sort_Ascending(String strValue1, String strValue2, String strColumnName, String strDataType) {
		switch (strDataType.toLowerCase()) {
		case "integer":
			if (Integer.parseInt(strValue1) <= Integer.parseInt(strValue2)) {
				actions.reportCreatePASS("Verify Ascending Sorting according to " + strColumnName,
						"List should be sorted(Ascending)correctly", "List is sorted(Ascending) correctly", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Ascending Sorting according to " + strColumnName,
						"List should be sorted(Ascending) correctly", "List is not sorted(Ascending) correctly",
						"FAIL");
			}
			break;
		case "string":
			int ReturnNumber = strValue1.toUpperCase().compareTo(strValue2.toUpperCase());
			if (ReturnNumber <= 0) {
				actions.reportCreatePASS("Verify Ascending Sorting according to " + strColumnName,
						"List should be sorted(Ascending)correctly", "List is sorted(Ascending) correctly", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Ascending Sorting according to " + strColumnName,
						"List should be sorted(Ascending) correctly", "List is not sorted(Ascending) correctly",
						"FAIL");
			}
			break;

		default:
			break;

		}
	}

	public void Verify_Sort_Descending(String strValue1, String strValue2, String strColumnName, String strDataType) {
		switch (strDataType.toLowerCase()) {
		case "integer":
			if (Integer.parseInt(strValue1) >= Integer.parseInt(strValue2)) {
				actions.reportCreatePASS("Verify Descending Sorting according to " + strColumnName,
						"List should be sorted(Descending) correctly", "List is sorted correctly(Descending)", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Descending Sorting according to " + strColumnName,
						"List should be sorted(Descending) correctly", "List is not sorted(Descending) correctly",
						"FAIL");
			}
			break;
		case "string":
			int ReturnNumber = strValue1.toUpperCase().compareTo(strValue2.toUpperCase());
			if (ReturnNumber >= 0) {
				actions.reportCreatePASS("Verify Descending Sorting according to " + strColumnName,
						"List should be sorted(Descending) correctly", "List is sorted correctly(Descending)", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Descending Sorting according to " + strColumnName,
						"List should be sorted(Descending) correctly", "List is not sorted(Descending) correctly",
						"FAIL");
			}
			break;
		default:
			break;
		}
	}

	// Verify Table Header Fields
	public void verifyTablecolumnsPresent(String tableLocator, String colName) {

		boolean iscolPresent = mcd.RFM_VerifyTableColumns(tableLocator, colName);

		if (iscolPresent) {
			actions.reportCreatePASS("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is present in table", "Pass");
		} else {
			actions.reportCreateFAIL("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is NOT present in table",
					"Fail");
		}
	}

}