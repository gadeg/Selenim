package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class PRC_0121_UpdtPSDetlasFutPrc {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// Declare test-data variables for other data-parameters
	private String strNavigateToAdmin, strExptMesssage, strSearchAlert;
	private String strOperation, strActivity, strLevel, strUID, strDBName;

	public PRC_0121_UpdtPSDetlasFutPrc(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// GetTestData for other data-parameters
		strNavigateToAdmin = mcd.GetTestData("DT_NAVIGATE_TO_ADMIN");
		strOperation = mcd.GetTestData("DT_OPERATION");
		strActivity = mcd.GetTestData("DT_ACTIVITY");
		strLevel = mcd.GetTestData("DT_LEVEL");
		strDBName = mcd.GetTestData("DT_DBNAME");
		strUID = mcd.GetTestData("DT_USERID");
		strExptMesssage = mcd.GetTestData("DT_MESSAGE");
		strSearchAlert = mcd.GetTestData("DT_SEARCHRES");
	}

	@Test
	public void test_PRC_0121_UpdtPSDetlasFutPrc() throws InterruptedException {
		String strTestDescription = "Verify Update Price Set Details (Future Price Changes) functionality of Base price set";

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			/** Get Test Case Description */
			actions.setTestcaseDescription(strTestDescription);

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Navigating to Admin */
			System.out.println("> Navigate to :: " + strNavigateToAdmin);
			actions.select_menu("RFMHome.Navigation", strNavigateToAdmin);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			// Setting the values for Price fields
			rfm.RFM_Admin_Update_PricingTags("true", "Restrict price type attribute from expanding");
			rfm.RFM_Admin_Update_PricingTags("false", "Display price type attribute as expanded by default");

			/** Navigating to Price Sets */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			// Selecting the first available price set
			WebElement PriceSet = mcd.GetTableCellElement("PackageReport.Table", 1, 1, "a");
			actions.click(PriceSet);
			mcd.smartsync(180);
			mcd.SwitchToWindow("#Title");

			// Select future date link in the future price changes part
			// getting Number of future settings date present also
			actions.WaitForElementPresent("PriceSets.SBFutureSetting", 120);
			List<WebElement> FutDates = driver.findElements(By.xpath(actions.getLocator("PriceSets.SBFutureSetting")));
			Thread.sleep(5000);
			// Creating future date if not present
			if (FutDates.size() < 2) {
				mcd.SelectDate_OpenCalender("10", "next");
				mcd.smartsync(180);
				// Enter future price settings
				actions.WaitForElementPresent("ManagePS.AllPrice", 120);
				actions.clear("ManagePS.AllPrice");
				actions.setValue("ManagePS.AllPrice", "10");
				actions.click("AddTenderType.ApplyButton");
				Thread.sleep(2000);
				try {
					actions.click("FutureSettings.Apply");
					try {
						driver.switchTo().alert().accept();
					} catch (Exception e) {
					}
				} catch (Exception e1) {
				}
				mcd.smartsync(120);
			} else {
				actions.click(FutDates.get(1));
				mcd.smartsync(180);
			}
			Thread.sleep(2000);
			// Navigating back to the main page Price Sets
			// Validating cancel button functionality also
			actions.keyboardEnter("RFM.Cancelbtn");
			mcd.smartsync(180);
			mcd.SwitchToWindow("#Title");
			mcd.smartsync(180);
			if (actions.getPageTitle().equals("Manage Price Sets")) {
				actions.reportCreatePASS("Verify the navigation back to the main page",
						"Manage Price Sets page should be displayed", "Manage Price Sets page is displaying", "Pass");
			} else {
				actions.reportCreateFAIL("Verify the navigation back to the main page",
						"Manage Price Sets page should be displayed", "Manage Price Sets page is not displaying",
						"Fail");
			}

			// Selecting the first available price set
			PriceSet = mcd.GetTableCellElement("PackageReport.Table", 1, 1, "a");
			String PriceSetName = PriceSet.getText();
			String strRestNode = mcd.GetTableCellElement("PackageReport.Table", 1, 2, "").getText();
			actions.click(PriceSet);
			mcd.smartsync(180);
			mcd.SwitchToWindow("#Title");

			// Selecting the first future date link on future price changes grid
			List<WebElement> FutDates1 = driver.findElements(By.xpath(actions.getLocator("PriceSets.SBFutureSetting")));
			FutDates1.get(1).click();
			mcd.smartsync(180);
			Thread.sleep(2000);
			actions.WaitForElementPresent("ManagePS.DateSelected", 120);
			String FutDt = driver.findElement(By.xpath(actions.getLocator("ManagePS.DateSelected"))).getText();

			// Validating 'Please enter search criteria'
			actions.keyboardEnter("RestaurantSet.Searchbtn");
			boolean alert = false;
			alert = mcd.VerifyAlertMessageDisplayed("Alert", strSearchAlert, true, AlertPopupButton.OK_BUTTON);
			if (alert) {
				actions.reportCreatePASS("Verify" + strSearchAlert, strSearchAlert + " should be displayed",
						strSearchAlert + " is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify" + strSearchAlert, strSearchAlert + " should be displayed",
						strSearchAlert + " is not displayed", "Fail");
			}

			// Getting Minus Icons list
			List<WebElement> MinusSyms = driver.findElements(By.xpath(actions.getLocator("ManagePriceSet.MinusIcon")));

			// Getting Price text boxes list
			List<WebElement> PriceValueTextBoxes = driver
					.findElements(By.xpath(actions.getLocator("PriceSets.ProductPrice")));

			// Check if MInus Icon is displayed, if displayed click on it
			if (MinusSyms.get(0).isDisplayed()) {
				MinusSyms.get(0).click();
			}
			// Getting the value from the Price value text box, adding 1 and
			// again
			// converting back to String
			String priceVal = PriceValueTextBoxes.get(0).getAttribute("value");
			float val = Float.parseFloat(priceVal);
			float value = val + 1;
			String strval = String.valueOf(value);
			PriceValueTextBoxes.get(0).clear();
			PriceValueTextBoxes.get(0).sendKeys(strval);

			// Validating for changes made have been saved
			actions.keyboardEnter("PriceSet.ApplyButton");
			mcd.smartsync(180);
			boolean validate = mcd.VerifyOnscreenMessage("SubstitutionGroups.InfoMessage", strExptMesssage, true);
			if (validate) {
				actions.reportCreatePASS("Verify changes saved", "Changes made should be saved",
						"Changes made are saved", "Pass");
			} else {
				actions.reportCreateFAIL("Verify changes saved", "Changes made should be saved",
						"Changes made are not saved", "Fail");
			}

			// verify the audit log now for Price Sets Update activity
			if (rfm.VerifyAuditLog_Entry(strOperation, strActivity, strRestNode)) {
				actions.reportCreatePASS("Verifying the Audit log", "Audit log should display correct values",
						"Audit log displayed correct values", "Pass");
			} else {
				actions.reportCreateFAIL("Verifying the Audit log", "Audit log should display correct values",
						"Audit log not displayed correct values", "Fail");
			}

			String strDescription = "Future Setting " + FutDt + " for Price Set " + PriceSetName + " has been updated.";
			// verify the audit log details for Price Sets Update activity
			if (rfm.RFM_VerifyAuditLog_Details(strDBName, strUID, strOperation, strActivity, strLevel, strRestNode,
					strDescription)) {
				actions.reportCreatePASS("Verifying the Audit log details",
						"Audit log details should display correct values", "Audit log displayed correct values",
						"Pass");
			} else {
				actions.reportCreateFAIL("Verifying the Audit log details",
						"Audit log details should display correct values",
						"Audit log details not displayed correct values", "Fail");
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			// reporting the Fail condition
			actions.catchException(e);
		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}
}
