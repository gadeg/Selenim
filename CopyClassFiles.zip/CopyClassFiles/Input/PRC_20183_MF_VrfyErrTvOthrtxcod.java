package xtam.test;

import java.util.Map;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class PRC_20183_MF_VrfyErrTvOthrtxcod {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// Declare test-data variables for other data-parameters
	private String strMsg;
	private String strNavigateToAdmin;
	private String strNavigateTo_TT;
	private String strNavigateTo_TC;
	private String TaxRuleDropdownValue;
	private String AllPrc;

	public PRC_20183_MF_VrfyErrTvOthrtxcod(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");

		// GetTestData for other data-parameters
		strMsg = mcd.GetTestData("DT_MSG");
		strNavigateTo_TT = mcd.GetTestData("DT_NAVIGATE_TO_TT");
		strNavigateTo_TC = mcd.GetTestData("DT_NAVIGATE_TO_TC");
		AllPrc = mcd.GetTestData("AllPrcValue");
		strNavigateToAdmin = mcd.GetTestData("DT_NAVIGATE_TO_ADMIN");
	}

	@Test
	public void test_PRC_20183_MF_VrfyErrTvOthrtxcod() throws InterruptedException {
		String strTestDescription = "Verify error message for Tax Value field  Other Tax Code, Tax Rule, Tax Entry when it is expanded";

		try {
			System.out.println("******************************* Test execution starts");

			/** Get Test case Description */
			actions.setTestcaseDescription(strTestDescription);

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Navigating to Admin */
			System.out.println("> Navigate to :: " + strNavigateToAdmin);
			actions.select_menu("RFMHome.Navigation", strNavigateToAdmin);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Actions specific to test-flow
			// Automating the Pre - Req
			rfm.RFM_Admin_Update_PricingTags("false", "Restrict price type attribute from expanding");
			rfm.RFM_Admin_Update_PricingTags("false", "Display price type attribute as expanded by default");
			rfm.RFM_Admin_Update_PricingTags("0", "Automatically fill price type attribute option price value");
			rfm.RFM_Admin_Update_PricingTags("0", "Automatically fill price type attribute option tax value");

			actions.waitForPageToLoad(120);
			/** Navigating to Master Fee */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(180);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			String[] Msg = strMsg.split("#");
			actions.waitForPageToLoad(180);

			// Creating new fee by clicking on new fee button
			actions.WaitForElementPresent("MasterFee.NewFeeBtn");
			actions.keyboardEnter("MasterFee.NewFeeBtn");
			actions.smartWait(20);
			// clear fee ID field
			actions.WaitForElementPresent("MasterFee.FeeId");
			actions.clear("MasterFee.FeeId");
			// Entering unique ID
			Random rand_num = new Random();
			int iFeeId = rand_num.nextInt((99) + 5);
			System.out.println(iFeeId);
			actions.setValue("MasterFee.FeeId", Integer.toString(iFeeId));
			actions.WaitForElementPresent("MasterFee.FeeName");
			// Entering unique Name
			String strNewFeeName = mcd.fn_GetRndName("ATS");
			actions.setValue("MasterFee.FeeName", strNewFeeName);
			actions.WaitForElementPresent("FeeSet.AllPrc");
			actions.clear("FeeSet.AllPrc");
			actions.setValue("FeeSet.AllPrc", AllPrc);

			// Select fee type from the drop down
			actions.WaitForElementPresent("MasterFee.FeeType");
			actions.setValue("MasterFee.FeeType", "Rate");

			// clicking on Tax value Expand
			actions.javaScriptClick("DepositSet.TaxPlusIcon");

			// Verifying one box at a time
			// Other tax code
			actions.WaitForElementPresent("DepositSet.OtherTaxCode");
			actions.setValue("DepositSet.OtherTaxCode", "Always");
			actions.click("ApplyChangesDetails.Save");
			// Verify Alert message
			boolean msg1 = mcd.VerifyAlertMessageDisplayed("Warning", Msg[1], true, AlertPopupButton.OK_BUTTON);

			if (msg1) {
				actions.reportCreatePASS("Verify 'Please select Other Tax Rule' Alert",
						"'Please select Other Tax Rule' Alert should be displayed",
						"'Please select Other Tax Rule' Alert is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify 'Please select Other Tax Rule' Alert",
						"'Please select Other Tax Rule' Alert should be displayed",
						"'Please select Other Tax Rule' Alert is not displayed", "Fail");
			}

			// Other tax code
			actions.WaitForElementPresent("DepositSet.OtherTaxRule");
			actions.setValue("DepositSet.OtherTaxRule", "GST");
			// Click on save button
			actions.click("ApplyChangesDetails.Save");
			Thread.sleep(1000);
			// Verify Alert message
			boolean msg2 = mcd.VerifyAlertMessageDisplayed("Warning", Msg[2], true, AlertPopupButton.OK_BUTTON);
			if (msg2) {
				actions.reportCreatePASS("Verify 'Please select Other Tax Entry' Alert",
						"'Please select Other Tax Entry' Alert should be displayed",
						"'Please select Other Tax Entry' Alert is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify 'Please select Other Tax Entry' Alert",
						"'Please select Other Tax Entry' Alert should be displayed",
						"'Please select Other Tax Entry' Alert is not displayed", "Fail");
			}

			// Other tax entry
			// actions.setValue("DepositSet.OtherTaxEntry", "1");
			actions.WaitForElementPresent("DepositSet.OtherTaxEntry");
			Select select = new Select(actions.getWebElement("DepositSet.OtherTaxEntry"));
			select.selectByIndex(1);
			actions.click("ApplyChangesDetails.Save");
			actions.smartWait(180);
			// To verify your changes have been saved by entering unique Fee ID
			boolean flag = false, flagFeeId = false;
			try {
				flag = mcd.VerifyOnscreenMessage("ManageFee.SSMsg", Msg[6], true);
			} catch (Exception e) {
				do {
					try {
						flagFeeId = mcd.VerifyOnscreenMessage("MasterFee.Header", Msg[7], true);
						if (flagFeeId) {
							actions.clear("MasterFee.FeeId");
							// Entering unique Fee ID
							rand_num = new Random();
							iFeeId = rand_num.nextInt((99) + 5);
							System.out.println(iFeeId);
							actions.setValue("MasterFee.FeeId", Integer.toString(iFeeId));
							actions.keyboardEnter("ApplyChangesDetails.Save");
							actions.smartWait(180);
						}
					} catch (Exception ee) {
						actions.WaitForElementPresent("ManageFee.SSMsg");
						flag = mcd.VerifyOnscreenMessage("ManageFee.SSMsg", Msg[6], true);
						flagFeeId = false;
					}
				} while (flagFeeId);
			}
			actions.WaitForElementPresent("DepositSet.OtherTaxCode");
			actions.setValue("DepositSet.OtherTaxCode", "Optional");
			actions.smartWait(10);
			actions.WaitForElementPresent("DepositSet.OtherTaxRule");
			actions.setValue("DepositSet.OtherTaxRule", "GST");
			actions.smartWait(10);
			actions.click("ManageFee.Applybtn");
			Thread.sleep(2000);

			actions.WaitForElementPresent("DepositSet.OtherTaxRule");
			actions.setValue("DepositSet.OtherTaxRule", "Select");
			Select select1 = new Select(actions.getWebElement("DepositSet.OtherTaxEntry"));
			select1.selectByIndex(1);

			// Verify Alert message
			boolean msg4 = mcd.VerifyAlertMessageDisplayed("Warning", Msg[4], true, AlertPopupButton.OK_BUTTON);
			if (msg4) {
				actions.reportCreatePASS("Verify 'Please select Tax Rule' Alert",
						"'Please select Tax Rule' Alert should be displayed",
						"'Please select Tax Rule' Alert is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify Please select Tax Rule' Alert",
						"'Please select Tax Rule' Alert should be displayed",
						"'Please select Tax Rule' Alert is not displayed", "Fail");
			}
			actions.WaitForElementPresent("DepositSet.OtherTaxCode");
			actions.setValue("DepositSet.OtherTaxCode", "Select");
			actions.WaitForElementPresent("DepositSet.OtherTaxRule");
			actions.setValue("DepositSet.OtherTaxRule", "GST");

			// Verify Alert message
			boolean msg3 = mcd.VerifyAlertMessageDisplayed("Warning", Msg[3], true, AlertPopupButton.OK_BUTTON);
			if (msg3) {
				actions.reportCreatePASS("Verify 'Please select Tax Code' Alert",
						"'Please select Tax Code' Alert should be displayed",
						"'Please select Tax Code' Alert is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify Please select Tax Code' Alert",
						"'Please select Tax Code' Alert should be displayed",
						"'Please select Tax Code' Alert is not displayed", "Fail");
			}

			actions.WaitForElementPresent("DepositSet.OtherTaxRule");
			actions.setValue("DepositSet.OtherTaxRule", "Select");
			Select select2 = new Select(actions.getWebElement("DepositSet.OtherTaxEntry"));
			select2.selectByIndex(1);

			// Verify Alert message
			mcd.VerifyAlertMessageDisplayed("Warning", Msg[4], true, AlertPopupButton.OK_BUTTON);
			actions.click("ManageFee.Applybtn");
			actions.WaitForElementPresent("FeeSet.TaxCode");
			actions.setValue("FeeSet.TaxCode", "Always");
			actions.setValue("FeeSet.TaxRule", "TAX_CHAIN");

			Select select3 = new Select(driver.findElement(By.xpath(actions.getLocator("FeeSet.TaxEntry"))));
			Integer TaxRuleDropdownsize = select3.getOptions().size();

			for (int i = 0; i <= TaxRuleDropdownsize - 1; i++) {
				TaxRuleDropdownValue = select3.getOptions().get(i).getText();
				System.out.println(TaxRuleDropdownValue);
			}
			actions.click("RFM.CancelBtn");
			Thread.sleep(2000);
			// Verify Alert message
			boolean msg5 = mcd.VerifyAlertMessageDisplayed("Warning", Msg[5], true, AlertPopupButton.OK_BUTTON);
			if (msg5) {
				actions.reportCreatePASS("Unsaved data will be lost' Alert",
						"'Unsaved data will be lost' Alert should be displayed",
						"'Unsaved data will be lost' Alert is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify 'Unsaved data will be lost' Alert",
						"'Unsaved data will be lost' Alert should be displayed",
						"'Unsaved data will be lost' Alert is not displayed", "Fail");
			}

			/** Logout the application */
			rfm.Logout();
		} catch (Exception e) {
			// reporting the Fail condition
			actions.catchException(e);
		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}
}