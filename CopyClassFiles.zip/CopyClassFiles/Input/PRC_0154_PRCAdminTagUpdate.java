package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;

public class PRC_0154_PRCAdminTagUpdate {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// Declare test-data variables for other data-parameters
	private String strNavigateAdm;
	private String strFuturePrc;

	public PRC_0154_PRCAdminTagUpdate(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// GetTestData for other data-parameters
		strNavigateAdm = mcd.GetTestData("NavigateAdm");
		strFuturePrc = mcd.GetTestData("FuturePrc");
	}

	@Test
	public void test_PRC_0154_PRCAdminTagUpdate() throws InterruptedException {

		String strTestDescription = "Verify the Impact at Price Sets screen when value of <display-price-type-attribute-as-expanded-by-default> and <restrict-price-type-attribute-from-expanding> tag are set to false";

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			/** Get application time */
			actions.setTestcaseDescription(strTestDescription);

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Navigating to Admin */
			System.out.println("> Navigate to :: " + strNavigateAdm);
			actions.select_menu("RFMHome.Pricing", strNavigateAdm);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			mcd.SwitchToWindow("#Title");

			// Setting below two price attributes to 'false'
			rfm.RFM_Admin_Update_PricingTags("false", "Restrict price type attribute from expanding");
			rfm.RFM_Admin_Update_PricingTags("false", "Display price type attribute as expanded by default");

			/** Navigating to Price Sets */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Pricing", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			// Select the first price set to verify the price attributes
			try {
				WebElement FirstPS = mcd.GetTableCellElement("PackageReport.Table", 1, 1, "a");
				actions.click(FirstPS);
				mcd.smartsync(180);
			} catch (Exception e) {
				actions.reportCreateFAIL("Verify Price Sets are present", "At least one price set must be present",
						"Not a single price set is present in the Application", "Fail");
			}
			mcd.SwitchToWindow("#Title");

			// Verifying pricing attributes for current date
			VerifyPriceAttributes();

			// Creating future date if not present
			List<WebElement> FutDates = driver.findElements(By.xpath(actions.getLocator("PriceSets.SBFutureSetting")));
			if (FutDates.size() < 2) {
				mcd.SelectDate_OpenCalender("10", "next");
				mcd.smartsync(180);
				// Enter future price setting
				actions.WaitForElementPresent("ManagePS.AllPrice", 120);
				actions.clear("ManagePS.AllPrice");
				actions.setValue("ManagePS.AllPrice", strFuturePrc);
				actions.click("AddTenderType.ApplyButton");
				Thread.sleep(2000);

				try {
					if (mcd.GetGlobalData("Instance").trim().toLowerCase().contains("us")) {
						actions.click("FutureSettings.Apply");

						driver.switchTo().alert().accept();
					} else {
						actions.keyboardEnter("DimensionGroup.SaveButton");
					}
				} catch (Exception e1) {
				}
				mcd.smartsync(120);
			} else {
				actions.click(FutDates.get(1));
				mcd.smartsync(180);
			}

			// Verifying pricing attributes for future date
			VerifyPriceAttributes();

			// Adding available Menu Items
			actions.keyboardEnter("SubstitutionGroups.AddMenuItemButton");
			mcd.waitAndSwitch("Price Sets : Common Menu Item Selector");
			actions.keyboardEnter("RecipeReport.ViewFullListBtn");
			mcd.smartsync(180);
			actions.setValue("CMIS.Availabilitydrpdwn", "Available");
			mcd.smartsync(180);
			WebElement chkbox = mcd.GetTableCellElement("CommonMenuItemSelector.MenuItemList", 1, 1, "input");
			actions.click(chkbox);
			actions.keyboardEnter("CommonSelector.Save");
			mcd.SwitchToWindow("Price Sets");

			// Verifying pricing attributes after adding menu items
			VerifyPriceAttributes();

			actions.click("RFM.Cancelbtn");
			mcd.smartsync(180);
			mcd.SwitchToWindow("#Title");
			WebElement FirstPS = mcd.GetTableCellElement("PackageReport.Table", 1, 1, "a");
			actions.click(FirstPS);
			mcd.smartsync(180);
			mcd.SwitchToWindow("#Title");

			// Verifying pricing attributes again for current date
			VerifyPriceAttributes();

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);
		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}

	// Function to verify the pricing attributes
	// 1.collapsed by default
	// 2.Can be collapsed and expanded
	public void VerifyPriceAttributes() throws Exception {
		List<WebElement> Plus_Icons = driver.findElements(By.xpath(actions.getLocator("ManagePriceSet.PlusIcon")));
		// Entering common value into all price values
		// 1. if plus icon is not displayed
		// 2. if different values are present for eatin, other and takeout
		if (!Plus_Icons.get(0).isDisplayed()) {
			actions.WaitForElementPresent("ManagePS.AllPrice", 120);
			actions.clear("ManagePS.AllPrice");
			actions.setValue("ManagePS.AllPrice", strFuturePrc);
			actions.click("AddTenderType.ApplyButton");
			Thread.sleep(2000);
			try {
				if (mcd.GetGlobalData("Instance").trim().toLowerCase().contains("us")) {
					actions.click("FutureSettings.Apply");
					driver.switchTo().alert().accept();
				} else {
					actions.keyboardEnter("DimensionGroup.SaveButton");
				}
			} catch (Exception e1) {
			}
			mcd.smartsync(180);
		}
		if (Plus_Icons.get(0).isDisplayed()) {
			actions.reportCreatePASS("Verify Price attributes are collapsed by default",
					"Price attributes should be collapsed by default", "Price attributes are collapsed by default",
					"Pass");
		} else {
			actions.reportCreateFAIL("Verify Price attributes are collapsed by default",
					"Price attributes should be collapsed by default", "Price attributes are not collapsed by default",
					"Fail");
		}

		try {
			actions.click(Plus_Icons.get(0));

			List<WebElement> Minus_Icons = driver
					.findElements(By.xpath(actions.getLocator("ManagePriceSet.MinusIcon")));
			if (Minus_Icons.get(0).isDisplayed()) {
				actions.reportCreatePASS("Verify Price attributes expanding and collapsing",
						"Price attributes can be collapsed and expanded", "Price attributes are expanded", "Pass");
			} else {
				actions.reportCreateFAIL("Verify Price attributes expanding and collapsing",
						"Price attributes can be collapsed and expanded", "Price attributes are not expanded", "Fail");
			}
		} catch (Exception e) {
		}
	}
}
