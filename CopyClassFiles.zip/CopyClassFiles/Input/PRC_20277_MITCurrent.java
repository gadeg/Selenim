package xtam.test;

import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import org.openqa.selenium.WebElement;

import crossbrowser.library.Keywords;
import crossbrowser.library.PackageValidation;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.XMLValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class PRC_20277_MITCurrent {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private XMLValidations xmlValidation;
	private PackageValidation pkg;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo,restNum,MenuTaxMsg,ExpectTaxMsg[];
	private boolean flag;
	// TODO: Declare test-data variables for other data-parameters

	public PRC_20277_MITCurrent(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		pkg = new PackageValidation(driver, actions, uiActions, inputData, mcd, rfm);
		xmlValidation = new XMLValidations();

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		restNum			= mcd.GetTestData("DT_Rest");
		MenuTaxMsg		= mcd.GetTestData("DT_MenuTaxSetMessages");
		// TODO: GetTestData for other data-parameters
		ExpectTaxMsg = MenuTaxMsg.split("#");
	}

	@Test
	public void test_PRC_20277_MITCurrent() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			
			actions.setTestcaseDescription("Menu Items added to the current tax set are also added to the future tax set");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Create Menu Item Tax Set
			actions.click("MenuItemTaxSet.NewTaxSetBtn");
			mcd.waitAndSwitch("Add New Menu Item Tax Set");
			
			String mittset = mcd.fn_GetRndName("MITTSet");
			System.out.println(mittset);
			actions.clear("AddNewMenuItemTaxSet.SetNameTextBox");
			actions.setValue("AddNewMenuItemTaxSet.SetNameTextBox", mittset);
			
			actions.click("Deposit.DSSelectNode");
			mcd.waitAndSwitch("Select Node");
			actions.WaitForElementPresent("SelectNodeRest.SearchTextField", 180);
			mcd.Selectrestnode_JavaScriptClk("RFMSelectNode.SelectNodeTable", restNum);
			mcd.SwitchToWindow("Add New Menu Item Tax Set");
			actions.click("AddNewMenuItemSet.Next");
			
			
		/*	do {
				String mittset = mcd.fn_GetRndName("MITTSet");
				System.out.println(mittset);
				actions.clear("AddNewMenuItemTaxSet.SetNameTextBox");
				actions.setValue("AddNewMenuItemTaxSet.SetNameTextBox", mittset);
				actions.click("AddNewMenuItemSet.Next");
				actions.smartWait(50);
				try{
					flag = mcd.VerifyOnscreenMessage("AddNewFlavorSet.ErrorMessage", ExpectTaxMsg[0], true);
					
				}catch (Exception e){
					flag = false;
					actions.smartWait(10);
				}
			}while(flag);*/
			
			// Adding the menu item
			mcd.SwitchToWindow("@Menu Item Tax Set : Common Menu Item Selector");
			actions.WaitForElementPresent("CommonMenuItemSelector.ViewFullListBtn", 50);
			actions.click("CommonMenuItemSelector.ViewFullListBtn");
			actions.smartWait(50);
			actions.setValue("AddRemoveMenu.Availability", "Available");
			actions.smartWait(50);
			actions.setValue("AddRemoveMI.FilterStatus", "Active");
			actions.smartWait(50);
			
			/** Selecting the record & saving it */
			WebElement elem_checkbox = mcd.GetTableCellElement("AddRemoveComponent.webtable", 1, "Add", "input");
			actions.javaScriptClick(elem_checkbox);
			WebElement elem_checkbox1 = mcd.GetTableCellElement("AddRemoveComponent.webtable", 2, "Add", "input");
			actions.javaScriptClick(elem_checkbox1);
			actions.WaitForElementPresent("RFM.SaveBtn", 180);
			actions.click("RFM.SaveBtn");
			mcd.SwitchToWindow("@Title");
			actions.click("RFM.CancelButton");
			actions.smartWait(180);
			
			// Select the newly create menu item tax set
			actions.clear("MenuItemSets.SearchTxtBox");
			actions.setValue("MenuItemSets.SearchTxtBox", mittset);
			actions.click("MediaAssets.SearchButton");
			actions.smartWait(100);
			actions.click("FlavorSet.TableNameValue");
			mcd.waitAndSwitch("Apply Changes Details");
			actions.javaScriptClick("MenuItemSets.FutureDate");
			actions.click("ApplyChangesDetails.datepicker");
			actions.smartWait(10);
			mcd.Get_future_date(3,"Close", strApplicationDate);
			actions.smartWait(30);
			actions.click("ApplyChangesDetails.Save");
			mcd.SwitchToWindow("@Manage Menu Item Tax Set");
			
			// Click on Cancel Button
			actions.smartWait(20);
			actions.click("NewMITaxSet.Cancel");
			
			// Select the same menu item tax set
			actions.clear("MenuItemSets.SearchTxtBox");
			actions.setValue("MenuItemSets.SearchTxtBox", mittset);
			actions.click("MediaAssets.SearchButton");
			actions.smartWait(100);
			actions.click("FlavorSet.TableNameValue");
			actions.smartWait(50);
			
			
			// Add the menu item
			actions.click("ManageMenuItemTaxSet.AddRemoveMenuItem");
			mcd.waitAndSwitch("Menu Item Tax Set : Common Menu Item Selector");
			actions.WaitForElementPresent("CommonMenuItemSelector.ViewFullListBtn", 180);
			actions.click("CommonMenuItemSelector.ViewFullListBtn");
			actions.smartWait(180);
			actions.setValue("AddRemoveMenu.Availability", "Available");
			actions.smartWait(180);
			actions.setValue("AddRemoveMI.FilterStatus", "Active");
			actions.smartWait(180);
			
			/** Selecting the record & saving it */
			WebElement elem_checkbox2 = mcd.GetTableCellElement("AddRemoveComponent.webtable", 3, "Add", "input");
			actions.javaScriptClick(elem_checkbox2);
			WebElement elem_checkbox3 = mcd.GetTableCellElement("AddRemoveComponent.webtable", 4, "Add", "input");
			actions.javaScriptClick(elem_checkbox3);
			actions.WaitForElementPresent("RFM.SaveBtn", 180);
			actions.click("RFM.SaveBtn");
			mcd.SwitchToWindow("Manage Menu Item Tax Set");
			actions.smartWait(30);
			actions.click("RFM.CancelButton");
			actions.smartWait(100);
			
			
			// Search menu item tax set which has just been updated
			actions.clear("MenuItemSets.SearchTxtBox");
			actions.setValue("MenuItemSets.SearchTxtBox", mittset);
			actions.click("MediaAssets.SearchButton");
			actions.smartWait(100);
			actions.click("ScreenSet.SearchedValueFutureSettings");
			actions.smartWait(100);
			
			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}
