/**
 * 
 */
package xtam.test;

/**
 * @author akrani
 *
 */
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;

public class PRC_20276_MITSchngCurntPropFutr {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private String FutureSettings, MenuItemTaxSet, strTaxCodeDropDownValueCurntSett, TaxRuleDropdownValueCurrent,
			TaxEntryDropdownValueCurrent, strTaxCodeDropDownValueFutSett, TaxRuleDropdownValueFutSett,
			TaxEntryDropdownValueFutSett;
	Integer rowCount;

	public PRC_20276_MITSchngCurntPropFutr(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters

	}

	@Test
	public void test_PRC_20276_MITSchngCurntPropFutr() throws InterruptedException {

		String strTestDescription = "Verify that Tax setting changes made to the current tax settings for a menu item are propagated to future tax settings unless the future tax settings have been changed for that menu item. "; // TODO:
																																																									// Test
																																																									// Case
																																																									// Description

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);


			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			/** Get application time */
			actions.setTestcaseDescription(strTestDescription);

			// ------------------------------------------------------------------------
			// Actions specific to test-flow
			actions.keyboardEnter("TaxType.ViewFullListButton");
			actions.smartWait(100);

			// Validating whether Future Settings already present or not
			rowCount = mcd.GetTableRowCount("ScriptManagement.TableNameValue");
			if (rowCount > 1) {
				for (int i = 1; i <= rowCount; i++) {
					FutureSettings = mcd.GetTableCellValue("ScriptManagement.TableNameValue", i, "Future Settings", "",
							"");
					if (FutureSettings.equals("")) {
						// Retrieving MenuItemTaxSet Name of table
						MenuItemTaxSet = mcd.GetTableCellValue("ScriptManagement.TableNameValue", i, "Name", "", "");
						WebElement ElementTaxSetNm = mcd.GetTableCellElement("ScriptManagement.TableNameValue", i,
								"Name", "a");
						actions.keyboardEnter(ElementTaxSetNm);
						break;
					}
				}
			} else if (rowCount == 1) {
				WebElement ElementTaxSetNm = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1, "Name", "a");
				actions.keyboardEnter(ElementTaxSetNm);
			} else {
				System.out.println("No Active Menu Item Tax Set Available ");
			}

			mcd.SwitchToWindow("Apply Changes Details");
			driver.findElement(By.xpath(actions.getLocator("ApplyChangesDetails.futureDateRadioButton"))).click();
			driver.findElement(By.xpath(actions.getLocator("ApplyChangesDetails.CalendarIcon"))).click();
			mcd.Get_future_date(1, "Close", strApplicationDate);
			actions.keyboardEnter("ApplyChangesDetails.MDSaveButton");

			// actions.smartWait(10);
			Thread.sleep(3000);
			mcd.SwitchToWindow("@Manage Menu Item Tax Set");
			actions.keyboardEnter("NewScript.CancleButton");
			mcd.SwitchToWindow("#Title");

			// Clicking on Menu Item Tax Set name having current setting
			actions.clear("TenderSet.SearchTextBox");
			actions.setValue("TenderSet.SearchTextBox", MenuItemTaxSet);
			actions.keyboardEnter("TaxType.SearchButton");
			actions.smartWait(100);

			WebElement ElementTaxSetNm1 = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1, "Name", "a");
			actions.keyboardEnter(ElementTaxSetNm1);

			// Switching to Manage Menu Item Tax Set
			mcd.SwitchToWindow("#Title");
			Select select2 = new Select(
					driver.findElement(By.xpath(actions.getLocator("ManageMenuItemTaxSet.TaxCodeFirstDropDown"))));
			strTaxCodeDropDownValueCurntSett = select2.getFirstSelectedOption().getText();
			Select select = new Select(
					driver.findElement(By.xpath(actions.getLocator("ManageMenuItemTaxSet.AllTexRuleDropDown"))));
			Select select1 = new Select(
					driver.findElement(By.xpath(actions.getLocator("ManageMenuItemTaxSet.TaxEntryDropdown"))));

			String value;
			if (strTaxCodeDropDownValueCurntSett.equals("Never")) {
				value="Optional";
				actions.setValue("ManageMenuItemTaxSet.TaxCodeFirstDropDown", "Optional");
				TaxRuleDropdownValueCurrent = "TAX_CHAIN";
				actions.setValue("ManageMenuItemTaxSet.AllTexRuleDropDown", TaxRuleDropdownValueCurrent);

				TaxEntryDropdownValueCurrent = select1.getOptions().get(1).getText();
				actions.setValue("ManageMenuItemTaxSet.TaxEntryDropdown", TaxEntryDropdownValueCurrent);
			} else {
				value="Never";
				actions.setValue("ManageMenuItemTaxSet.TaxCodeFirstDropDown", "Never");
			}

			actions.keyboardEnter("ManageMenuItemTaxSet.ApplyButton");
			actions.smartWait(100);
			actions.WaitForElementPresent("NewScript.CancleButton");
			actions.keyboardEnter("NewScript.CancleButton");
			mcd.SwitchToWindow("#Title");

			// Clicking on Menu Item Tax Set name having Future Settings
			actions.WaitForElementPresent("TenderSet.SearchTextBox");
			actions.clear("TenderSet.SearchTextBox");
			actions.setValue("TenderSet.SearchTextBox", MenuItemTaxSet);
			actions.keyboardEnter("TaxType.SearchButton");
			actions.smartWait(100);

			WebElement ElementTaxSetNm2 = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1,
					"Future Settings", "a");
			actions.keyboardEnter(ElementTaxSetNm2);

			// Switching to Manage Menu Item Tax Set
			mcd.SwitchToWindow("#Title");
			Select select3 = new Select(
					driver.findElement(By.xpath(actions.getLocator("ManageMenuItemTaxSet.TaxCodeFirstDropDown"))));
			Select select4 = new Select(
					driver.findElement(By.xpath(actions.getLocator("ManageMenuItemTaxSet.AllTexRuleDropDown"))));
			Select select5 = new Select(
					driver.findElement(By.xpath(actions.getLocator("ManageMenuItemTaxSet.TaxEntryDropdown"))));

			strTaxCodeDropDownValueFutSett = select3.getFirstSelectedOption().getText();
			TaxRuleDropdownValueFutSett = select4.getFirstSelectedOption().getText();
			TaxEntryDropdownValueFutSett = select5.getFirstSelectedOption().getText();

			if (strTaxCodeDropDownValueFutSett.equalsIgnoreCase("value")
					&& TaxRuleDropdownValueFutSett.equalsIgnoreCase(TaxRuleDropdownValueCurrent)
					&& TaxEntryDropdownValueFutSett.equalsIgnoreCase(TaxEntryDropdownValueCurrent)) {
				actions.reportCreatePASS(
						"Verify that the changes that have been made for current settings are also propagated to future settings.",
						"Changes that have been made for current settings are also propagated to future settings.",
						"Changes that have been made for current settings are also propagated to future settings.",
						"Pass");
			} else {
				actions.reportCreateFAIL(
						"Verify that the changes that have been made for current settings are also propagated to future settings.",
						"Changes that have been made for current settings are also propagated to future settings.",
						"Changes that have been made for current settings are not propagated to future settings.",
						"Fail");
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			actions.catchException(e);
		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}