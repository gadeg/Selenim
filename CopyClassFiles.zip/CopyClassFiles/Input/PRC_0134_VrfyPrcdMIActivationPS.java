package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;

public class PRC_0134_VrfyPrcdMIActivationPS {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// Declare test-data variables for other data-parameters
	private String strNavigateToAdmin;
	private String strOperation, strActivity, strNode, strLevel, strUID, strDBName;

	public PRC_0134_VrfyPrcdMIActivationPS(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// GetTestData for other data-parameters
		strNavigateToAdmin = mcd.GetTestData("DT_NAVIGATE_TO_ADMIN");
		strOperation = mcd.GetTestData("DT_OPERATION");
		strActivity = mcd.GetTestData("DT_ACTIVITY");
		strLevel = mcd.GetTestData("DT_LEVEL");
		strDBName = mcd.GetTestData("DT_DBNAME");
		strUID = mcd.GetTestData("DT_USERID");
	}

	@Test
	public void test_PRC_0134_VrfyPrcdMIActivationPS() throws InterruptedException {
		String strTestDescription = "Verify that Only priced menu items will activated and menu items are activated only if the selected price set is active and assigned to a restaurant";

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			/** Get Test Case Description */
			actions.setTestcaseDescription(strTestDescription);

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Navigating to Admin */
			System.out.println("> Navigate to :: " + strNavigateToAdmin);
			actions.select_menu("RFMHome.Navigation", strNavigateToAdmin);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			// Setting the values for Price fields
			rfm.RFM_Admin_Update_PricingTags("false", "Restrict price type attribute from expanding");
			rfm.RFM_Admin_Update_PricingTags("false", "Display price type attribute as expanded by default");

			/** Navigating to Price Sets */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			// Getting the name of a price set which is Active and Assigned to
			// Restaurant
			actions.WaitForElementPresent("PricingSets.StatusFilter", 120);
			Select StatusVal = new Select(driver.findElement(By.xpath(actions.getLocator("PricingSets.StatusFilter"))));
			StatusVal.selectByVisibleText("Active");
			mcd.smartsync(180);
			int iActivePSets = mcd.GetTableRowCount("PriceSet.Table");
			String ActivePS = "";
			boolean isAssgntoRest = false;
			for (int j = 2; j < iActivePSets; j++) {
				WebElement AssgndRestImg = mcd.GetTableCellElement("PriceSet.Table", j, 1, "span/img");
				if (AssgndRestImg.isDisplayed()) {
					ActivePS = mcd.GetTableCellElement("PriceSet.Table", j, 1, "a").getText();
					actions.reportCreatePASS("Verify the Active Price Set available and Assigned to Restaurant",
							"At least one active Price Set should be available", "Active Price Set is available",
							"Pass");
					isAssgntoRest = true;
					break;
				}
			}
			if (!isAssgntoRest) {
				actions.reportCreateFAIL("Verify the Active Price Set available and Assigned to Restaurant",
						"At least one active Price Set should be available", "Active Price Set is not available",
						"Fail");
			}

			// Searching for a price set which is Active and Assigned to
			// Restaurant
			actions.WaitForElementPresent("PricingSets.SearchTextBox", 120);
			actions.setValue("PricingSets.SearchTextBox", ActivePS);
			actions.keyboardEnter("RestaurantSet.Searchbtn");
			mcd.smartsync(180);
			Actions builder = new Actions(driver);
			builder.moveByOffset(500, 0).click().perform();
			actions.WaitForElementPresent("PriceSet.Table", 120);
			String strRestNode = mcd.GetTableCellElement("PriceSet.Table", 1, 2, "").getText();
			mcd.GetTableCellElement("PriceSet.Table", 1, 1, "a").click();
			mcd.smartsync(180);
			mcd.SwitchToWindow("#Title");

			// Getting the names of Inactive/Not Approved Menu Items
			actions.keyboardEnter("ManageMenuItemTaxSet.AddRemoveButton");
			mcd.waitAndSwitch("Price Sets : Common Menu Item Selector");
			actions.WaitForElementPresent("MenuItemSets.Status", 120);
			if (strMarket.equalsIgnoreCase("us country office")) {
				actions.setValue("MenuItemSets.Status", "Not Approved");
				mcd.smartsync(180);
			} else if (strMarket.equalsIgnoreCase("australasia")) {
				actions.setValue("MenuItemSets.Status", "Inactive");
				mcd.smartsync(180);
			}
			String NtApprvPS1 = mcd.GetTableCellElement("Deposit.AddDepositTable", 1, 4, "").getText();
			String NtApprvPS2 = mcd.GetTableCellElement("Deposit.AddDepositTable", 2, 4, "").getText();
			actions.keyboardEnter("ApprovalStatusChanges.CancelBtn");
			mcd.SwitchToWindow("Price Sets");
			actions.WaitForElementPresent("PriceSets.SearchDropDown", 120);
			actions.setValue("PriceSets.SearchDropDown", "Exact Match");
			actions.WaitForElementPresent("PricingSets.SearchTextBox", 120);
			actions.setValue("PricingSets.SearchTextBox", NtApprvPS1 + "+" + NtApprvPS2);
			actions.keyboardEnter("RestaurantSet.Searchbtn");
			mcd.smartsync(180);
			actions.WaitForElementPresent("PriceSets.ProductPrice", 120);
			List<WebElement> PriceFields = driver.findElements(By.xpath(actions.getLocator("PriceSets.ProductPrice")));

			if (PriceFields.get(0).equals("")) {
				PriceFields.get(0).clear();
				PriceFields.get(0).sendKeys("10.00");
			}

			if (PriceFields.get(1).equals("")) {
				PriceFields.get(1).clear();
				PriceFields.get(1).sendKeys("5.00");
			}

			// Activating the Inactive Menu Items by checking Activate All Menu
			// Items check box
			if (!actions.isElementSelected("ManagePriceSet.ActivateAllMenuItemChkbox")) {
				actions.javaScriptClick("ManagePriceSet.ActivateAllMenuItemChkbox");
			}
			actions.keyboardEnter("PriceSet.ApplyButton");
			mcd.smartsync(180);

			// Validating activation is successful
			if (actions.isTextPresence("Your changes have been saved.", true)) {
				actions.reportCreatePASS("Verify Activation of Inactive Men Items",
						"Inactive Menu Items should be activated", "Inactive Menu Items are activated", "Pass");
			} else {
				actions.reportCreateFAIL("Verify Activation of Inactive Men Items",
						"Inactive Menu Items should be activated", "Inactive Menu Items are not activated", "Fail");
			}
			mcd.waitAndSwitch("Activate Menu Items");
			mcd.smartsync(180);
			actions.waitForPageToLoad(120);
			Thread.sleep(10000);
			actions.click("RFM.Okbtn");
			mcd.SwitchToWindow("Price Sets");

			// Navigating back to Manage price sets
			actions.keyboardEnter("ApprovalStatusChanges.CancelBtn");
			mcd.smartsync(180);
			mcd.SwitchToWindow("#Title");
			// ------------------------------------
			// Checking for a price set which is active and not assigned to
			// restaurant
			actions.clear("PricingSets.SearchTextBox");
			actions.keyboardEnter("RestaurantSet.Searchbtn");
			mcd.smartsync(180);
			boolean isNotAssgntoRest = false;
			actions.WaitForElementPresent("PricingSets.StatusFilter", 120);
			StatusVal = new Select(driver.findElement(By.xpath(actions.getLocator("PricingSets.StatusFilter"))));
			StatusVal.selectByVisibleText("Active");
			mcd.smartsync(180);
			iActivePSets = mcd.GetTableRowCount("PriceSet.Table");
			String ActivePSNotAssgnRest = "";
			for (int j = 1; j < iActivePSets; j++) {
				WebElement AssgndRestImg = mcd.GetTableCellElement("PriceSet.Table", j, 1, "span/img");
				if (!AssgndRestImg.isDisplayed()) {
					ActivePSNotAssgnRest = mcd.GetTableCellElement("PriceSet.Table", j, 1, "a").getText();
					actions.reportCreatePASS("Verify the Active Price Set available and not Assigned to Restaurant",
							"At least one active Price Set should be available",
							"Active Price Set is not assigned to restaurant", "Pass");
					isNotAssgntoRest = true;
					break;
				}
			}

			// if active and not assigned to restaurant price set is not
			// available, changing the status from inactive to active and saving
			if (!isNotAssgntoRest) {
				actions.setValue("PricingSets.StatusFilter", "Inactive");
				mcd.smartsync(180);
				WebElement ActiveNotAssgndToRest = mcd.GetTableCellElement("PriceSet.Table", 1, 1, "a");
				ActivePSNotAssgnRest = ActiveNotAssgndToRest.getText();
				actions.click(ActiveNotAssgndToRest);
				mcd.smartsync(180);
				mcd.SwitchToWindow("#Title");

				actions.WaitForElementPresent("ManagePS.PPPrcSetFilter", 120);
				actions.setValue("ManagePS.PPPrcSetFilter", "Active");
				actions.keyboardEnter("PriceSet.ApplyButton");
				mcd.smartsync(180);
				actions.keyboardEnter("ApprovalStatusChanges.CancelBtn");
				mcd.smartsync(180);
				mcd.SwitchToWindow("#Title");
			}

			// Searching for a price set which is Active and Not Assigned to
			// Restaurant
			actions.WaitForElementPresent("PricingSets.SearchTextBox", 120);
			actions.setValue("PricingSets.SearchTextBox", ActivePSNotAssgnRest);
			actions.keyboardEnter("RestaurantSet.Searchbtn");
			mcd.smartsync(180);
			actions.WaitForElementPresent("PriceSet.Table", 120);
			mcd.GetTableCellElement("PriceSet.Table", 1, 1, "a").click();
			mcd.SwitchToWindow("#Title");

			if (!actions.isElementEnabled("ManagePriceSet.ActivateAllMenuItemChkbox")) {
				actions.reportCreatePASS("Verify activate Menu Items check box",
						"Activate Menu Item check box should be disabled", "Activate Menu Item check box is disabled",
						"Pass");
			} else {
				actions.reportCreateFAIL("Verify activate Menu Items check box",
						"Activate Menu Item check box should be disabled",
						"Activate Menu Item check box is not disabled", "Fail");
			}
			actions.keyboardEnter("ApprovalStatusChanges.CancelBtn");
			mcd.smartsync(180);
			mcd.SwitchToWindow("#Title");

			// verify the audit log now
			if (rfm.VerifyAuditLog_Entry(strOperation, strActivity, strRestNode.trim())) {
				actions.reportCreatePASS("Verifying the Audit log", "Audit log should display correct values",
						"Audit log displayed correct values", "Pass");
			} else {
				actions.reportCreateFAIL("Verifying the Audit log", "Audit log should display correct values",
						"Audit log not displayed correct values", "Fail");
			}

			String strDescription = "The Menu Item(s) has been activated from Price Set .";
			// verify the audit log details
			if (rfm.RFM_VerifyAuditLog_Details(strDBName, strUID, strOperation, strActivity, strLevel,
					strRestNode.trim(), strDescription)) {
				actions.reportCreatePASS("Verifying the Audit log details",
						"Audit log details should display correct values", "Audit log displayed correct values",
						"Pass");
			} else {
				actions.reportCreateFAIL("Verifying the Audit log details",
						"Audit log details should display correct values",
						"Audit log details not displayed correct values", "Fail");
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			// reporting the Fail condition
			actions.catchException(e);
		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}
}