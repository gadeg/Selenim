package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class PRC_0118_PrcSet_ChangeDate {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;

	// TODO: Declare test-data variables for other data-parameters
	private String strApplicationDate;
	private String strPriceSetType;
	private String strPriceSetName;
	private String strNewPrice;
	private String strMessage1;
	private String strMessage2;
	private String strMessage3;

	public PRC_0118_PrcSet_ChangeDate(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");

		// TODO: GetTestData for other data-parameters
		strPriceSetType = mcd.GetTestData("PriceSetType");
		strNewPrice = mcd.GetTestData("FuturePrice");
		strMessage1 = mcd.GetTestData("Message1");
		strMessage2 = mcd.GetTestData("Message2");
		strMessage3 = mcd.GetTestData("Message3");
	}

	@Test
	public void PRC_0118_PrcSet_ChangeDate() throws InterruptedException {

		try {

			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription(
					"Verify Update Price Set Details (Change Date) functionality  of Base price set");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// Updating prices set
			strPriceSetName = RFM_PRC_UpdatePriceSet_ChangeDate(strPriceSetType, strPriceSetName, strNewPrice,
					strMessage1, strMessage2, strMessage3);

			// ** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			// Selecting existing future set
			RFM_PRC_ChangeDate_TwoExistingFutureSetting(strPriceSetName, strMessage1, strMessage2, strMessage3);

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	public String RFM_PRC_UpdatePriceSet_ChangeDate(String strPriceSetType, String strPriceSetName, String strNewPrice,
			String strMessage1, String strMessage2, String strMessage3) throws Exception {
		// String Future_Date = null;
		String ChngdDate = null;
		String ChngdDate2 = null;
		String PriceSets[] = new String[4];

		// Verifying filter button
		if (actions.isElementEnabled("ScreenSet.FilterListFilterButton")) {
			actions.reportCreatePASS("Verify Filter button", "Filter button should enable", "Filter button is enable",
					"PASS");
		} else {
			actions.reportCreateFAIL("Verify Filter button", "Filter button should enable",
					"Filter button is not enable", "FAIL");
		}

		//Verifying table columns
		verifyTablecolumnsPresent("FieldPermissions.Table", "Name");
		verifyTablecolumnsPresent("FieldPermissions.Table", "Node");
		verifyTablecolumnsPresent("FieldPermissions.Table", "Type");
		verifyTablecolumnsPresent("FieldPermissions.Table", "Status");
		verifyTablecolumnsPresent("FieldPermissions.Table", "Delete");
		// Selecting base price set
		actions.setValue("RFMPriceSets.dropdownSearchList", strPriceSetType);
		actions.setValue("RFMPriceSets.MainSearchbox", "a");
		actions.keyboardEnter("RFMPriceSets.MainSearch");
		actions.smartWait(180);

		// Get row count and selecting base prices set
		int rw_cnt = mcd.GetTableRowCount("PriceSet.Table");
		if (rw_cnt > 0) {
			strPriceSetName = driver.findElement(By.xpath("//*[@id='priceSetData']/tr[1]/td[1]/a")).getText();
			driver.findElement(By.xpath("//*[@id='priceSetData']/tr[1]/td[1]/a")).sendKeys(Keys.ENTER);
			
		} else {
			actions.reportCreateFAIL("There are no " + strPriceSetType + " price sets in this market",
					"There are no " + strPriceSetType + " price sets in this market",
					"There are no " + strPriceSetType + " price sets in this market", "FAIL");
		}

		mcd.SwitchToWindow("#Title");
		String Current_date = driver.findElement(By.xpath(actions.getLocator("ManagePS.DateSelected"))).getText();
		String CurrDt = null;
		if (mcd.GetGlobalData("Instance").toLowerCase().contains("ap")) {
			CurrDt = Current_date.split("/")[0].trim();
		} else if (mcd.GetGlobalData("Instance").toLowerCase().contains("us")) {
			CurrDt = Current_date.split(" ")[1].trim().replace(",", "").trim();
		} else if (mcd.GetGlobalData("Instance").toLowerCase().contains("eu")) {
			CurrDt = Current_date.split(" ")[1].trim().replace(",", "").trim();
		}

		int TodaysDt = Integer.parseInt(CurrDt);

		// Checking future settings for price sets
		List<WebElement> FDate = driver.findElements(By.xpath(actions.getLocator("PriceSet.PPFutureDateLink")));
		Boolean Future_Flag = false;
		int numOfSettings = 0;
		if (FDate.size() >= 3) {
			System.out.println("PS has 2 or more future setting");
			Future_Flag = true;
			numOfSettings = 0;
		} else if (FDate.size() > 1) {
			System.out.println("PS has 1 future setting");
			Future_Flag = true;
			numOfSettings = 1;
		} else {
			System.out.println("PS does not have future setting");
			Future_Flag = false;
			numOfSettings = 2;
		}

		for (int num = 1; num <= numOfSettings; num++) {

			int Dt_toSelect = 0;
			if (TodaysDt <= 29) {
				Dt_toSelect = TodaysDt + num;
			} else {
				Dt_toSelect = TodaysDt - num;
			}

			// Select a future date from the calendar
			mcd.SelectDate_OpenCalender(Integer.toString(Dt_toSelect), "next");
			actions.smartWait(180);
			String PriceValue = driver.findElement(By.xpath(actions.getLocator("PriceSets.PriceTextBox")))
					.getAttribute("value");

			// Updating price set value
			if (PriceValue.equals(strNewPrice)) {
				PriceValue = "1.0";
				actions.clear("UpdtMultipleSet.AllPrc");
				Thread.sleep(2000);
				actions.setValue("UpdtMultipleSet.AllPrc", PriceValue);
				actions.click("UpdtMultipleSet.Apply");
				Thread.sleep(3000);
				actions.click("ManagePS.ApplyBtn");
				Thread.sleep(10000);
			}

			actions.clear("UpdtMultipleSet.AllPrc");
			Thread.sleep(1000);
			actions.setValue("UpdtMultipleSet.AllPrc", strNewPrice);
			actions.click("UpdtMultipleSet.Apply");
			actions.waitForPageToLoad(180);
			actions.click("ManagePS.ApplyBtn");
			Thread.sleep(2000);

			try {
				driver.switchTo().alert().accept();
			} catch (Exception e) {
				System.out.println("No alert active");
			}
			actions.smartWait(180);

			// Navigate again to price sets
			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Pricing", strNavigateTo);
			Thread.sleep(3000);
			actions.waitForPageToLoad(120);

			mcd.SwitchToWindow("#Title");

			// Type price set name & Click Search
			actions.setValue("RFMPriceSets.MainSearchbox", strPriceSetName);
			actions.keyboardEnter("RFMPriceSets.MainSearch");
			actions.smartWait(180);

			// Click on Price Set link
			driver.findElement(By.xpath(actions.getLocator("RFMPriceSets.PriceSet1"))).sendKeys(Keys.ENTER);
			Thread.sleep(2000);
			mcd.SwitchToWindow("#Title");
			
		       // Verify Quick search drop down
            String ele = mcd.getdropdownvalues("PriceSets.SearchDropDown");
            String ele2 = mcd.GetTestData("DT_DropDown");
            String[] ele3 = ele2.split("#");
            Boolean flag2 = false;
            for (int i = 0; i < ele3.length; i++) {
                  if (ele.contains(ele3[i])) {
                         flag2 = true;
                  }

                  else {
                         flag2 = false;
                         break;
                  }

            }
            if (flag2 == true) {
                  actions.reportCreatePASS("Verify View Type Drop Down Values",
                                "View Type Drop Down Values should be Present", "View Type Drop Down Values is Present",
                                "PASS");
            } else {
                  actions.reportCreateFAIL("Verify View Type Drop Down Values",
                                "View Type Drop Down Values should be Present", "View Type Drop Down Values is not Present",
                                "FAIL");
            }


		}
		
		//Verifying search button
		if(actions.isElementPresent("SetAssignmentReport.SearchButton")){
			actions.reportCreatePASS("Verify Search button", "Search button should display", "Search button is displayed", "PASS");
		}else{
			actions.reportCreateFAIL("Verify Search button", "Search button should display", "Search button is not displayed", "FAIL");

		}
		
		//Verifying Change by date tab is enable
		if(actions.isElementEnabled("PriceSets.Changesbydate"))
		{
			actions.reportCreatePASS("Verify Change by date tab", "Change by date tab should enable", "Change by date tab is enable", "PASS");
		}else{
			actions.reportCreateFAIL("Verify Change by date tab", "Change by date tab should enable", "Change by date tab is not enable", "FAIL");

		}
		
		//Verifying Future changes by menu item tab is enable
				if(actions.isElementEnabled("PriceSets.Changesbydate"))
				{
					actions.reportCreatePASS("Verify Future changes by menu item tab", "Future changes by menu item tab should enable", "Future changes by menu item tab is enable", "PASS");
				}else{
					actions.reportCreateFAIL("Verify Future changes by menu item tab", "Future changes by menu item tab should enable", "Future changes by menu item tab is not enable", "FAIL");

				}
				
				//Verifying search button
				if(actions.isElementPresent("ManageMenuItemTaxSet.AddRemoveMenuItem")){
					actions.reportCreatePASS("Verify Add/Remove Menu Item button", "Add/Remove Menu Item button should display", "Add/Remove Menu Item button is displayed", "PASS");
				}else{
					actions.reportCreateFAIL("Verify Add/Remove Menu Item button", "Add/Remove Menu Item button should display", "Add/Remove Menu Item button is not displayed", "FAIL");

				}
				
				//Verifying Price DDL is enable
				if(actions.isElementEnabled("PriceSets.Changesbydate"))
				{
					actions.reportCreatePASS("Verify Price DDL", "Price DDL should enable", "Price DDL is enable", "PASS");
				}else{
					actions.reportCreateFAIL("Verify Price DDL", "Price DDL should enable", "Price DDL is not enable", "FAIL");

				}
				
				//Verifying Mass update tax settings is disable
				if(!actions.isElementEnabled("ManagePS.UpdtTaxBtn2"))
				{
					actions.reportCreatePASS("Verify Mass update tax settings button", "Mass update tax settings button should disable", "Mass update tax settings button is disable", "PASS");
				}else{
					actions.reportCreateFAIL("Verify Mass update tax settings button", "Mass update tax settings button should disable", "Mass update tax settings button is not disable", "FAIL");

				}
				
				//Verifying Copy tax is disable
				if(!actions.isElementEnabled("ManagePS.CpyTaxStatus"))
				{
					actions.reportCreatePASS("VerifyCopy tax button", "Copy tax button should disable", "Copy tax button is disable", "PASS");
				}else{
					actions.reportCreateFAIL("Verify Copy tax button", "Copy tax button should disable", "Copy tax button is not disable", "FAIL");

				}
				
				//Verifying Apply button
				if(actions.isElementEnabled("PriceSet.ApplyButton")){
					actions.reportCreatePASS("Verify Apply button", "Apply button should enable", "Apply button is enable", "PASS");
				}else{
					actions.reportCreateFAIL("Verify Apply button", "Apply button should enable", "Apply button is not enable", "FAIL");

				}
				
				//Verifying Cancel button
				if(actions.isElementEnabled("RFM.CancelBtn")){
					actions.reportCreatePASS("Verify Cancel button", "Cancel button should enable", "Cancel button is enable", "PASS");
				}else{
					actions.reportCreateFAIL("Verify Cancel button", "Cancel button should enable", "Cancel button is not enable", "FAIL");

				}
			
			
		// Refresh FDate
		FDate = driver.findElements(By.xpath(actions.getLocator("PriceSets.SBFutureSetting")));
		String[] Future_dates = new String[FDate.size()];
		String[] dates = new String[FDate.size()];

		for (int f = 0; f < FDate.size(); f++) {
			Future_dates[f] = FDate.get(f).getText();

			if (mcd.GetGlobalData("Instance").toLowerCase().contains("ap")) {
				dates[f] = Future_dates[f].split("/")[0].trim();
			} else if (mcd.GetGlobalData("Instance").toLowerCase().contains("us")) {
				dates[f] = Future_dates[f].split(" ")[1].trim().replace(",", "").trim();
			} else if (mcd.GetGlobalData("Instance").toLowerCase().contains("eu")) {
				dates[f] = Future_dates[f].split(" ")[1].trim().replace(",", "").trim();
			}
			System.out.println(Future_dates[f] + " : " + dates[f]);

		}

		// Click on first future Setting
		FDate.get(1).click();
		actions.smartWait(180);
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		// Verify that new tab displays the correct date
		Thread.sleep(8000);
		String Date_displayed = driver.findElement(By.xpath(actions.getLocator("ManagePS.DateSelected"))).getText();

		if (Date_displayed.equals(Future_dates[1])) {

			actions.reportCreatePASS("Correct future date is displayed on future tab",
					"Correct future date is displayed on future tab", "Correct future date is displayed on future tab",
					"PASS");
		} else {

			actions.reportCreateFAIL("Incorrect future date is displayed on future tab",
					"Incorrect future date is displayed on future tab",
					"Incorrect future date is displayed on future tab", "FAIL");
		}

		// Verify that Change Date button is displayed & enabled
		try {
			if (driver.findElement(By.xpath(actions.getLocator("ManagePS.ChngeDateBtn"))).isDisplayed()) {
				if ((driver.findElement(By.xpath(actions.getLocator("ManagePS.ChngeDateBtn"))).isEnabled())) {

					actions.reportCreatePASS("Future Settings Applied : Change Date button is displayed & enabled",
							"Future Settings Applied : Change Date button is displayed & enabled",
							"Future Settings Applied : Change Date button is displayed & enabled", "PASS");
				} else {

					actions.reportCreateFAIL("Future Settings Applied : Change Date button is disabled ",
							"Future Settings Applied : Change Date button is disabled ",
							"Future Settings Applied : Change Date button is disabled ", "FAIL");
				}
			}
		} catch (Exception e) {

			actions.reportCreateFAIL("Future Settings Applied :  Change Date button is not displayed",
					"Future Settings Applied :  Change Date button is not displayed",
					"Future Settings Applied :  Change Date button is not displayed", "FAIL");
		}

		// Click on Copy Tax & select Cancel
		actions.click("ManagePS.ChngeDateBtn");

		Boolean VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Confirmation", strMessage1, true,
				AlertPopupButton.CANCEL_BUTTON);
		if (VerifyPopUpMsg = true) {

			actions.reportCreatePASS("Warning msg on clicking Change Date button & Clicked Cancel ",
					"Warning msg on clicking Change Date button & Clicked Cancel ",
					"Warning msg on clicking Change Date button & Clicked Cancel ", "PASS");
		} else {

			actions.reportCreateFAIL("Warning msg on clicking Change Date button  & Clicked Cancel",
					"Warning msg on clicking Change Date button  & Clicked Cancel",
					"Warning msg on clicking Change Date button  & Clicked Cancel", "FAIL");
		}

		// Click on Change Button & select OK
		actions.click("ManagePS.ChngeDateBtn");

		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Confirmation", strMessage1, true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg = true) {

			actions.reportCreatePASS("Warning msg on clicking Change Date button & Clicked OK",
					"Warning msg on clicking Change Date button & Clicked OK",
					"Warning msg on clicking Change Date button & Clicked OK", "PASS");
		} else {

			actions.reportCreateFAIL("Warning msg on clicking Change Date button  & Clicked OK",
					"Warning msg on clicking Change Date button  & Clicked OK",
					"Warning msg on clicking Change Date button  & Clicked OK", "FAIL");
		}

		// Thread.sleep(2000);

		mcd.SwitchToWindow("Apply Changes Details");
		// Thread.sleep(2000);
		actions.click("ManagePS.ChangeDtCalender");

		// Selecting date and verify pop-up
		mcd.select_date(dates[1], "current");
		actions.click("ManagePS.ChangeDtSave");
		Thread.sleep(3000);
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Message", strMessage2, true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg = true) {

			actions.reportCreatePASS("No changes in date message recieved & Clicked OK",
					"No changes in date message recieved & Clicked OK",
					"No changes in date message recieved & Clicked OK", "PASS");
		} else {

			actions.reportCreateFAIL("No changes in date message not recieved & Clicked OK",
					"No changes in date message not recieved & Clicked OK",
					"No changes in date message not recieved & Clicked OK", "FAIL");
		}

		ChngdDate = driver.findElement(By.xpath(actions.getLocator("ManagePS.ChngDateText"))).getAttribute("value");
		actions.keyboardEnter("RFM.Cancelbtn");
		Thread.sleep(3000);
		actions.waitForPageToLoad(120);
		mcd.waitAndSwitch("Price Sets");
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);
		System.out.println(">>>>>>>>> " + driver.getTitle());
		actions.keyboardEnter("RFM.Cancelbtn");
		mcd.waitAndSwitch("#Title");
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		// Verify Change Date
		actions.clear("RFMPriceSets.MainSearchbox");
		Thread.sleep(1000);
		// Type price set name & Click Search
		actions.setValue("RFMPriceSets.MainSearchbox", strPriceSetName);
		actions.keyboardEnter("RFMPriceSets.MainSearch");
		Thread.sleep(5000);
		actions.smartWait(180);

		// Click on Price Set link
		driver.findElement(By.xpath(actions.getLocator("RFMPriceSets.PriceSet1"))).sendKeys(Keys.ENTER);
		Thread.sleep(5000);
		actions.waitForPageToLoad(120);
		mcd.SwitchToWindow("#Title");
		FDate = driver.findElements(By.xpath(actions.getLocator("PriceSets.SBFutureSetting")));

		// Click on first future Setting
		FDate.get(1).click();
		actions.smartWait(180);
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		// Chnging date
		List<WebElement> ChangdFDate = driver.findElements(By.xpath(actions.getLocator("PriceSets.SBFutureSetting")));
		Boolean blnRes = false;
		int reqDateIndex = 0;
		if (ChangdFDate.get(1).getText().trim().equals(ChngdDate.trim())) {

			actions.reportCreatePASS("Changed Date is displayed under Future Price Changes area.",
					"Changed Date is displayed under Future Price Changes area.",
					"Changed Date is displayed under Future Price Changes area.", "PASS");
			blnRes = true;

		} else {

			blnRes = false;

			actions.reportCreateFAIL("Previous Future Setting date is still displayed under Future Price Changes area",
					"Previous Future Setting date is still displayed under Future Price Changes area",
					"Previous Future Setting date is still displayed under Future Price Changes area", "FAIL");
		}

		return strPriceSetName;

	}

	public void RFM_PRC_ChangeDate_TwoExistingFutureSetting(String strPriceSetName, String strMessage1,
			String strMessage2, String strMessage3) throws Exception {

		// Selecting existing prices set name
		// Thread.sleep(2000);
		actions.smartWait(180);
		actions.WaitForElementPresent("RFMPriceSets.MainSearchbox", 180);
		// Type price set name & Click Search
		// Thread.sleep(2000);
		actions.smartWait(180);
		actions.setValue("RFMPriceSets.MainSearchbox", strPriceSetName);
		// Thread.sleep(2000);
		actions.keyboardEnter("RFMPriceSets.MainSearch");
		// Thread.sleep(3000);
		actions.smartWait(180);

		// Click on Price Set link and verify future setting
		driver.findElement(By.xpath(actions.getLocator("RFMPriceSets.PriceSet1"))).sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		mcd.SwitchToWindow("#Title");
		List<WebElement> FutureDates = driver.findElements(By.xpath(actions.getLocator("PriceSets.SBFutureSetting")));

		// Get 2nd Future date details that will replace 1st Future Date setting
		WebElement Date2 = FutureDates.get(2);
		String Date2_Value = Date2.getText();
		String Date2_Dt = null, Date2_Mnth = null, Date2_Yr = null;
		if (mcd.GetGlobalData("Instance").toLowerCase().contains("ap")) {
			Date2_Dt = Date2_Value.split("/")[0].trim();
			Date2_Mnth = Date2_Value.split("/")[1].trim();
			Date2_Yr = Date2_Value.split("/")[2].trim();

		} else if (mcd.GetGlobalData("Instance").toLowerCase().contains("us")) {
			Date2_Dt = Date2_Value.split(" ")[1].trim().replace(",", "").trim();
			Date2_Mnth = Date2_Value.split(" ")[0].trim();
			Date2_Yr = Date2_Value.split(" ")[2].trim();

		} else if (mcd.GetGlobalData("Instance").toLowerCase().contains("eu")) {
			Date2_Dt = Date2_Value.split(" ")[1].trim().replace(",", "").trim();
			Date2_Mnth = Date2_Value.split(" ")[0].trim();
			Date2_Yr = Date2_Value.split(" ")[2].trim();

		}

		if ((mcd.GetGlobalData("Instance").toLowerCase().contains("us"))
				| (mcd.GetGlobalData("Instance").toLowerCase().contains("eu"))) {
			if (Date2_Mnth.equalsIgnoreCase("jan")) {
				Date2_Mnth = "01";
			} else if (Date2_Mnth.equalsIgnoreCase("feb")) {
				Date2_Mnth = "02";
			} else if (Date2_Mnth.equalsIgnoreCase("mar")) {
				Date2_Mnth = "03";
			} else if (Date2_Mnth.equalsIgnoreCase("apr")) {
				Date2_Mnth = "04";
			} else if (Date2_Mnth.equalsIgnoreCase("may")) {
				Date2_Mnth = "05";
			} else if (Date2_Mnth.equalsIgnoreCase("jun")) {
				Date2_Mnth = "06";
			} else if (Date2_Mnth.equalsIgnoreCase("jul")) {
				Date2_Mnth = "07";
			} else if (Date2_Mnth.equalsIgnoreCase("aug")) {
				Date2_Mnth = "08";
			} else if (Date2_Mnth.equalsIgnoreCase("sep")) {
				Date2_Mnth = "09";
			} else if (Date2_Mnth.equalsIgnoreCase("oct")) {
				Date2_Mnth = "10";
			} else if (Date2_Mnth.equalsIgnoreCase("nov")) {
				Date2_Mnth = "11";
			} else if (Date2_Mnth.equalsIgnoreCase("dec")) {
				Date2_Mnth = "12";
			}
		}
		Date2.click();
		Thread.sleep(2000);
		actions.smartWait(180);
		actions.waitForPageToLoad(120);

		// Store the data for further use.
		List<WebElement> Menu_Items = driver.findElements(By.xpath(actions.getLocator("ManagePS.ListofAddedMI")));
		String[] Items = new String[Menu_Items.size()];
		String[] Costs = new String[Menu_Items.size()];

		for (int k = 0; k < Menu_Items.size(); k++) {
			Items[k] = Menu_Items.get(k).getText().split("-")[1].trim();

			Costs[k] = driver.findElement(By.xpath(actions.getLocator("PriceSets.STMenuItemPrice")))
					.getAttribute("value");

		}

		/** Select Menu Option */
		System.out.println("> Navigate to :: " + strNavigateTo);
		actions.select_menu("RFMHome.Pricing", strNavigateTo);
		Thread.sleep(3000);
		actions.waitForPageToLoad(120);
		mcd.SwitchToWindow("#Title");

		// Type price set name & Click Search
		actions.setValue("RFMPriceSets.MainSearchbox", strPriceSetName);
		actions.keyboardEnter("RFMPriceSets.MainSearch");
		actions.smartWait(180);

		// Click on Price Set link
		driver.findElement(By.xpath(actions.getLocator("RFMPriceSets.PriceSet1"))).sendKeys(Keys.ENTER);
		Thread.sleep(3000);
		mcd.SwitchToWindow("#Title");
		FutureDates = driver.findElements(By.xpath(actions.getLocator("PriceSets.SBFutureSetting")));

		// Get 1st Future Date Details
		WebElement Date1 = FutureDates.get(1);
		String Date1_Value = Date1.getText();

		String Date1_Dt = null, Date1_Mnth = null, Date1_Yr = null;
		if (mcd.GetGlobalData("Instance").toLowerCase().contains("ap")) {
			Date1_Dt = Date1_Value.split("/")[0].trim();
			Date1_Mnth = Date1_Value.split("/")[1].trim();
			Date1_Yr = Date1_Value.split("/")[2].trim();

		} else if (mcd.GetGlobalData("Instance").toLowerCase().contains("us")) {
			Date1_Dt = Date1_Value.split(" ")[1].trim().replace(",", "").trim();
			Date1_Mnth = Date1_Value.split(" ")[0].trim();
			Date1_Yr = Date1_Value.split(" ")[2].trim();

		} else if (mcd.GetGlobalData("Instance").toLowerCase().contains("eu")) {
			Date1_Dt = Date1_Value.split(" ")[1].trim().replace(",", "").trim();
			Date1_Mnth = Date1_Value.split(" ")[0].trim();
			Date1_Yr = Date1_Value.split(" ")[2].trim();

		}
		if ((mcd.GetGlobalData("Instance").toLowerCase().contains("us"))
				| (mcd.GetGlobalData("Instance").toLowerCase().contains("eu"))) {
			if (Date1_Mnth.equalsIgnoreCase("jan")) {
				Date1_Mnth = "01";
			} else if (Date1_Mnth.equalsIgnoreCase("feb")) {
				Date1_Mnth = "02";
			} else if (Date1_Mnth.equalsIgnoreCase("mar")) {
				Date1_Mnth = "03";
			} else if (Date1_Mnth.equalsIgnoreCase("apr")) {
				Date1_Mnth = "04";
			} else if (Date1_Mnth.equalsIgnoreCase("may")) {
				Date1_Mnth = "05";
			} else if (Date1_Mnth.equalsIgnoreCase("jun")) {
				Date1_Mnth = "06";
			} else if (Date1_Mnth.equalsIgnoreCase("jul")) {
				Date1_Mnth = "07";
			} else if (Date1_Mnth.equalsIgnoreCase("aug")) {
				Date1_Mnth = "08";
			} else if (Date1_Mnth.equalsIgnoreCase("sep")) {
				Date1_Mnth = "09";
			} else if (Date1_Mnth.equalsIgnoreCase("oct")) {
				Date1_Mnth = "10";
			} else if (Date1_Mnth.equalsIgnoreCase("nov")) {
				Date1_Mnth = "11";
			} else if (Date1_Mnth.equalsIgnoreCase("dec")) {
				Date1_Mnth = "12";
			}
		}
		Date1.click();
		actions.smartWait(180);
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		// To select Date2, get the difference between the 2 dates :
		int YrDiff = Integer.parseInt(Date2_Yr) - Integer.parseInt(Date1_Yr);
		System.out.println(YrDiff);
		int monthDiff = 0;
		if (YrDiff == 0) {
			monthDiff = Integer.parseInt(Date2_Mnth) - Integer.parseInt(Date1_Mnth);
			System.out.println(monthDiff);
		} else {
			if (Integer.parseInt(Date2_Mnth) > Integer.parseInt(Date1_Mnth)) {
				monthDiff = Integer.parseInt(Date2_Mnth) - Integer.parseInt(Date1_Mnth);
			} else {
				monthDiff = Integer.parseInt(Date1_Mnth) - Integer.parseInt(Date2_Mnth);
			}
			monthDiff = monthDiff + (YrDiff * 12);
			System.out.println(monthDiff);
		}

		// Click on Change Button & select OK
		actions.click("ManagePS.ChngeDateBtn");
		Boolean VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strMessage1, true,
				AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg = true) {

			actions.reportCreatePASS("Warning msg on clicking Change Date button & Clicked OK",
					"Warning msg on clicking Change Date button & Clicked OK",
					"Warning msg on clicking Change Date button & Clicked OK", "PASS");
		} else {

			actions.reportCreateFAIL("Warning msg on clicking Change Date button  & Clicked OK",
					"Warning msg on clicking Change Date button  & Clicked OK",
					"Warning msg on clicking Change Date button  & Clicked OK", "FAIL");
		}

		// Selecting date in apply change widow
		mcd.SwitchToWindow("Apply Changes Details");
		Thread.sleep(2000);
		System.out.println(driver.getTitle());
		actions.click("ManagePS.ChangeDtCalender");

		if (monthDiff == 0) {
			actions.click("ManagePS.ChangeDtCalender");
			mcd.select_date(Date2_Dt, "current");
			Thread.sleep(1000);
		} else {

			for (int m = 1; m <= monthDiff; m++) {
				actions.click("ManagePS.ChangeDtCalender");
				mcd.select_date(Date2_Dt, "next");
				Thread.sleep(1000);
			}
		}
		String FinalDate = driver.findElement(By.xpath(actions.getLocator("ManagePS.ChngDateText")))
				.getAttribute("value");

		actions.click("ManagePS.ChangeDtSave");
		Thread.sleep(3000);
		actions.waitForPageToLoad(120);

		// Verify save changes message on screen
		mcd.SwitchToWindow("Manage Price Sets");
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);
		actions.verifyTextPresence(strMessage3, false);
		Thread.sleep(3000);

		/*
		 * Actions builder = new Actions(driver); builder.moveByOffset(0,
		 * 500).click().perform();
		 * 
		 * // Selecting price set actions.clear("RFMPriceSets.MainSearchbox");
		 * Thread.sleep(1000); actions.setValue("RFMPriceSets.MainSearchbox",
		 * strPriceSetName); actions.keyboardEnter("RFMPriceSets.MainSearch");
		 * actions.smartWait(180);
		 * 
		 * // Click on Price Set link
		 * driver.findElement(By.xpath(actions.getLocator(
		 * "RFMPriceSets.PriceSet1"))).click(); Thread.sleep(2000);
		 * actions.waitForPageToLoad(120); mcd.SwitchToWindow("#Title");
		 * 
		 * //Verifying data in future price changes area List<WebElement>
		 * ChangdFDate = driver.findElements(By.xpath(actions.getLocator(
		 * "PriceSets.SBFutureSetting"))); Boolean blnRes = false;
		 * 
		 * if (ChangdFDate.size() == FutureDates.size() - 1) {
		 * 
		 * int f = 1; if
		 * (ChangdFDate.get(f).getText().trim().equals(Date2_Value.trim())) {
		 * 
		 * actions.reportCreatePASS(
		 * "Changed Date is displayed under Future Price Changes area.",
		 * "Changed Date is displayed under Future Price Changes area.",
		 * "Changed Date is displayed under Future Price Changes area.",
		 * "PASS"); blnRes = true; } else if
		 * (ChangdFDate.get(f).getText().trim().equals(Date1_Value.trim())) {
		 * blnRes = false;
		 * 
		 * actions.reportCreateFAIL(
		 * "Previous Future Setting date is still displayed under Future Price Changes area."
		 * ,
		 * "Previous Future Setting date is still displayed under Future Price Changes area."
		 * ,
		 * "Previous Future Setting date is still displayed under Future Price Changes area."
		 * , "FAIL"); }
		 * 
		 * 
		 * } else {
		 * 
		 * actions.reportCreateFAIL( "Number of Future Settings changed from " +
		 * FutureDates.size() + " to " + ChangdFDate.size(),
		 * "Number of Future Settings changed from " + FutureDates.size() +
		 * " to " + ChangdFDate.size(),
		 * "Number of Future Settings changed from " + FutureDates.size() +
		 * " to " + ChangdFDate.size(), "FAIL"); }
		 */

		/*
		 * // Store the data for further use. List<WebElement> ChangedMItems =
		 * driver.findElements(By.xpath(actions.getLocator(
		 * "ManagePS.ListofAddedMI"))); String[] NewItems = new
		 * String[ChangedMItems.size()]; String[] NewCosts = new
		 * String[ChangedMItems.size()];
		 * 
		 * int k = 0; NewItems[k] =
		 * ChangedMItems.get(k).getText().split("-")[1].trim(); NewCosts[k] =
		 * driver.findElement(By.xpath(actions.getLocator(
		 * "PriceSets.STMenuItemPrice"))) .getAttribute("value");
		 * 
		 * if ((Items[0].contains(NewItems[0])) &&
		 * (NewCosts[0].equals(Costs[0]))) { blnRes = true; } else { blnRes =
		 * false; } if (blnRes) { actions.reportCreatePASS(
		 * "New Future Date settings are correctly displayed",
		 * "New Future Date settings are correctly displayed",
		 * "New Future Date settings are correctly displayed", "PASS"); } else {
		 * actions.reportCreateFAIL(
		 * "New Future Date settings are not correctly displayed.",
		 * "New Future Date settings are not correctly displayed.",
		 * "New Future Date settings are not correctly displayed.", "FAIL"); }
		 */
		
	}
	public void verifyTablecolumnsPresent(String tableLocator, String colName) {

        boolean iscolPresent = mcd.RFM_VerifyTableColumns(tableLocator, colName);

        if (iscolPresent) {
               actions.reportCreatePASS("Verify " + colName + " Column is present in table",
                            colName + " Column should be present in table", colName + " Column is present in table", "Pass");
        } else {
               actions.reportCreateFAIL("Verify " + colName + " Column is present in table",
                            colName + " Column should be present in table", colName + " Column is NOT present in table",
                            "Fail");
        }
 }
}
