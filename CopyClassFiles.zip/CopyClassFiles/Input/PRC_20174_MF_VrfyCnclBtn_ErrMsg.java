package xtam.test;

import java.util.Map;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class PRC_20174_MF_VrfyCnclBtn_ErrMsg {

	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String Value;
	private String number;
	// TODO: Declare test-data variables for other data-parameters
	private String strWM1;
	private String Invalid, strNavigateToAdmin, strApplicationDate;

	public PRC_20174_MF_VrfyCnclBtn_ErrMsg(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");

		// TODO: GetTestData for other data-parameters
		strWM1 = mcd.GetTestData("DT_WARN");
		Invalid = mcd.GetTestData("InvalidVal");
		strNavigateToAdmin = mcd.GetTestData("DT_NAVIGATE_TO_Admin");
	}

	@Test
	public void PRC_20174_MF_VrfyCnclBtn_ErrMsg() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			/** Get Test case Description */
			actions.setTestcaseDescription(
					"Verify Cancel button functionality and error messages while creating new fee.");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateToAdmin);
			actions.select_menu("RFMHome.Navigation", strNavigateToAdmin);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();
			// ------------------------------------------------------------------------
			// Automating the Pre - Req
			rfm.RFM_Admin_Update_PricingTags("false", "Restrict price type attribute from expanding");
			rfm.RFM_Admin_Update_PricingTags("false", "Display price type attribute as expanded by default");

			// Navigating to Master Fee
			actions.waitForPageToLoad(120);
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			actions.waitForPageToLoad(180);
			mcd.SwitchToWindow("#Title");

			String[] warn = strWM1.split("#");

			// Click on Search Button & GetText Fee ID,Fee Name
			actions.click("PriceSet.SearchBtn");
			actions.smartWait(20);
			WebElement element = mcd.GetTableCellElement("ScreenSet.Table", 1, "Fee ID", " ");
			number = element.getText();
			WebElement element1 = mcd.GetTableCellElement("ScreenSet.Table", 1, "Fee Name", " ");
			Value = element1.getText();

			// Click on New Fee Button & Click on Cancel Button
			actions.WaitForElementPresent("MasterFee.NewFeeBtn");
			actions.keyboardEnter("MasterFee.NewFeeBtn");
			actions.smartWait(180);
			
			//Verify Status,TaxEntry,TaxCode&Tax Rule DropDown are Present
			if (actions.isElementEnabled("FeeSet.Status")) {
				actions.reportCreatePASS("Verify Status DropDown ",
						"Status DropDown should be Present", "Status DropDown is Present",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify Status DropDown ",
						"Status DropDown should be Present", "Status DropDown is not Present",
						"FAIL");
			}
			if (actions.isElementEnabled("FeeSet.TaxCode")) {
				actions.reportCreatePASS("Verify TaxCode DropDown ",
						"TaxCode DropDown should be Present", "TaxCode DropDown is Present",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify TaxCode DropDown ",
						"TaxCode DropDown should be Present", "TaxCode DropDown is not Present",
						"FAIL");
			}
			if (actions.isElementEnabled("FeeSet.TaxRule")) {
				actions.reportCreatePASS("Verify TaxRule DropDown ",
						"TaxRule DropDown should be Present", "TaxRule DropDown is Present",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify TaxRule DropDown ",
						"TaxRule DropDown should be Present", "TaxRule DropDown is not Present",
						"FAIL");
			}
			if (actions.isElementEnabled("FeeSet.AllTaxEntry")) {
				actions.reportCreatePASS("Verify TaxEntry DropDown ",
						"TaxEntry DropDown should be Present", "TaxEntry DropDown is Present",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify TaxEntry DropDown ",
						"TaxEntry DropDown should be Present", "TaxEntry DropDown is not Present",
						"FAIL");
			}
			
			actions.click("RFM.CancelBtn");
			actions.smartWait(180);

			// Click on New Fee Button & Click on Save Button,Verify Alert
			// Message
			actions.click("MasterFee.NewFeeBtn");
			actions.keyboardEnter("ApplyChangesDetails.Save");
			boolean warn0 = mcd.VerifyAlertMessageDisplayed("Warning", warn[0], true, AlertPopupButton.OK_BUTTON);
			if (warn0) {
				actions.reportCreatePASS("Verify 'Please enter Fee ID' Alert",
						"'Please enter Fee ID' Alert sholud be displayed.", "'Please enter Fee ID' Alert is displayed.",
						"Pass");
			} else {
				actions.reportCreateFAIL("Verify 'Please enter Fee ID' Alert",
						"'Please enter Fee ID' Alert sholud be displayed.",
						"'Please enter Fee ID' Alert is not displayed.", "Fail");
			}

			// Verify User should not be able to enter more than 2 digits in Fee
			// Id field
			actions.WaitForElementPresent("MasterFee.FeeId");
			int rnd = mcd.fn_GetRndNumInRange(100, 200);
			actions.setValue("MasterFee.FeeId", rnd);
			String strValue = driver.findElement(By.xpath(actions.getLocator("MasterFee.FeeId")))
					.getAttribute("maxlength");
			if (strValue.equals("2")) {
				actions.reportCreatePASS("Verify Fee ID", "Fee ID should be accept only 2 Intergers",
						"Fee ID is accept only 2 Intergers", "Pass");
			} else {
				actions.reportCreateFAIL("Verify Fee ID", "Fee ID should be accept only 2 Intergers",
						"Fee ID is not accept only 2 Intergers", "Fail");
			}

			// Enter already existing Fee ID & Click on Save Button,Verify Alert
			// Message
			actions.WaitForElementPresent("MasterFee.FeeId");
			actions.clear("MasterFee.FeeId");
			actions.setValue("MasterFee.FeeId", number);
			actions.keyboardEnter("ApplyChangesDetails.Save");
			boolean warn1 = mcd.VerifyAlertMessageDisplayed("Warning", warn[1], true, AlertPopupButton.OK_BUTTON);
			if (warn1) {
				actions.reportCreatePASS("Verify 'Please enter Fee Name' Alert with 'OK' button",
						"'Please enter Fee Name' Alert with 'OK' button should be displayed.",
						"'Please enter Fee Name' Alert with 'OK' button is displayed.", "PASS");
			} else {
				actions.reportCreateFAIL("Verify 'Please enter Fee Name' Alert with 'OK' button",
						"'Please enter Fee Name' Alert with 'OK' button should be displayed.",
						"'Please enter Fee Name' Alert with 'OK' button is not displayed.", "FAIL");
			}

			// Enter string more than 60 characters in Fee Name TextBox
			String strVal2;
			strVal2 = mcd.generateString('c', 61);
			System.out.println(strVal2.length());
			actions.setValue("MasterFee.FeeName", strVal2);
			String charc = driver.findElement(By.xpath(actions.getLocator("MasterFee.FeeName"))).getAttribute("value");
			System.out.println(charc.length());
			if (charc.length() >= 60) {
				actions.reportCreatePASS("verify the whether Fee name text box accepected 60 Characters",
						" Fee name name text box should be accepected 60 Characters",
						" Fee name name text box should not  be accepected more than 60 Characters", "PASS");
			} else {
				actions.reportCreateFAIL("verify the whether  Fee name text box accepected 60 characters",
						"Fee name text box should be accepected 60 Characters ",
						" Fee name text box should be accepected more than 60 Characters", "FAIL");
			}

			// Enter already existing Fee Name & Click on Save Button,Verify
			// Alert Message
			actions.WaitForElementPresent("MasterFee.FeeName");
			actions.clear("MasterFee.FeeName");
			actions.setValue("MasterFee.FeeName", Value);
			actions.keyboardEnter("ApplyChangesDetails.Save");
			boolean warn2 = mcd.VerifyAlertMessageDisplayed("Warning", warn[2], true, AlertPopupButton.OK_BUTTON);
			if (warn2) {
				actions.reportCreatePASS("Verify 'Please select Fee Type' Alert with 'OK' button",
						"'Please select Fee Type' Alert with 'OK' button should be displayed.",
						"'Please select Fee Type' Alert with 'OK' button is displayed.", "PASS");
			} else {
				actions.reportCreateFAIL("Verify 'Please select Fee Type' Alert with 'OK' button",
						"'Please select Fee Type' Alert with 'OK' button should be displayed.",
						"'Please select Fee Type' Alert with 'OK' button is not displayed.", "FAIL");
			}

			// Select value 'Amount' from Fee Type DropDown& Click on Save
			// Button,Verify Alert Message
			actions.WaitForElementPresent("MasterFee.FeeType");
			actions.setValue("MasterFee.FeeType", "Amount");
			actions.keyboardEnter("ApplyChangesDetails.Save");
			boolean warn3 = mcd.VerifyAlertMessageDisplayed("Warning", warn[3], true, AlertPopupButton.OK_BUTTON);
			if (warn3) {
				actions.reportCreatePASS("Verify 'Please enter Value' Alert with 'OK' button",
						"'Please enter Value' Alert with 'OK' button should be displayed.",
						"'Please enter Value' Alert with 'OK' button is displayed.", "PASS");
			} else {
				actions.reportCreateFAIL("Verify 'Please enter Value' Alert with 'OK' button",
						"'Please enter Value' Alert with 'OK' button should be displayed.",
						"'Please enter Value' Alert with 'OK' button is not displayed.", "FAIL");
			}

			// Enter Invalid value in Value field & Click on Save Button,Verify
			// Alert Message
			actions.WaitForElementPresent("FeeSet.AllPrc");
			actions.setValue("FeeSet.AllPrc", Invalid);
			actions.keyboardEnter("ApplyChangesDetails.Save");
			boolean warn4 = mcd.VerifyAlertMessageDisplayed("Warning", warn[4], true, AlertPopupButton.OK_BUTTON);
			if (warn4) {
				actions.reportCreatePASS("Verify 'Please enter correct value' Alert with 'OK' button",
						"'Please enter correct value' Alert with 'OK' button should be displayed.",
						"'Please enter correct value' Alert with 'OK' button is displayed.", "PASS");
			} else {
				actions.reportCreateFAIL("Verify 'Please enter correct value' Alert with 'OK' button",
						"'Please enter correct value' Alert with 'OK' button should be displayed.",
						"'Please enter correct value' Alert with 'OK' button is not displayed.", "FAIL");
			}

			// Select value 'Rate' from Fee Type DropDown& Click on Save
			// Button,Verify Alert Message
			actions.WaitForElementPresent("MasterFee.FeeType");
			actions.setValue("MasterFee.FeeType", "Rate");
			actions.keyboardEnter("ApplyChangesDetails.Save");
			boolean warn5 = mcd.VerifyAlertMessageDisplayed("Warning", warn[5], true, AlertPopupButton.OK_BUTTON);
			if (warn5) {
				actions.reportCreatePASS("Verify 'Please enter value from 0 to 100' Alert with 'OK' button",
						"'Please enter value from 0 to 100' Alert with 'OK' button should be displayed.",
						"'Please enter value from 0 to 100' Alert with 'OK' button is displayed.", "PASS");
			} else {
				actions.reportCreateFAIL("Verify 'Please enter value from 0 to 100' Alert with 'OK' button",
						"'Please enter value from 0 to 100' Alert with 'OK' button should be displayed.",
						"'Please enter value from 0 to 100' Alert with 'OK' button is not displayed.", "FAIL");
			}

			// Enter valid value in Value field & Click on Save Button
			actions.WaitForElementPresent("FeeSet.AllPrc");
			actions.clear("FeeSet.AllPrc");
			actions.setValue("FeeSet.AllPrc", number);
			actions.keyboardEnter("ApplyChangesDetails.Save");
			actions.smartWait(180);

			// Entering unique Fee ID
			actions.WaitForElementPresent("MasterFee.FeeId");
			boolean flag=false;
			do {
			int rnd2 = mcd.fn_GetRndNumInRange(20, 90);
			actions.clear("MasterFee.FeeId");
			actions.setValue("MasterFee.FeeId", rnd2);

			// Entering unique Fee Name & Click on Cancel,Verify Alert Message
			actions.clear("MasterFee.FeeName");
			String strNewFeeName = mcd.fn_GetRndName("ATS");
			actions.setValue("MasterFee.FeeName", strNewFeeName);
			actions.click("RFM.CancelBtn");
			mcd.VerifyAlertMessageDisplayed("Unsaved data will be lost. Are you sure you want to proceed?", warn[6],
					true, AlertPopupButton.CANCEL_BUTTON);
			actions.smartWait(180);
			// Click on save button&Verify Alert Message
			actions.click("ApplyChangesDetails.Save");
			actions.smartWait(180);
			try
			{
			flag = driver.findElement(By.xpath("//*[@id='addEditFeeForm_errorCode']/li/span")).isDisplayed();
			}
			catch(Exception e)
			{
				flag=false;
			}
			
			} while (flag);
			
			actions.verifyTextPresence(warn[7], true);
		
			// ------------------------------------------------------------------------
			// Actions specific to test-flow
			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			// Reporter.log("Test Failed :: " + e.getCause() + " - " +
			// e.getMessage());
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

}
