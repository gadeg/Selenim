package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class PRC_20227_FSUpdtCurrFutr {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private String strSuccessMsg, strRegion, strExistingSetMsg;
	private String strUpdateMsg, strFeeMsg, strCancelMsg;
	private String[] strFields;

	public PRC_20227_FSUpdtCurrFutr(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters

		strSuccessMsg = mcd.GetTestData("SUCCESS_MSG");
		strUpdateMsg = mcd.GetTestData("UPDATE_MSG");
		strRegion = mcd.GetTestData("DT_Region");
		strExistingSetMsg = mcd.GetTestData("DT_ExistingMsg");
		strFeeMsg = mcd.GetTestData("DT_FeeMsg");
		strCancelMsg = mcd.GetTestData("DT_CancelMsg");
	}

	@Test
	public void test_PRC_20227_FSUpdtCurrFutr() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription(
					"Verify the Current Settings and Future Settings pop-up for Active Fee Sets.");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			// PRICING > Fee > Fee Sets
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Actions specific to test-flow
			String strNamePrefix = mcd.fn_GetRndName("Auto");
			String strStatus = "Active";
			String strCopyFlag = "No";
			int iNumOfFee = 0;

			// Create New Fee Set
			String strFSNoCpy = PriceActions.RFM_PRC_CreateNewFeeSet(strNamePrefix, strMarket, strSuccessMsg, strStatus,
					strCopyFlag, strRegion, strFeeMsg, strCancelMsg, iNumOfFee, strExistingSetMsg);

			// Select any Active fee set & Update the Fee Set Name
			actions.setValue("ParameterSet.Name", strFSNoCpy);
			actions.click("CopySettingfrmMI.srchbtn");
			actions.smartWait(120);
			WebElement eleFeeSetName = mcd.GetTableCellElement("RFM.WebTable", 1, "Name", "a");
			actions.click(eleFeeSetName);
			actions.smartWait(20);
			actions.WaitForElementPresent("FeeSet.ExistingFeeSetName");
			actions.clear("FeeSet.ExistingFeeSetName");
			String strFeeName = mcd.fn_GetRndName("Auto");
			actions.setValue("FeeSet.ExistingFeeSetName", strFeeName);

			// Click on Apply button & Select the Now radio button and clicks on
			// Save button.
			actions.keyboardEnter("Lookups.saveButton");
			try {
				mcd.SwitchToWindow("Apply Changes Details");
				actions.click("ApplyChangesDetails.RPSaveButton");

			} catch (Exception e) {
				System.out.println("Apply Changes Details is not displayed");
			}

			try {
				driver.switchTo().window("");
			} catch (Exception e) {
				System.out.println("Alert is not displayed");
			}
			try {

				actions.acceptAlert();

			} catch (Exception e) {
				System.out.println("Alert is not displayed");
			}

			Thread.sleep(50000);
			String strSucess = driver.findElement(By.xpath(actions.getLocator("SubstitutionGroups.InfoMessage")))
					.getText();
			if (strSucess.equalsIgnoreCase("Your changes have been saved.")) {
				actions.reportCreatePASS("Verify Suceess Message is Dispalyed",
						"Suceess Message Should be Dispalyed As Expected", "Suceess Message is Dispalyed As Expected",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify Suceess Message is Dispalyed",
						"Suceess Message Should be Dispalyed As Expected",
						"Suceess Message is not Dispalyed As Expected", "FAIL");
			}

			// Verify the Updated Fee Set Name.
			String ExistingFeeSet = driver.findElement(By.xpath(actions.getLocator("FeeSet.ExistingFeeSetName")))
					.getAttribute("value");
			if (ExistingFeeSet.equalsIgnoreCase(strFeeName)) {
				actions.reportCreatePASS("Verify the Fee Set Name", "The Fee Set Name should be updated",
						"The Fee Set Name is updated", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the Fee Set Name", "The Fee Set Name should be updated",
						"The Fee Set Name is not updated", "FAIL");
			}

			actions.click("WorkflowsUpdateWorkflow.cancel");
			actions.smartWait(20);

			// Again select any Active fee set having no future settings &
			// Update the Fee Set Name
			actions.clear("ParameterSet.Name");
			actions.setValue("ParameterSet.Name", strFeeName);
			actions.click("CopySettingfrmMI.srchbtn");
			actions.smartWait(120);
			WebElement eleFeeSetName1 = mcd.GetTableCellElement("RFM.WebTable", 1, "Name", "a");
			actions.click(eleFeeSetName1);
			actions.smartWait(20);
			actions.WaitForElementPresent("FeeSet.ExistingFeeSetName");
			actions.clear("FeeSet.ExistingFeeSetName");
			String strFeeName1 = mcd.fn_GetRndName("Auto");
			actions.setValue("FeeSet.ExistingFeeSetName", strFeeName1);

			// Click on Apply button & Select the Future Date radio button and
			// selects a future date,Click on Save button
			actions.keyboardEnter("Lookups.saveButton");
			try {
				mcd.SwitchToWindow("Apply Changes Details");
				actions.click("ApplyChangesDetails.radiobtnFutureDate");
				actions.click("ApplyChangesDetails.FutureDatecalender");
				mcd.Get_future_date(1, "Close", strApplicationDate);
				actions.click("ApplyChangesDetails.RPSaveButton");
				// mcd.SwitchToWindow("@Fee Sets");
			} catch (Exception e) {
				System.out.println("Apply Changes Details is not displayed");
			}
			try {
				driver.switchTo().window("");
			} catch (Exception e) {
				System.out.println("Alert is not displayed");
			}
			try {

				actions.acceptAlert();

			} catch (Exception e) {
				System.out.println("Alert is not displayed");
			}
			Thread.sleep(20000);
			String strSucess1 = driver.findElement(By.xpath(actions.getLocator("SubstitutionGroups.InfoMessage")))
					.getText();
			if (strSucess1.equalsIgnoreCase("Your changes have been saved.")) {
				actions.reportCreatePASS("Verify Suceess Message is Dispalyed",
						"Suceess Message Should be Dispalyed As Expected", "Suceess Message is Dispalyed As Expected",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify Suceess Message is Dispalyed",
						"Suceess Message Should be Dispalyed As Expected",
						"Suceess Message is not Dispalyed As Expected", "FAIL");
			}

			// Verify the Updated Fee Set Name.
			String ExistingFeeSet1 = driver.findElement(By.xpath(actions.getLocator("FeeSet.ExistingFeeSetName")))
					.getAttribute("value");
			if (ExistingFeeSet1.equalsIgnoreCase(strFeeName1)) {
				actions.reportCreatePASS("Verify the Fee Set Name", "The Fee Set Name should be updated",
						"The Fee Set Name is updated", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the Fee Set Name", "The Fee Set Name should be updated",
						"The Fee Set Name is not updated", "FAIL");
			}
			actions.click("WorkflowsUpdateWorkflow.cancel");
			actions.smartWait(20);

			// Again select any Active fee set having future settings & Update
			// the Fee Set Name
			actions.clear("ParameterSet.Name");
			actions.setValue("ParameterSet.Name", strFeeName1);
			actions.click("CopySettingfrmMI.srchbtn");
			actions.smartWait(120);
			WebElement eleFeeSetName2 = mcd.GetTableCellElement("RFM.WebTable", 1, "Name", "a");
			actions.click(eleFeeSetName2);
			actions.smartWait(20);
			actions.WaitForElementPresent("FeeSet.ExistingFeeSetName");
			actions.clear("FeeSet.ExistingFeeSetName");
			String strFeeName2 = mcd.fn_GetRndName("Auto");
			actions.setValue("FeeSet.ExistingFeeSetName", strFeeName2);

			// Click on Apply button.
			actions.keyboardEnter("Lookups.saveButton");

			try {
				driver.switchTo().window("");
			} catch (Exception e) {
				System.out.println("Alert is not displayed");
			}
			try {

				actions.acceptAlert();

			} catch (Exception e) {
				System.out.println("Alert is not displayed");
			}
			Thread.sleep(20000);
			String strSucess2 = driver.findElement(By.xpath(actions.getLocator("SubstitutionGroups.InfoMessage")))
					.getText();
			if (strSucess2.equalsIgnoreCase("Your changes have been saved.")) {
				actions.reportCreatePASS("Verify Suceess Message is Dispalyed",
						"Suceess Message Should be Dispalyed As Expected", "Suceess Message is Dispalyed As Expected",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify Suceess Message is Dispalyed",
						"Suceess Message Should be Dispalyed As Expected",
						"Suceess Message is not Dispalyed As Expected", "FAIL");
			}

			// Verify Updated Fee Set Name
			String ExistingFeeSet2 = driver.findElement(By.xpath(actions.getLocator("FeeSet.ExistingFeeSetName")))
					.getAttribute("value");
			if (ExistingFeeSet2.equalsIgnoreCase(strFeeName2)) {
				actions.reportCreatePASS("Verify the Fee Set Name", "The Fee Set Name should be updated",
						"The Fee Set Name is updated", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the Fee Set Name", "The Fee Set Name should be updated",
						"The Fee Set Name is not updated", "FAIL");
			}

			actions.click("WorkflowsUpdateWorkflow.cancel");
			actions.smartWait(20);

			// Again select any Active Fee Set by clicking on the Future
			// Settings hyperlink & Update the Set Name
			actions.clear("ParameterSet.Name");
			actions.setValue("ParameterSet.Name", strFeeName2);
			actions.click("CopySettingfrmMI.srchbtn");
			actions.smartWait(120);
			WebElement eleFeeSetName3 = mcd.GetTableCellElement("RFM.WebTable", 1, "Future Settings", "a");
			actions.click(eleFeeSetName3);
			actions.smartWait(20);
			actions.WaitForElementPresent("FeeSet.ExistingFeeSetName");
			actions.clear("FeeSet.ExistingFeeSetName");
			String strFeeName3 = mcd.fn_GetRndName("Auto");
			actions.setValue("FeeSet.ExistingFeeSetName", strFeeName3);

			// Click on Apply button
			actions.keyboardEnter("Lookups.saveButton");

			try {
				driver.switchTo().window("");
			} catch (Exception e) {
				System.out.println("Alert is not displayed");
			}
			try {

				actions.acceptAlert();

			} catch (Exception e) {
				System.out.println("Alert is not displayed");
			}
			Thread.sleep(20000);
			String strSucess3 = driver.findElement(By.xpath(actions.getLocator("SubstitutionGroups.InfoMessage")))
					.getText();
			if (strSucess3.equalsIgnoreCase("Your changes have been saved.")) {
				actions.reportCreatePASS("Verify Suceess Message is Dispalyed",
						"Suceess Message Should be Dispalyed As Expected", "Suceess Message is Dispalyed As Expected",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify Suceess Message is Dispalyed",
						"Suceess Message Should be Dispalyed As Expected",
						"Suceess Message is not Dispalyed As Expected", "FAIL");
			}

			// Verify Updated Fee Set Name
			String ExistingFeeSet3 = driver.findElement(By.xpath(actions.getLocator("FeeSet.ExistingFeeSetName")))
					.getAttribute("value");
			if (ExistingFeeSet3.equalsIgnoreCase(strFeeName3)) {
				actions.reportCreatePASS("Verify the Fee Set Name", "The Fee Set Name should be updated",
						"The Fee Set Name is updated", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the Fee Set Name", "The Fee Set Name should be updated",
						"The Fee Set Name is not updated", "FAIL");
			}

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (

		Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}