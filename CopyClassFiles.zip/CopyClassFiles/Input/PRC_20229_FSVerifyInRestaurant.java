package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class PRC_20229_FSVerifyInRestaurant {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private String strSuccessMsg;
	private String strUpdateMsg;
	private String strNavigateToRestProf;
	private String strNodeNum;

	public PRC_20229_FSVerifyInRestaurant(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strSuccessMsg = mcd.GetTestData("SUCCESS_MSG");
		strUpdateMsg = mcd.GetTestData("UPDATE_MSG");
		strNavigateToRestProf = mcd.GetTestData("DT_NAVIGATE_TO_RP");
		strNodeNum = mcd.GetTestData("NODE_NUM");
	}

	@Test
	public void test_PRC_20229_FSVerifyInRestaurant() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription(
					"Verify the updated Fee Set Name is reflected in the Fee Set DDL at Restaurant profile : Operation Details Tab (updated Set is already assigned to the Restaurant)");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			// PRICING > Fee > Fee Sets
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------

			// Automating Pre_Req

			// Fee Set1 is attached to Restaurant 10 - McDonald's Test and the
			// Set Name is already updated.
			actions.click("CopySettingfrmMI.srchbtn");
			actions.smartWait(120);
			WebElement eleFeeSetName = mcd.GetTableCellElement("RFM.WebTable", 1, "Name", "a");
			actions.click(eleFeeSetName);
			actions.smartWait(20);
			actions.WaitForElementPresent("FeeSet.ExistingFeeSetName");
			actions.clear("FeeSet.ExistingFeeSetName");
			String strFeeName = mcd.fn_GetRndName("Auto");
			actions.setValue("FeeSet.ExistingFeeSetName", strFeeName);
			actions.keyboardEnter("Lookups.saveButton");
			try {
				mcd.SwitchToWindow("Apply Changes Details");
				actions.keyboardEnter("ApplyChangesDetails.RPSaveButton");
				mcd.SwitchToWindow("@Fee Sets");
			} catch (Exception e) {
				System.out.println("Apply Changes Details is not displayed");
			}
			try {
				if (mcd.VerifyAlertMessageDisplayed("Warning Message", strUpdateMsg, true,
						AlertPopupButton.OK_BUTTON)) {
					actions.reportCreatePASS("Verify Alert is Present or not", "Alert should be Present as Expected",
							"Alert is Present as Expected", "PASS");
				}
			} catch (Exception e) {
				System.out.println("Alert is not displayed");
			}

			actions.verifyTextPresence(strSuccessMsg, true);
			Thread.sleep(50000);
			// Assign to Restaurant

			// ADMIN > Restaurant Profile
			System.out.println("> Navigate to :: " + strNavigateToRestProf);
			actions.select_menu("RFMHome.Navigation", strNavigateToRestProf);
			Thread.sleep(5000);
			actions.waitForPageToLoad(120);

			// Select Rest and Assigned Update the Fee Set to Rest
			actions.setValue("RestaurantProfile.SearchTextBox", strNodeNum);
			actions.keyboardEnter("ManageOrderTotalDiscountSet.apply");
			actions.smartWait(20);
			WebElement ElementTaxTypNm1 = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1, "Number", "a");
			actions.click(ElementTaxTypNm1);
			actions.smartWait(100);
			actions.keyboardEnter("RestaurantProfile.OperationsDetails");
			actions.smartWait(100);
			Select strValue = new Select(driver.findElement(By.xpath(actions.getLocator("RestProfile.FeeSet"))));
			String values2 = strValue.getFirstSelectedOption().getText();
			if (values2.equalsIgnoreCase(strFeeName)) {
				actions.reportCreatePASS("Verify the updated Fee Set Name in the DDL",
						"Updated Fee Set Name should be Selected in the Fee Set DDL",
						"Updated Fee Set Name is Selected in the Fee Set DDL", "PASS");
			} else {
				actions.setValue("RestProfile.FeeSet", strFeeName);
				Thread.sleep(2000);
				actions.click("RestaurantProfile.ApplyButton");
				try {
					mcd.waitAndSwitch("Apply Changes Details");
					Thread.sleep(2000);
					actions.keyboardEnter("ApplyChangesDetails.RPSaveButton");
					mcd.waitAndSwitch("@Restaurant Profile");
				} catch (Exception e) {

					System.out.println("Apply Changes Details is not displayed");
				}
				try {
					mcd.VerifyAlertMessageDisplayed("Warning Message", strUpdateMsg, true, AlertPopupButton.OK_BUTTON);
				} catch (Exception e) {
					System.out.println("Warning Message is not displayed");
				}
				mcd.waitAndSwitch("Run Validation Report");
				actions.keyboardEnter("NewScript.CancleButton");
				mcd.waitAndSwitch("@Restaurant Profile");
			}
			Thread.sleep(50000);
			
			// ADMIN > Restaurant Profile
			System.out.println("> Navigate to :: " + strNavigateToRestProf);
			actions.select_menu("RFMHome.Navigation", strNavigateToRestProf);
			Thread.sleep(5000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			// User navigates to the Restaurant to which the updated Fee Set is
			// already attached
			actions.setValue("RestaurantProfile.SearchTextBox", strNodeNum);
			actions.keyboardEnter("ManageOrderTotalDiscountSet.apply");
			actions.smartWait(20);
			WebElement ElementTaxTypNm2 = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1, "Number", "a");
			actions.click(ElementTaxTypNm2);
			actions.smartWait(100);

			// User navigates to Operations Tab and verifies the value in Fee
			// Set field.
			actions.keyboardEnter("RestaurantProfile.OperationsDetails");
			actions.smartWait(100);
			Select strValue1 = new Select(driver.findElement(By.xpath(actions.getLocator("RestProfile.FeeSet"))));
			String values3 = strValue1.getFirstSelectedOption().getText();
			if (values3.equalsIgnoreCase(strFeeName)) {
				actions.reportCreatePASS("Verify the updated Fee Set Name in the DDL",
						"Updated Fee Set Name should be Present in the Fee Set DDL",
						"Updated Fee Set Name is Present in the Fee Set DDL", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the updated Fee Set Name in the DDL",
						"Updated Fee Set Name should be Present in the Fee Set DDL",
						"Updated Fee Set Name is not Present in the Fee Set DDL", "FAIL");
			}

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}