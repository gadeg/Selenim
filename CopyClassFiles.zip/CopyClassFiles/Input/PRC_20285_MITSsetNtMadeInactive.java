/**
 * 
 */
package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class PRC_20285_MITSsetNtMadeInactive {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;
	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo, strRest;
	// TODO: Declare test-data variables for other data-parameters
	private String strNavigateTo_RP, strNode, ErroMsg, Status, strNavigateTo_Report;
	private String strMITS, strMenuIteamTaxSetDropdownValue, strPopup, Err, ErrSplit[], strPopupSplit[],
			strNewMenuIteamTaxSetName, strMenuItemTaxSet, strRestaurentNo, strNavigateTo_SetAssig, strNavigateTo_View;
	private String strNavigateToST;

	public PRC_20285_MITSsetNtMadeInactive(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);
		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters
		strNavigateTo_RP = mcd.GetTestData("DT_NAVIGATE_TO_RP");
		strRest = mcd.GetTestData("DT_Rest");
		strPopup = mcd.GetTestData("DT_POPUP");
		strNavigateTo_Report = mcd.GetTestData("DT_NAVIGATE_TO_REPORT");
		strNavigateTo_View = mcd.GetTestData("DT_NAVIGATE_TO_VIEW");
		strNavigateTo_SetAssig = mcd.GetTestData("DT_NAVIGATE_TO_SETASSIG");
	}

	@Test
	public void test_PRC_20285_MITSsetNtMadeInactive() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription(
					"Verify updated Menu Item Tax Set Name reflected in Menu Item tax Set DDL at Restaurant profile: Op Details Tab & Op Details Tab of restaurants for which updated set is already assigned to it & is reflected in menu item tax report & set assignment report.");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			// PRICING > Taxes > Menu Item Tax Set
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.smartWait(20);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Actions specific to test-flow
			strPopupSplit = strPopup.split("#");
			

			// Automate Pre-Req

			// Update Menu Item Tax Set Name
			actions.keyboardEnter("RecipeReport.ViewFullListBtn");
			actions.smartWait(20);
			WebElement ElementTaxTypNm = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1, "Name", "a");
			actions.keyboardEnter(ElementTaxTypNm);
			try {
				mcd.SwitchToWindow("Apply Changes Details");
				actions.keyboardEnter("ApplyChangesDetails.RPSaveButton");
				mcd.SwitchToWindow("@Manage Menu Item Tax Set");
			} catch (Exception e) {
				System.out.println("Apply Changes Details is not displayed");
			}
			actions.smartWait(20);
			actions.clear("MenuItemTaxSet.MITSName");
			String ele1 = mcd.fn_GetRndName("AMITS");
			actions.setValue("MenuItemTaxSet.MITSName", ele1);
			actions.keyboardEnter("PromotionMgmt.ApplyButton");
			try {
				if (mcd.VerifyAlertMessageDisplayed("Warning Message", strPopupSplit[1], true,
						AlertPopupButton.OK_BUTTON)) {
					actions.reportCreatePASS("Verify Alert is Present or not", "Alert should be Present as Expected",
							"Alert is Present as Expected", "PASS");
				}
			} catch (Exception e) {
				System.out.println("Alert is not displayed");
			}
			actions.smartWait(20);
			actions.verifyTextPresence("Your changes have been saved.", true);
			actions.keyboardEnter("NewScript.CancleButton");
			actions.smartWait(20);

			// ADMIN > Restaurant Profile
			System.out.println("> Navigate to :: " + strNavigateTo_RP);
			actions.select_menu("RFMHome.Navigation", strNavigateTo_RP);
			Thread.sleep(8000);
			actions.smartWait(20);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");
			
			// Assigned Menu Item Tax Set to Rest.
			actions.setValue("RestaurantProfile.SearchTextBox", strRest);
			actions.keyboardEnter("ManageOrderTotalDiscountSet.apply");
			actions.smartWait(20);
			WebElement ElementTaxTypNm1 = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1, "Number", "a");
			actions.click(ElementTaxTypNm1);
			actions.smartWait(100);
			actions.keyboardEnter("RestaurantProfile.OperationsDetails");
			actions.smartWait(100);
			Select strValue = new Select(
					driver.findElement(By.xpath(actions.getLocator("RestaurantProfile.MenuIteamTaxSetDropdown"))));
			String values2 = strValue.getFirstSelectedOption().getText();
			if (values2.equalsIgnoreCase(ele1)) {
				actions.reportCreatePASS("Verify the updated Menu Item Tax Set Name in the DDL",
						"Updated Menu Item Tax Set Name should be Selected in the MITS DDL",
						"Updated Menu Item Tax Set Name is Selected in the MITS DDL", "PASS");
			} else {
				actions.setValue("RestaurantProfile.MenuIteamTaxSetDropdown", ele1);
				Thread.sleep(2000);
				actions.click("RestaurantProfile.ApplyButton");
				try {
					mcd.waitAndSwitch("Apply Changes Details");
					Thread.sleep(2000);
					actions.keyboardEnter("ApplyChangesDetails.RPSaveButton");
					mcd.waitAndSwitch("@Restaurant Profile");
				} catch (Exception e) {

					System.out.println("Apply Changes Details is not displayed");
				}
				try {
					mcd.VerifyAlertMessageDisplayed("Warning Message", strPopupSplit[1], true,
							AlertPopupButton.OK_BUTTON);
				} catch (Exception e) {
					System.out.println("Warning Message is not displayed");
				}
				mcd.waitAndSwitch("Run Validation Report");
				actions.keyboardEnter("NewScript.CancleButton");
				mcd.waitAndSwitch("@Restaurant Profile");
			}
			// ADMIN > Restaurant Profile
			System.out.println("> Navigate to :: " + strNavigateTo_RP);
			actions.select_menu("RFMHome.Navigation", strNavigateTo_RP);
			Thread.sleep(8000);
			actions.smartWait(20);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			// Click on the Restaurant Number hyperlink
			WebElement ElementTaxTypNm2 = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1, "Number", "a");
			actions.keyboardEnter(ElementTaxTypNm2);
			actions.smartWait(20);

			// Navigate to Operations Tab & Verify the updated Menu Item Tax Set
			// Name in the DDL.
			actions.keyboardEnter("RestaurantProfile.OperationsDetails");
			actions.smartWait(100);
			String values = mcd.getdropdownvalues("RestaurantProfile.MenuIteamTaxSetDropdown");
			if (values.contains(ele1)) {
				actions.reportCreatePASS("Verify the updated Menu Item Tax Set Name in the DDL",
						"Updated Menu Item Tax Set Name should be Present in the MITS DDL",
						"Updated Menu Item Tax Set Name is Present in the MITS DDL", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the updated Menu Item Tax Set Name in the DDL",
						"Updated Menu Item Tax Set Name should be Present in the MITS DDL",
						"Updated Menu Item Tax Set Name is not Present in the MITS DDL", "FAIL");
			}

			// Click on Cancel Button
			actions.click("MassSetAssignment.Searchbtn");
			actions.smartWait(20);

			// Navigates to the Restaurant to which the updated Menu Item Tax
			// Set is already attached
			actions.setValue("RestaurantProfile.SearchTextBox", strRest);
			actions.click("PackageReport.RestSrchButton");
			actions.smartWait(20);
			WebElement ElementTaxTypNm3 = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1, "Number", "a");
			actions.keyboardEnter(ElementTaxTypNm3);
			actions.smartWait(100);
			actions.keyboardEnter("RestaurantProfile.OperationsDetails");
			actions.smartWait(100);

			// Verify the value in Menu Item Tax Set field.
			Select strValue1 = new Select(
					driver.findElement(By.xpath(actions.getLocator("RestaurantProfile.MenuIteamTaxSetDropdown"))));

			String values3 = strValue1.getFirstSelectedOption().getText();
			if (values3.equalsIgnoreCase(ele1)) {
				actions.reportCreatePASS("Verify the updated Menu Item Tax Set Name in the DDL",
						"Updated Menu Item Tax Set Name should be Present in the MITS DDL",
						"Updated Menu Item Tax Set Name is Present in the MITS DDL", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the updated Menu Item Tax Set Name in the DDL",
						"Updated Menu Item Tax Set Name should be Present in the MITS DDL",
						"Updated Menu Item Tax Set Name is not Present in the MITS DDL", "FAIL");
			}

			// REPORTS > Menu Item > Tax Report
			System.out.println("> Navigate to :: " + strNavigateTo_Report);
			actions.select_menu("RFMHome.Navigation", strNavigateTo_Report);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			// Select the Rest and generates a report.
			actions.setValue("SelectARestaurant.searchtext", strRest);
			actions.click("SelectNode.ExactMatch");
			actions.keyboardEnter("SelectNode.SearchBtn");
			mcd.Selectrestnode("SelectNode.MITSTree", strRest);
			actions.keyboardEnter("UsersNewUser.greaterThan");
			actions.keyboardEnter("UpdateBusinessLimitsSet.apply");
			Thread.sleep(2000);
			
			// REPORTS > View Generate Report
			System.out.println("> Navigate to :: " + strNavigateTo_View);
			actions.select_menu("RFMHome.Navigation", strNavigateTo_View);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			// Verify the data populated in Menu Item Tax Set column
			actions.setValue("ViewGenReport.ReportType", "Menu Item Tax Report");
			actions.smartWait(30);

			actions.javaScriptClick("RFM.SearchBtn");
			actions.smartWait(30);

			// Check for 'In-Process' if not loop should be going till it
			// changes to 'Generated'
			int rc_rpt, cn_rpt;
			String status = "";
			rc_rpt = mcd.GetTableRowCount("FieldPermissions.Table");
			if (rc_rpt > 1) {

				do {
					actions.click("ViewGeneratedReport.DateTimeFltr");
					Thread.sleep(100);
					actions.click("ViewGeneratedReport.DateTimeFltr");
					Thread.sleep(1000);
					status = driver.findElements(By.xpath("//*[@id='col2']")).get(1).getText().trim();
				} while (status.equals("In-Process"));
			} else {

				do {
					actions.click("MasterMenuItemList.SearchButton_New");
					Thread.sleep(1000);
					status = driver.findElements(By.xpath("//*[@id='col2']")).get(1).getText().trim();
				} while (status.equals("In-Process"));

			}
			driver.findElement(
					By.xpath("//*[@id='Sess1']/tbody/tr[1]/td[1]//*[(normalize-space(text())='Menu Item Tax Report')]"))
					.click();
			if (driver.findElement(By.xpath(actions.getLocator("ViewGenerateReport.MITSetName"))).getText()
					.contains(ele1)) {
				actions.reportCreatePASS("Verify the updated Menu Item Tax Set Name ",
						"Updated Menu Item Tax Set Name should be Present", "Updated Menu Item Tax Set Name is Present",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify the updated Menu Item Tax Set Name ",
						"Updated Menu Item Tax Set Name should be Present",
						"Updated Menu Item Tax Set Name is not Present", "FAIL");
			}
			// REPORTS > Set Assignment Report
			System.out.println("> Navigate to :: " + strNavigateTo_SetAssig);
			actions.select_menu("RFMHome.Navigation", strNavigateTo_SetAssig);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			// Selects Menu Item Tax Set from Select Set Type DDL and Click on
			// Search button
			actions.setValue("SetAssignmentReport.SelectSetTypeDDL", "Menu Item Tax Set");
			actions.smartWait(20);
			actions.keyboardEnter("TenderTypeList.ViewFullListButton");
			actions.smartWait(20);

			// Verify Updated Menu Item Tax Set
			Boolean flag = false;
			List ele = driver.findElements(By.xpath(actions.getLocator("SetAssignmentReport.TableValues")));
			for (int i = 1; i <= ele.size(); i++) {
				String text = driver.findElement(By.xpath("//*[@id='tblLeft']/tbody/tr[" + i + "]/td[1]")).getText();
				if (text.equalsIgnoreCase(ele1)) {
					flag = true;
					break;
				}
			}

			if (flag) {
				actions.reportCreatePASS("Verify the updated Menu Item Tax Set Name ",
						"Updated Menu Item Tax Set Name should be Present", "Updated Menu Item Tax Set Name is Present",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify the updated Menu Item Tax Set Name ",
						"Updated Menu Item Tax Set Name should be Present",
						"Updated Menu Item Tax Set Name is not Present", "FAIL");
			}
			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}
}