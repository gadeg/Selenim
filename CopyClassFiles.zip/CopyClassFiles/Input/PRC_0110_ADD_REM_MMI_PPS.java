package xtam.test;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class PRC_0110_ADD_REM_MMI_PPS {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// Declare test-data variables for other data-parameters
	private String strSrchType, strSrchText, strValTxt[], Validate_Text, Setname;
	private String strOperation, strActivity, strLevel, strUID, strDBName;

	public PRC_0110_ADD_REM_MMI_PPS(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// GetTestData for other data-parameters
		strSrchType = mcd.GetTestData("DT_SRCHTYPE");
		strSrchText = mcd.GetTestData("DT_SRCHDATA");
		Validate_Text = mcd.GetTestData("DT_VALIDATETEXT");
		strOperation = mcd.GetTestData("DT_OPERATION");
		strActivity = mcd.GetTestData("DT_ACTIVITY");
		strLevel = mcd.GetTestData("DT_LEVEL");
		strDBName = mcd.GetTestData("DT_DBNAME");
		strUID = mcd.GetTestData("DT_USERID");
		strValTxt = Validate_Text.split("#");
	}

	@Test
	public void test_PRC_0110_ADD_REM_MMI_PPS() throws InterruptedException {
		String strTestDescription = "Verify Add/Remove Menu Items functionality promotional price set";

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			// setting the test case description
			actions.setTestcaseDescription(strTestDescription);

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Navigate to Price Sets */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// selecting and searching for a Promotional Price Set
			actions.setValue("PriceSets.SearchType", strSrchType);
			actions.setValue("PriceSet.SearchBox", strSrchText);
			actions.keyboardEnter("PriceSet.SearchBtn");
			mcd.smartsync(180);

			// getting the table element and clicking on the first record
			WebElement record_set = mcd.GetTableCellElement("RFM.WebTable", 1, "Name", "a");
			String Nodes = mcd.GetTableCellValue("RFM.WebTable", 1, "Node", "", "");
			Setname = record_set.getText();
			actions.keyboardEnter(record_set);
			mcd.smartsync(180);
			actions.WaitForElementPresent("ManagePS.AddRemoveMIBtn", 180);

			// Adding Menu Item by clicking on the Add/Remove button
			actions.click("ManagePS.AddRemoveMIBtn");
			mcd.SwitchToWindow(" Price Sets : Common Menu Item Selector");
			actions.click("RFM.ViewFullListBtn");
			mcd.smartsync(180);
			// setting the available in the search list
			actions.setValue("AddRemoveMenu.Availability", "Available");
			mcd.smartsync(180);

			// getting the webElement from the table
			String Item_name = null;
			try {
				Item_name = mcd.GetTableCellValue("PriceSetList.PSTable", 1, "Name", "", "");
				// getting the check box web element and selecting it
				WebElement AddCheck_box = mcd.GetTableCellElement("PriceSetList.PSTable", 1, "Add", "input");
				actions.click(AddCheck_box);
				actions.reportCreatePASS("Verify selecting the Available menu Item",
						"Should select the available menu Item", "Selected menu item '" + Item_name + "successfuly",
						"Pass");
			} catch (Exception e) {
				actions.reportCreateFAIL("Verify selecting the Available menu Item",
						"Should select the available menu Item", "Not able to selected menu item", "Fail");
			}
			actions.click("CommonSelector.Save");
			driver.switchTo().window("");
			// switching back to parent window
			mcd.SwitchToWindow("@Price Sets");
			mcd.smartsync(180);
			
			// verifying the success message
			actions.verifyTextPresence(strValTxt[1].trim(), true);

			// Clicking on the Add/Remove button
			actions.click("ManagePS.AddRemoveMIBtn");
			mcd.SwitchToWindow(" Price Sets : Common Menu Item Selector");

			// checking 'View Current Changes' button is enabled after selecting
			// Remove check box and validating the same
			actions.click("RFM.ViewFullListBtn");
			mcd.smartsync(180);
			actions.setValue("AddRemoveMenu.Availability", "Available");
			mcd.smartsync(180);
			WebElement AddCheck_box = mcd.GetTableCellElement("PriceSetList.PSTable", 1, "Add", "input");
			actions.click(AddCheck_box);

			if (actions.isElementEnabled("CommonMenuItemSelector.ViewCurrentChanges")) {
				actions.reportCreatePASS("Verify view current changes button after selecting Add check box",
						"view current changes button should be enabled", "view current changes button is enabled",
						"Pass");
			} else {
				actions.reportCreateFAIL("Verify view current changes button after selecting Add check box",
						"view current changes button should be enabled", "view current changes button is not enabled",
						"Fail");
			}
			
			// Checking Remove check box is disabled against Add check box while Adding a Menu Item
			WebElement RemoveCheck_box1 = mcd.GetTableCellElement("PriceSetList.PSTable", 1, "Remove", "input");
			if (!RemoveCheck_box1.isEnabled()) {
				actions.reportCreatePASS("Verify Remove check box", "Remove check box should be disabled",
						"Remove check box is disabled", "Pass");
			} else {
				actions.reportCreateFAIL("Verify Remove check box", "Remove check box should be disabled",
						"Remove check box is not disabled", "Fail");
			}
			actions.click("CommonMenuItemSelector.ViewCurrentChanges");
			mcd.waitAndSwitch("View Current Changes");
			actions.click("RFM.Okbtn");
			mcd.waitAndSwitch("Price Sets : Common Menu Item Selector");

			// checking 'View Current Changes' button is enabled after selecting
			// Add check box and validating the same
			actions.click("RFM.ViewFullListBtn");
			mcd.smartsync(180);
			actions.setValue("AddRemoveMenu.Availability", "Assigned");
			mcd.smartsync(180);
			WebElement RemoveCheck_box = mcd.GetTableCellElement("PriceSetList.PSTable", 1, "Remove", "input");
			actions.click(RemoveCheck_box);
			if (actions.isElementEnabled("CommonMenuItemSelector.ViewCurrentChanges")) {
				actions.reportCreatePASS("Verify view current changes button after selecting Remove check box",
						"view current changes button should be enabled", "view current changes button is enabled",
						"Pass");
			} else {
				actions.reportCreateFAIL("Verify view current changes button after selecting Remove check box",
						"view current changes button should be enabled", "view current changes button is not enabled",
						"Fail");
			}
			actions.click("CommonMenuItemSelector.ViewCurrentChanges");
			mcd.waitAndSwitch("View Current Changes");
			actions.click("RFM.Okbtn");
			mcd.waitAndSwitch("Price Sets : Common Menu Item Selector");
			actions.click("CommonSelector.Save");

			boolean result = false;
			try {
				String AlertText = driver.switchTo().alert().getText();
				if (AlertText.contains("on removing")) {
					// validate the Pop alert message
					result = mcd.VerifyAlertMessageDisplayed("Confirmation", strValTxt[0].trim(), true,
							AlertPopupButton.OK_BUTTON);
					if (result == true) {
						actions.reportCreatePASS("Verify pop up alert Message",
								"Pop Up alert Message '" + strValTxt[0].trim() + " ' should be displayed",
								"Pop Up alert Message '" + strValTxt[0].trim() + " ' is displayed", "Pass");
					} else {
						actions.reportCreateFAIL("Verify pop up alert Message",
								"Pop Up alert Message '" + strValTxt[0].trim() + " ' should be displayed",
								"Pop Up alert Message '" + strValTxt[0].trim() + " ' is not displayed", "Fail");
					}
				}
			} catch (Exception e) {
			}
			driver.switchTo().window("");
			mcd.waitAndSwitch("Price Sets");
			mcd.smartsync(180);

			// Verify the audit log for Update
			if (rfm.VerifyAuditLog_Entry(strOperation, strActivity.trim(), Nodes)) {
				actions.reportCreatePASS("Verify the audit Log", "Audit Log should display correct values",
						"Audit Log displayed correct values", "Pass");
			} else {
				actions.reportCreateFAIL("Verify the audit Log", "Audit Log should display correct values",
						"Audit Log displayed incorrect values", "Fail");
			}

			// verify the audit log details
			String strDescription = strValTxt[2].trim().replace("?", Setname);
			if (rfm.RFM_VerifyAuditLog_Details(strDBName, strUID, strOperation, strActivity, strLevel, Nodes,
					strDescription)) {
				actions.reportCreatePASS("Verify the audit Log details",
						"Audit Log details should display correct values",
						"Audit Log details  displayed correct values", "Pass");
			} else {
				actions.reportCreateFAIL("Verify the audit Log details",
						"Audit Log details should display correct values",
						"Audit Log details displayed incorrect values", "Fail");
			}
			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			// reporting the Fail condition
			actions.catchException(e);
		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}
}
