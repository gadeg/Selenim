package xtam.test;

import java.util.Map;
import java.util.Random;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class PRC_20180_MF_VfandTaxf {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;
	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateToMF;
	// TODO: Declare test-data variables for other data-parameters
	private String strMsg;
	private String strNavigateToAdmin;
	private String TkOutPrc, EatingPrc, OthPrc;

	public PRC_20180_MF_VfandTaxf(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);
		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateToMF = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters
		strMsg = mcd.GetTestData("DT_MSG");
		TkOutPrc = mcd.GetTestData("TakeOut");
		EatingPrc = mcd.GetTestData("Eatin");
		OthPrc = mcd.GetTestData("Other");
		strNavigateToAdmin = mcd.GetTestData("DT_NAVIGATE_TO_Admin");
	}

	@Test
	public void test_PRC_20180_MF_VfandTaxf() throws InterruptedException {
		// String strPageTitle = "Fee"; // TODO: Exact page-title
		// String strPageSubHeading = ""; // TODO: Page Heading
		// TODO: Test Case Description
		String strTestDescription = "Verify error message for Value field expanded and Tax Value when it is collapsed to All field";

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			/** Get Test Case Description */
			actions.setTestcaseDescription(strTestDescription);

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateToAdmin);
			actions.select_menu("RFMHome.Navigation", strNavigateToAdmin);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Verify Page Header */
			// System.out.println("> Verify Page Heading");
			// mcd.VerifyPageTitle(strPageTitle);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Actions specific to test-flow
			// Aotomating the Pre - Req
			rfm.RFM_Admin_Update_PricingTags("false", "Restrict price type attribute from expanding");
			rfm.RFM_Admin_Update_PricingTags("false", "Display price type attribute as expanded by default");
			rfm.RFM_Admin_Update_PricingTags("0", "Automatically fill price type attribute option price value");

			// Navigating to Master Fee
			actions.waitForPageToLoad(120);
			System.out.println("> Navigate to :: " + strNavigateToMF);
			actions.select_menu("RFMHome.Navigation", strNavigateToMF);
			Thread.sleep(2000);
			actions.waitForPageToLoad(180);

			mcd.SwitchToWindow("#Title");

			String[] Msg = strMsg.split("#");
			actions.waitForPageToLoad(120);
			actions.WaitForElementPresent("MasterFee.NewFeeBtn");
			actions.keyboardEnter("MasterFee.NewFeeBtn");
			// actions.smartWait(20);
			// Clesr Fee Id Field
			actions.WaitForElementPresent("MasterFee.FeeId");
			actions.clear("MasterFee.FeeId");

			// Entering unique ID
			Random rand_num = new Random();
			int strNewFeeiD = rand_num.nextInt((99) + 5);
			System.out.println(strNewFeeiD);
			actions.setValue("MasterFee.FeeId", Integer.toString(strNewFeeiD));

			// Entering unique Name
			actions.WaitForElementPresent("MasterFee.FeeName");
			String strNewFeeName = mcd.fn_GetRndName("ATS");
			actions.setValue("MasterFee.FeeName", strNewFeeName);

			actions.WaitForElementPresent("MasterFee.FeeType");

			actions.setValue("MasterFee.FeeType", "Rate");
			actions.click("ApplyChangesDetails.Save");
			// actions.smartWait(10);
			Thread.sleep(1000);

/*			boolean warn0 = mcd.VerifyAlertMessageDisplayed("Warning", Msg[0], true, AlertPopupButton.OK_BUTTON);

			if (warn0) {
				actions.reportCreatePASS("Verify 'Please enter Value' Alert with 'OK' button",
						"'Please enter Value' Alert with 'OK' button should be displayed.",
						"'Please enter Value' Alert with 'OK' button is displayed.", "PASS");
			} else {
				actions.reportCreateFAIL("Verify 'Please enter Value' Alert with 'OK' button",
						"'Please enter Value' Alert with 'OK' button should be displayed.",
						"'Please enter Value' Alert with 'OK' button is not displayed.", "FAIL");
			}

			// Click on the '+' Icon of Price value
			actions.waitForPageToLoad(120);
			actions.click("DepositSet.PlusIcon");

			// Enter value in TkOutPrc field
			actions.WaitForElementPresent("FeeSet.TkOutPrc");
			actions.setValue("FeeSet.TkOutPrc", TkOutPrc);

			// Enter value in OthPrc field
			actions.WaitForElementPresent("FeeSet.OthPrc");
			actions.setValue("FeeSet.OthPrc", OthPrc);

			// Click on save
			actions.click("ApplyChangesDetails.Save");
			Thread.sleep(1000);

			// Verify alert message
			boolean warn1 = mcd.VerifyAlertMessageDisplayed("Warning", Msg[1], true, AlertPopupButton.OK_BUTTON);

			if (warn1) {
				actions.reportCreatePASS("Verify 'Please enter Eatin Value' Alert with 'OK' button",
						"'Please enter Eatin Value' Alert with 'OK' button should be displayed.",
						"'Please enter Eatin Value' Alert with 'OK' button is displayed.", "PASS");
			} else {
				actions.reportCreateFAIL("Verify 'Please enter Eatin Value' Alert with 'OK' button",
						"'Please enter Eatin Value' Alert with 'OK' button should be displayed.",
						"'Please enter Eatin Value' Alert with 'OK' button is not displayed.", "FAIL");
			}

			// Enter value in EatinPrc field
			actions.WaitForElementPresent("FeeSet.EatingPrc");
			actions.setValue("FeeSet.EatingPrc", EatingPrc);

			// Clear
			actions.clear("FeeSet.OthPrc");

			// Click on save
			actions.click("ApplyChangesDetails.Save");
			Thread.sleep(1000);

			// Verify alert
			boolean warn2 = mcd.VerifyAlertMessageDisplayed("Warning", Msg[2], true, AlertPopupButton.OK_BUTTON);

			if (warn2) {
				actions.reportCreatePASS("Verify 'Please enter Other Value' Alert with 'OK' button",
						"'Please enter Other Value' Alert with 'OK' button should be displayed.",
						"'Please enter Other Value' Alert with 'OK' button is displayed.", "PASS");
			} else {
				actions.reportCreateFAIL("Verify 'Please enter Other Value' Alert with 'OK' button",
						"'Please enter Other Value' Alert with 'OK' button should be displayed.",
						"'Please enter Other Value' Alert with 'OK' button is not displayed.", "FAIL");
			}

			// Enter value in other price field
			actions.WaitForElementPresent("FeeSet.OthPrc");
			actions.setValue("FeeSet.OthPrc", OthPrc);
			actions.WaitForElementPresent("FeeSet.TkOutPrc");

			// clear
			actions.clear("FeeSet.TkOutPrc");

			// click on save
			actions.click("ApplyChangesDetails.Save");
			Thread.sleep(1000);

			// verify alert message
			boolean warn3 = mcd.VerifyAlertMessageDisplayed("Warning", Msg[3], true, AlertPopupButton.OK_BUTTON);

			if (warn3) {
				actions.reportCreatePASS("Verify 'Please enter Takeout Value' Alert with 'OK' button",
						"'Please enter Takeout Value' Alert with 'OK' button should be displayed.",
						"'Please enter Takeout Value' Alert with 'OK' button is displayed.", "PASS");
			} else {
				actions.reportCreateFAIL("Verify 'Please enter Takeout Value' Alert with 'OK' button",
						"'Please enter Takeout Value' Alert with 'OK' button should be displayed.",
						"'Please enter Takeout Value' Alert with 'OK' button is not displayed.", "FAIL");
			}

			// Enter value in TkOutPrc field
			actions.WaitForElementPresent("FeeSet.TkOutPrc");
			actions.setValue("FeeSet.TkOutPrc", TkOutPrc);
*/
			// Select Always from the dropdown
			actions.WaitForElementPresent("FeeSet.TaxCode");
			actions.setValue("FeeSet.TaxCode", "Always");
			actions.click("ApplyChangesDetails.Save");
			Thread.sleep(1000);

			// Verify Alert message
			boolean warn4 = mcd.VerifyAlertMessageDisplayed("Warning", Msg[4], true, AlertPopupButton.OK_BUTTON);

			if (warn4) {
				actions.reportCreatePASS("Verify 'Please select Tax Rule' Alert with 'OK' button",
						"'Please select Tax Rule' Alert with 'OK' button should be displayed.",
						"'Please select Tax Rule' Alert with 'OK' button is displayed.", "PASS");
			} else {
				actions.reportCreateFAIL("Verify 'Please select Tax Rule' Alert with 'OK' button",
						"'Please select Tax Rule' Alert with 'OK' button should be displayed.",
						"'Please select Tax Rule' Alert with 'OK' button is not displayed.", "FAIL");
			}

			// Select any option from the TaxRule dropdown
			actions.WaitForElementPresent("FeeSet.TaxRule");
			actions.setValue("FeeSet.TaxRule", "GST");
			actions.click("ApplyChangesDetails.Save");
			Thread.sleep(1000);

			// Verify Alert message
			boolean warn5 = mcd.VerifyAlertMessageDisplayed("Warning", Msg[5], true, AlertPopupButton.OK_BUTTON);

			if (warn5) {
				actions.reportCreatePASS("Verify 'Please select Tax Entry' Alert with 'OK' button",
						"'Please select Tax Entry' Alert with 'OK' button should be displayed.",
						"'Please select Tax Entry' Alert with 'OK' button is displayed.", "PASS");
			} else {
				actions.reportCreateFAIL("Verify 'Please select Tax Entry' Alert with 'OK' button",
						"'Please select Tax Entry' Alert with 'OK' button should be displayed.",
						"'Please select Tax Entry' Alert with 'OK' button is not displayed.", "FAIL");
			}

			Thread.sleep(1000);
			// actions.setValue("FeeSet.AllTaxEntry", "1");
			actions.WaitForElementPresent("FeeSet.AllTaxEntry");
			Select select = new Select(actions.getWebElement("FeeSet.AllTaxEntry"));
			select.selectByIndex(1);

			actions.click("ApplyChangesDetails.Save");
			actions.smartWait(180);

			// To verify your changes have been saved by entering unique fee ID
			boolean flag = false, flagFeeId = false;
			try {
				flag = mcd.VerifyOnscreenMessage("ManageFee.SSMsg", Msg[9], true);

			} catch (Exception e) {

				do {
					try {
						flagFeeId = mcd.VerifyOnscreenMessage("MasterFee.Header", Msg[10], true);
						if (flagFeeId) {
							actions.clear("MasterFee.FeeId");
							// Entering unique Fee ID
							rand_num = new Random();
							strNewFeeiD = rand_num.nextInt((99) + 5);
							System.out.println(strNewFeeiD);
							actions.setValue("MasterFee.FeeId", Integer.toString(strNewFeeiD));
							actions.keyboardEnter("ApplyChangesDetails.Save");
							actions.smartWait(10);
						}
					} catch (Exception ee) {
						actions.WaitForElementPresent("ManageFee.SSMsg", 180);
						flag = mcd.VerifyOnscreenMessage("ManageFee.SSMsg", Msg[9], true);
						flagFeeId = false;
					}
				} while (flagFeeId);
			}

			// actions.verifyTextPresence("Your changes have been saved.",
			// true);
			actions.smartWait(20);

			actions.WaitForElementPresent("FeeSet.TaxCode");
			actions.setValue("FeeSet.TaxCode", "Optional");
			actions.smartWait(50);
			actions.WaitForElementPresent("FeeSet.TaxRule");
			actions.setValue("FeeSet.TaxRule", "VAT");

			// Click on apply button
			actions.click("ManageFee.Applybtn");
			Thread.sleep(1000);

			// Verify alert message
			boolean warn6 = mcd.VerifyAlertMessageDisplayed("Warning", Msg[6], true, AlertPopupButton.OK_BUTTON);

			if (warn6) {
				actions.reportCreatePASS("Verify 'Please select Tax Entry' Alert with 'OK' button",
						"'Please select Tax Entry' Alert with 'OK' button should be displayed.",
						"'Please select Tax Entry' Alert with 'OK' button is displayed.", "PASS");
			} else {
				actions.reportCreateFAIL("Verify 'Please select Tax Entry' Alert with 'OK' button",
						"'Please select Tax Entry' Alert with 'OK' button should be displayed.",
						"'Please select Tax Entry' Alert with 'OK' button is not displayed.", "FAIL");
			}

			actions.WaitForElementPresent("FeeSet.TaxCode");
			actions.setValue("FeeSet.TaxCode", "Select");
			actions.WaitForElementPresent("FeeSet.TaxRule");
			actions.setValue("FeeSet.TaxRule", "FLAT");

			// Verify alert message
			boolean warn7 = mcd.VerifyAlertMessageDisplayed("Warning", Msg[7], true, AlertPopupButton.OK_BUTTON);

			if (warn7) {
				actions.reportCreatePASS("Verify 'Please select Tax Code' Alert with 'OK' button",
						"'Please select Tax Code' Alert with 'OK' button should be displayed.",
						"'Please select Tax Code' Alert with 'OK' button is displayed.", "PASS");
			} else {
				actions.reportCreateFAIL("Verify 'Please select Tax Code' Alert with 'OK' button",
						"'Please select Tax Code' Alert with 'OK' button should be displayed.",
						"'Please select Tax Code' Alert with 'OK' button is not displayed.", "FAIL");
			}

			actions.WaitForElementPresent("FeeSet.TaxRule");
			actions.setValue("FeeSet.TaxRule", "Select");
			actions.smartWait(30);
			actions.WaitForElementPresent("FeeSet.TaxCode");
			actions.setValue("FeeSet.TaxCode", "Optional");
			// actions.setValue("FeeSet.AllTaxEntry", "1");
			Select select1 = new Select(actions.getWebElement("FeeSet.AllTaxEntry"));
			select1.selectByIndex(1);

			// Verify alert message
			boolean warn8 = mcd.VerifyAlertMessageDisplayed("Warning", Msg[8], true, AlertPopupButton.OK_BUTTON);

			if (warn8) {
				actions.reportCreatePASS("Verify 'Please select Tax Rule' Alert with 'OK' button",
						"'Please select Tax Rule' Alert with 'OK' button should be displayed.",
						"'Please select Tax Rule' Alert with 'OK' button is displayed.", "PASS");
			} else {
				actions.reportCreateFAIL("Verify 'Please select Tax Rule' Alert with 'OK' button",
						"'Please select Tax Rule' Alert with 'OK' button should be displayed.",
						"'Please select Tax Rule' Alert with 'OK' button is not displayed.", "FAIL");
			}

			// ------------------------------------------------------------------------
			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}