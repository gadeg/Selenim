package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;

public class PRC_20173_VrfyList_Status {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;

	// TODO: Declare test-data variables for other data-parameters

	public PRC_20173_VrfyList_Status(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");

	}

	@Test
	public void PRC_20173_VrfyList_Status() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription(
					"Verify View Full List, Post Status filter, Pagination and sorting Functionality");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			// ------------------------------------------------------------------------

			// Verify "Fee" screen should Search with Status,New Fee & Delete
			// ,Future Settings are Present
			if (actions.isElementEnabled("PermissionReportbyRole.SearchDDL")) {
				actions.reportCreatePASS("Verify Search with Status DropDown ",
						"Search with Status DropDown should be Present", "Search with Status DropDown is Present",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify Search with Status DropDown ",
						"Search with Status DropDown should be Present", "Search with Status DropDown is not Present",
						"FAIL");
			}
			verifyTablecolumnsPresent("DimensionNameSets.tbl", "Future Settings");
			verifyTablecolumnsPresent("DimensionNameSets.tbl", "Delete");
			if (actions.isElementPresent("MasterFee.NewFeeBtn")) {
				actions.reportCreatePASS("Verify New Fee Button ", "New Fee Button should be Present",
						"New Fee Button is Present", "PASS");
			} else {
				actions.reportCreateFAIL("Verify New Fee Button", "New Fee Button should be Present",
						"New Fee Button is not Present", "FAIL");
			}

			// Click on Search Button & All fee names exist in application are
			// displayed in search result .
			actions.keyboardEnter("PriceSet.SearchBtn");
			actions.smartWait(180);
			int tablerowcount = mcd.GetTableRowCount("PriceSetList.PSTable");
			if (tablerowcount != 0) {
				actions.reportCreatePASS("Verify Search functionality", "Available Fee Items should be displayed",
						"Available Fee Items are displayed", "PASS");
			} else {
				actions.reportCreatePASS("Verify Search functionality", "Available Fee Items should be displayed",
						"No Fee Items are not available", "PASS");
			}

			// Selecting 'Active' from the DropDown& Active status only are
			// displayed in Search Grid
			actions.setValue("ProductionRouting.Status", input.get("DT_Status"));
			actions.smartWait(180);
			int rowCount = mcd.GetTableRowCount("RefreshSettings.Table");
			if (rowCount == 0) {
				actions.reportCreatePASS("Verify Master Fee table", "Master Fee table Should be have Active Fee",
						"Master Fee table having no Active Fee", "PASS");
			} else {
				String stts = mcd.GetTableCellValue("ViewGeneratedReport.ReportTable", 1, 3, "", "");
				if (stts.equals("Active")) {
					actions.reportCreatePASS("Verify 'Active' status by the filter",
							"Only elements with 'Active' status should be displayed",
							"Elements with 'Active' status are displayed", "PASS");
				} else {
					actions.reportCreateFAIL("Verify 'Active' status by the filter",
							"Only elements with 'Active' status should be displayed",
							"Elements with 'Active' status are not displayed", "FAIL");
				}
			}
			// Selecting 'Inactive' from the DropDown& InActive status only are
			// displayed in Search Grid
			actions.setValue("ProductionRouting.Status", input.get("DT_Status1"));
			actions.smartWait(180);
			int rowCount1 = mcd.GetTableRowCount("RefreshSettings.Table");
			if (rowCount1 == 0) {
				actions.reportCreatePASS("Verify Master Fee table", "Master Fee table Should be have Inactive Fee",
						"Master Fee table having no Inactive Fee", "PASS");
			} else {
				String stts1 = mcd.GetTableCellValue("ViewGeneratedReport.ReportTable", 1, 3, "", "");
				if (stts1.equals("Inactive")) {
					actions.reportCreatePASS("Verify 'Inactive' status by the filter",
							"Only elements with 'Inactive' status should be displayed",
							"Elements with 'Inactive' status are displayed", "PASS");
				} else {
					actions.reportCreateFAIL("Verify 'Inactive' status by the filter",
							"Only elements with 'Inactive' status should be displayed",
							"Elements with 'Inactive' status are not displayed", "FAIL");
				}
			}
			// Selecting 'Suspended' from the DropDown& Suspended status only
			// are displayed in Search Grid
			actions.setValue("ProductionRouting.Status", input.get("DT_Status2"));
			actions.smartWait(180);
			int rowCount2 = mcd.GetTableRowCount("RefreshSettings.Table");
			if (rowCount2 == 0) {
				actions.reportCreatePASS("Verify Master Fee table", "Master Fee table Should be have Suspended Fee",
						"Master Fee table  having no Suspended Fee", "PASS");
			} else {
				String stts2 = mcd.GetTableCellValue("ViewGeneratedReport.ReportTable", 1, 3, "", "");
				if (stts2.equals("Suspended")) {
					actions.reportCreatePASS("Verify 'Suspended' status by the filter",
							"Only elements with 'Suspended' status should be displayed",
							"Elements with 'Suspended' status are displayed", "PASS");
				} else {
					actions.reportCreateFAIL("Verify 'Suspended' status by the filter",
							"Only elements with 'Suspended' status should be displayed",
							"Elements with 'Suspended' status are not displayed", "FAIL");
				}
			}
			// Selecting 'All' from the DropDown
			actions.setValue("ProductionRouting.Status", input.get("DT_Status3"));
			actions.smartWait(180);

			// Verifying sorting functionality for 'Fee ID'
			actions.click("Fee.FeeIdsortingLink");
			actions.smartWait(180);
			String strSortOrderValue = driver.findElement(By.xpath(actions.getLocator("RestaurantProfile.sort")))
					.getAttribute("src");
			if (!strSortOrderValue.contains("up")) {
				actions.click("Fee.FeeIdsortingLink");
			}
			List<WebElement> eleRws = driver
					.findElements(By.xpath(actions.getLocator("MassStatusUpdate.ComponentMINumber")));
			int iNewMIRwCnt = eleRws.size();
			Boolean flag1 = false;
			for (int i = 1; i <= iNewMIRwCnt - 1; i++) {
				int MI_Num1 = Integer
						.parseInt(driver.findElement(By.xpath("//*[@id='Sess1']/tbody/tr[" + i + "]/td[1]")).getText());
				int j = i + 1;
				int MI_Num2 = Integer
						.parseInt(driver.findElement(By.xpath("//*[@id='Sess1']/tbody/tr[" + j + "]/td[1]")).getText());
				if (MI_Num1 <= MI_Num2) {
					flag1 = true;

				} else {
					flag1 = false;
					break;

				}

			}
			if (flag1) {
				actions.reportCreatePASS("Verify Sorting according to Fee ID", "List should be sorted correctly",
						"List is sorted correctly", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Sorting according to Fee ID", "List should be sorted correctly",
						"List is not sorted correctly", "FAIL");
			}

			// Verifying sorting functionality for 'Fee Name'
			driver.findElement(By.xpath(actions.getLocator("Fee.FeeNamesortingLink"))).click();
			actions.smartWait(180);
			actions.waitForPageToLoad(120);
			String strSortOrderValue1 = driver.findElement(By.xpath(actions.getLocator("RestaurantProfile.sort")))
					.getAttribute("src");
			if (!strSortOrderValue1.contains("up")) {
				actions.click("Fee.FeeNamesortingLink");
			}

			List<WebElement> eleRws1 = driver
					.findElements(By.xpath(actions.getLocator("MassStatusUpdate.ComponentMIName")));
			int iNewMIRwCnt1 = eleRws1.size();
			Boolean flag2 = false;
			for (int i = 1; i <= iNewMIRwCnt1 - 1; i++) {
				String MI_Num3 = driver.findElement(By.xpath("//*[@id='Sess1']/tbody/tr[" + i + "]/td[2]")).getText();
				int j = i + 1;
				String MI_Num4 = driver.findElement(By.xpath("//*[@id='Sess1']/tbody/tr[" + j + "]/td[2]")).getText();

				if ((MI_Num3.toLowerCase().compareTo(MI_Num4.toLowerCase())) <= 0) {
					flag2 = true;

				} else {
					flag2 = false;
					break;

				}

			}
			if (flag2) {
				actions.reportCreatePASS("Verify Sorting according to Fee Name", "List should be sorted correctly",
						"List is sorted correctly", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Sorting according to Fee Name", "List should be sorted correctly",
						"List is not sorted correctly", "FAIL");
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	// Verify Table Header Fields
	public void verifyTablecolumnsPresent(String tableLocator, String colName) {

		boolean iscolPresent = mcd.RFM_VerifyTableColumns(tableLocator, colName);

		if (iscolPresent) {
			actions.reportCreatePASS("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is present in table", "Pass");
		} else {
			actions.reportCreateFAIL("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is NOT present in table",
					"Fail");
		}
	}

}
