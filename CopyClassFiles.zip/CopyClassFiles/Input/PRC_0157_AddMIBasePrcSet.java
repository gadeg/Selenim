package xtam.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;

public class PRC_0157_AddMIBasePrcSet {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// Declare test-data variables for other data-parameters
	private String strAddRemoveMsg;

	public PRC_0157_AddMIBasePrcSet(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// GetTestData for other data-parameters
		strAddRemoveMsg = mcd.GetTestData("AddRemoveMsg");
	}

	@Test
	public void test_PRC_0157_AddMIBasePrcSet() throws InterruptedException {

		try {
			System.out.println("*********** Test execution starts ***********");
			actions.setTestcaseDescription(
					"Verify the functionality of Add Menu  Item for Base Price Set Button in Future Settings screen and Verify that only newly added menu item is displayed");
			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Navigate to Price Sets */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Pricing", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			Actions builder = new Actions(driver);
			builder.moveByOffset(0, 500).click().perform();

			// Get the row count of the price set list displayed
			int rw_cnt = mcd.GetTableRowCount("Price.PriceSets");

			// Selecting Base Price set from the table
			for (int i = 1; i < rw_cnt; i++) {
				try {
					String PromotionType = mcd.GetTableCellElement("Price.PriceSets", i, 3, "").getText();
					if (PromotionType.trim().equals("B")) {
						// Click on Price Set link
						mcd.GetTableCellElement("Price.PriceSets", i, 1, "a").click();
						mcd.smartsync(180);
						break;
					}
				} catch (Exception e) {
					System.out.println("This price set is not attached to any restaurant");
				}
			}

			// Select future date link in the future price changes part
			// getting Number of future settings date present also
			List<WebElement> FutDates = driver.findElements(By.xpath(actions.getLocator("PriceSets.SBFutureSetting")));
			Thread.sleep(5000);
			// Creating future date if not present
			if (FutDates.size() < 2) {
				mcd.SelectDate_OpenCalender("10", "next");
				mcd.smartsync(180);
				// Enter future price setting
				actions.WaitForElementPresent("ManagePS.AllPrice", 120);
				actions.clear("ManagePS.AllPrice");
				actions.setValue("ManagePS.AllPrice", "10");
				actions.click("AddTenderType.ApplyButton");
				Thread.sleep(2000);
				try {
					if (mcd.GetGlobalData("Instance").trim().toLowerCase().contains("us")) {
						actions.click("FutureSettings.Apply");
						try {
							driver.switchTo().alert().accept();
						} catch (Exception e) {
						}
					} else {
						Thread.sleep(2000);
						actions.keyboardEnter("DimensionGroup.SaveButton");
						mcd.smartsync(180);
					}
				} catch (Exception e1) {
				}
				mcd.smartsync(120);
			} else {
				actions.click(FutDates.get(1));
				mcd.smartsync(180);
			}
			Thread.sleep(8000);
			actions.waitForPageToLoad(120);
			actions.WaitForElementPresent("ManagePS.DateSelected", 120);
			
			// Verify that new tab displays the correct date and validate
			String Date_displayed = driver.findElement(By.xpath(actions.getLocator("ManagePS.DateSelected"))).getText();
			FutDates = driver.findElements(By.xpath(actions.getLocator("PriceSets.SBFutureSetting")));
			if (Date_displayed.trim().equals(FutDates.get(1).getText().trim())) {
				actions.reportCreatePASS("Verify date in future tab", "Correct future date should be displayed",
						"Correct future date displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify date in future tab", "Correct future date should be displayed",
						"Correct future date not displayed", "FAIL");
			}

			// Check 'Add Menu Item' button is displayed and validate the same
			if (actions.isElementPresent("ManagePS.FutureAddMI")) {
				actions.reportCreatePASS("Verify Add Menu Item button", "Add Menu Item button should be displayed",
						"Add Menu Item button is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify Add Menu Item button", "Add Menu Item button should be displayed",
						"Add Menu Item button is not displayed", "Fail");
			}
			
			// Add Menu Items to the price set in future date
			actions.click("ManagePS.FutureAddMI");
			// Switch to new window
			mcd.waitAndSwitch("Price Sets : Common Menu Item Selector");
			actions.keyboardEnter("CommonSelector.ViewFullBtn");
			mcd.smartsync(180);
			// Select Available from Availability drop down
			actions.setValue("CommonSelector.AvailabilityDrpDwn", "Available");
			mcd.smartsync(180);
			// Get all the Add check box elements
			List<WebElement> Add_Chkbox = driver
					.findElements(By.xpath(".//input[@type = 'checkbox'][contains(@onclick, 'addMenuItem')]"));
			int Item_Counts = Add_Chkbox.size();

			// Check menu items and add accordingly
			int i_temp = 0;
			String TXpath = null, e = "";
			List<String> MnuItem_Names = new ArrayList<String>();
			for (int n = 0; n < Item_Counts; n++) {
				// Check whether enabled for Add or not
				if ((Add_Chkbox.get(n).isEnabled())) {
					// Check box enabled - Add Item
					Add_Chkbox.get(n).sendKeys(Keys.SPACE);
					// Get Item Name
					String p = Integer.toString(n + 1);
					e = driver.findElement(By.xpath("//*[@id='commonTableBody']/tr[" + p + "]/td[4]")).getText();
					MnuItem_Names.add(e);
					i_temp++;
				} else {
					System.out.println("This MI is already added");
				}
				if (i_temp == 3) {
					break;
				}
			}
			actions.keyboardEnter("CommonSelector.Save");

			// Switch back to Main Window - Title "Price Sets"
			mcd.waitAndSwitch("Price Sets");
			mcd.smartsync(180);
			Thread.sleep(5000);
			// Menu Items have been Added/Removed successfully from the Price
			// Set.
			String OutputMsg = driver.findElement(By.xpath(actions.getLocator("ManagePS.AddRemoveMsg"))).getText();
			if (OutputMsg.equals(strAddRemoveMsg)) {
				actions.reportCreatePASS("Verify Menu item addition", "Menu Items should be added", "Menu Items added",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify Menu item addition", "Menu Items should be added",
						"Menu Items not added", "FAIL");
			}

			// Get the list of items displayed
			List<WebElement> Added_Items = driver.findElements(By.xpath(actions.getLocator("ManagePS.ListofAddedMI")));
			int AddItem_check = 0;

			for (int k = 0; k < Added_Items.size(); k++) {
				String Added_ItemName = Added_Items.get(k).getText().split("-")[1].trim();
				// Verify that the added items are same as displayed items
				if (Added_ItemName.equals(MnuItem_Names.get(k))) {
					AddItem_check++;
				} else {
					System.out.println("Check " + Added_ItemName);
					System.out.println("Check " + MnuItem_Names.get(k));
				}
			}
			if (AddItem_check == 3) {
				actions.reportCreatePASS("Verify menu items displayed", "Only newly added items should be displayed",
						"Only newly added items are displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify menu items displayed", "Only newly added items should be displayed",
						"Items are incorrectly displayed", "FAIL");
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);
		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}
}
