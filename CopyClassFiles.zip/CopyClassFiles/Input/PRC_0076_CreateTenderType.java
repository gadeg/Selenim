 package xtam.test;


import java.util.Date;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;


public class PRC_0076_CreateTenderType {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();
	
	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;
	
	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	
	private String strTenderName;
	private String strTenderId;
	private String strLegacyId;
	private String strFiscalIndex;
	private String strDefSkimAmt;
	private String strDefHaloAmt;
	private String strCurrencyDecimal;
	private String strChgMaxAllwd;	
	private String strPaymentType;
	private String strTaxOption;
	private String strTaxSubTotalOption;
	private String strChangeName;
	private String strStatus;
	private String strForeignCurrency;
	private String strExchangeRate;
	private String strOrientation;
	private String strPrecision;
	private String strRounding;
	private String strExchMode;
	private String strAmount,strmsg,strmessage;
	
	private String NewTenderType = null;

	
	public PRC_0076_CreateTenderType (WebDriver nodeDriver, Map inputData, Object or){
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();
		
		mcd = new lib_MCD (driver, actions, uiActions, inputData);
		rfm = new lib_RFM2 (driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);
		
		// Read input Test-Data
		strURL 			= mcd.GetTestData("DT_URL");
		strUserName 	= mcd.GetTestData("DT_USER_NAME");
		strPassword 	= mcd.GetTestData("DT_PASSWORD");
		strMarket 		= mcd.GetTestData("DT_MARKET");
		strNavigateTo 	= mcd.GetTestData("DT_NAVIGATE_TO");
		strmessage=mcd.GetTestData("DT_MESSAGE");
		// TODO: GetTestData for other data-parameters
		
		strTenderName 		= mcd.GetTestData("TenderName");
		strTenderId 		= mcd.GetTestData("TenderId");
		strLegacyId 		= mcd.GetTestData("LegacyId");
		strFiscalIndex 		= mcd.GetTestData("FiscalIndex");
		strDefSkimAmt 		= mcd.GetTestData("DefSkimAmt");
		strDefHaloAmt 		= mcd.GetTestData("DefHaloAmt");
		strCurrencyDecimal 	= mcd.GetTestData("CurrencyDecimal");
		strChgMaxAllwd		= mcd.GetTestData("ChgMaxAllwd");
		
		strPaymentType			= mcd.GetTestData("PaymentType");
		strTaxOption			= mcd.GetTestData("TaxOption");
		strTaxSubTotalOption	= mcd.GetTestData("TaxSubTotalOption");
		strChangeName			= mcd.GetTestData("ChangeName");
		strStatus				= mcd.GetTestData("Status");
		strForeignCurrency		= mcd.GetTestData("ForeignCurrency");
		strExchangeRate			= mcd.GetTestData("ExchangeRate");
		strOrientation			= mcd.GetTestData("Orientation");
		strPrecision			= mcd.GetTestData("Precision");
		strRounding				= mcd.GetTestData("Rounding");
		strExchMode				= mcd.GetTestData("ExchMode");
		strAmount				= mcd.GetTestData("Amount");
		strmsg=mcd.GetTestData("DT_MSG");
	}
	
	
	@Test
	public void PRC_0076_CreateTenderType() throws InterruptedException {
						
		try {
			System.out.println("********************************************************************** Test execution starts");

			/** Set test case description */
			 actions.setTestcaseDescription("Create a New Tender Type and verify all mandatory fields are available for an existing Tender Type");
			 
					
			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);
			
			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			Boolean blnFlag = rfm.SelectMarket(strMarket);
		
			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Pricing", strNavigateTo);
			Thread.sleep(5000);
			actions.waitForPageToLoad(10000);

			//Verifying Tender Type List screen Search within Status and Status 
			if(actions.isElementEnabled("ProductionRouting.SearchWithinStatus"))
			{
				actions.reportCreatePASS("Verify Search within status dropdown", "Search within status dropdown should enable", "Search within status is enable", "PASS");
			}else{
				actions.reportCreateFAIL("Verify Search within status dropdown", "Search within status dropdown should enable", "Search within status is not enable", "FAIL");

			}
			
			if(!actions.isElementEnabled("ProductionRouting.Status"))
			{
				actions.reportCreatePASS("Verify  status dropdown", "Status dropdown should display", "Status dropdown is disable", "PASS");
			}else{
				actions.reportCreateFAIL("Verify  status dropdown", "Status dropdown should display", "Status dropdown is not disable", "FAIL");

			}
			
						
			//Create new Tender type
		    NewTenderType = PriceActions.RFM_PRC_CreateNewTenderType(strPaymentType, strTaxOption, strTaxSubTotalOption, strChangeName, strStatus, strForeignCurrency, strExchangeRate, strOrientation, strPrecision, strRounding, strExchMode, strAmount);
			actions.smartWait(180);
			
			
			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Pricing", strNavigateTo);
			Thread.sleep(5000);
			actions.waitForPageToLoad(10000);
			actions.keyboardEnter("SetAssignmentReport.SearchButton");
			actions.smartWait(180);
			String value1= driver.findElement(By.xpath(actions.getLocator("SelRestFromGBL.FirstVal"))).getText();
			String value2=driver.findElement(By.xpath(actions.getLocator("ManageTenderType.Link2"))).getText();
			
			//Verify error message while creating existing tender type name
			actions.keyboardEnter("ManageTenderType.NewTenderTypeButton");
			actions.WaitForElementPresent("NewTenderType.TenderName", 10000);
			actions.setValue("NewTenderType.TenderName", NewTenderType);
			Thread.sleep(500);
			
			String SLeagcyID = Get_Unique_ID_Name("Legacy ID");
			String STenderID = Get_Unique_ID_Name("Tender ID");
			actions.setValue("NewTenderType.TenderId", STenderID);
			actions.setValue("NewTenderType.LegacyId", SLeagcyID);
			actions.keyboardEnter("NewTenderType.Save");
			actions.smartWait(180);
			actions.verifyTextPresence(strmessage, true);
			
			//Click on cancel
			actions.keyboardEnter("RFM.CancelBtn");
			mcd.VerifyAlertMessageDisplayed("Warning", strmsg, true, AlertPopupButton.OK_BUTTON);
			
			 
			//Searching for existing tender type and click on name
			actions.setValue("TenderTypeList.SearchTextbox", NewTenderType);
			actions.keyboardEnter("SetAssignmentReport.SearchButton");
			actions.smartWait(180);
			
			
			//Verify sorting order for tender type
			Verify_Sort_Ascending(value1,value2,"Tender Type Name","string");
			actions.keyboardEnter("SelRestFromGBL.FirstVal");
			actions.smartWait(180);
			
			
			//Verify all mandatory fields are displayed or not
			String str=input.get("DT_VALUES").toString();
			boolean flag = false;
			String actual_value[]=null;
			
			
			List <WebElement> ELE= driver.findElements(By.xpath("//*[@class='RedText']/.."));
			
			for(int i=0; i<ELE.size();i++){
				actual_value=ELE.get(i).getText().split("*");
				if(str.toLowerCase().trim().contains(actual_value[0].toLowerCase().trim())){
					flag = true;				
				}else{
					flag = false;
					break;
					
				}
				
			}
			
			if(flag){
				actions.reportCreatePASS("Verify all mandatory fields", "All mandatory fields related to TENDER_FOREIGN_CURRENCY should display", "All mandatory fields related to TENDER_FOREIGN_CURRENCY is displayed", "true");
			}else{
				actions.reportCreateFAIL("Verify all mandatory fields", "All mandatory fields related to TENDER_FOREIGN_CURRENCY should display", actual_value+ " mandatory field for type TENDER_FOREIGN_CURRENCY is not displayed", "false");
			}
				
			
			/** Logout the application */
			rfm.Logout();
			

		} catch(Exception e) {
			
			System.out.println("Test Failed :: " + e.getCause() + " - " +  e.getMessage());
			actions.catchException(e);
			
		        } finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
	
		}
	}
	
	public String Get_Unique_ID_Name(String FieldName) {
		String s = null;
		switch (FieldName) {
		case "Tender Name":
			s = mcd.fn_GetRndName("Auto");
			break;
		case "Tender ID":
			// Getting unique Tender ID

			Date d = new Date();
			int i = (int) d.getTime();
			String temp = Integer.toString(i).substring(1);
			s = "" + d.getSeconds() + "" + temp;
			break;
		case "Legacy ID":
			s = mcd.fn_GetRndName("").split("_")[1];
			break;

		default:
			break;
		}
		return s;
	}

	
	/**
     * SORTING ASCENDING
     */

     public void Verify_Sort_Ascending(String strValue1, String strValue2, String strColumnName, String strDataType) {

            switch (strDataType.toLowerCase()) {
            case "integer":
                   if (Integer.parseInt(strValue1) <= Integer.parseInt(strValue2)) {
                         actions.reportCreatePASS("Verify Ascending Sorting according to " + strColumnName,
                                       "List should be sorted(Ascending)correctly", "List is sorted(Ascending) correctly", "PASS");
                         // System.out.println("sorted ascending correct");
                   } else {
                         actions.reportCreateFAIL("Verify Ascending Sorting according to " + strColumnName,
                                       "List should be sorted(Ascending) correctly", "List is not sorted(Ascending) correctly",
                                       "FAIL");
                         // System.out.println("sorted ascending incorrect");
                   }
                   break;
            case "string":
                   int ReturnNumber = strValue1.toUpperCase().compareTo(strValue2.toUpperCase());
                   if (ReturnNumber <= 0) {
                         actions.reportCreatePASS("Verify Ascending Sorting according to " + strColumnName,
                                       "List should be sorted(Ascending)correctly", "List is sorted(Ascending) correctly", "PASS");
                         // System.out.println("sorted ascending correct");
                   } else {
                         actions.reportCreateFAIL("Verify Ascending Sorting according to " + strColumnName,
                                       "List should be sorted(Ascending) correctly", "List is not sorted(Ascending) correctly",
                                       "FAIL");
                         // System.out.println("sorted ascending incorrect");
                   }
                   break;
            default:
                   break;
            }

     }
	
}
