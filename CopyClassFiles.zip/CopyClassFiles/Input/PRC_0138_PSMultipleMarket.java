
package xtam.test;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class PRC_0138_PSMultipleMarket {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;
	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strPriceSetName;
	private String strSecondMrkt;
	private String strStatusIA;

	private String strPrcSetType;
	private String strStatus_Msg;
	private String strNewPrice1;
	private String strNodeNum;
	private String strResMessage;
	private String strStatus_1;
	private String strMarktTwoRest;
	private String strTestDes;

	public PRC_0138_PSMultipleMarket(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strPriceSetName = mcd.GetTestData("DT_PSNAME");
		strSecondMrkt = mcd.GetTestData("DT_SECONDMARKET");
		strStatusIA = mcd.GetTestData("DT_STATUSIA");

		strPrcSetType = mcd.GetTestData("PriceSetType");
		strStatus_Msg = mcd.GetTestData("Status_Msg");
		strNewPrice1 = mcd.GetTestData("NewPrice1");
		strNodeNum = mcd.GetTestData("NodeNum");
		strResMessage = mcd.GetTestData("Result_Message");
		strStatus_1 = mcd.GetTestData("Status_1");
		strMarktTwoRest = mcd.GetTestData("DT_Market_2_Rest");
		strTestDes = mcd.GetTestData("DT_Description");
	}

	@Test
	public void test_PRC_0138_PSMultipleMarket() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription(strTestDes);

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// Creating a Price Set on Market-1
			strPriceSetName = PriceActions.RFM_PRC_CreatePrcSetWOCpy(strPrcSetType, strStatus_Msg, strNewPrice1,
					strNodeNum, strApplicationDate, strResMessage, strStatus_1);

			/** Click on Change Market button to select another Market */
			// Navigate to Home first
			System.out.println("> Navigate to :: " + "Home");
			actions.select_menu("RFMHome.Navigation", "Home");

			actions.WaitForElementPresent("RFM.STChangeMarketLink", 180);
			actions.click("RFM.STChangeMarketLink");
			System.out.println("> Select Market (Second node)");
			rfm.SelectMarket(strSecondMrkt);

			// navigate to price set
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			// Creating same Price Set on Market-2
			String strPriceSetName_2 = PriceActions.RFM_PRC_CreatePrcSetWOCpy(strPrcSetType, strStatus_Msg,
					strNewPrice1, strMarktTwoRest, strApplicationDate, strResMessage, strStatus_1, strPriceSetName);

			// Searching and deleting the Price set on Market-2
			actions.setValue("RFMMassUpdatePrice.SearchText", strPriceSetName_2);
			actions.click("RestaurantProfile.Searchbtn");
			actions.waitForPageToLoad(120);
			WebElement Element = mcd.GetTableCellElement("FieldPermissions.Table", 1, "Delete", "a");
			actions.click(Element);
			mcd.VerifyAlertMessageDisplayed("Warning", "Are you sure you want to delete the selected item?", true,
					AlertPopupButton.OK_BUTTON);
			mcd.smartsync(180);

			/** Verify Delete Message successfully Displayed on Page */
			boolean blMessage = actions.isTextPresence("Delete has been successfully completed", true);
			if (blMessage) {
				actions.reportCreatePASS("Delete Message should get displayed successfully",
						"Delete Message should get displayed successfully", "Delete Message displayed successfully",
						"PASS");
			} else {
				actions.reportCreateFAIL("Delete Message should get displayed successfully",
						"Delete Message should get displayed successfully", "Delete Message not displayed successfully",
						"FAIL");
			}

			/** Click on Change Market button */
			// Navigate to Home first
			System.out.println("> Navigate to :: " + "Home");
			actions.select_menu("RFMHome.Navigation", "Home");

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			actions.WaitForElementPresent("RFM.STChangeMarketLink", 180);
			actions.click("RFM.STChangeMarketLink");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			// After navigating to Price Set, checking the Same Price set
			// present in Market-1 (i.e Not deleted in Market-1, though it is
			// deleted in Market-2)
			actions.setValue("RFMMassUpdatePrice.SearchText", strPriceSetName_2);
			actions.keyboardEnter("RestaurantProfile.Searchbtn");
			mcd.smartsync(120);

			// Validating for the presence of Price Set in Market-1
			String temp = mcd.GetTableCellValue("FieldPermissions.Table", 1, 1, "a", "");
			if (temp.equals(strPriceSetName_2)) {
				actions.reportCreatePASS("Verify the price set name",
						"Even after deleting a price set with same name on other market, it should not be deleted from this market",
						"Even after deleting a price set with same name on other market, it is not deleted from this market",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify the price set name",
						"Even after deleting a price set with same name on other market, it should not be deleted from this market",
						"Even after deleting a price set with same name on other market, it is deleted from this market",
						"FAIL");
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			// reporting the Fail condition
			actions.catchException(e);
		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}
}
