package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Keywords.DialogType;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class PRC_20106_CreatePriceSetWOCpy {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;
	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo, strWM, strwms, strNodeWm, strinvalidnode, strnodesearch, StrinvalidSearch;
	private boolean flag;
	private String strOperation, strActivity, strLevel, strUserID, strDBName, strleveldetails;
	private String strExpectLevelDetails[], strExpectlevel[];

	// TODO: Declare test-data variables for other data-parameters

	private String strNamePrefix;
	private String[] strPrcSetType;
	private String strResMessage;
	private String strTestPrc;
	private String strNodeNum;
	private String strMIAddMsg;

	public PRC_20106_CreatePriceSetWOCpy(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);
		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strWM = mcd.GetTestData("DT_WarningMessage");
		strNodeWm = mcd.GetTestData("DT_NodeWarng");
		strinvalidnode = mcd.GetTestData("DT_InvalidNode");
		strnodesearch = mcd.GetTestData("DT_SelectNodeWm");
		StrinvalidSearch = mcd.GetTestData("DT_InValidSearch");
		strwms = mcd.GetTestData("DT_MITWM");
		strOperation = mcd.GetTestData("DT_OPERATION");
		strActivity = mcd.GetTestData("DT_ACTIVITY");
		strLevel = mcd.GetTestData("DT_LEVEL");
		strDBName = mcd.GetTestData("DT_DBNAME");
		strUserID = mcd.GetTestData("DT_USER_NAME");
		strleveldetails = mcd.GetTestData("DT_LevelDetails");
		// TODO: GetTestData for other data-parameters

		strNamePrefix = mcd.GetTestData("NAME_PREFIX");
		strPrcSetType = mcd.GetTestData("PRC_SET_TYPE").split("#");
		strResMessage = mcd.GetTestData("RESULT_MSG");
		strTestPrc = mcd.GetTestData("TEST_PRC");
		strNodeNum = mcd.GetTestData("NODE_NUM");
		strMIAddMsg = mcd.GetTestData("MIADDITION_MSG");

		strExpectlevel = strLevel.split("#");
		strExpectLevelDetails = strleveldetails.split("#");
	}

	@Test
	public void PRC_20106_CreatePriceSetWOCpy() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription(
					"Verify creation of new Base/Promotion Price Set without copying existing price set");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();
			// ------------------------------------------------------------------------
			
			/** PRC_20106 **/
			
			// Create a Base Price Set without copying settings from existing
			// price set
			String strBasePrcSet = RFM_PRC_CreatePrcSetWOCpy(strPrcSetType[0], strResMessage, strTestPrc, strNodeNum,
					strApplicationDate, strMIAddMsg, strWM, strNodeWm, strnodesearch, StrinvalidSearch, strinvalidnode,
					"Active");

			if (!(strBasePrcSet.equals(null))) {
				actions.reportCreatePASS("Verify creation of Base Price Set w/o copying existing set",
						"Price Set should be created", "Price Set created successfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify creation of Base Price Set w/o copying existing set",
						"Price Set should be created", "Price Set not created", "FAIL");
			}
			actions.saveScenarioData("PRC_20106_CreatePriceSetWOCpy", "BasePriceSet", strBasePrcSet);
			
			
			/** PRC_20111 **/

			// Create a Promotion Price Set without copying settings from
			// existing price set
			actions.smartWait(20);
			String strPromPrcSet = RFM_PRC_CreatePromotionPrcSetWOCpy(strResMessage, strTestPrc, strNodeNum,
					strApplicationDate, strMIAddMsg, strwms, "Active");
			if (!(strPromPrcSet.equals(null))) {
				actions.reportCreatePASS("Verify creation of Promotion Price Set w/o copying existing set",
						"Price Set should be created", "Price Set created successfully", "PASS");
			} else {
				actions.reportCreateFAIL("Verify creation of Promotion Price Set w/o copying existing set",
						"Price Set should be created", "Price Set not created", "FAIL");
			}
			actions.saveScenarioData("PRC_20106_CreatePriceSetWOCpy", "PromotionalPriceSet", strPromPrcSet);

			// Verify Audit log details
			boolean AuditlogCorrectValuesDisplayed = rfm.VerifyAuditLog_Entry(strOperation, strActivity,
					strExpectlevel[0]);

			if (AuditlogCorrectValuesDisplayed) {
				actions.reportCreatePASS("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation," + "ActivityValue,Level",
						"Correct values are displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation," + "ActivityValue,Level",
						"Correct values are not displayed", "Fail");
			}

			String AuditDesc = "Current Setting for Price Set " + strPromPrcSet + " has been updated.";

			boolean isAuditlogCorrectValuesDisplayed = rfm.RFM_VerifyAuditLog_Details(strDBName, strUserID,
					strOperation, strActivity, strExpectlevel[1], strExpectLevelDetails[0], AuditDesc);

			if (isAuditlogCorrectValuesDisplayed) {
				actions.reportCreatePASS("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "Activities,Level & description ",
						"Correct values are displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "Activities,Level & description ",
						"Correct values are not displayed", "Fail");
			}

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	public String RFM_PRC_CreatePromotionPrcSetWOCpy(String strResMessage, String strTestPrc, String strNodeNum,
			String strApplicationDate, String strMIAddMsg, String strwms, String strStatus) throws Exception {
		String[] InfoMsg = strMIAddMsg.split("#");
		String[] wms = strwms.split("#");
		String[] testprc = strTestPrc.split("#");
		String strNamePrefix = "";
		boolean blnflag = true;

		// Verifying 'Search With Type' Filter
		Boolean searchwithtypw;
		Select selObj = new Select(driver.findElement(By.xpath(actions.getLocator("PriceSets.SearchType"))));
		searchwithtypw = selObj.getFirstSelectedOption().getText().trim().equalsIgnoreCase("All");
		reporting_Pass_Fail("Verify whether Search With Type All is selected by default for Status DDL",
				"Search With Type All should be selected by default", "Search With Type All is selected by default",
				"Search With Type All is not selected by default", searchwithtypw);

		// Verifying Search TextBox Editable
		Boolean promotionNameTextbox;
		promotionNameTextbox = actions.isElementPresent("PriceSet.SearchBox");
		reporting_Pass_Fail("Verify whether Search TextBox Editable", "Search TextBox  should be Editable",
				"Search TextBox is Editable", "Search TextBox Textbox is not Editable", promotionNameTextbox);

		// Verifying 'Status within status' Filter
		Boolean resultStatus;
		Select Obj = new Select(driver.findElement(By.xpath(actions.getLocator("PriceSets.SearchbyStatus"))));
		resultStatus = Obj.getFirstSelectedOption().getText().trim().equalsIgnoreCase("Active/Inactive");
		reporting_Pass_Fail("Verify whether Status within status Active/Inactive is selected by default for Status DDL",
				"Status within status Active/Inactive should be selected by default",
				"Status within status Active/Inactive is selected by default",
				"Status within status Active/Inactive is not selected by default", resultStatus);

		// Verifying presence of 'Search' Button
		Boolean Searchbutton;
		Searchbutton = actions.isElementPresent("CopySettingfrmMI.srchbtn");
		reporting_Pass_Fail("Verify whether 'Search' Button is present", "'Search' Button should be present",
				"'Search' Button is present", "'Search' Button is not present", Searchbutton);

		// Click on New price set Button
		actions.WaitForElementPresent("PriceSets.NewPriceSetBtn", 50);
		actions.click("PriceSets.NewPriceSetBtn");
		mcd.waitAndSwitch("New Price Sets");

		// Click on Promotion Radio Button And Selecting Start and End Date
		actions.click("NewPriceSet.PromRadioBtn");
		actions.click("NewPriceSet.StartDate");
		mcd.sel_current_date("NewPriceSet.StartDate", strApplicationDate);
		actions.click("NewPriceSet.EndDate");
		mcd.select_date("27", "next", "NewPriceSet.EndDate");

		// Enter unique Price Set Name
		String strNewPrcSet = null;
		strNewPrcSet = mcd.fn_GetRndName(strNamePrefix);
		strNewPrcSet = strNewPrcSet.subSequence(0, 10).toString();

		// Enter new price set name
		actions.click("AddNewDayPartSet.SelectBtn");
		mcd.waitAndSwitch("Select Node");
		actions.WaitForElementPresent("SelectNodeRest.SearchTextField", 180);
		mcd.Selectrestnode_JavaScriptClk("RFMSelectNode.SelectNodeTable", strNodeNum);
		mcd.waitAndSwitch("New Price Sets");
		do {
			strNewPrcSet = mcd.fn_GetRndName(strNamePrefix);
			strNewPrcSet = strNewPrcSet.subSequence(0, 10).toString();
			actions.WaitForElementPresent("NewPriceSet.Name", 180);
			actions.clear("NewPriceSet.Name");
			actions.setValue("NewPriceSet.Name", strNewPrcSet);
			Thread.sleep(500);

			// Click Next
			actions.keyboardEnter("NewPriceSet.Next");
			Thread.sleep(2000);
			actions.waitForPageToLoad(180);
			boolean blnWindow = false;
			try {
				blnWindow = mcd.SwitchToWindow("@Price Sets : Common Menu Item Selector");
				if (blnWindow) {
					System.out.println("Set Name and number accepted successfully");
					blnflag = false;
				} else {
					mcd.SwitchToWindow("New Price Sets");
					if (actions.isTextPresence(InfoMsg[1].trim(), true)) {
						blnflag = true;
						System.out.println("Entered  number " + strNewPrcSet + " is already exist.");
						System.out.println(blnflag);
					}

				}
			} catch (Exception e) {
				if (actions.isTextPresence(InfoMsg[1].trim(), true)) {
					blnflag = true;
					System.out.println("Entered  number " + strNewPrcSet + " is already exist.");
					System.out.println(blnflag);
				}
			}

		} while (blnflag == true);

		// Click on Save Button and verify alert message
		actions.keyboardEnter("RFM.SaveBtn");
		if (mcd.VerifyAlertMessageDisplayed("Information", wms[0], true, AlertPopupButton.OK_BUTTON)) {
			actions.reportCreatePASS("Veriyfing the '" + wms[0] + " 'is Present or not", wms[0] + " should be present",
					wms[0] + " is present", "Pass");
		} else {
			actions.reportCreateFAIL("Veriyfing the '" + wms[0] + " 'is Present or not", wms[0] + " should be present",
					wms[0] + " is not present", "Fail");
		}
		// Click View Full List
		actions.keyboardEnter("RFM.ViewFullListBtn");
		Thread.sleep(1000);
		actions.smartWait(180);

		// Check MI to add
		WebElement eleMIfrPrcSet = mcd.GetTableCellElement("Deposit.AddDepositTable", 1, "Add", "input");
		// eleMIfrPrcSet.sendKeys(Keys.SPACE);
		actions.javaScriptClick(eleMIfrPrcSet);
		actions.click("RFM.SaveBtn");
		mcd.SwitchToWindow("#Title");
		actions.verifyTextPresence(InfoMsg[0], true);

		// In Quick tool, in 'All prices' textbox, Enter the value with more
		// than 2 decimal places and click on Apply button
		actions.clear("ManagePS.AllPrice");
		actions.setValue("ManagePS.AllPrice", testprc[1]);
		actions.keyboardEnter("ManagePS.QuickToolApply");
		if (mcd.VerifyAlertMessageDisplayed("Information", wms[1], true, AlertPopupButton.OK_BUTTON)) {
			actions.reportCreatePASS("Veriyfing the '" + wms[1] + " 'is Present or not", wms[1] + " should be present",
					wms[1] + " is present", "Pass");
		} else {
			actions.reportCreateFAIL("Veriyfing the '" + wms[1] + " 'is Present or not", wms[1] + " should be present",
					wms[1] + " is not present", "Fail");
		}

		// Select radio button for Eatin prices and Enter price value with more
		// than 2 decimal places in eatin , takeout and other prices, one after
		// other and click on Apply button
		actions.javaScriptClick("PriceSet.AllPriceTypeRadioBtn");
		actions.clear("PriceSets.EatinPriceId");
		actions.setValue("PriceSets.EatinPriceId", testprc[1]);
		actions.clear("PriceSets.TakeOutPriceId");
		actions.setValue("PriceSets.TakeOutPriceId", testprc[1]);
		actions.clear("PriceSets.OtherPrices");
		actions.setValue("PriceSets.OtherPrices", testprc[1]);
		actions.keyboardEnter("ManagePS.QuickToolApply");
		if (mcd.VerifyAlertMessageDisplayed("Information", wms[1], true, AlertPopupButton.OK_BUTTON)) {
			actions.reportCreatePASS("Veriyfing the '" + wms[1] + " 'is Present or not", wms[1] + " should be present",
					wms[1] + " is present", "Pass");
		} else {
			actions.reportCreateFAIL("Veriyfing the '" + wms[1] + " 'is Present or not", wms[1] + " should be present",
					wms[1] + " is not present", "Fail");
		}

		// Enter the value having upto 2 decimal places in Eatin, takeout and
		// other prices
		actions.clear("PriceSets.EatinPriceId");
		actions.setValue("PriceSets.EatinPriceId", testprc[0]);
		actions.clear("PriceSets.TakeOutPriceId");
		actions.setValue("PriceSets.TakeOutPriceId", testprc[0]);
		actions.clear("PriceSets.OtherPrices");
		actions.setValue("PriceSets.OtherPrices", testprc[0]);
		actions.keyboardEnter("ManagePS.QuickToolApply");
		actions.smartWait(10);
		actions.keyboardEnter("PriceSet.ApplyButton");
		actions.smartWait(20);
		actions.verifyTextPresence(strResMessage, true);
		Thread.sleep(2000);
		actions.WaitForElementPresent("ManagePS.PPPrcSetFilter", 180);
		actions.setValue("ManagePS.PPPrcSetFilter", strStatus);
		actions.keyboardEnter("PriceSet.ApplyButton");
		actions.smartWait(50);
		actions.verifyTextPresence(strResMessage, false);

		// Click on cancel to close the page
		actions.click("NewPriceSet.Cancel");
		mcd.SwitchToWindow("#Title");
		return strNewPrcSet;
		
	}

	public String RFM_PRC_CreatePrcSetWOCpy(String strPrcSetType, String strResMessage, String strTestPrc,
			String strNodeNum, String strApplicationDate, String strMIAddMsg, String strWM, String strNodeWm,
			String strnodesearch, String StrinvalidSearch, String strinvalidnode, String strStatus) throws Exception {
		String[] InfoMsg = strMIAddMsg.split("#");
		String[] testprc = strTestPrc.split("#");
		String strNamePrefix = "";
		boolean blnflag = true;

		// Get the text of First price set
		actions.smartWait(20);
		String Pricesetname = driver.findElement(By.xpath(actions.getLocator("RestaurantProfile.TableFirstValue")))
				.getText();
		System.out.println(Pricesetname);

		// Verifying 'Search With Type' Filter
		Boolean searchwithtypw;
		Select selObj = new Select(driver.findElement(By.xpath(actions.getLocator("PriceSets.SearchType"))));
		searchwithtypw = selObj.getFirstSelectedOption().getText().trim().equalsIgnoreCase("All");
		reporting_Pass_Fail("Verify whether Search With Type All is selected by default for Status DDL",
				"Search With Type All should be selected by default", "Search With Type All is selected by default",
				"Search With Type All is not selected by default", searchwithtypw);

		// Verifying Search TextBox Editable
		Boolean promotionNameTextbox;
		promotionNameTextbox = actions.isElementPresent("PriceSet.SearchBox");
		reporting_Pass_Fail("Verify whether Search TextBox Editable", "Search TextBox  should be Editable",
				"Search TextBox is Editable", "Search TextBox Textbox is not Editable", promotionNameTextbox);

		// Verifying 'Status within status' Filter
		Boolean resultStatus;
		Select Obj = new Select(driver.findElement(By.xpath(actions.getLocator("PriceSets.SearchbyStatus"))));
		resultStatus = Obj.getFirstSelectedOption().getText().trim().equalsIgnoreCase("Active/Inactive");
		reporting_Pass_Fail("Verify whether Status within status Active/Inactive is selected by default for Status DDL",
				"Status within status Active/Inactive should be selected by default",
				"Status within status Active/Inactive is selected by default",
				"Status within status Active/Inactive is not selected by default", resultStatus);

		// Verifying presence of 'Search' Button
		Boolean Searchbutton;
		Searchbutton = actions.isElementPresent("CopySettingfrmMI.srchbtn");
		reporting_Pass_Fail("Verify whether 'Search' Button is present", "'Search' Button should be present",
				"'Search' Button is present", "'Search' Button is not present", Searchbutton);

		// Click on New price set Button
		actions.WaitForElementPresent("PriceSets.NewPriceSetBtn", 50);
		actions.click("PriceSets.NewPriceSetBtn");
		mcd.waitAndSwitch("New Price Sets");
		actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
		// Don�t enter price set name and click on Next button
		actions.keyboardEnter("NewPriceSet.Next");
		if (mcd.VerifyAlertMessageDisplayed("Information", strWM, true, AlertPopupButton.OK_BUTTON)) {
			actions.reportCreatePASS("Veriyfing the '" + strWM + " 'is Present or not", strWM + " should be present",
					strWM + " is present", "Pass");
		} else {
			actions.reportCreateFAIL("Veriyfing the '" + strWM + " 'is Present or not", strWM + " should be present",
					strWM + " is not present", "Fail");
		}

		// Enter Price Set name with more than 60 characters
		String strVal2;
		strVal2 = generateString('c', 61);
		System.out.println(strVal2.length());
		actions.clear("NewPriceSets.TextBox");
		actions.setValue("NewPriceSets.TextBox", strVal2);
		String charc = driver.findElement(By.xpath(actions.getLocator("NewPriceSets.TextBox"))).getAttribute("value");
		System.out.println(charc.length());
		if (charc.length() >= 60) {
			actions.reportCreatePASS("verify the whether group name search box accepected more than 60 Characters",
					"group name search box should be accepected more than 60 Characters",
					"group name search box should not  be accepected more than 60 Characters", "PASS");
		} else {
			actions.reportCreateFAIL("verify the whether group name box accepected 60 characters",
					"group name search box should be accepected more than 60 Characters ",
					"group name search box should be accepected more than 60 Characters", "FAIL");
		}

		// Enter Price Set name, don�t select node and click on Next button
		actions.clear("NewPriceSets.TextBox");
		actions.setValue("NewPriceSets.TextBox", "Price Set");
		actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
		actions.keyboardEnter("NewPriceSet.Next");
		if (mcd.VerifyAlertMessageDisplayed("Information", strNodeWm, true, AlertPopupButton.OK_BUTTON)) {
			actions.reportCreatePASS("Veriyfing the '" + strNodeWm + " 'is Present or not",
					strNodeWm + " should be present", strNodeWm + " is present", "Pass");
		} else {
			actions.reportCreateFAIL("Veriyfing the '" + strNodeWm + " 'is Present or not",
					strNodeWm + " should be present", strNodeWm + " is not present", "Fail");
		}

		// Click on Select button
		actions.smartWait(10);
		actions.click("AddNewDayPartSet.SelectBtn");
		mcd.waitAndSwitch("Select Node");
		actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
		// Don�t enter search criteria and click on Search button
		actions.click("SelectNodeRest.SearchButton");
		if (mcd.VerifyAlertMessageDisplayed("Information", strnodesearch, true, AlertPopupButton.OK_BUTTON)) {
			actions.reportCreatePASS("Veriyfing the '" + strnodesearch + " 'is Present or not",
					strnodesearch + " should be present", strnodesearch + " is present", "Pass");
		} else {
			actions.reportCreateFAIL("Veriyfing the '" + strnodesearch + " 'is Present or not",
					strnodesearch + " should be present", strnodesearch + " is not present", "Fail");
		}

		// Enter invalid node and click on search button
		actions.clear("SelectNodeRest.SearchTextField");
		actions.setValue("SelectNodeRest.SearchTextField", StrinvalidSearch);
		actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
		actions.keyboardEnter("SelectNodeRest.SearchButton");
		if (mcd.VerifyAlertMessageDisplayed("Information", strinvalidnode, true, AlertPopupButton.OK_BUTTON)) {
			actions.reportCreatePASS("Veriyfing the '" + strinvalidnode + " 'is Present or not",
					strinvalidnode + " should be present", strinvalidnode + " is present", "Pass");
		} else {
			actions.reportCreateFAIL("Veriyfing the '" + strinvalidnode + " 'is Present or not",
					strinvalidnode + " should be present", strinvalidnode + " is not present", "Fail");
		}

		// Select 'Market' Node from Select Node section
		actions.clear("SelectNodeRest.SearchTextField");
		actions.closeWindow();
		mcd.SwitchToWindow("New Price Sets");
		actions.click("AddNewDayPartSet.SelectBtn");
		mcd.waitAndSwitch("Select Node");
		mcd.Selectrestnode_JavaScriptClk("RFMSelectNode.SelectNodeTable", strNodeNum);
		mcd.SwitchToWindow("New Price Sets");

		// Enter duplicate or existing Price Set name and click on Next button
		actions.closeWindow();
		mcd.SwitchToWindow("@Title");
		actions.smartWait(10);
		actions.WaitForElementPresent("PriceSets.NewPriceSetBtn", 50);
		actions.click("PriceSets.NewPriceSetBtn");
		mcd.waitAndSwitch("New Price Sets");
		actions.clear("NewPriceSets.TextBox");
		actions.setValue("NewPriceSets.TextBox", Pricesetname);
		actions.smartWait(10);
		actions.click("AddNewDayPartSet.SelectBtn");
		mcd.waitAndSwitch("Select Node");
		actions.WaitForElementPresent("SelectNodeRest.SearchTextField", 180);
		mcd.Selectrestnode_JavaScriptClk("RFMSelectNode.SelectNodeTable", strNodeNum);
		mcd.waitAndSwitch("New Price Sets");
		actions.keyboardEnter("NewPriceSet.Next");
		actions.smartWait(20);

		// Verify On-Screen Message
		flag = mcd.VerifyOnscreenMessage("AdvanceSettings.ActionMessage",
				"Price Set name already exists, please enter a different Price Set Name.", true);

		if (flag) {
			actions.reportCreatePASS("Verify the on-screen message",
					"Message 'Price Set name already exists, please enter a different Price Set Name.'",
					"Expected Message is displayed", "PASS");
		} else {
			actions.reportCreateFAIL("Verify the on-screen message",
					"Message 'Price Set name already exists, please enter a different Price Set Name.'",
					"Expected Message is not displayed", "FAIL");
		}

		// Enter valid Price Set Name and click on Next button
		actions.closeWindow();
		mcd.SwitchToWindow("@Title");
		actions.WaitForElementPresent("PriceSets.NewPriceSetBtn", 50);
		actions.click("PriceSets.NewPriceSetBtn");
		mcd.waitAndSwitch("New Price Sets");

		// Enter unique Price Set Name
		String strNewPrcSet = null;
		strNewPrcSet = mcd.fn_GetRndName(strNamePrefix);
		strNewPrcSet = strNewPrcSet.subSequence(0, 10).toString();

		// Enter new price set name
		actions.click("AddNewDayPartSet.SelectBtn");
		mcd.waitAndSwitch("Select Node");
		actions.WaitForElementPresent("SelectNodeRest.SearchTextField", 180);
		mcd.Selectrestnode_JavaScriptClk("RFMSelectNode.SelectNodeTable", strNodeNum);
		mcd.waitAndSwitch("New Price Sets");
		do {
			strNewPrcSet = mcd.fn_GetRndName(strNamePrefix);
			strNewPrcSet = strNewPrcSet.subSequence(0, 10).toString();
			actions.WaitForElementPresent("NewPriceSet.Name", 180);
			actions.clear("NewPriceSet.Name");
			actions.setValue("NewPriceSet.Name", strNewPrcSet);
			

			// Click Next
			actions.keyboardEnter("NewPriceSet.Next");
			boolean blnWindow = false;
			try {
				blnWindow = mcd.SwitchToWindow("@Price Sets : Common Menu Item Selector");
				if (blnWindow) {
					System.out.println("Set Name and number accepted successfully");
					blnflag = false;
				} else {
					mcd.SwitchToWindow("New Price Sets");
					if (actions.isTextPresence(InfoMsg[1].trim(), true)) {
						blnflag = true;
						System.out.println("Entered  number " + strNewPrcSet + " is already exist.");
						System.out.println(blnflag);
					}

				}
			} catch (Exception e) {
				if (actions.isTextPresence(InfoMsg[1].trim(), true)) {
					blnflag = true;
					System.out.println("Entered  number " + strNewPrcSet + " is already exist.");
					System.out.println(blnflag);
				}
			}

		} while (blnflag == true);

		/** adding the menu item now */
		actions.WaitForElementPresent("CommonMenuItemSelector.ViewFullListBtn",10);
		actions.keyboardEnter("CommonMenuItemSelector.ViewFullListBtn");
		actions.smartWait(50);
		
		
		/** Selecting the record & saving it */
		WebElement elem_checkbox = mcd.GetTableCellElement("AddRemoveComponent.webtable", 6, "Add", "input");
		actions.javaScriptClick(elem_checkbox);
		WebElement elem_checkbox1 = mcd.GetTableCellElement("AddRemoveComponent.webtable", 7, "Add", "input");
		actions.javaScriptClick(elem_checkbox1);
		actions.WaitForElementPresent("RFM.SaveBtn", 180);
		actions.click("RFM.SaveBtn");
		actions.smartWait(50);
		mcd.SwitchToWindow("#Title");
		actions.verifyTextPresence(InfoMsg[0], true);
		actions.clear("ManagePS.AllPrice");
		Thread.sleep(500);
		actions.setValue("ManagePS.AllPrice", testprc[0]);
		Thread.sleep(500);
		actions.click("ManagePS.QuickToolApply");
		Thread.sleep(2000);
		actions.WaitForElementPresent("ManagePS.PPPrcSetFilter", 180);
		actions.setValue("ManagePS.PPPrcSetFilter", strStatus);
		actions.click("ManagePS.PPALLSave");
		Thread.sleep(1000);
		actions.smartWait(180);
		actions.verifyTextPresence(strResMessage, false);

		// Click on cancel to close the page
		actions.click("NewPriceSet.Cancel");
		mcd.SwitchToWindow("#Title");
		return strNewPrcSet;
	}

	// Function for Reporting Pass/Fail
	public void reporting_Pass_Fail(String Desc, String ExpRes, String ActRes_Pass, String ActRes_Fail,
			Boolean status) {
		if (status) {
			actions.reportCreatePASS(Desc, ExpRes, ActRes_Pass, "PASS");
		}

		if (!status) {
			actions.reportCreateFAIL(Desc, ExpRes, ActRes_Fail, "FAIL");
		}
	}
	// To generate the string of specific size

	public static String generateString(char c, Integer n) {
		StringBuilder b = new StringBuilder();
		for (Integer x = 0; x < n; x++)
			b.append(c);
		return b.toString();
	}

}
