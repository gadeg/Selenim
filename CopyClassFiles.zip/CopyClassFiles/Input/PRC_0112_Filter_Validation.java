package xtam.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class PRC_0112_Filter_Validation {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo, promotionset, inactive_set, str_act_inact, stractive, strinactive, strbase,
			strpromotional, strAll;

	private String strNewPrcSet, strPrcSetType, strResMessage, strNodeNum, strNumOfMenuItem1, strStatus_Msg,
			strNewPrice1, strStatus;

	public PRC_0112_Filter_Validation(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");

		// TODO: GetTestData for other data-parameters

		promotionset = mcd.GetTestData("DT_PROMOTION");
		inactive_set = mcd.GetTestData("DT_INACTIVE");
		str_act_inact = mcd.GetTestData("DT_ACT_INACT");
		stractive = mcd.GetTestData("DT_ACTIVE");
		strinactive = mcd.GetTestData("DT_INACTIVE");
		strbase = mcd.GetTestData("BAST_TYPE");
		strpromotional = mcd.GetTestData("PRO_TYPE");
		strAll = mcd.GetTestData("DT_ALL");

		strNewPrcSet = mcd.GetTestData("PriceSet_Name");
		strPrcSetType = mcd.GetTestData("PriceSetType");
		strResMessage = mcd.GetTestData("Result_Message");
		strNodeNum = mcd.GetTestData("NodeNum");
		strNumOfMenuItem1 = mcd.GetTestData("NumOfMenuItem1");
		strStatus_Msg = mcd.GetTestData("Status_Msg");
		strNewPrice1 = mcd.GetTestData("NewPrice1");
		// strStatus = mcd.GetTestData("Status");

	}

	@Test
	public void test_PRC_0112_Filter_Validation() throws InterruptedException {

		try {

			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription(
					"Verify the Search Price Set by type 'Base and Promotional' and  status 'Active and Inactive 'functionality");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			// Creating new priceset for base
			String strpriceset1 = RFM_PRC_Create_PriceSet(strNewPrcSet, strPrcSetType, strResMessage, strNodeNum,
					strNumOfMenuItem1, strStatus_Msg, strNewPrice1, stractive);
			actions.smartWait(180);

			// Selecting ALL from search with type ddl
			actions.setValue("MenuItempriceByPriceSetReport.PriceTypeDDL", "All");
			int rc = mcd.GetTableRowCount("FieldPermissions.Table");
			if (rc > 0) {
				actions.reportCreatePASS("Verify all records", "All record should be display",
						"All records are displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify all records", "All record should be display",
						"All records are displayed", "FAIL");

			}

			// Enter invalid price set name and click search button
			actions.setValue("ProductionRouting.SearchTextField", "AAAAAA");
			actions.keyboardEnter("SetAssignmentReport.SearchButton");
			actions.smartWait(180);
			actions.verifyTextPresence("Search returned no matching results.", true);
			actions.clear("ProductionRouting.SearchTextField");
			actions.keyboardEnter("SetAssignmentReport.SearchButton");
			actions.smartWait(180);

			// Enter valid base price set name in search text box and click on
			// Search button and verify the fields
			CheckingTextinAllColumns(strpriceset1, str_act_inact, strbase);

			// Taking promotional set from manage price set table
			actions.clear("ProductionRouting.SearchTextField");
			actions.setValue("ProductionRouting.SearchTextField", "P");
			actions.setValue("MenuItempriceByPriceSetReport.PriceTypeDDL", "Promotional");
			actions.keyboardEnter("SetAssignmentReport.SearchButton");
			actions.smartWait(180);
			String promotionset_Name = driver.findElement(By.xpath(actions.getLocator("MasterMenuItemList.NumberLink")))
					.getText();

			// Select Promotional from search with type DDL, enter valid price
			// set in search text box and click on search button and verify the
			// fields
			CheckingTextinAllColumns(promotionset_Name, str_act_inact, strpromotional);

			// Verifying manage price set table columns
			verifyTablecolumnsPresent("FieldPermissions.Table", "Name");
			verifyTablecolumnsPresent("FieldPermissions.Table", "Node");
			verifyTablecolumnsPresent("FieldPermissions.Table", "Type");
			verifyTablecolumnsPresent("FieldPermissions.Table", "Status");
			verifyTablecolumnsPresent("FieldPermissions.Table", "Delete");

			// Changing price set status
			actions.clear("ProductionRouting.SearchTextField");
			actions.setValue("ProductionRouting.SearchTextField", strpriceset1);
			actions.setValue("MenuItempriceByPriceSetReport.PriceTypeDDL", "Base");
			actions.keyboardEnter("SetAssignmentReport.SearchButton");
			actions.smartWait(180);
			String priceset_Status = driver.findElement(By.xpath(actions.getLocator("ManagePriceSets.Status")))
					.getText();
			actions.keyboardEnter("MasterMenuItemList.NumberLink");
			actions.smartWait(180);
			if (priceset_Status.equals("Active")) {
				actions.setValue("ManagePS.Status", "Inactive");
			} else {
				actions.setValue("ManagePS.Status", "Active");
			}

			actions.keyboardEnter("PriceSet.ApplyButton");
			actions.smartWait(180);
			actions.verifyTextPresence("Your changes have been saved.", true);
			actions.keyboardEnter("RFM.CancelBtn");
			actions.smartWait(180);

			// Select Base from search with type DDL, enter promotional price
			// set name in search text box and click on search button
			actions.setValue("MenuItempriceByPriceSetReport.PriceTypeDDL", "Base");
			actions.clear("ProductionRouting.SearchTextField");
			actions.setValue("ProductionRouting.SearchTextField", promotionset_Name);
			actions.keyboardEnter("SetAssignmentReport.SearchButton");
			actions.smartWait(180);
			actions.verifyTextPresence("Search returned no matching results.", true);

			// Select Promotional from search with type DDL, enter Base price
			// set name in search text box and click on search button
			actions.setValue("MenuItempriceByPriceSetReport.PriceTypeDDL", "Promotional");
			actions.clear("ProductionRouting.SearchTextField");
			actions.setValue("ProductionRouting.SearchTextField", strpriceset1);
			actions.keyboardEnter("SetAssignmentReport.SearchButton");
			actions.smartWait(180);
			actions.verifyTextPresence("Search returned no matching results.", true);

			// Enter Price Set name in search text box, select 'Active' from
			// status DDL and click on Search button and verify fields
			actions.setValue("MenuItempriceByPriceSetReport.PriceTypeDDL", "All");
			actions.clear("ProductionRouting.SearchTextField");
			actions.keyboardEnter("SetAssignmentReport.SearchButton");
			actions.smartWait(180);
			actions.setValue("PricingSets.StatusFilter", "Active");
			actions.smartWait(180);
			String active_string = driver
					.findElement(By.xpath(actions.getLocator("MasterMenuItemList.tableFirstElement"))).getText();
			CheckingTextinAllColumns(active_string, stractive, strAll);

			// Enter Price Set name in search text box, select 'Inactive' from
			// status DDL and click on Search button and verify the fields
			actions.setValue("MenuItempriceByPriceSetReport.PriceTypeDDL", "All");
			actions.clear("ProductionRouting.SearchTextField");
			actions.keyboardEnter("SetAssignmentReport.SearchButton");
			actions.smartWait(180);
			actions.setValue("PricingSets.StatusFilter", "Inactive");
			actions.smartWait(180);

			String inactive_string = driver
					.findElement(By.xpath(actions.getLocator("MasterMenuItemList.tableFirstElement"))).getText();

			CheckingTextinAllColumns(inactive_string, inactive_set, strAll);

			// Enter Inactive Price Set name in search text box, select 'Active'
			// from status DDL and click on Search button
			actions.clear("ProductionRouting.SearchTextField");
			actions.setValue("ProductionRouting.SearchTextField", inactive_string);
			actions.setValue("ManageDimensionGroups.SearchWithinStatus", "Active");
			actions.keyboardEnter("SetAssignmentReport.SearchButton");
			actions.smartWait(180);
			actions.verifyTextPresence("Search returned no matching results.", true);

			// Enter Active Price Set name in search text box, select 'Inactive'
			// from status DDL and click on Search button
			actions.clear("ProductionRouting.SearchTextField");
			actions.setValue("ProductionRouting.SearchTextField", active_string);
			actions.setValue("ManageDimensionGroups.SearchWithinStatus", "Inactive");
			actions.keyboardEnter("SetAssignmentReport.SearchButton");
			actions.smartWait(180);
			actions.verifyTextPresence("Search returned no matching results.", true);

			/** Logout the application */
			rfm.Logout();

		} catch (

		Exception e)

		{

			// reporting the Fail condition
			actions.catchException(e);

		} finally

		{
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}

	}

	// VERIFYING TABLE COLUMS CODE
	public void verifyTablecolumnsPresent(String tableLocator, String colName) {

		boolean iscolPresent = mcd.RFM_VerifyTableColumns(tableLocator, colName);

		if (iscolPresent) {
			actions.reportCreatePASS("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is present in table", "Pass");
		} else {
			actions.reportCreateFAIL("Verify " + colName + " Column is present in table",
					colName + " Column should be present in table", colName + " Column is NOT present in table",
					"Fail");
		}
	}

	public void CheckingTextinAllColumns(String PricSetName, String Status, String Statustype) {
		actions.clear("ProductionRouting.SearchTextField");
		actions.setValue("ProductionRouting.SearchTextField", PricSetName);
		actions.setValue("PricingSets.StatusFilter", Status);
		actions.setValue("MenuItempriceByPriceSetReport.PriceTypeDDL", Statustype);
		actions.keyboardEnter("SetAssignmentReport.SearchButton");
		actions.smartWait(180);
		List<WebElement> ele_ManagePriceSet_Values_FirstRow = driver
				.findElements(By.xpath("//*[@id='priceSetData']/tr[1]/td"));
		boolean flag = false;
		if (ele_ManagePriceSet_Values_FirstRow.size() == 5) {

			for (int i = 0; i < ele_ManagePriceSet_Values_FirstRow.size() - 1; i++) {

				if (!ele_ManagePriceSet_Values_FirstRow.get(i).getText().isEmpty()) {
					flag = true;
				} else {
					flag = false;
				}
				if (!flag) {
					actions.reportCreateFAIL("Verifying column values", "Column values should display",
							"Column values are not displayed", "FAIL");
					break;
				}
			}

		} else {
			actions.reportCreateFAIL("Verifying Values of first row", "First row values should display",
					"First row values are not display", "FAIL");
		}

		if (flag) {
			actions.reportCreatePASS("Verifying column values", "Column values should display",
					"Column values are  displayed", "PASS");

			if (ele_ManagePriceSet_Values_FirstRow.get(2).getText().contentEquals("B")
					|| ele_ManagePriceSet_Values_FirstRow.get(2).getText().contentEquals("P")) {
				actions.reportCreatePASS("Verify type column values", "Column type values should be P or B",
						"Column type value is :" + ele_ManagePriceSet_Values_FirstRow.get(2).getText(), "PASS");
			} else {
				actions.reportCreateFAIL("Verify type column values", "Column type values should be P or B",
						"Column type value is :" + ele_ManagePriceSet_Values_FirstRow.get(2).getText(), "FAIL");
			}

			if (ele_ManagePriceSet_Values_FirstRow.get(3).getText().contains("Active")
					|| ele_ManagePriceSet_Values_FirstRow.get(3).getText().contains("Inactive")) {
				actions.reportCreatePASS("Verify status column values",
						"Column status values should be Active or Inactive",
						"Column type value is :" + ele_ManagePriceSet_Values_FirstRow.get(3).getText(), "PASS");
			} else {
				actions.reportCreateFAIL("Verify status column values",
						"Column status values should be Active or Inactive",
						"Column type value is :" + ele_ManagePriceSet_Values_FirstRow.get(3).getText(), "FAIL");
			}
		}
	}

	// Creating new prices set
	public String RFM_PRC_Create_PriceSet(String strNewPrcSet, String strPrcSetType, String strResMessage,
			String strNodeNum, String strNumOfMenuItem, String strStatus_Msg, String strNewPrice, String strStatus)
			throws Exception {

		/** Get application time */
		WebElement apptime = mcd.getdate();
		String strApplicationDate = apptime.getText();

		int iTemp = 0;
		actions.click("PriceSet.NewBtn");
		Thread.sleep(2000);

		// Switch to New Price Sets window
		mcd.SwitchToWindow("New Price Sets");
		switch (strPrcSetType) {
		case "Base":
			strNewPrcSet = mcd.fn_GetRndName("Base");
			break;
		case "Promotion":
			strNewPrcSet = mcd.fn_GetRndName("Prom");
			break;
		default:

			actions.reportCreateFAIL("Verfiy data", "Enter correct price set name", "Incorrect data", "FAIL");
			break;
		}

		// Enter new price set name :
		actions.WaitForElementPresent("NewPriceSet.Name", 180);
		actions.setValue("NewPriceSet.Name", strNewPrcSet);
		Thread.sleep(500);
		actions.click("NewPriceSet.SelectNode");

		// Switch to Select Node Window and selecting restaurant
		mcd.SwitchToWindow("Select Node");
		actions.click("SelectNode.ExactMtchRadiobtn");
		Thread.sleep(500);
		actions.setValue("SelectNode.SearchBox", strNodeNum);
		Thread.sleep(500);
		actions.keyboardEnter("SelectNode.SearchButton");
		Thread.sleep(1000);
		actions.waitForPageToLoad(120);
		Boolean Node_chk = mcd.Selectrestnode_JavaScriptClk("SelectNode.NodeTable", strNodeNum);
		Thread.sleep(2000);
		mcd.SwitchToWindow("New Price Sets");

		switch (strPrcSetType) {
		case "Base":

			actions.keyboardEnter("NewPriceSet.BaseRadioBtn");
			Thread.sleep(1000);
			break;
		case "Promotion":

			actions.javaScriptClick("NewPriceSet.PromRadioBtn");
			Thread.sleep(1000);
			driver.findElement(By.id("startDateAnchor")).click();
			mcd.Get_future_date(0, "close", strApplicationDate);
			driver.findElement(By.id("endDateAnchor")).click();
			mcd.Get_future_date(3, "close", strApplicationDate);

			break;
		default:
			System.out.println("Please enter correct Price Set Type (Base/Promotion)");
			break;
		}

		// Click Next
		actions.keyboardEnter("NewPriceSet.Next");
		Thread.sleep(5000);
		actions.waitForPageToLoad(120);
		mcd.SwitchToWindow("@Price Sets");
		driver.switchTo().window("");
		mcd.SwitchToWindow("@Price Sets : Common Menu Item Selector");

		// Switch to Price Sets : Common Menu Item Selector - to add new menu
		actions.keyboardEnter("CommonSelector.ViewFullBtn");
		Thread.sleep(10000);
		actions.setValue("CommonSelector.AvailabilityDrpDwn", "Available");
		Thread.sleep(7000);
		List<WebElement> Add_Chkbox = driver
				.findElements(By.xpath(".//input[@type = 'checkbox'][contains(@onclick, 'addMenuItem')]"));
		int Item_Counts = Add_Chkbox.size();
		List<String> MnuItem_Names = new ArrayList<String>();
		int i_temp = 0;
		for (int n = 0; n <= Item_Counts; n++) {
			if ((Add_Chkbox.get(n).isEnabled())) {
				Add_Chkbox.get(n).sendKeys(Keys.SPACE);
				String p = Integer.toString(n + 1);
				String e = driver.findElement(By.xpath("//*[@id='commonTableBody']/tr[" + p + "]/td[4]")).getText();
				MnuItem_Names.add(e);

				i_temp++;
			} else {
				System.out.println("This MI is already added");
			}

			if (i_temp == Integer.parseInt(strNumOfMenuItem)) {
				System.out.println("Selected items for Add MI");
				break;
			}
			Thread.sleep(1000);
		}

		// Save Changes and Verify success message
		actions.keyboardEnter("CommonSelector.Save");
		actions.smartWait(180);
		actions.verifyTextPresence(strResMessage, true);
		actions.verifyTextPresence(strResMessage, true);

		String CreatedPS_msg = null;
		CreatedPS_msg = "Manage Price Set : " + strNewPrcSet;
		actions.verifyTextPresence(CreatedPS_msg, true);
		String currStatus = actions.getValue("ManagePS.Status");
		if (!currStatus.equals(strStatus)) {
			actions.setValue("ManagePS.Status", strStatus);
			Thread.sleep(1000);

			// Set price to all menu items
			actions.clear("UpdtMultipleSet.AllPrc");
			Thread.sleep(2000);
			actions.clear("UpdtMultipleSet.AllPrc");
			Thread.sleep(1000);
			actions.setValue("UpdtMultipleSet.AllPrc", strNewPrice);
			Thread.sleep(1000);
			actions.click("UpdtMultipleSet.Apply");
			Thread.sleep(20000);

			// Save changes
			actions.click("NewPriceSet.SaveBtn");
			actions.smartWait(180);

		}

		Thread.sleep(5000);

		// Verify success message for status & price updates
		actions.verifyTextPresence(strStatus_Msg, true);
		actions.reportCreatePASS("Verify price set set active", "Price set should be set as active",
				"Price set saved as active", "PASS");

		actions.keyboardEnter("RFM.CancelBtn");
		actions.smartWait(180);
		return strNewPrcSet;
	}

}
