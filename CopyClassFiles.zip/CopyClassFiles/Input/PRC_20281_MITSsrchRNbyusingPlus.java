/**
 * 
 */
package xtam.test;

import java.util.List;
/**
 * @author akrani
 *
 */
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;


public class PRC_20281_MITSsrchRNbyusingPlus {
       private Keywords actions;
       private WebDriver driver;
       private Map input;
       private UIValidations uiActions;
       private SoftAssert softAssert = new SoftAssert();
       
       private lib_MCD mcd;
       private lib_RFM2 rfm;
       
       private String strApplicationDate;
       
       // Test-Data Variables
       private Object strURL;
       private Object strUserName;
       private Object strPassword;
       private String strMarket;
       private String strNavigateTo;
       // TODO: Declare test-data variables for other data-parameters
       private String strErrMsg,Rest_String,strNode;
       boolean flag=false,blnSrch=false;
       
       public PRC_20281_MITSsrchRNbyusingPlus (WebDriver nodeDriver, Map inputData, Object or){
              driver = nodeDriver;
              input = inputData;
              actions = new Keywords(driver, or);
              uiActions = new UIValidations();
              
              mcd = new lib_MCD (driver, actions, uiActions, inputData);
              rfm = new lib_RFM2 (driver, actions, uiActions, inputData, mcd);

              // Read input Test-Data
              strURL                     = mcd.GetTestData("DT_URL");
              strUserName   = mcd.GetTestData("DT_USER_NAME");
              strPassword   = mcd.GetTestData("DT_PASSWORD");
              strMarket            = mcd.GetTestData("DT_MARKET");
              strNavigateTo        = mcd.GetTestData("DT_NAVIGATE_TO");
              // TODO: GetTestData for other data-parameters
              strErrMsg			   = mcd.GetTestData("DT_ERROR");
              strNode			   = mcd.GetTestData("DT_NODE");
       }
       
       @Test
       public void test_PRC_20281_MITSsrchRNbyusingPlus() throws InterruptedException {             
              try {
                     System.out.println("********************************************************************** Test execution starts");
					 actions.setTestcaseDescription("Search Multiple Restaurants by Restaurant Number or Restaurant name by using �+� as a separator");
                     /** Launch and Login RFM */
                     System.out.println("> Launch and Login RFM");
                     rfm.LaunchAndLogin(strURL, strUserName, strPassword);
                     
                     /** Select Market (Node) */
                     System.out.println("> Select Market (Node)");
                     rfm.SelectMarket(strMarket);
              
                     /** Select Menu Option */
                     System.out.println("> Navigate to :: " + strNavigateTo);
                     actions.select_menu("RFMHome.Navigation",strNavigateTo);
                     Thread.sleep(2000);
                     actions.waitForPageToLoad(120);

                     /** Verify Page Header */
                     // System.out.println("> Verify Page Heading");
                    //  mcd.VerifyPageTitle(strPageTitle);

                     /** Update title of new Page  */
                     mcd.SwitchToWindow("#Title");
                     
                     /** Get application time */
                     WebElement apptime = mcd.getdate();
                     strApplicationDate = apptime.getText();


                     // ------------------------------------------------------------------------ Actions specific to test-flow
					 actions.WaitForElementPresent("MenuItemTaxSet.NewMenuItemTaxSetButton");	
					 actions.keyboardEnter("MenuItemTaxSet.NewMenuItemTaxSetButton");
				   		
				   		//Switching to "Add New Menu Item Tax Set"
				   		mcd.SwitchToWindow("Add New Menu Item Tax Set");
				   		
				   		actions.WaitForElementPresent("AddNewMenuItemTaxSet.SelectButton");
				   		actions.keyboardEnter("AddNewMenuItemTaxSet.SelectButton");
				   		Thread.sleep(3000);
				   		//actions.smartWait(30);
				   		mcd.SwitchToWindow("Select Node");
						//Verifying rider message To search for Multiple Restaurant, include a �+� between Restaurant Number or Restaurant Name on Select Node
						flag=mcd.VerifyOnscreenMessage("SelectNode.Text", strErrMsg, true);

						if(flag=true){
	                   	 actions.reportCreatePASS("Verify rider message To search for Multiple Restaurant, include a �+� between Restaurant Number or Restaurant Name on Select Node",
	        						"Rider message To search for Multiple Restaurant, include a �+� between Restaurant Number or Restaurant Name on Select Node should displays",
	        						"Rider message To search for Multiple Restaurant, include a �+� between Restaurant Number or Restaurant Name on Select Node is displayed",
	        						"Pass");
	        			} else {
	        				actions.reportCreateFAIL("Verify Pop up message is displays as Please enter Tax Type Code",
	        						"Pop up message should displays as Please enter Tax Type Code",
	        						"Pop up message is not displays as Please enter Tax Type Code",
	        						"Fail"); 
	                    }
						
	                    //Verify search result for Begins with alphabets searched
						//actions.click("SelectNode.BeginsWithRadioButton");
						driver.findElement(By.xpath(actions.getLocator("SelectNode.BeginsWithRadioButton"))).click(); 
						actions.click("SelectNode.RestaurantNameRadioButton");
						
						actions.setValue("SelectNode.SearchTextTreeTextBox","a+b");
						actions.keyboardEnter("RFMAuditLog.SearchRestaurant");
						//actions.smartWait(20);
						actions.WaitForElementPresent("SelectNode.ARTableFirstValue",5); 
						List<WebElement> listEle1 = driver.findElements(By.xpath("//span[@class = 'leaf']//label"));
	                    
	                    for(int j = 0;j<=2;j++)
	                    { 
	                          Rest_String = listEle1.get(j).getText().split("-")[1].trim().toLowerCase();
	                          if(Rest_String.startsWith("a") || Rest_String.startsWith("b")){
	                          System.out.println("present");
	                          blnSrch = true;
	                          
	                          }else{
	                                  blnSrch=false;
	                                  break;                          
	                    }
	                    }
	                     
	                    if(blnSrch){
	                          actions.reportCreatePASS("Verify search result for Begins with alphabets searched", "The searched alphabets should be present", "The searched alphabets are present", "PASS");
	                    }else{
	                          actions.reportCreateFAIL("Verify search result for Begins with alphabets searched", "The searched alphabets should be present", "The searched alphabets are not present", "FAIL");
	                    }
	                    
	                   //Verify search result for Begins with Numeric searched
	                   // actions.click("SelectNode.BeginsWithRadioButton");
	                    driver.findElement(By.xpath(actions.getLocator("SelectNode.Contains"))).click(); 
						actions.click("SelectNode.RestaurantNumberRadioButton");
						
						actions.clear("SelectNode.SearchTextTreeTextBox");
						actions.setValue("SelectNode.SearchTextTreeTextBox","1+2");
						actions.keyboardEnter("RFMAuditLog.SearchRestaurant");
						//actions.smartWait(20);
						actions.WaitForElementPresent("SelectNode.ARTableFirstValue",5); 
						List<WebElement> listEle2 = driver.findElements(By.xpath("//span[@class = 'leaf']//label"));
	                          Rest_String = listEle2.get(0).getText().trim();
	                          if(Rest_String.contains("1") || Rest_String.contains("2")){
	                          System.out.println("present");
	                          blnSrch = true;
	                          
	                          }else{
	                                  blnSrch=false;
	                                                           
	                    }
	                     
	                    if(blnSrch){
	                          actions.reportCreatePASS("Verify search result for Begins with Numeric searched", "The searched Numeric should be present", "The searched Numeric are present", "PASS");
	                    }else{
	                          actions.reportCreateFAIL("Verify search result for Begins with Numeric searched", "The searched Numeric should be present", "The searched Numeric are not present", "FAIL");
	                    }

	                    actions.clear("SelectNode.SearchTextTreeTextBox");
	                    actions.setValue("SelectNode.SearchTextTreeTextBox",strNode);
	                    actions.click("SelectNode.ExactMatchRadioButton");
	                    actions.keyboardEnter("RFMAuditLog.SearchRestaurant");
						//actions.smartWait(20);
	                    actions.WaitForElementPresent("SelectNode.ARTableFirstValue",10); 
//						mcd.Selectrestnode("SelectNode.MITSTree",strNode);
						if (mcd.GetGlobalData("Instance").toLowerCase().contains("eu")) {
							mcd.Selectrestnode_JavaScriptClk("SelectNode.CPTable", strNode);
						} else {
							mcd.Selectrestnode("SelectNode.MITSTree",strNode);
						}						
				   		mcd.SwitchToWindow("Add New Menu Item Tax Set");
				   		actions.WaitForElementPresent("NewTaxType.TaxTypeNameField");
				   		actions.setValue("NewTaxType.TaxTypeNameField", "a");
				   		actions.keyboardEnter("AddNewTenderSet.NextButton");
				   		mcd.SwitchToWindow("@Menu Item Tax Set : Common Menu Item Selector");
				   		
                     // ------------------------------------------------------------------------ 
                     
                     /** Logout the application */
                     rfm.Logout();
                     

              } catch(Exception e) {
                     
                     //reporting the Fail condition
                     actions.catchException(e);
                     
              } finally {
                     actions.quitBrowser();
                     actions.verifyTestCase(this.getClass());            
              }
       }
}