package xtam.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;

public class PRC_0142_AssignedPrcSet_Active {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private String strApplicationDate;
	private String strResMessage;
	private String strError_Msg, strNewPrcSet, strPrcSetType, strStatus_Msg, strBase, strRest1, strStatusActive,
			strStatusInactive;

	public PRC_0142_AssignedPrcSet_Active(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters

		strResMessage = mcd.GetTestData("Result_Message");
		strError_Msg = mcd.GetTestData("Error_Msg");
		strBase = mcd.GetTestData("DT_BASE");
		strRest1 = mcd.GetTestData("DT_REST1");
		strStatusActive = mcd.GetTestData("DT_STATUS_ACTIVE");
		strStatusInactive = mcd.GetTestData("DT_STATUS_INACTIVE");
	}

	@Test
	public void PRC_0142_AssignedPrcSet_Active() throws InterruptedException {
		// String strPageTitle = "Manage Price Sets"; // TODO: Exact page-title
		// String strPageSubHeading = "Manage Price Sets"; // TODO: Page Heading
		String strTestDescription = "Verify that a Price Set can only be marked as inactive when it is not assigned to a restaurant.";

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription(strTestDescription);

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			/** Get application time */
			actions.setTestcaseDescription(strTestDescription);

			// ------------------------------------------------------------------------
			// Actions specific to test-flow

			String Assigned_PriceSet = null;
			WebElement SetA = null;
			int rw_cnt = mcd.GetTableRowCount("Price.PriceSets");
			// Get one assigned & unassigned price set.
			for (int i = 1; i <= rw_cnt; i++) {
				try {
					if (driver.findElement(By.xpath("//*[@id='priceSetData']/tr[" + i + "]/td[1]/span/img"))
							.isDisplayed()) {
						Assigned_PriceSet = driver
								.findElement(By.xpath("//*[@id='priceSetData']/tr[" + i + "]/td[1]/a")).getText();
						SetA = driver.findElement(By.xpath("//*[@id='priceSetData']/tr[" + i + "]/td[1]/a"));
						break;
					}
				} catch (Exception e) {
					System.out.println("There are no Price Sets assigned to restaurants");
				}
			}

			// Check - An assigned price set can not be made inactive
			System.out.println(SetA.getText());
			actions.javaScriptClick(SetA);
			mcd.smartsync(180);

			actions.setValue("ManagePS.Status", strStatusInactive);

			// Need to add TestData column for strStatusInactive
			actions.click("ManagePS.ALLApply");
			mcd.smartsync(180);

			// Verifying A Price set assigned to any restaurant can not be made
			// inactive
			boolean BlnVal = actions.isTextPresence(strError_Msg, true);
			if (BlnVal) {
				actions.reportCreatePASS("Verify " + strError_Msg, strError_Msg + " should be displayed",
						strError_Msg + " is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify " + strError_Msg, strError_Msg + " should be displayed",
						strError_Msg + " is not displayed", "Fail");
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			actions.catchException(e);
		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}
}
