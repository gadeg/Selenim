/**
 * 
 */
package xtam.test;

/**
 * @author akrani
 *
 */
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;


public class PRC_20278_MITSrmvCurntPropFutur {
       private Keywords actions;
       private WebDriver driver;
       private Map input;
       private UIValidations uiActions;
       private SoftAssert softAssert = new SoftAssert();
       
       private lib_MCD mcd;
       private lib_RFM2 rfm;
       
       private String strApplicationDate;
       
       // Test-Data Variables
       private Object strURL;
       private Object strUserName;
       private Object strPassword;
       private String strMarket;
       private String strNavigateTo;
       // TODO: Declare test-data variables for other data-parameters
       private String FutureSettings,MenuItemTaxSet,strRemovedMenuIteam,strRemovedMenuIteamFutSeting,strPopup,strPopupSplit[];
       Integer rowCount;
       
       public PRC_20278_MITSrmvCurntPropFutur (WebDriver nodeDriver, Map inputData, Object or){
              driver = nodeDriver;
              input = inputData;
              actions = new Keywords(driver, or);
              uiActions = new UIValidations();
              
              mcd = new lib_MCD (driver, actions, uiActions, inputData);
              rfm = new lib_RFM2 (driver, actions, uiActions, inputData, mcd);

              // Read input Test-Data
              strURL                     = mcd.GetTestData("DT_URL");
              strUserName   = mcd.GetTestData("DT_USER_NAME");
              strPassword   = mcd.GetTestData("DT_PASSWORD");
              strMarket            = mcd.GetTestData("DT_MARKET");
              strNavigateTo        = mcd.GetTestData("DT_NAVIGATE_TO");
              // TODO: GetTestData for other data-parameters
              strPopup            = mcd.GetTestData("DT_POPUP");
       }
       
       @Test
       public void test_PRC_20278_MITSrmvCurntPropFutur() throws InterruptedException {
//              String strPageTitle = "Menu Item Tax Set";				// TODO: Exact page-title
//              String strPageSubHeading = "Menu Item Tax Set";		// TODO: Page Heading
              String strTestDescription = " Menu Items removed from the current tax set are also removed from the future tax set unless the future tax settings have been changed for that menu item.";		// TODO: Test Case Description
              
              try {
                     System.out.println("********************************************************************** Test execution starts");

                     /** Launch and Login RFM */
                     System.out.println("> Launch and Login RFM");
                     rfm.LaunchAndLogin(strURL, strUserName, strPassword);
                     
                     /** Select Market (Node) */
                     System.out.println("> Select Market (Node)");
                     rfm.SelectMarket(strMarket);
              
                     /** Select Menu Option */
                     System.out.println("> Navigate to :: " + strNavigateTo);
                     actions.select_menu("RFMHome.Navigation",strNavigateTo);
                     Thread.sleep(2000);
                     actions.waitForPageToLoad(120);

                     /** Verify Page Header */
                     // System.out.println("> Verify Page Heading");
                    //  mcd.VerifyPageTitle(strPageTitle);

                     /** Update title of new Page  */
                     mcd.SwitchToWindow("#Title");
                     
                     /** Get application time */
                     WebElement apptime = mcd.getdate();
                     strApplicationDate = apptime.getText();

					 /** Get application time */
					 actions.setTestcaseDescription(strTestDescription);

                     // ------------------------------------------------------------------------ Actions specific to test-flow
					 strPopupSplit=strPopup.split("#");
					 
					 actions.keyboardEnter("TaxType.ViewFullListButton");                
                     actions.smartWait(100);
                     //Validating whether Future Settings already present or not
                     rowCount=mcd.GetTableRowCount("ScriptManagement.TableNameValue");
                     if(rowCount>1){
                    	 for(int i=1;i<=rowCount;i++){
    						 FutureSettings = mcd.GetTableCellValue("ScriptManagement.TableNameValue",i, "Future Settings", "", "");
    							if (FutureSettings.equals("")) {			
    								// Retrieving MenuItemTaxSet Name of table
    									MenuItemTaxSet = mcd.GetTableCellValue("ScriptManagement.TableNameValue",i,"Name", "","");
    									WebElement ElementTaxSetNm = mcd.GetTableCellElement("ScriptManagement.TableNameValue",i,"Name", "a");
    									actions.keyboardEnter(ElementTaxSetNm);  									
    									break;
    							}  
    					 } 
                     }else if(rowCount==1){
                    	 WebElement ElementTaxSetNm = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1,"Name","a");
             			 actions.keyboardEnter(ElementTaxSetNm);
                     }else{
                    	 System.out.println("No Active Menu Item Tax Set Available ");
                     }
                 
                     mcd.SwitchToWindow("Apply Changes Details");
                     actions.click("ApplyChangesDetails.futureDateRadioButton");
  	     			 actions.click("ApplyChangesDetails.CalendarIcon");
  					 mcd.Get_future_date(2, "Close", strApplicationDate);
 					 actions.keyboardEnter("ApplyChangesDetails.MDSaveButton"); 					 					 
 					 //actions.smartWait(10);
 					 Thread.sleep(2000);
 					 mcd.SwitchToWindow("@Manage Menu Item Tax Set");
                    
 					 actions.WaitForElementPresent("NewScript.CancleButton");
 					 actions.keyboardEnter("NewScript.CancleButton");
 					 mcd.SwitchToWindow("#Title");
 					
 					//Clicking on Menu Item Tax Set name having current setting		
 					 actions.setValue("TenderSet.SearchTextBox", MenuItemTaxSet);
 					 actions.keyboardEnter("TaxType.SearchButton");
 					 actions.smartWait(20);
     				
     				 WebElement ElementTaxSetNm1 = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1,"Name","a");
         			 actions.keyboardEnter(ElementTaxSetNm1);
         			 
         			 //Switching to Manage Menu Item Tax Set
         			 mcd.SwitchToWindow("#Title");  
         			 
         			 //-to add the Menu Item clicking on AddRemoveButton,
                     actions.keyboardEnter("ManageMenuItemTaxSet.AddRemoveButton");
                     
                     mcd.SwitchToWindow("Menu Item Tax Set : Common Menu Item Selector");
                     actions.javaScriptClick("TaxType.ViewFullListButton");
                     actions.smartWait(100);
                     
                     actions.setValue("ManageMenuItemTaxSet.AvailabilityDropdown","Available");
                     actions.smartWait(20);
                     
                     WebElement ElementMITSadd =mcd.GetTableCellElement("AddTenderType.Table", 1, 1, "input");
                    // actions.javaScriptClick("ElementMITSadd");
                     ElementMITSadd.click();
                     actions.keyboardEnter("AddTaxType.SaveButton");
                     mcd.SwitchToWindow("Manage Menu Item Tax Set");
                     
                     //-to remove the Menu Item clicking on AddRemoveButton
                     actions.keyboardEnter("ManageMenuItemTaxSet.AddRemoveButton");
                     mcd.SwitchToWindow("Menu Item Tax Set : Common Menu Item Selector");
                     
                     actions.javaScriptClick("TaxType.ViewFullListButton");
                     actions.smartWait(100);
                     
                     actions.setValue("ManageMenuItemTaxSet.AvailabilityDropdown","Assigned");
                     actions.smartWait(10);
                     
                     WebElement ElementMITS =mcd.GetTableCellElement("AddTenderType.Table", 1, 2, "input[1]");
                     ElementMITS.click();
                     
                     strRemovedMenuIteam=mcd.GetTableCellValue("AddTenderType.Table", 1, 2, "", "");
                     
                     actions.keyboardEnter("AddTaxType.SaveButton");
                   //  driver.switchTo().window("");
 					 mcd.VerifyAlertMessageDisplayed("Warning Message", strPopupSplit[0], true, AlertPopupButton.OK_BUTTON);
 					
 					 // actions.smartWait(10);
 					 Thread.sleep(2000);
                     mcd.SwitchToWindow("Manage Menu Item Tax Set");
                                         
                     actions.keyboardEnter("NewScript.CancleButton");
 					 mcd.SwitchToWindow("#Title");
 					
 					//Clicking on Menu Item Tax Set name having Future setting
 					actions.WaitForElementPresent("TenderSet.SearchTextBox");
 					actions.clear("TenderSet.SearchTextBox");
 					actions.setValue("TenderSet.SearchTextBox", MenuItemTaxSet);
     				actions.keyboardEnter("TaxType.SearchButton");
     				actions.smartWait(20);
     				
     				 WebElement ElementMITSnm = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1,"Future Settings","a");
         			 actions.keyboardEnter(ElementMITSnm);
         			 
         			 
         			 //Switching to Manage Menu Item Tax Set
         			 mcd.SwitchToWindow("#Title");
         			 
         			 strRemovedMenuIteamFutSeting=mcd.GetTableCellValue("ScriptManagement.TableNameValue",2,1, "", "");
         			 
         			 if(!strRemovedMenuIteam.equals("strRemovedMenuIteamFutSeting")){
         				actions.reportCreatePASS("Verify The 'Menu item' that was removed from the current settings is removed from future settings.",
        						"The 'Menu item' that was removed from the current settings should removed from future settings.",
        						"The 'Menu item' that was removed from the current settings is removed from future settings.",
        						"Pass");
         			 } else {
        				actions.reportCreateFAIL("Verify The 'Menu item' that was removed from the current settings is removed from future settings.",
        						"The 'Menu item' that was removed from the current settings should removed from future settings.",
        						"The 'Menu item' that was removed from the current settings is not removed from future settings.",
        						"Fail"); 
         			 }
                     // ------------------------------------------------------------------------ 
                     
                     /** Logout the application */
                     rfm.Logout();
                     

              } catch(Exception e) {
                     
                     //reporting the Fail condition
                     actions.catchException(e);
                     
              } finally {
                     actions.quitBrowser();
                     actions.verifyTestCase(this.getClass());
                     
                           
              }
       }
}