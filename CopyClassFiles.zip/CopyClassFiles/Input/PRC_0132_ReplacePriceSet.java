package xtam.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;

public class PRC_0132_ReplacePriceSet {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo, strNavigate;
	// TODO: Declare test-data variables for other data-parameters

	private Object strpriceset1;
	private Object strpriceset2;
	private String strMethod;
	private String strNewPrcSet;
	private String strResMessage;
	private String strPrcSetType;
	private String strNodeNum;
	private String strNumOfMenuItem1;
	private String strNumOfMenuItem2;
	private String strStatus_Msg;
	private String strNewPrice1;
	private String strNewPrice2;
	private String strStatus, strApplicationDate;

	private String strNavigateRP;
	private String strActivateFlag;
	int strNum;
	private String strNum1, strTaxChain, strTaxChain1;

	public PRC_0132_ReplacePriceSet(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strNavigate = mcd.GetTestData("DT_NAVIGATE_TO_ADMIN");
		// TODO: GetTestData for other data-parameters

		strpriceset1 = mcd.GetTestData("PRICESET1");
		strpriceset2 = mcd.GetTestData("PRICESET2");
		strMethod = mcd.GetTestData("Method");
		strNewPrcSet = mcd.GetTestData("PriceSet_Name");
		strResMessage = mcd.GetTestData("Result_Message");
		strPrcSetType = mcd.GetTestData("PriceSetType");
		strNodeNum = mcd.GetTestData("NodeNum");
		strStatus_Msg = mcd.GetTestData("Status_Msg");
		strNumOfMenuItem1 = mcd.GetTestData("NumOfMenuItem1");
		strNumOfMenuItem2 = mcd.GetTestData("NumOfMenuItem2");
		strNewPrice1 = mcd.GetTestData("NewPrice1");
		strNewPrice2 = mcd.GetTestData("NewPrice2");
		strStatus = mcd.GetTestData("Status");
		strActivateFlag = mcd.GetTestData("ActivateFlag");

	}

	@Test
	public void PRC_0132_ReplacePriceSet() throws InterruptedException {
		try {
			actions.setTestcaseDescription(
					"Verify Manage Price Set � Replace Price Set functionality of Base type price set with activate menu item checked and method type tax and price");

			System.out.println(
					"********************************************************************** Test execution starts");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigate);
			actions.select_menu("RFMHome.Navigation", strNavigate);
			Thread.sleep(5000);
			actions.waitForPageToLoad(5000);
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();
			// ------------------------------------------------------------------------
			// Actions specific to test-flow

			// Automating the Pre - Req Site
			rfm.RFM_Admin_Update_PricingTags("0", "Automatically fill price type attribute option price value");
			rfm.RFM_Admin_Update_PricingTags("0", "Automatically fill price type attribute option tax value");
			rfm.RFM_Admin_Update_PricingTags("false", "Restrict price type attribute from expanding");

			// Navigate to PRICING >Price Sets
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Pricing", strNavigateTo);
			Thread.sleep(5000);
			actions.waitForPageToLoad(2000);
			mcd.SwitchToWindow("#Title");

			// Create Price Set1
			int num = mcd.fn_GetRndNumInRange(1, 1);
			strpriceset1 = RFM_PRC_Create_PriceSet(strNewPrcSet, strPrcSetType, strResMessage, strNodeNum,
					strNumOfMenuItem1, strStatus_Msg, strNewPrice1, strStatus, num);
			System.out.println("PS1 = " + strpriceset1);

			// Enter Different Price Values & Click on Apply Button
			actions.click("PriceSet.AllPriceTypeRadioBtn");
			int num5 = mcd.fn_GetRndNumInRange(1, 3);
			actions.setValue("PriceSets.EatinPriceId", num5);
			int num1 = mcd.fn_GetRndNumInRange(4, 5);
			actions.setValue("PriceSets.TakeOutPriceId", num1);
			int num2 = mcd.fn_GetRndNumInRange(6, 9);
			actions.setValue("PriceSets.OtherPrices", num2);
			actions.click("UpdateDayPartSet.apply");
			actions.smartWait(20);
			actions.keyboardEnter("PriceSet.ApplyButton");

			// Navigate to PRICING >Price Sets
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Pricing", strNavigateTo);
			Thread.sleep(5000);
			actions.waitForPageToLoad(10000);

			// Create Price Set 2
			int num4 = mcd.fn_GetRndNumInRange(5, 5);
			strpriceset2 = RFM_PRC_Create_PriceSet(strNewPrcSet, strPrcSetType, strResMessage, strNodeNum,
					strNumOfMenuItem2, strStatus_Msg, strNewPrice2, strStatus, num4);
			Thread.sleep(3000);
			System.out.println("PS2 = " + strpriceset2);

			// Navigate to PRICING >Price Sets
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Pricing", strNavigateTo);
			Thread.sleep(5000);
			actions.waitForPageToLoad(10000);

			// Replace Price Set 1 with Price Set 2
			RFM_PRC_Replace_PriceSet(strpriceset1, strpriceset2, strMethod, strNavigateTo, strPrcSetType,
					strActivateFlag);

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	public String RFM_PRC_Create_PriceSet(String strNewPrcSet, String strPrcSetType, String strResMessage,
			String strNodeNum, String strNumOfMenuItem, String strStatus_Msg, String strNewPrice, String strStatus,
			int m) throws Exception {

		// Click on New Price Set Button & Select Price Type Base/Promotion
		// Price Set
		actions.keyboardEnter("PriceSet.NewBtn");
		mcd.SwitchToWindow("New Price Sets");
		switch (strPrcSetType) {
		case "Base":
			strNewPrcSet = mcd.fn_GetRndName("Base");
			break;
		case "Promotion":
			strNewPrcSet = mcd.fn_GetRndName("Prom");
			break;
		default:
			actions.reportCreateFAIL("Verfiy data", "Enter correct price set name", "Incorrect data", "FAIL");
			break;
		}

		// Enter New Price Set Name and Select Node
		actions.setValue("NewPriceSet.Name", strNewPrcSet);
		actions.keyboardEnter("NewPriceSet.SelectNode");
		mcd.waitAndSwitch("Select Node");
		actions.keyboardEnter("SelectNode.ExactMtchRadiobtn");
		actions.setValue("SelectNode.SearchBox", strNodeNum);
		actions.keyboardEnter("SelectNode.SearchButton");
		mcd.Selectrestnode_JavaScriptClk("SelectNode.NodeTable", strNodeNum);
		mcd.SwitchToWindow("$New Price Sets");

		// Select Price Type
		switch (strPrcSetType) {
		case "Base":
			actions.keyboardEnter("NewPriceSet.BaseRadioBtn");
			break;

		case "Promotion":
			actions.javaScriptClick("NewPriceSet.PromRadioBtn");
			driver.findElement(By.id("startDateAnchor")).click();
			mcd.Get_future_date(0, "close", strApplicationDate);
			driver.findElement(By.id("endDateAnchor")).click();
			mcd.Get_future_date(3, "close", strApplicationDate);
			break;
		default:
			System.out.println("Please enter correct Price Set Type (Base/Promotion)");
			break;
		}

		// Click Next Button & Switch to Price Sets : Common Menu Item Selector
		// - to add new menu items
		actions.keyboardEnter("NewPriceSet.Next");
		mcd.SwitchToWindow("@Price Sets : Common Menu Item Selector");

		// Select Available Menu Items & Click on Apply Button,Verify success
		// message
		actions.keyboardEnter("CommonSelector.ViewFullBtn");
		actions.smartWait(20);
		actions.setValue("CommonSelector.AvailabilityDrpDwn", "Available");
		Thread.sleep(7000);
		List<WebElement> Add_Chkbox = driver
				.findElements(By.xpath(".//input[@type = 'checkbox'][contains(@onclick, 'addMenuItem')]"));
		int Item_Counts = Add_Chkbox.size();
		List<String> MnuItem_Names = new ArrayList<String>();
		int i_temp = 0;
		for (int n = m; n <= Item_Counts; n++) {
			if ((Add_Chkbox.get(n).isEnabled())) {
				Add_Chkbox.get(n).sendKeys(Keys.SPACE);
				String p = Integer.toString(n + 1);
				String e = driver.findElement(By.xpath("//*[@id='commonTableBody']/tr[" + p + "]/td[4]")).getText();
				MnuItem_Names.add(e);
				i_temp++;
			} else {
				System.out.println("This MI is already added");
			}

			if (i_temp == Integer.parseInt(strNumOfMenuItem)) {
				System.out.println("Selected items for Add MI");
				break;
			}
		}
		actions.keyboardEnter("CommonSelector.Save");
		actions.smartWait(20);
		actions.verifyTextPresence(strResMessage, true);

		// Set Price to all menu items & Select Status
		String currStatus = actions.getValue("ManagePS.Status");
		if (!currStatus.equals(strStatus)) {
			actions.setValue("ManagePS.Status", strStatus);
			actions.clear("UpdtMultipleSet.AllPrc");
			actions.setValue("UpdtMultipleSet.AllPrc", strNewPrice);
			actions.click("UpdateDayPartSet.apply");
			actions.smartWait(20);
			actions.keyboardEnter("PriceSet.ApplyButton");
			actions.smartWait(20);
		}

		actions.verifyTextPresence(strStatus_Msg, true);

		return strNewPrcSet;
	}

	public void RFM_PRC_Replace_PriceSet(Object strpriceset1, Object strpriceset2, String strMethod,
			String strNavigateTo, String strPrcSetType, String strActivateFlag) throws Exception {

		// Select any Price Set
		switch (strPrcSetType) {
		case "Base":
			actions.setValue("RFMPriceSets.dropdownSearchList", "Base");
			break;
		case "Promotion":
			actions.setValue("RFMPriceSets.dropdownSearchList", "Promotional");
			break;
		default:
			System.out.println("Please enter correct Price Set Type (Base/Promotion)");
			break;
		}

		// Click on Price Set1
		actions.setValue("RFMPriceSets.MainSearchbox", strpriceset1);
		actions.keyboardEnter("RFMPriceSets.MainSearch");
		actions.smartWait(120);
		actions.keyboardEnter("RFMPriceSets.PriceSet2");
		actions.smartWait(120);
		List<WebElement> MenuItemList1 = driver.findElements(By.xpath(actions.getLocator("PriceSets.MenuItemsTable")));

		/** Navigate again to price sets */
		System.out.println("> Navigate to :: " + strNavigateTo);
		actions.select_menu("RFMHome.Pricing", strNavigateTo);
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);
		mcd.SwitchToWindow("#Title");

		actions.keyboardEnter("RFMPriceSets.ReplaceBtn");
		mcd.SwitchToWindow("Replace Price");

		actions.click("RFMPriceSets.CancelBtn");

		mcd.SwitchToWindow("Manage Price Sets");

		// Again click Replace
		actions.keyboardEnter("RFMPriceSets.ReplaceBtn");
		mcd.SwitchToWindow("Replace Price");

		// Select Price & Taxes
		actions.setValue("RFMPriceSets.dropdown", strMethod);
		// actions.verifyTestStep(actions.getValue("RFMPriceSets.dropdown"),
		// strMethod, true); // VP1

		// Click on Cancel. Warning message should display
		actions.click("RFMPriceSets.CancelBtn");

		mcd.SwitchToWindow("Manage Price Sets");

		// -------------------------------------------------------

		// Again click Replace
		actions.keyboardEnter("RFMPriceSets.ReplaceBtn");
		mcd.SwitchToWindow("Replace Price");

		// Select check box as per Base/Promotion

		switch (strPrcSetType) {
		case "Base":

			// Base Price
			actions.click("RFMPriceSets.BaseRadio");
			Thread.sleep(1000);
			break;
		case "Promotion":

			// Promotion Price
			actions.click("RFMPriceSets.PromotionRadio");
			Thread.sleep(1000);
			break;
		default:
			System.out.println("Please enter correct Price Set Type (Base/Promotion)");
			break;
		}

		// Select first price set
		actions.click("RFMPriceSets.SelectFirst");
		mcd.waitAndSwitch("Price Sets");

		// Search & Select desired price set
		actions.setValue("RFMPriceSets.PriceSetSearchbox", strpriceset1);
		actions.keyboardEnter("RFMPriceSets.PriceSetSearch");
		actions.smartWait(20);
		actions.keyboardEnter("RFMPriceSets.PriceSet1");
		// actions.smartWait(20);
		mcd.SwitchToWindow("$Replace Price");

		// Select first price set
		// actions.WaitForElementPresent("RFMPriceSets.SelectSecond", 10);
		actions.keyboardEnter("RFMPriceSets.SelectSecond");
		mcd.waitAndSwitch("Price Sets");

		// Search & Select desired price set
		actions.setValue("RFMPriceSets.PriceSetSearchbox", strpriceset2);
		actions.keyboardEnter("RFMPriceSets.PriceSetSearch");
		actions.smartWait(20);
		String priceset = actions.getValue("RFMPriceSets.PriceSet2");
		actions.keyboardEnter("RFMPriceSets.PriceSet2");
		// Switch back to Replace price window
		mcd.SwitchToWindow("$Replace Price");

		// Select required type - Price/ Price & taxes
		// actions.WaitForElementPresent("RFMPriceSets.dropdown", 10);
		actions.setValue("RFMPriceSets.dropdown", strMethod);
		Thread.sleep(3000);
		actions.click("RFMPriceSets.ReplaceBtn");
		mcd.SwitchToWindow("@Manage Price Sets");
		actions.smartWait(20);

		// Search second Price Sets
		// And Verify whether 2nd Price set is replaced correctly by first price
		// set
		switch (strPrcSetType) {
		case "Base":

			// Base Price
			actions.setValue("RFMPriceSets.dropdownSearchList", "Base");
			Thread.sleep(1000);
			break;
		case "Promotion":

			// Promotion Price
			actions.setValue("RFMPriceSets.dropdownSearchList", "Promotional");
			Thread.sleep(1000);
			break;
		default:
			System.out.println("Please enter correct Price Set Type (Base/Promotion)");
			break;
		}

		System.out.println("text: " + strpriceset2);
		actions.setValue("RFMPriceSets.MainSearchbox", strpriceset2);
		actions.click("RFMPriceSets.MainSearch");
		actions.smartWait(20);
		actions.keyboardEnter("RFMPriceSets.PriceSet2");

		// Store Menu items for price set 2
		List<WebElement> MenuItemList2 = driver.findElements(By.xpath(actions.getLocator("ManagePS.ListofAddedMI")));
		Boolean MenuItemCheck = false;

		// Verify whether both price sets have same menu items
		if (MenuItemList1.size() == MenuItemList2.size()) {
			MenuItemCheck = true;

			if (MenuItemCheck) {
				actions.reportCreatePASS("Verify Replace functionality",
						"Replace functionality working correctly. Replaced price set has same menu items as other price set",
						"Replace functionality working correctly. Replaced price set has same menu items as other price set",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify Replace functionality",
						"Replace functionality working correctly. Replaced price set has same menu items as other price set",
						"Replace functionality not working correctly.", "FAIL");

			}
		}
	}

}
