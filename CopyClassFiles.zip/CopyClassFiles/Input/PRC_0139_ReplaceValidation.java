package xtam.test;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;

public class PRC_0139_ReplaceValidation {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;
	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters

	private String[] strPrcSetType;
	private String strResMessage;
	private String strTestPrc;
	private String strNodeNum;
	private String strMIAddMsg;
	private String strPriceSetType;
	String strBasePrcSet1 = null;
	String strBasePrcSet2 = null;
	String strPromPrcSet1 = null;
	String strPromPrcSet2 = null;

	public PRC_0139_ReplaceValidation(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters
		strPrcSetType = mcd.GetTestData("PRC_SET_TYPE").split("#");
		strResMessage = mcd.GetTestData("RESULT_MSG");
		strTestPrc = mcd.GetTestData("TEST_PRC");
		strNodeNum = mcd.GetTestData("NODE_NUM");
		strMIAddMsg = mcd.GetTestData("MIADDITION_MSG");

	}

	@Test
	public void PRC_0139_ReplaceValidation() throws InterruptedException {

		try {
			actions.setTestcaseDescription(
					"Verify that Base Price set cannot be overwritten with Promotional Price set or vice-versa");
			System.out.println(
					"********************************************************************** Test execution starts");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Pricing", strNavigateTo);
			Thread.sleep(5000);
			actions.waitForPageToLoad(10000);

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Actions specific to test-flow

			// Get input data for further use
			// get 4 price sets - 2 Base; 2 Promotional
			strBasePrcSet1 = PriceActions.RFM_PRC_CreatePrcSetWOCpy(strPrcSetType[0], strResMessage, strTestPrc,
					strNodeNum, strApplicationDate, strMIAddMsg, "Active");
			strBasePrcSet2 = PriceActions.RFM_PRC_CreatePrcSetWOCpy(strPrcSetType[0], strResMessage, strTestPrc,
					strNodeNum, strApplicationDate, strMIAddMsg, "Active");
			strPromPrcSet1 = PriceActions.RFM_PRC_CreatePrcSetWOCpy(strPrcSetType[1], strResMessage, strTestPrc,
					strNodeNum, strApplicationDate, strMIAddMsg, "Active");
			strPromPrcSet2 = PriceActions.RFM_PRC_CreatePrcSetWOCpy(strPrcSetType[1], strResMessage, strTestPrc,
					strNodeNum, strApplicationDate, strMIAddMsg, "Active");

			// Verification for Base price set type
			// Base Price Set can be replaced with only base price set not
			// promotional set
			strPriceSetType = "Base";
			PriceActions.RFM_PRC_ReplacePriceSetValidation(strPriceSetType, strBasePrcSet1, strBasePrcSet2,
					strPromPrcSet2);

			// Verification for Base price set type
			// Promotional Price Set can be replaced with only promotional price
			// set not base set
			strPriceSetType = "Promotional";
			PriceActions.RFM_PRC_ReplacePriceSetValidation(strPriceSetType, strPromPrcSet1, strPromPrcSet2,
					strBasePrcSet2);

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			// Reporter.log("Test Failed :: " + e.getCause() + " - " +
			// e.getMessage());
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

}
