package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;

public class PRC_0150_UpdatePrcSetName {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// Declare test-data variables for other data-parameters

	private String strResMessage;
	private String strNavigateMUP;
	private String strNavigateRP;

	public PRC_0150_UpdatePrcSetName(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// GetTestData for other data-parameters
		strResMessage = mcd.GetTestData("Result_Message");
		strNavigateMUP = mcd.GetTestData("NavigateMUP");
		strNavigateRP = mcd.GetTestData("NavigateRP");
	}

	@Test
	public void test_PRC_0150_UpdatePrcSetName() throws InterruptedException {

		try {
			System.out.println("******************************** Test execution starts");

			actions.setTestcaseDescription(mcd.GetTestData("DT_Description"));
			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			// For Active Price Set, updating the name and verifying whether it
			// is reflected in MUP and RP
			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Pricing", strNavigateTo);
			Thread.sleep(5000);
			actions.waitForPageToLoad(120);

			mcd.SwitchToWindow("#Title");

			actions.WaitForElementPresent("PriceSet.FilterByStatus", 120);
			actions.setValue("PriceSet.FilterByStatus", "Active");
			mcd.smartsync(180);
			RFM_PRC_UpdatePriceSetName(strResMessage, strNavigateMUP, strNavigateRP);

			Thread.sleep(5000);
			// For Inactive Price Set, updating the name and verifying whether
			// it is reflected in Price sets result grid
			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Pricing", strNavigateTo);
			Thread.sleep(5000);
			actions.waitForPageToLoad(120);

			mcd.SwitchToWindow("#Title");
			actions.WaitForElementPresent("PriceSet.FilterByStatus", 120);
			actions.setValue("PriceSet.FilterByStatus", "Inactive");
			mcd.smartsync(180);

			String Inactive_PriceSet = mcd.GetTableCellElement("Price.PriceSets", 1, 1, "a").getText();
			mcd.GetTableCellElement("Price.PriceSets", 1, 1, "a").click();
			actions.WaitForElementPresent("ManagePS.PriceSetName", 10);
			actions.clear("ManagePS.PriceSetName");
			Thread.sleep(2000);

			// Appended Auto_updt to current price set name
			String updt_APriceSet = "Auto_updt_" + Inactive_PriceSet;
			actions.setValue("ManagePS.PriceSetName", updt_APriceSet);
			actions.click("ManagePS.ALLApply");
			mcd.smartsync(180);
			Thread.sleep(5000);

			// Verify success message
			actions.verifyTextPresence(strResMessage, true);

			// Navigating back to Manage Price Sets page to verify the updated
			// Inactive price Set name
			actions.keyboardEnter("RFM.Cancelbtn");
			mcd.smartsync(180);
			mcd.SwitchToWindow("#Title");

			actions.WaitForElementPresent("PricingSets.SearchTextBox", 120);
			actions.setValue("PricingSets.SearchTextBox", updt_APriceSet);
			actions.keyboardEnter("RestaurantSet.Searchbtn");
			mcd.smartsync(180);
			String Updated_PriceSet = mcd.GetTableCellElement("Price.PriceSets", 1, 1, "a").getText();

			if (Updated_PriceSet.equals(updt_APriceSet)) {
				actions.reportCreatePASS("Verify updated price set in Price Set result grid",
						"Updated Price Set should be displayed correctly in Price Set result grid",
						"Updated Price Set is displayed correctly in Price Set result grid", "PASS");
			} else {
				actions.reportCreateFAIL("Verify updated price set in Price Set result grid",
						"Updated Price Set should be displayed correctly in Price Set result grid",
						"Updated Price Set is not displayed in Price Set result grid", "Fail");
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
		} finally {
			actions.verifyTestCase(this.getClass());
		}
	}

	// Function to update the price set name and verify the update name in MUP
	// and RP modules
	public void RFM_PRC_UpdatePriceSetName(String strResMessage, String strNavigateMUP, String strNavigateRP)
			throws Exception {
		String Assigned_PriceSet = null;
		String updt_APriceSet = null;
		String strNode = null;

		// Searching the Price Set which is assigned to Restaurant and updating
		// its name
		int rw_cnt = mcd.GetTableRowCount("Price.PriceSets");
		// Get one assigned price set to update
		for (int i = 1; i <= rw_cnt; i++) {
			try {
				if (driver.findElement(By.xpath("//*[@id='priceSetData']/tr[" + i + "]/td[1]/span/img"))
						.isDisplayed()) {
					Assigned_PriceSet = mcd.GetTableCellElement("Price.PriceSets", i, 1, "a").getText();
					// Get the node name to which this price set is assigned to.
					strNode = mcd.GetTableCellElement("Price.PriceSets", i, 2, "").getText();
					Actions builder = new Actions(driver);
					builder.moveByOffset(500, 0).click().perform();
					mcd.GetTableCellElement("Price.PriceSets", i, 1, "a").click();
					actions.WaitForElementPresent("ManagePS.PriceSetName", 10);
					actions.clear("ManagePS.PriceSetName");
					Thread.sleep(2000);

					// Appended Auto_updt to current price set name
					updt_APriceSet = "Auto_updt_" + Assigned_PriceSet;
					actions.setValue("ManagePS.PriceSetName", updt_APriceSet);
					actions.click("ManagePS.ALLApply");
					Thread.sleep(5000);

					// Verify success message
					actions.verifyTextPresence(strResMessage, true);
					break;
				}
			} catch (Exception e) {
				System.out.println("This price set is not attached to any restaurant");
			}
		}

		// Verify updated Price Set name in - Mass update prices
		/** Select Menu Option */
		System.out.println("> Navigate to :: " + strNavigateMUP);
		actions.select_menu("RFMHome.Pricing", strNavigateMUP);
		Thread.sleep(5000);
		actions.waitForPageToLoad(120);

		// Assigning a Menu Item
		actions.keyboardEnter("RestaurantSet.Searchbtn");
		mcd.smartsync(180);
		List<WebElement> MnuItm_List = driver.findElements(By.xpath("//tr[@onclick = 'SelectLeftRow(this)']"));

		if (MnuItm_List != null) {
			MnuItm_List.get(0).click();
		}
		Thread.sleep(1000);
		actions.click("UpdateSet.AddRow");
		Thread.sleep(1000);
		actions.click("UpdateSet.NextBtn");
		Thread.sleep(10000);

		// Price Sets - Search for updated price set
		actions.setValue("UpdatePrcSet.SearchBox", updt_APriceSet);
		actions.keyboardEnter("UpdatePrcSet.SearchButton");
		mcd.smartsync(180);

		// Verify whether the updated name is displayed and validate the same
		WebElement eleTable = actions.getwebDriverLocator(actions.getLocator("UpdatePrcSet.PriceSetTable"));
		if (eleTable != null) {
			List<WebElement> eleRows = eleTable.findElements(By.xpath(".//tbody/tr/td[1]"));
			if (eleRows.get(0).getText().equals(updt_APriceSet)) {
				actions.reportCreatePASS("Verify updated price set in Mass update prices",
						"Updated Price Set should be displayed correctly in Mass Update Prices",
						"Updated Price Set is displayed correctly in Mass Update Prices", "PASS");
			} else {
				actions.reportCreateFAIL("Verify updated price set in Mass update prices",
						"Updated Price Set should be displayed correctly in Mass Update Prices",
						"Updated Price Set is not displayed correctly in Mass Update Prices", "FAIL");
			}
		}

		// Verify updated Price Set name in - Restaurant Profile
		// Navigate to Admin > Restaurant Profile
		System.out.println("> Navigate to :: " + strNavigateRP);
		actions.select_menu("RFMHome.Pricing", strNavigateRP);
		Thread.sleep(5000);
		actions.waitForPageToLoad(20);

		// Search & Select node to which updated price set is assigned
		actions.setValue("RestaurantUpdt.SearchRestro", strNode);
		actions.keyboardEnter("RestaurantUpdt.SearchRestroBtn");
		mcd.smartsync(180);
		mcd.GetTableCellElement("PackageSchedule.Table", 1, 1, "a").click();
		mcd.smartsync(180);

		// Select MenuItem/POS tab
		actions.click("RestaurantUpdt.MITab");
		mcd.smartsync(180);
		actions.WaitForElementPresent("RestaurantUpdt.SetType", 120);
		actions.setValue("RestaurantUpdt.SetType", "Pricing");
		mcd.smartsync(180);
		Thread.sleep(2000);

		// Verify updated price set name is displayed
		int srch_cnt = mcd.GetTableRowCount("CopyComponent.ResTable2");

		String Srchd_Name = null;
		for (int k = 1; k <= srch_cnt; k++) {
			Srchd_Name = mcd.GetTableCellElement("CopyComponent.ResTable2", k, 1, "").getText();
			Srchd_Name = Srchd_Name.split("\\(")[0].trim();

			if (Srchd_Name.equals(updt_APriceSet)) {
				actions.reportCreatePASS("Verify updated price set in restaurant profile",
						"Updated Price Set should be displayed correctly in restaurant profile",
						"Updated Price Set is displayed correctly in restaurant profile", "PASS");
			} else {
				actions.reportCreateFAIL("Verify updated price set in restaurant profile",
						"Updated Price Set should be displayed correctly in restaurant profile",
						"Updated Price Set is not displayed correctly in restaurant profile", "FAIL");
			}
		}
	}
}