package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class PRC_20197_MF_VrfyPrAtriRestrExp {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;
	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String atribute, strNavigateToAdmin, FeeName1, FeeName;
	private int num1;

	public PRC_20197_MF_VrfyPrAtriRestrExp(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);
		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strNavigateToAdmin = mcd.GetTestData("DT_NAVIGATE_TO_ADMIN");

	}

	@Test
	public void test_PRC_20197_MF_VrfyPrAtriRestrExp() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription(
					"Verify that Price Type Attributes can be restricted from being expanded based on Market Level Parameter 'restrict-price-type-attribute-from-expanding' when it is true.");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateToAdmin);
			actions.select_menu("RFMHome.Navigation", strNavigateToAdmin);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Actions specific to test-flow
			// Automated the Pre - Req:
			rfm.RFM_Admin_Update_PricingTags("true", "Restrict price type attribute from expanding");
			rfm.RFM_Admin_Update_PricingTags("false", "Display price type attribute as expanded by default");

			/** Navigate to Master Fee */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(180);
			mcd.SwitchToWindow("#Title");
			actions.waitForPageToLoad(120);

			// Create New Fee
			createNewFee();

			// Click on Cancel Button
			actions.click("RestaurantSet.Cancelbtn");
			actions.smartWait(180);

			// Validations is already Completed in PRC_20173_VrfyList_Status

			// Click on New Fee button & Verify Price Type Attributes should not
			// be expandable
			actions.WaitForElementPresent("MasterFee.NewFeeBtn");
			actions.keyboardEnter("MasterFee.NewFeeBtn");
			actions.smartWait(10);

			// Validations is already Completed in
			// PRC_20174_MF_VrfyCnclBtn_ErrMsg

			actions.keyboardEnter("DepositSet.TaxPlusIcon");
			if (actions.isElementPresent("DepositSet.TaxPlusIcon")) {
				actions.reportCreatePASS("Verify Price Type Attributes is expandable",
						"Price Type Attributes should not be  expandable", "Price Type Attributes is not expandable",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify Price Type Attributes is expandable",
						"Price Type Attributes should not be  expandable", "Price Type Attributes is expandable",
						"FAIL");
			}
			actions.keyboardEnter("DepositSet.PlusIcon");
			if (actions.isElementPresent("DepositSet.PlusIcon")) {
				actions.reportCreatePASS("Verify Price Type Attributes is expandable",
						"Price Type Attributes should not be  expandable", "Price Type Attributes is not expandable",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify Price Type Attributes is expandable",
						"Price Type Attributes should not be  expandable", "Price Type Attributes is expandable",
						"FAIL");
			}

			// Click on Cancel button & Click on first element of the table
			actions.keyboardEnter("RFM.CancelBtn");
			actions.smartWait(20);
			actions.clear("MasterFee.SearchBox");
			actions.setValue("MasterFee.SearchBox", FeeName1);
			actions.click("PriceSet.SearchBtn");
			actions.smartWait(180);
			WebElement tbl = mcd.GetTableCellElement("ScreenSet.Table", 1, "Fee Name", "a");
			actions.keyboardEnter(tbl);
			actions.smartWait(50);

			// Verify Price Type Attributes should not be expandable
			actions.keyboardEnter("DepositSet.TaxPlusIcon");
			if (actions.isElementPresent("DepositSet.TaxPlusIcon")) {
				actions.reportCreatePASS("Verify Price Type Attributes is expandable",
						"Price Type Attributes should not be  expandable", "Price Type Attributes is not expandable",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify Price Type Attributes is expandable",
						"Price Type Attributes should not be  expandable", "Price Type Attributes is expandable",
						"FAIL");
			}
			actions.keyboardEnter("DepositSet.PlusIcon");
			if (actions.isElementPresent("DepositSet.PlusIcon")) {
				actions.reportCreatePASS("Verify Price Type Attributes is expandable",
						"Price Type Attributes should not be  expandable", "Price Type Attributes is not expandable",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify Price Type Attributes is expandable",
						"Price Type Attributes should not be  expandable", "Price Type Attributes is expandable",
						"FAIL");
			}

			// Click on Cancel Button & Checking Future Settings present or not
			// in application on 1st row
			actions.click("RestaurantSet.Cancelbtn");
			actions.smartWait(180);
			actions.clear("MasterFee.SearchBox");
			actions.setValue("MasterFee.SearchBox", FeeName1);
			actions.click("PriceSet.SearchBtn");
			actions.smartWait(180);
			WebElement FutSet = mcd.GetTableCellElement("MasterMenuItemList.SearchRes", 1, "Future Settings", "a");
			String FutureSettings = FutSet.getText();
			if (!FutureSettings.equals(" ")) {
				tbl = mcd.GetTableCellElement("MasterMenuItemList.SearchRes", 1, "Future Settings", "a");
				actions.keyboardEnter(tbl);
				actions.smartWait(20);

			} else {
				// Selecting 'Active' from the DropDown & Click on first menu
				// item from the table to apply the Future Settings
				tbl = mcd.GetTableCellElement("MasterMenuItemList.SearchRes", 1, "Fee Name", "a");
				actions.javaScriptClick(tbl);
				actions.smartWait(20);
				actions.clear("FeeSets.FeeName");
				String FeeName = mcd.fn_GetRndName("Auto");
				actions.setValue("FeeSets.FeeName", FeeName);
				actions.keyboardEnter("FeeSets.ApplyBtn");
				try {
					actions.waitForPageToLoad(120);
					mcd.SwitchToWindow("Apply Changes Details");
					actions.click("ApplyChangesDetails.FutureDate");
					actions.click("ApplyChangesDetails.FutureDateCalendar");
					mcd.Get_future_date(2, "Close", strApplicationDate);
					actions.WaitForElementPresent("ApplyChangesDetails.Save");
					actions.keyboardEnter("ApplyChangesDetails.saveExportOptionSet");
					mcd.SwitchToWindow("@Manage Fee");
				} catch (Exception e) {
					System.out.println("Apply Changes Details window is not available");
				}
				try {
					mcd.VerifyAlertMessageDisplayed("Warning",
							"Update of Fee Name will affect both current and future settings (if present).", true,
							AlertPopupButton.OK_BUTTON);
				} catch (Exception e) {
					System.out.println("Alert not Present");
				}

				// Click on cancel button & Click on First element in the table
				actions.WaitForElementPresent("FeeSets.CancelBtn", 180);
				actions.keyboardEnter("FeeSets.CancelBtn");
				actions.WaitForElementPresent("PriceSet.SearchBtn");
				actions.clear("MasterFee.SearchBox");
				actions.setValue("MasterFee.SearchBox", FeeName);
				actions.click("PriceSet.SearchBtn");
				actions.smartWait(180);
				tbl = mcd.GetTableCellElement("MasterMenuItemList.SearchRes", 1, "Future Settings", "a");
				actions.keyboardEnter(tbl);
				actions.smartWait(20);
			}

			// Verify Price Type Attributes should not be expandable
			actions.click("DepositSet.TaxPlusIcon");
			if (actions.isElementPresent("DepositSet.TaxPlusIcon")) {
				actions.reportCreatePASS("Verify Price Type Attributes is expandable",
						"Price Type Attributes should not be  expandable", "Price Type Attributes is not expandable",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify Price Type Attributes is expandable",
						"Price Type Attributes should not be  expandable", "Price Type Attributes is expandable",
						"FAIL");
			}
			actions.click("DepositSet.PlusIcon");
			if (actions.isElementPresent("DepositSet.PlusIcon")) {
				actions.reportCreatePASS("Verify Price Type Attributes is expandable",
						"Price Type Attributes should not be  expandable", "Price Type Attributes is not expandable",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify Price Type Attributes is expandable",
						"Price Type Attributes should not be  expandable", "Price Type Attributes is expandable",
						"FAIL");
			}

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	public void createNewFee() throws Exception {
		actions.keyboardEnter("MasterFee.NewFeeBtn");
		mcd.SwitchToWindow("#Title");
		actions.WaitForElementPresent("FeeSets.FeeName");
		Boolean flag = false;
		do {
			try {
				int num2 = mcd.fn_GetRndNumInRange(100, 999);
				actions.clear("MasterFee.FeeId");
				actions.setValue("MasterFee.FeeId", num2);
				FeeName1 = mcd.fn_GetRndName("Auto");
				actions.clear("FeeSets.FeeName");
				actions.setValue("FeeSets.FeeName", FeeName1);
				actions.setValue("MasterFee.FeeType", "Amount");
				actions.setValue("FeeSet.Status", "Active");
				num1 = mcd.fn_GetRndNumInRange(1, 9);
				if (actions.isElementPresent("DepositSet.PlusIcon")) {
					actions.clear("FeeSets.AllValue");
					actions.setValue("FeeSets.AllValue", num1);
				} else {
					actions.clear("FeeSets.EatinValue");
					actions.setValue("FeeSets.EatinValue", num1);
					actions.clear("FeeSet.TkOutPrc");
					actions.setValue("FeeSet.TkOutPrc", num1);
					actions.clear("FeeSet.OthPrc");
					actions.setValue("FeeSet.OthPrc", num1);
				}
				actions.keyboardEnter("RFMUpdateLocalizationSet.SaveButton");
				actions.smartWait(20);

			} catch (Exception err) {
				actions.reportCreateFAIL("Creating New Fee", "Should be able to create New Fee",
						"Failed to create New Fee", "FAIL");
			}
		} while (actions.isElementPresent("MasterFee.Header"));

	}
}
