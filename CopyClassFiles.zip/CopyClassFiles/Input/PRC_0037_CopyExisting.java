/**
   [Class description.  This Class contains the following Test Cases:
   			PRC_0037_CopyExisting
	]  
   @author Anubhuti
   @version 1.0
**/

package xtam.test;

import java.util.Map;
import java.util.Random;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class PRC_0037_CopyExisting {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;
	private String strApplicationDate;
	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo, restNum,Uswarngmsg;
	private boolean flag;
	private String strOperation, StrActivity, StrLevel, StrLevedetails, strDBName, strUserID, strnodename;
	private String strExpectlevel[], strExpectLevelDetails[], Taxtypemes[];
	// TODO: Declare test-data variables for other data-parameters
	private String strWM;
	private String strScsMsg, strErrMsg;

	public PRC_0037_CopyExisting(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);
		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		restNum = mcd.GetTestData("DT_Rest");
		Uswarngmsg	= mcd.GetTestData("DT_US_Warningmessage");
		strnodename = mcd.GetTestData("DT_NodeName");
		strOperation = mcd.GetTestData("DT_OPERATION");
		StrActivity = mcd.GetTestData("DT_ACTIVITY");
		strDBName = mcd.GetTestData("DT_DBNAME");
		strUserID = mcd.GetTestData("DT_USER_NAME");
		StrLevel = mcd.GetTestData("DT_LEVEL");
		StrLevedetails = mcd.GetTestData("DT_LevelDetails");
		strScsMsg = mcd.GetTestData("DT_SuccessMsg");
		strErrMsg = mcd.GetTestData("DT_ErrMsg");
		// TODO: GetTestData for other data-parameters
		strWM = mcd.GetTestData("DT_Warning_Message");
		strExpectlevel = StrLevel.split("#");
		strExpectLevelDetails = StrLevedetails.split("#");
		
	}

	@Test
	public void test_PRC_0037_CopyExisting() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription("Verify create functionality of Tax Type by copying any existing Tax Type");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();
			// ------------------------------------------------------------------------
			// Get the first tax type name
			actions.keyboardEnter("PriceSet.SearchBtn");
			actions.smartWait(30);
			String Taxtypename = driver.findElement(By.xpath(actions.getLocator("TaxType.FirstValue"))).getText();
			System.out.println(Taxtypename);

			// Create Tax Type
			actions.WaitForElementPresent("TaxType.NewTaxTypeButton", 10);
			actions.click("TaxType.NewTaxTypeButton");
			mcd.waitAndSwitch("Add New Tax Type");
			actions.clear("NewTaxType.TaxTypeName");
			actions.setValue("NewTaxType.TaxTypeName", Taxtypename);
			actions.click("NewTaxType.SelectNodeButton");
			mcd.SwitchToWindow("Select Node");
			actions.WaitForElementPresent("SelectNodeRest.SearchTextField", 180);
			mcd.Selectrestnode_JavaScriptClk("RFMSelectNode.SelectNodeTable", restNum);
			mcd.SwitchToWindow("Add New Tax Type");
			actions.click("NewTaxType.Next");
			actions.smartWait(10);

			// Verify the on-screen message
			flag = mcd.VerifyOnscreenMessage("TaxType.ErrorMessage",
					"    Tax Type Name already exists, please enter a different Tax Type Name.", true);

			if (flag) {
				actions.reportCreatePASS("Verify the on-screen message",
						"Message '    Tax Type Name already exists, please enter a different Tax Type Name.'",
						"Expected Message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify the on-screen message",
						"Message '    Tax Type Name already exists, please enter a different Tax Type Name.'",
						"Expected Message is not displayed", "FAIL");
			}

			// Searching for the max string
			actions.closeWindow();
			mcd.SwitchToWindow("@Title");
			actions.WaitForElementPresent("TaxType.NewTaxTypeButton", 10);
			actions.click("TaxType.NewTaxTypeButton");
			mcd.waitAndSwitch("Add New Tax Type");
			String strVal2;
			strVal2 = generateString('c', 900);
			System.out.println(strVal2.length());
			actions.clear("NewTaxType.TaxTypeName");
			actions.setValue("NewTaxType.TaxTypeName", strVal2);
			actions.smartWait(50);
			String newflavorsetname = driver.findElement(By.xpath(actions.getLocator("NewTaxType.TaxTypeName")))
					.getAttribute("value");
			System.out.println(newflavorsetname.length());
			if (newflavorsetname.length() <= 900) {
				actions.reportCreatePASS("verify the whether search box accepected more than 900 Characters",
						"search box should be accepected more than 900 Characters",
						"search box should not be accepected more than 60 Characters", "PASS");
			} else {
				actions.reportCreateFAIL("verify the whether Search box accepected 900 characters",
						"search box should be accepected more than 900 Characters ",
						"search box should be accepected more than 60 Characters", "FAIL");
			}
			actions.clear("NewTaxType.TaxTypeName");

			// Select Node
			actions.click("NewTaxType.SelectNodeButton");
			mcd.SwitchToWindow("Select Node");
			actions.WaitForElementPresent("SelectNodeRest.SearchTextField", 50);
			mcd.Selectrestnode_JavaScriptClk("RFMSelectNode.SelectNodeTable", restNum);

			// Enter unique tax name
			mcd.waitAndSwitch("Add New Tax Type");
			String name = RandomStringUtils.randomAlphanumeric(6);
			System.out.println(name);
			actions.clear("NewTaxType.TaxTypeName");
			actions.setValue("NewTaxType.TaxTypeName", name);

			// Selecting Copy Settings From Existing Tax Type
			actions.click("NewTaxType.YesRadioButton");
			actions.keyboardEnter("NewTaxType.SelectCopyTextTypeButton");
			mcd.SwitchToWindow("Copy Settings From Existing Tax Type");
			actions.WaitForElementPresent("PriceSet.SearchBtn", 10);
			actions.click("PriceSet.SearchBtn");
			actions.smartWait(50);
			actions.click("DiscountSet.TableFirstVal");
			mcd.waitAndSwitch("Add New Tax Type");
			actions.click("NewPriceSet.Cancel");

			// Verify Warning Message
			if (mcd.VerifyAlertMessageDisplayed("Information", strWM, true, AlertPopupButton.CANCEL_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + strWM + " 'is Present or not",
						strWM + " should be present", strWM + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + strWM + " 'is Present or not",
						strWM + " should be present", strWM + " is not present", "Fail");
			}
			
			
			// again click on cancel and also click on ok button alert
			actions.click("NewPriceSet.Cancel");
			if (mcd.VerifyAlertMessageDisplayed("Information", strWM, true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + strWM + " 'is Present or not",
						strWM + " should be present", strWM + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + strWM + " 'is Present or not",
						strWM + " should be present", strWM + " is not present", "Fail");
			}
			

			// Create taxtype by copying exiting tax type
			mcd.SwitchToWindow("@Tax Type");
			actions.WaitForElementPresent("TaxType.NewTaxTypeButton", 10);
			actions.click("TaxType.NewTaxTypeButton");
			mcd.waitAndSwitch("Add New Tax Type");
			actions.clear("NewTaxType.TaxTypeName");

			String taxtype = mcd.fn_GetRndName("Taxt");
			System.out.println(taxtype);

			actions.setValue("NewTaxType.TaxTypeName", taxtype);
			actions.click("NewTaxType.SelectNodeButton");
			mcd.SwitchToWindow("Select Node");
			actions.WaitForElementPresent("SelectNodeRest.SearchTextField", 180);
			mcd.Selectrestnode_JavaScriptClk("RFMSelectNode.SelectNodeTable", restNum);
			mcd.SwitchToWindow("Add New Tax Type");

			// Selecting Copy Settings From Existing Tax Type
			actions.click("NewTaxType.YesRadioButton");
			actions.keyboardEnter("NewTaxType.SelectCopyTextTypeButton");
			mcd.SwitchToWindow("Copy Settings From Existing Tax Type");
			actions.WaitForElementPresent("PriceSet.SearchBtn", 10);
			actions.click("PriceSet.SearchBtn");
			actions.smartWait(30);
			actions.click("DiscountSet.TableFirstVal");
			mcd.waitAndSwitch("Add New Tax Type");
			actions.smartWait(10);

			// Click on Next button and verify the on screen message
			actions.click("NewTaxType.Next");
			if (strMarket.equals("US Country Office")){
				mcd.VerifyAlertMessageDisplayed("Information", Uswarngmsg, true, AlertPopupButton.OK_BUTTON);
				
				
			}
			mcd.SwitchToWindow("@Add Tax Type");
			actions.keyboardEnter("ApplyChangesDetails.Save");
			actions.smartWait(180);
			boolean flag = false, flagFeeId = false;
			try {
				/** Verify Success Messsage */
				flag = mcd.VerifyOnscreenMessage("UpdateTaxType.SvMessage", strScsMsg, true);

			} catch (Exception e) {

				do {
					try {
						/** Verify Error Messsage */
						flagFeeId = mcd.VerifyOnscreenMessage("UpdateTaxType.ErrorCode", strErrMsg, true);
						if (flagFeeId) {
							actions.clear("AddTaxType.TaxTypeCodeTextbox");
							// Entering unique Fee ID
							Random rand_num = new Random();
							int strNewFeeiD = rand_num.nextInt((99) + 5);
							System.out.println(strNewFeeiD);
							/** Set Value in Tax Code Field */
							actions.setValue("AddTaxType.TaxTypeCodeTextbox", Integer.toString(strNewFeeiD));
							actions.keyboardEnter("ApplyChangesDetails.Save");
							actions.smartWait(10);
						}
					} catch (Exception ee) {
						actions.WaitForElementPresent("UpdateTaxType.SvMessage", 180);
						flag = mcd.VerifyOnscreenMessage("UpdateTaxType.SvMessage", strScsMsg, true);
						flagFeeId = false;
					}
				} while (flagFeeId);
			}
			boolean SuccessMsg = mcd.VerifyOnscreenMessage("UpdateTaxType.SvMessage", strScsMsg, true);
			if (SuccessMsg) {
				actions.reportCreatePASS("Verify Tax Type is created by copying existing Tax Type",
						"Tax Type should be created by copying existing Tax Type",
						"Tax Type is created by copying existing Tax Type", "Pass");
			} else {
				actions.reportCreateFAIL("Verify Tax Type is created by copying existing Tax Type",
						"Tax Type should be created by copying existing Tax Type",
						"Tax Type is not created by copying existing Tax Type", "Fail");
			}

			// Verify the Audit log Details
			boolean AuditlogCorrectValuesDisplayed1 = rfm.VerifyAuditLog_Entry(strOperation, StrActivity,
					strExpectlevel[0]);

			if (AuditlogCorrectValuesDisplayed1) {
				actions.reportCreatePASS("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "strExpectActivity[1],Level",
						"Correct values are displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation," + "ActivityValue,Level",
						"Correct values are not displayed", "Fail");
			}

			String AuditDescc = "Tax Type " + taxtype + " has been created at Node " + strnodename + ".";

			boolean isAuditlogCorrectValuesDisplayed1 = rfm.RFM_VerifyAuditLog_Details(strDBName, strUserID,
					strOperation, StrActivity, strExpectlevel[1], strExpectLevelDetails[0], AuditDescc);

			if (isAuditlogCorrectValuesDisplayed1) {
				actions.reportCreatePASS("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "Activities,Level & description ",
						"Correct values are displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "Activities,Level & description ",
						"Correct values are not displayed", "Fail");
			}

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			// Reporter.log("Test Failed :: " + e.getCause() + " - " +
			// e.getMessage());
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
	// To generate the string of specific size

	public static String generateString(char c, Integer n) {
		StringBuilder b = new StringBuilder();
		for (Integer x = 0; x < n; x++)
			b.append(c);
		return b.toString();
	}
}
