package xtam.test;


import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD.AlertPopupButton;


public class PRC_0238_MPU_VerifyErrMsg {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();
	
	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;
	
	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	
	private String strApplicationDate;
	private String strExptMessage;
	private String strValidAmtMessage;
	private String strNewPrice;
	private String strMessageBeforeSave;
	private String strResultMessage;
	
	private String strTaxCode;
	private String strTaxRule;
	private String strTaxEntry;
	private String strTaxType;
	private String strEatingPrc;
	private String strTakeOutPrc;
	private String strOtherPrice;

	
	public PRC_0238_MPU_VerifyErrMsg (WebDriver nodeDriver, Map inputData, Object or){
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();
		
		mcd = new lib_MCD (driver, actions, uiActions, inputData);
		rfm = new lib_RFM2 (driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);
		
		// Read input Test-Data
		strURL 			= mcd.GetTestData("DT_URL");
		strUserName 	= mcd.GetTestData("DT_USER_NAME");
		strPassword 	= mcd.GetTestData("DT_PASSWORD");
		strMarket 		= mcd.GetTestData("DT_MARKET");
		strNavigateTo 	= mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters
		
		strExptMessage 			= mcd.GetTestData("Message");
		strNewPrice 			= mcd.GetTestData("NewPrice");
		strValidAmtMessage		= mcd.GetTestData("ValidAmtMessage");
		strMessageBeforeSave	= mcd.GetTestData("MessageBeforeSave");
		strResultMessage 		= mcd.GetTestData("ResultMessage");
		
		strTaxCode	= mcd.GetTestData("TaxCode");
		strTaxRule	= mcd.GetTestData("TaxRule");
		strTaxEntry	= mcd.GetTestData("TaxEntry");
		strTaxType	= mcd.GetTestData("TaxType");
		
		strEatingPrc	= mcd.GetTestData("EatingPrc");
		strTakeOutPrc	= mcd.GetTestData("TakeOutPrc");
		strOtherPrice	= mcd.GetTestData("OtherPrice");
	}
	
	@Test
	public void PRC_0238_MPU_VerifyErrMsg() throws InterruptedException {
		String strTestDescription = "Verify the error messages of  Mass Update Prices functionality when �All prices are entered";		// TODO: Test Case Description
		
		try {
			 actions.setTestcaseDescription(strTestDescription);
			System.out.println("********************************************************************** Test execution starts");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);
			
			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);
		
            /** Select Menu Option */
            System.out.println("> Navigate to :: " + strNavigateTo);
            actions.select_menu("RFMHome.Navigation",strNavigateTo);
            Thread.sleep(2000);
            actions.waitForPageToLoad(120);

            /** Update title of new Page  */
            mcd.SwitchToWindow("#Title");
            
            /** Get application time */
            WebElement apptime = mcd.getdate();
            strApplicationDate = apptime.getText();

			 /** Get application time */
            
            /* Checking error messages for >,>>,<,<< */
            
            actions.click("RecipeReport.NextBtn");
            mcd.VerifyAlertMessageDisplayed("warning message", "No data to transfer.", true,AlertPopupButton.OK_BUTTON);
            
            actions.click("RecipeReport.PreviousBtn");
            mcd.VerifyAlertMessageDisplayed("warning message", "No data to transfer.", true,AlertPopupButton.OK_BUTTON);
            
            actions.click("SuspendPackage.DoubleGreaterthan");
            mcd.VerifyAlertMessageDisplayed("warning message", "No data to transfer.", true,AlertPopupButton.OK_BUTTON);
            
            actions.click("SuspendPackage.DoubleLessthan");
            mcd.VerifyAlertMessageDisplayed("warning message", "No data to transfer.", true,AlertPopupButton.OK_BUTTON);
			
		
			// ------------------------------------------------------------------------ Actions specific to test-flow
			
			// Verify Mass Update Prices
            RFM_PRC_MassUpdatePricesValidations(strExptMessage, strValidAmtMessage, strMessageBeforeSave, strResultMessage, strNewPrice, strTaxCode, strTaxRule, strTaxEntry, strTaxType, strApplicationDate);
			
			
			// ------------------------------------------------------------------------ 

            
			/** Logout the application */
			rfm.Logout();
			

		}catch(Exception e) {
			//Reporter.log("Test Failed :: " + e.getCause() + " - " +  e.getMessage());
			System.out.println("Test Failed :: " + e.getCause() + " - " +  e.getMessage());
			actions.catchException(e);
			
		        } finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
	
	public void RFM_PRC_MassUpdatePricesValidations(String strStartDateMessage, String strValidAmtMessage,
			String strMessageBeforeSave, String strResultMessage, String strNewPrice, String strTaxCode,
			String strTaxRule, String strTaxEntry, String strTaxType, String strApplicationDate) throws Exception {

		this.RFM_PRC_MUP_Prerquisite();

		// Updating date
		Boolean Check1 = driver.findElement(By.xpath(actions.getLocator("Massupdateprices.start"))).isDisplayed();
		Boolean Check2 = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.StartDate"))).isEnabled();
		if (Check1) {
			if (Check2) {
				actions.reportCreatePASS("Verify Start Date TextBox", "Should be present & enabled",
						"Present & Enabled", "PASS");
				// Reporter.log("Start Date textbox is present and enabled -
				// PASS");
			} else {
				actions.reportCreateFAIL("Verify Start Date TextBox", "Should be present & enabled",
						"Present but disabled", "FAIL");
				// Reporter.log("Start Date textbox is disabled - FAIL");
			}
		} else {
			actions.reportCreateFAIL("Verify Start Date TextBox", "Should be present & enabled", "Not Present", "PASS");
			// Reporter.log("Start Date button is not present - FAIL");
		}

		// Selecting Today's date (Today Button)
		Thread.sleep(1000);
		actions.click("UpdtMultipleSet.TodayBtn");

		// Getting today's date in required format
		WebElement apptime = mcd.getdate();
		String app_date = apptime.getText();

		String dtForm = mcd.GetTestData("DT_DATE_FORMAT");
		String TodayDt = app_date.substring(0, dtForm.length());

		// Reading date displayed in the application
		String CurrDate = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.StartDate")))
				.getAttribute("value");

		// Verifying date
		if (CurrDate.trim().equals(TodayDt.trim())) {
			actions.reportCreatePASS("Verify Today's date", "Today's date should be correctly updated as: "+CurrDate ,
					"Today's Date Displayed Correctly as: " +TodayDt, "PASS");
			// Reporter.log("Today's date correctly updated - PASS");
		} else {
			actions.reportCreateFAIL("Verify Today's date", "Today's date should be correctly updated as: "+CurrDate ,
					"Today's Date Not Displayed Correctly as: " +TodayDt, "FAIL");
			// Reporter.log("Today's date wrongly updated - FAIL");
		}

		// Verifying Clear button functionality
		actions.click("UpdtMultipleSet.Clear");
		Thread.sleep(500);
		Boolean chk = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.SDateVal"))).getAttribute("value")
				.isEmpty();

		if (chk) {
			actions.reportCreatePASS("Verify Clear button functionality", "Field data should be cleared",
					"Data cleared", "PASS");
			// Reporter.log("Clear Button Verification - PASS");
		} else {
			actions.reportCreateFAIL("Verify Clear button functionality", "Field data should be cleared",
					"Data not cleared", "FAIL");
			// Reporter.log("Clear Button Verification - FAIL");
		}

		// "Please enter start date." - Validation
		Thread.sleep(2000);
		actions.click("UpdtMultipleSet.Apply");
		Thread.sleep(2000);
		Boolean VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strStartDateMessage, true,
				AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg) {
			actions.reportCreatePASS("Start Date Mandatory Validation", "Start Date should be Mandatory",
					"Start Date is Mandatory", "PASS");
			// Reporter.log("Start Date Mandatory Validation PASS");
		} else {
			actions.reportCreateFAIL("Start Date Mandatory Validation", "Start Date should be Mandatory",
					"Start Date is not Mandatory", "FAIL");
			// Reporter.log("Start Date Mandatory Validation FAIL");
		}
		Thread.sleep(1000);

		// Checking Calendar Icon
		actions.click("UpdtMultipleSet.CalenderIcon");
		Thread.sleep(500);
		
		//Future date
		// mcd.Get_future_date(5, "UpdtMultipleSet.CalenderIcon", );
		mcd.Get_future_date(1, "close", strApplicationDate);

		chk = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.SDateVal"))).getAttribute("value")
				.isEmpty();

		if (!chk) {
			actions.reportCreatePASS("Date selection using calender", "Date should be selected", "Date selected",
					"PASS");
			// Reporter.log("Date selection using calender - PASS");
		} else {
			actions.reportCreateFAIL("Date selection using calender", "Date should be selected", "Date not selected",
					"FAIL");
			// Reporter.log("Date selection using calender - FAIL");
		}

		Thread.sleep(1000);

		// Valid input for All Prices Validation(non Numeric data)

		actions.click("UpdtMultipleSet.Clear");
		actions.click("UpdtMultipleSet.TodayBtn");
		actions.setValue("UpdtMultipleSet.AllPrc", "abc");
		actions.click("UpdtMultipleSet.Apply");
		Thread.sleep(3000);
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strValidAmtMessage, true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg) {
			actions.reportCreatePASS("Field - All Price - Non Numeric Validation",
					"Should not accept non-numeric values", "Does not accept non-numeric value", "PASS");
			// Reporter.log("Field - All Price - Non Numeric Validation PASS");
		} else {
			actions.reportCreateFAIL("Field - All Price - Non Numeric Validation",
					"Should not accept non-numeric values", "Accepts non-numeric value", "FAIL");
			// Reporter.log("Field - All Price - Non Numeric Validation FAIL");
		}

		// Mass Updating Prices
		// Verifying Date & Prices entered are updated correctly.
		actions.clear("UpdtMultipleSet.AllPrc");
		actions.clear("UpdtMultipleSet.AllPrc");
		actions.setValue("UpdtMultipleSet.AllPrc", strNewPrice);
		actions.click("UpdtMultipleSet.Apply");
		Thread.sleep(1000);
		actions.smartWait(120);

		String InpStrtDate = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.StartDate")))
				.getAttribute("value");
		String AppliedDate = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewDate")))
				.getAttribute("value");

		String ALL_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewAllPrc")))
				.getAttribute("value");

		if (InpStrtDate.equals(AppliedDate)) {
			actions.reportCreatePASS("Verify Start Date", "Start Date should be updated against for all prices",
					"Start Date entered is updated against for all prices", "PASS");
			// Reporter.log("Start Date entered is updated against for all
			// prices correctly - PASS");
		} else {
			actions.reportCreateFAIL("Verify Start Date", "Start Date should be updated against for all prices",
					"Start Date entered is not correctly updated against for all prices", "FAIL");
			// Reporter.log("Start Date entered is not updated correctly -
			// FAIL");
		}

		try {
			driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.ExpandImg"))).click();
		} catch (Exception err) {
			System.out.println("Price already expanded");
		}
		// actions.keyboardEnter("UpdtMultipleSet.ExpandImg");
		// Reading Eating/take out/other prices
		String Eating_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewEatingPrc")))
				.getAttribute("value");
		String TakeOut_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewTkOutPrc")))
				.getAttribute("value");
		String Other_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewOtherPrc")))
				.getAttribute("value");
		if ((ALL_Price.equals(strNewPrice)) && (Eating_Price.equals(strNewPrice)) && (TakeOut_Price.equals(strNewPrice))
				&& (Other_Price.equals(strNewPrice))) {
			actions.reportCreatePASS("Verify All Prices/Eating/Take out/Other Prices", "Should be updated correctly",
					"Updated correctly", "PASS");
			// Reporter.log("All Prices/Eating/Take out/Other Prices updated
			// correctly - PASS");
		} else {
			actions.reportCreateFAIL("Verify All Prices/Eating/Take out/Other Prices", "Should be updated correctly",
					"Not updated correctly", "FAIL");
			// Reporter.log("All Prices/Eating/Take out/Other Prices not updated
			// correctly - FAIL");
		}

		// ------------------------------------------------------------------------------
		// Update Tax Functionality
		// -----------------------------------------------------------------------------

		actions.clickAndVerify("UpdtMultipleSet.UpdtTax", "");
		Thread.sleep(2000);

		// String CurrHandle = driver.getWindowHandle();
		// //System.out.println("Current-" +driver.getTitle());
		// actions.windowSwitch(CurrHandle, "Mass Update Prices");
		// Thread.sleep(2000);

		mcd.SwitchToWindow("Mass Update Prices");

		// Update Tax
		Boolean TaxResult = this.RFM_MassUpdatePrc_UpdateTax(strTaxCode, strTaxRule, strTaxEntry, strTaxType);
		if (TaxResult) {
			actions.reportCreatePASS("Verify Update Tax", "Tax should be correctly updated", "Correctly updated",
					"PASS");
			// Reporter.log("Update Tax done successfully - PASS");
		} else {
			actions.reportCreateFAIL("Verify Update Tax", "Tax should be correctly updated", "Not correctly updated",
					"FAIL");
			// Reporter.log("Update Tax not done successfully - FAIL");
		}

		// String NewHandle = driver.getWindowHandle();
		// actions.windowSwitch(NewHandle, "Mass Update Prices");
		// Thread.sleep(3000);

		// Save & Apply Changes
		this.RFM_PRC_MUP_SaveAndApply(strMessageBeforeSave, strResultMessage);

		// Verifying correct prices are saved
		Thread.sleep(1000);

		try {
			driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.ExpandImg"))).click();
			Thread.sleep(1000);
		} catch (Exception e2) {
			System.out.println("Already expanded");
		}

		ALL_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewAllPrc"))).getAttribute("value");
		Eating_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewEatingPrc")))
				.getAttribute("value");
		TakeOut_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewTkOutPrc")))
				.getAttribute("value");
		Other_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewOtherPrc")))
				.getAttribute("value");

		if ((ALL_Price.equals(strNewPrice)) || ((Eating_Price.equals(strNewPrice))
				&& (TakeOut_Price.equals(strNewPrice)) && (Other_Price.equals(strNewPrice)))) {
			actions.reportCreatePASS("Verify All Prices/Eating/Take out/Other Prices", "Should be saved correctly",
					"Saved correctly", "PASS");
			// Reporter.log("All Prices/Eating/Take out/Other Prices saved
			// correctly - PASS");
		} else {
			actions.reportCreateFAIL("Verify All Prices/Eating/Take out/Other Prices", "Should be saved correctly",
					"Not saved correctly", "FAIL");
			// Reporter.log("All Prices/Eating/Take out/Other Prices not saved
			// correctly - FAIL");
		}
		Thread.sleep(1000);

	}
	public void RFM_PRC_MUP_Prerquisite() throws InterruptedException {
		
		// Menu Item
		actions.keyboardEnter("UpdateSet.VwFullList");
		Thread.sleep(2000);
		actions.smartWait(180);
		mcd.select_row("UpdateSet.MenuItemTable", 0);
		Thread.sleep(500);
		actions.click("UpdateSet.AddRow");
		Thread.sleep(500);
		actions.click("UpdateSet.NextBtn");
		Thread.sleep(2000);
		actions.smartWait(180);

		// Price Sets
		actions.click("UpdatePrcSet.VwFullList");
		Thread.sleep(2000);
		actions.smartWait(180);
		mcd.select_row("UpdatePrcSet.PriceSetTable", 0);
		Thread.sleep(500);
		actions.click("UpdatePrcSet.AddRow");
		Thread.sleep(500);
		actions.click("UpdatePrcSet.NextBtn");
		Thread.sleep(2000);
		actions.smartWait(180);
	}
	public void RFM_PRC_MUP_SaveAndApply(String strMessageBeforeSave, String strResultMessage) throws Exception {
		// Click Save
		Thread.sleep(2000);
		
		/*/Unchecking activate menu items checkbox*/
		if(driver.findElement(By.xpath(actions.getLocator("RFMMassUpdatePrices.chkActivateAllMI"))).isSelected()){
			actions.click("RFMMassUpdatePrices.chkActivateAllMI");
		}
		
		actions.click("UpdtMultipleSet.Save");
		Thread.sleep(3000);
		// actions.smartWait(120);

		// Check Alert message
		try {
			Boolean VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strMessageBeforeSave, true,
					AlertPopupButton.OK_BUTTON);
			if (VerifyPopUpMsg) {
				actions.reportCreatePASS("Verify Alert message before save", "Alert message should be given",
						"Alert message is given", "PASS");
				// Reporter.log("Alert Message before save is displayed -
				// PASS");
			} else {
				actions.reportCreateFAIL("Verify Alert message before save", "Alert message should be given",
						"Alert message is not given", "FAIL");
				// Reporter.log("Alert Message before save is not displayed -
				// FAIL");
			}
		} catch (Exception err) {
			System.out.println("No alerts");
		}

		// as the page is continuously loading because of pop up , only hard wait
		// can be solution here.
		// Thread.sleep(10000);

		actions.WaitForElementPresent("OutputWindow.OutputMsg", 180);
		// actions.smartWait(120);
		// Check Success Message

		String Result = driver.findElement(By.xpath(actions.getLocator("OutputWindow.OutputMsg"))).getText();
		if (Result.equals(strResultMessage)) {
			actions.reportCreatePASS("Verify Mass update of prices", "Should be done successfully", "Done successfully",
					"PASS");
			// Reporter.log("Mass update of prices done successfully - PASS");
		} else {
			actions.reportCreateFAIL("Verify Mass update of prices", "Should be done successfully",
					"Not done successfully", "PASS");
			// Reporter.log("Mass update of prices failed - FAIL");
		}

				/*		
		// Activating Menu Item case
		try {
			String Result_Img = driver.findElement(By.xpath(actions.getLocator("ActivateMISet.DoneImg2")))
					.getAttribute("src");
			if (Result_Img.contains("approve.jpg")) {
				actions.reportCreatePASS("Verify Activate Menu Item", "Activate Menu Item should be done successfully",
						"Activate Menu Item is done successfully", "PASS");
				// Reporter.log("Activate Menu Item is done successfully");
			} else {
				actions.reportCreateFAIL("Verify Activate Menu Item", "Activate Menu Item should be done successfully",
						"Activate Menu Item is not done successfully", "FAIL");
				// Reporter.log("Activate Menu Item is done successfully");
			}
		} catch (Exception e) {
			// Reporter.log("Activating Menu Item is unchecked");
		}
		// Click OK button
*/
		Thread.sleep(2000);
		actions.click("OutputWindow.OkBtn");
		Thread.sleep(5000);

		// Window navigated back to main window
		// System.out.println(driver.getTitle());
		if (driver.getTitle().equals("Mass Update Prices")) {
			actions.reportCreatePASS("Verify navigation after final output",
					"Window should be navigated back after updating prices",
					"Window navigated back after updating prices", "PASS");
			// Reporter.log("Window navigated back after updating prices -
			// PASS");
		} else {
			actions.reportCreateFAIL("Verify navigation after final output",
					"Window should be navigated back after updating prices",
					"Window not navigated back after updating prices", "FAIL");
			// Reporter.log("Window not navigated back after updating prices -
			// FAIL");
		}

	}
	public boolean RFM_MassUpdatePrc_UpdateTax(String strTaxCode, String strTaxRule, String strTaxEntry,
			String strTaxType) throws Exception {
		Boolean blnResult = false;

		
		//Clicking cancel button
				 
		actions.click("RFMMassUpdatePrices.Save");
        mcd.VerifyAlertMessageDisplayed("Warning message", "No changes have been made.", true,AlertPopupButton.OK_BUTTON);
		
		// Read the already existing tax entry value
		Select select = new Select(driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.MITaxEntry"))));
		String currEntry = select.getFirstSelectedOption().getText().trim();
		System.out.println(currEntry);

		// Enter Tax Code
		actions.setValue("UpdateTax.TaxCode", strTaxCode);
		Thread.sleep(3000);

		// Check Clear functionality
		// actions.click("UpdateTax.Clear");
		actions.keyboardEnter("UpdateTax.Clear");
		Thread.sleep(3000);
		String Str2 = actions.getValue("UpdateTax.TaxCode");
		if (Str2.equals("Default")) {
			// if (actions.getValue("UpdateTax.TaxCode").equals("Default")){
			actions.reportCreatePASS("Update Tax : Verify Clear button", "Field should get cleared",
					"Clear working as expected", "PASS");
			// Reporter.log("Clear button function in Update Tax - PASS");
		} else {
			actions.reportCreateFAIL("Update Tax : Verify Clear button", "Field should get cleared",
					"Clear not working as expected", "FAIL");
			// Reporter.log("Clear button function in Update Tax - FAIL");
		}

		Thread.sleep(2000);
		// Select rule before tax code - error message
		actions.setValue("UpdateTax.TaxRule", strTaxRule);
		Thread.sleep(500);
		Boolean VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", "Please select Tax Code.", true,
				AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg) {
			actions.reportCreatePASS("Verify Tax Code should be entered", "Correct message should be given",
					"Correct message is displayed", "PASS");
			// Reporter.log("Tax code must be selected before Tax rule
			// verification - PASS");
		} else {
			actions.reportCreateFAIL("Verify Tax Code should be entered", "Correct message should be given",
					"Correct message is not displayed, User is allowed to proceed without entering Tax code", "FAIL");
			// Reporter.log("Tax code must be selected before Tax rule
			// verification - FAIL");
		}
		Thread.sleep(1000);

		// Select Tax Code
		actions.setValue("UpdateTax.TaxCode", strTaxCode);
		Thread.sleep(1000);

		// Select Tax Rule
		actions.setValue("UpdateTax.TaxRule", strTaxRule);
		Thread.sleep(1000);

		// Apply Tax - Mandatory Rule Validation
		actions.click("UpdateTax.ApplyTax");
		// actions.javaScriptClick("UpdateTax.ApplyTax");
		Thread.sleep(1000);

		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", "Tax Entry is mandatory if a Tax Rule is selected.",
				true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg) {
			actions.reportCreatePASS("Verify Tax entry", "Tax entry should be mandatory is tax rule is selected",
					"Tax entry is mandatory", "PASS");
			// Reporter.log("Tax Entry must be entered message is displayed -
			// PASS");
		} else {
			actions.reportCreateFAIL("Verify Tax entry", "Tax entry should be mandatory is tax rule is selected",
					"Tax entry is not mandatory", "FAIL");
			// Reporter.log("Tax Entry must be entered message is not displayed
			// - FAIL");
		}
		Thread.sleep(1000);

		select = new Select(driver.findElement(By.xpath(actions.getLocator("UpdateTax.TaxEntry"))));

		// enter different Tax Entry
		for (int i = 0; i < select.getOptions().size(); i++) {
			if ((select.getOptions().get(i).getText().trim().equals(currEntry))
					|| (select.getOptions().get(i).getText().trim().equals("Default"))) {
				// Same as existing. Do nothing
				System.out.println(select.getOptions().get(i).getText().trim());
			} else {
				select.selectByIndex(i);
				break;
			}
		}

		strTaxEntry = actions.getValue("UpdateTax.TaxEntry");
		System.out.println(strTaxEntry);

		// Select Tax Type
		actions.setValue("UpdateTax.TaxType", strTaxType);
		Thread.sleep(1000);

		// Apply Tax

		actions.click("UpdateTax.ApplyTax");
		Thread.sleep(3000);

		// Apply the Tax settings
		actions.click("RFMMassUpdatePrices.Save");

		driver.switchTo().window("");
		mcd.SwitchToWindow("@Mass Update Prices");

		actions.click("UpdtMultipleSet.UpdtTax");
		Thread.sleep(2000);

		mcd.SwitchToWindow("Mass Update Prices");

		// String CurrHandle = driver.getWindowHandle();
		// //System.out.println("Current-" +driver.getTitle());
		// actions.windowSwitch(CurrHandle, "Mass Update Prices");
		// Thread.sleep(2000);

		// Verify Tax - All/Eating/Take out/Other
		String All_TaxCode = actions.getValue("UpdateTax.NewTaxCode");
		Thread.sleep(500);
		String All_TaxRule = actions.getValue("UpdateTax.NewTaxRule");
		Thread.sleep(500);
		String All_TaxEntry = actions.getValue("UpdateTax.NewTaxEntry");
		Thread.sleep(1500);

		// Expand Tax setting
		try {
			actions.click("UpdateTax.ExpandBtn");
			Thread.sleep(2000);
		} catch (Exception err) {
			System.out.println("Already expanded");
		}

		String Eat_TaxCode = actions.getValue("UpdateTax.NewEatingTxCode");
		Thread.sleep(500);
		String Eat_TaxRule = actions.getValue("UpdateTax.NewEatingTxRule");
		Thread.sleep(500);
		String Eat_TaxEntry = actions.getValue("UpdateTax.NewEatingTxEntry");
		Thread.sleep(500);

		String TO_TaxCode = actions.getValue("UpdateTax.NewTkOutCode");
		Thread.sleep(500);
		String TO_TaxRule = actions.getValue("UpdateTax.NewTkOutRule");
		Thread.sleep(500);
		String TO_TaxEntry = actions.getValue("UpdateTax.NewTkOutEntry");
		Thread.sleep(500);

		String Other_TaxCode = actions.getValue("UpdateTax.NewOtherCode");
		Thread.sleep(500);
		String Other_TaxRule = actions.getValue("UpdateTax.NewOtherRule");
		Thread.sleep(500);
		String Other_TaxEntry = actions.getValue("UpdateTax.NewOtherEntry");
		Thread.sleep(500);

		if (All_TaxCode.equals(strTaxCode) && Eat_TaxCode.equals(strTaxCode) && TO_TaxCode.equals(strTaxCode)
				&& Other_TaxCode.equals(strTaxCode)) {
			actions.reportCreatePASS("Verify Tax Code for ALL/Eating/Take out/Other fields",
					"Tax code should be updated", "Tax code is updated", "PASS");
			// Reporter.log("ALL/Eating/Take out/Other Tax Code update - PASS");
			blnResult = true;
		} else {
			actions.reportCreateFAIL("Verify Tax Code for ALL/Eating/Take out/Other fields",
					"Tax code should be updated", "Tax code is not updated", "FAIL");
			// Reporter.log("ALL/Eating/Take out/Other Tax Code update - FAIL");
			blnResult = false;
		}

		if (All_TaxRule.equals(strTaxRule) && Eat_TaxRule.equals(strTaxRule) && TO_TaxRule.equals(strTaxRule)
				&& Other_TaxRule.equals(strTaxRule)) {
			actions.reportCreatePASS("Verify Tax Rule for ALL/Eating/Take out/Other fields",
					"Tax rule should be updated", "Tax rule is updated", "PASS");
			// Reporter.log("ALL/Eating/Take out/Other Tax Rule update - PASS");
			blnResult = true;
		} else {
			actions.reportCreateFAIL("Verify Tax Rule for ALL/Eating/Take out/Other fields",
					"Tax rule should be updated", "Tax rule is not updated", "FAIL");
			// Reporter.log("ALL/Eating/Take out/Other Tax Rule update - FAIL");
			blnResult = false;
		}

		if (All_TaxEntry.equals(strTaxEntry) && Eat_TaxEntry.equals(strTaxEntry) && TO_TaxEntry.equals(strTaxEntry)
				&& Other_TaxEntry.equals(strTaxEntry)) {
			actions.reportCreatePASS("Verify Tax Entry for ALL/Eating/Take out/Other fields",
					"Tax entry should be updated", "Tax entry is updated", "PASS");
			// Reporter.log("ALL/Eating/Take out/Other Tax Entry update -
			// PASS");
			blnResult = true;
		} else {
			actions.reportCreateFAIL("Verify Tax Entry for ALL/Eating/Take out/Other fields",
					"Tax entry should be updated", "Tax entry is not updated", "FAIL");
			// Reporter.log("ALL/Eating/Take out/Other Tax Entry update -
			// FAIL");
			blnResult = false;
		}

		actions.keyboardEnter("RFM.CancelBtn");
		Thread.sleep(2000);

		driver.switchTo().window("");
		mcd.SwitchToWindow("@Mass Update Prices");

		return blnResult;

	}
}
