package xtam.test;

import java.util.Map;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Keywords.DialogType;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class PRC_0115_FilterStaus_Validation {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing prc;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strDescription;
	// Declare test-data variables for other data-parameters
	private String strSrchType[], strNavigateto[], strNode, srchtype, strSrchText[], srchtext, strValTxt[],
			Validate_Text, strtext;
	boolean matched = false;

	public PRC_0115_FilterStaus_Validation(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		prc = new Pricing(driver, actions, uiActions, inputData, mcd, rfm, or);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// GetTestData for other data-parameters
		srchtype = mcd.GetTestData("DT_SRCHTYPE");
		srchtext = mcd.GetTestData("DT_SRCHDATA");
		Validate_Text = mcd.GetTestData("DT_VALIDATETEXT");
		strDescription = mcd.GetTestData("DT_DESCRIPTION");
		strNode = mcd.GetTestData("DT_NODE");

		strValTxt = Validate_Text.split("#");
		strSrchType = srchtype.split("#");
		strSrchText = srchtext.split("#");
		strNavigateto = strNavigateTo.split("#");
	}

	@Test
	public void test_RFM_0115_Validating_Filter_List_and_Status_dropdown_lists() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			String strTestDescription = "Filter the records by selecting a values from 'Filter List' & 'Status' dropdown lists";

			// setting the test case description
			actions.setTestcaseDescription(strTestDescription);

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateto[0]);
			actions.select_menu("RFMHome.Navigation", strNavigateto[0]);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			// Creating a price set now for Pre-Req
			fn_CreateSet("New Price Set", "RFMSelectNode.SelectNode", mcd.GetGlobalData("Rest_1"), "No",
					"@Price Sets : Common Menu Item Selector", "New Price Sets");

			// adding the Active and Available menu items now
			actions.WaitForElementPresent("CommonMenuItemSelector.ViewFullListBtn", 180);
			actions.keyboardEnter("CommonMenuItemSelector.ViewFullListBtn");
			actions.smartWait(180);
			actions.setValue("AddRemoveMenu.Availability", "Available");
			actions.smartWait(180);
			actions.setValue("AddRemoveMI.FilterStatus", "Active");
			actions.smartWait(180);
			WebElement elem_checkbox = mcd.GetTableCellElement("AddRemoveComponent.webtable", 1, "Add", "input");
			actions.javaScriptClick(elem_checkbox);
			actions.click("RFM.SaveBtn");
			actions.smartWait(180);
			actions.click("RFM.CancelButton");
			actions.smartWait(180);
			actions.keyboardEnter("PriceSet.SearchBtn");
			actions.smartWait(180);

			// Don�t select any value from Region and Coop DDL and click on
			// Filter button to verify the alert message

			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.keyboardEnter("PriceSets.FilterButton");
			// verify the alert pop up and validate the same
			actions.isAlertPresent(180);
			if (mcd.VerifyAlertMessageDisplayed("Confirmation", strValTxt[0].trim(), true,
					AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Verify pop up alert Message",
						"Pop Up alert Message '" + strValTxt[0].trim() + " 'should be displayed",
						"Pop Up alert Message '" + strValTxt[0].trim() + " ' is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify pop up alert Message",
						"Pop Up alert Message '" + strValTxt[0].trim() + " ' should be displayed",
						"Pop Up alert Message '" + strValTxt[0].trim() + " ' is not displayed", "Fail");
			}

			// searching for the price sets associated with the
			// specific node validating the result for the filters applied
			actions.setValue("RFMPriceSets.PriceSetSearchbox", mcd.GetTestData("DT_PREFIX").substring(0, 3));
			actions.keyboardEnter("PriceSet.SearchBtn");
			actions.smartWait(20);

			/** Getting the row count after searching the record */
			int iRow_cnt = mcd.GetTableRowCount("Price.PriceSets");
			if (iRow_cnt <= 1) {
				// getting the records form the table
				String record = mcd.GetTableCellValue("Price.PriceSets", 1, "Node", "", "");

				// verifying the region now
				if (record.equalsIgnoreCase(strNode.trim())) {
					actions.reportCreatePASS(
							"Verify All the Price Sets created under" + strSrchText[0].trim()
									+ " should be listed or displayed in the result.",
							"All the Price Sets created under" + strSrchText[0].trim()
									+ " should be listed or displayed in the result.",
							"All the Price Sets created under" + strSrchText[0].trim()
									+ " is listed or displayed in the result.",
							"Pass");
				} else {
					actions.reportCreateFAIL(
							"Verify All the Price Sets created under" + strSrchText[0].trim()
									+ " should be listed or displayed in the result.",
							"All the Price Sets created under" + strSrchText[0].trim()
									+ " should be listed or displayed in the result.",
							"All the Price Sets created under" + strSrchText[0].trim()
									+ " is not listed or displayed in the result",
							"Fail");
				}
			} else {
				// filtering the records now and validating the same
				actions.setValue("PriceSetList.Filter", strSrchText[0].trim());

				Select select = new Select(driver.findElement(By.xpath(actions.getLocator("PriceSetList.Filter"))));
				String strActualRegionValue = select.getFirstSelectedOption().getText();
				System.out.println("strActualRegionValue>>" + strActualRegionValue);

				if (strActualRegionValue.equalsIgnoreCase(strSrchText[0].trim())) {
					actions.reportCreatePASS(
							"Verify Selected region '" + strSrchText[0].trim() + "' displayed in the DDL",
							"Selected region '" + strSrchText[0].trim() + "' should displayed in the DDL",
							"Selected region '" + strSrchText[0].trim() + "' is displayed in the DDL", "Pass");
				} else {
					actions.reportCreateFAIL(
							"Verify Selected region '" + strSrchText[0].trim() + "' displayed in the DDL",
							"Selected region '" + strSrchText[0].trim() + "' should displayed in the DDL",
							"Selected region '" + strSrchText[0].trim() + "' is not displayed in the DDL", "FAIL");
				}

				// applying the filter now
				actions.keyboardEnter("PriceSets.FilterButton");
				actions.smartWait(20);
				/** get the count for the filter list */
				iRow_cnt = mcd.GetTableRowCount("Price.PriceSets");
				if (iRow_cnt == 0) {
					System.out.println("No price sets exist for this region");
				} else {
					boolean blnmtch = false;
					for (int d = 0; d < iRow_cnt - 1; d++) {
						// getting the records form the table
						String record = mcd.GetTableCellValue("Price.PriceSets", d + 1, "Node", "", "");

						// verifying the region now
						if (record.equalsIgnoreCase(strNode.trim())) {
							actions.reportCreatePASS(
									"Verify All the Price Sets created under" + strSrchText[0].trim()
											+ " should be listed or displayed in the result.",
									"All the Price Sets created under" + strSrchText[0].trim()
											+ " should be listed or displayed in the result.",
									"All the Price Sets created under" + strSrchText[0].trim()
											+ " is listed or displayed in the result.",
									"Pass");
							blnmtch = true;
							break;

						}
					}

					if (blnmtch == false) {
						actions.reportCreateFAIL(
								"Verify All the Price Sets created under" + strSrchText[0].trim()
										+ " should be listed or displayed in the result.",
								"All the Price Sets created under" + strSrchText[0].trim()
										+ " should be listed or displayed in the result.",
								"All the Price Sets created under" + strSrchText[0].trim()
										+ " is not listed or displayed in the result",
								"Fail");
					}
				}
			}
			// clicking on the view list now
			actions.keyboardEnter("PriceSet.SearchBtn");
			actions.smartWait(20);

			// applying the filter by status now
			actions.setValue("PriceSet.FilterByStatus", strSrchType[1].trim());
			actions.smartWait(20);

			// getting the filtered result and validating for Active
			String status = mcd.GetTableCellValue("RFM.WebTable", 1, "Status", "", "");

			if (status.equalsIgnoreCase("Active")) {
				actions.reportCreatePASS("Validating the search with valid data", "Search should display exact record",
						"Search displayed exact record", "Pass");
			} else {
				actions.reportCreateFAIL("Validating the search with valid data", "Search should display exact record",
						"Search not displayed exact record", "Fail");
			}

			// applying the filter by status now
			actions.setValue("PriceSet.FilterByStatus", strSrchType[2].trim());
			actions.smartWait(20);

			// getting the filtered result and validating for Inactive
			status = mcd.GetTableCellValue("RFM.WebTable", 1, "Status", "", "");

			if (status.equalsIgnoreCase("Inactive")) {
				actions.reportCreatePASS("Validating the search with valid data", "Search should display exact record",
						"Search displayed exact record", "Pass");
			} else {
				actions.reportCreateFAIL("Validating the search with valid data", "Search should display exact record",
						"Search not displayed exact record", "Fail");
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			// reporting the Fail condition
			actions.catchException(e);
		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}

	// Creating new price set
	public String fn_CreateSet(String strAddNewSetName, String strrestlocator, String strrest, String strCopyExisting,
			String WindowName, String PopWinName) {
		String strFeatureSetName = "";
		try {
			/** Click on New Set **/
			String strXPath = "";
			strXPath = "//*[@class='button'][contains(text()," + "'" + strAddNewSetName + "')]";
			WebElement addNewSetButton = driver.findElement(By.xpath(strXPath));
			if (addNewSetButton != null) {
				actions.click(addNewSetButton);
			}

			/** -------Switch window to Add New Day Part Set---- **/
			mcd.SwitchToWindow(PopWinName);

			/** Set Value of Day part Set name and select name **/
			strFeatureSetName = mcd.GetTestData("DT_PREFIX") + "_" + RandomStringUtils.randomAlphabetic(5);
			actions.setValue("RFMAddNewSet.SetName", strFeatureSetName);
			actions.click("RFM.SBSelectNode");

			// Select Hierarchy from select window
			mcd.SwitchToWindow("Select Node");

			actions.click("SelectNode.ExactMtchRadiobtn");
			actions.setValue("SelectNode.SearchBox", strrest);
			actions.keyboardEnter("SelectNode.SearchButton");

			actions.smartWait(20);
			// actions.waitForPageToLoad(120);

			// actions.WaitForElementPresent("SelectNode.ARTableFirstValue");

			// selecting the rest node now
			if (mcd.GetGlobalData("Instance").toLowerCase().contains("eu")) {
				mcd.Selectrestnode("SelectNode.CPTable", strrest);
			} else {
				mcd.Selectrestnode("SelectNode.NodeTable", strrest);
			}
			/** switching to new window */
			mcd.SwitchToWindow("$" + PopWinName);

			/** Select Copy Existing **/
			if (strCopyExisting.equalsIgnoreCase("No")) {
				/** Click on Next **/
				actions.keyboardEnter("SelectNode.Next");
				Thread.sleep(5000);
				mcd.waitAndSwitch(WindowName);
				actions.smartWait(180);
			}
		} catch (Exception e) {
			System.out.println("Failed Test" + e.getMessage());
		}
		return strFeatureSetName;
	}
}
