package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class PRC_0151_UpdtPrcSet {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// Declare test-data variables for other data-parameters
	private String strTestDescription, strMsg, strstatus, strValue, strNavigateToPrcSet;
	private String strNavigateToVGR, strNavigateToMI, strNavigateToPS, strNavigateToTBR, strNavigateToSAR;
	boolean flag = false;

	public PRC_0151_UpdtPrcSet(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// GetTestData for other data-parameters
		strTestDescription = mcd.GetTestData("DT_DESCRIPTION");
		strMsg = mcd.GetTestData("DT_MESSAGE");
		strNavigateToVGR = mcd.GetTestData("DT_NAVIGATE_TO_VGR");
		strNavigateToMI = mcd.GetTestData("DT_NAVIGATE_TO_MI");
		strNavigateToPS = mcd.GetTestData("DT_NAVIGATE_TO_PS");
		strNavigateToTBR = mcd.GetTestData("DT_NAVIGATE_TO_TBR");
		strNavigateToSAR = mcd.GetTestData("DT_NAVIGATE_TO_SAR");
		strValue = mcd.GetTestData("DT_VAL");
		strNavigateToPrcSet = mcd.GetTestData("DT_NAVIGATE_TO_PRCSET");
	}

	@Test
	public void test_PRC_0151_UpdtPrcSet() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			/** Get Test Description */
			actions.setTestcaseDescription(strTestDescription);

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Navigating to Price Sets */
			System.out.println("> Navigate to :: " + strNavigateToPrcSet);
			actions.select_menu("RFMHome.Navigation", strNavigateToPrcSet);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			String[] val = strValue.split("#");

			Actions builder = new Actions(driver);
			builder.moveByOffset(500, 0).click().perform();
			// Selecting the first available price set
			WebElement PriceSet = mcd.GetTableCellElement("PackageReport.Table", 1, 1, "a");
			String strRestNode = mcd.GetTableCellElement("PackageReport.Table", 1, 2, "").getText();
			actions.click(PriceSet);
			mcd.smartsync(180);
			mcd.SwitchToWindow("#Title");

			// Updating a Price Set name to verify the the reflection in all
			// reports
			actions.WaitForElementPresent("ManagePS.PriceSetName", 120);
			actions.clear("ManagePS.PriceSetName");
			String strNewPSName = mcd.fn_GetRndName("Prc");
			actions.setValue("ManagePS.PriceSetName", strNewPSName);
			actions.keyboardEnter("PriceSet.ApplyButton");
			mcd.smartsync(180);

			/** Navigating to Menu Item Usage Report */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			// Adding 2 MI's from left to Right
			actions.keyboardEnter("RecipeReport.ViewFullListBtn");
			mcd.smartsync(180);
			mcd.select_row("MenuItemPriceByMI.TableLeftMI", 1);
			mcd.select_row("MenuItemPriceByMI.TableLeftMI", 2);
			actions.click("MenuItemUsageReport.CPSingle>");

			// Selecting the node on which the updated price set is created
			actions.setValue("RFMSelectNode.SearchEditbox", strRestNode);
			actions.click("MenuItemTaxReport.SearchByRestName");
			actions.click("RFMSelectNode.SearchButton");
			mcd.smartsync(180);
			mcd.Selectrestnode_JavaScriptClk("RFMSelectNode.SelectNodeTable", strRestNode);
			actions.click("MenuItemUsageReport.Next");

			// Click on All CheckBox
			actions.click("MenuItemUsageReport.AllFunctionsCheckbox");

			// Generating Menu Item Usage Report
			actions.click("RecipeReport.GenerateReportBtn");
			mcd.smartsync(180);
			Thread.sleep(2000);
			try {
				mcd.SwitchToWindow("Existing Reports");
				driver.findElement(By.xpath(actions.getLocator("MasterMenuItemList.ContinueButton"))).isDisplayed();
				actions.click("MasterMenuItemList.ContinueButton");
				actions.waitForPageToLoad(120);
				mcd.SwitchToWindow("Menu Item Usage Report");
			} catch (Exception e) {
				System.out.println("Existing reports window is not displayed");
			}
			// Verify Success Message
			mcd.smartsync(180);
			mcd.VerifyOnscreenMessage("MenuItemUsageReport.OnScreenMessage", strMsg, true);

			/** Navigate to View Generated Report */
			System.out.println("> Navigate to :: " + strNavigateToVGR);
			actions.select_menu("RFMHome.Navigation", strNavigateToVGR);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			// Search for 'Menu Item Usage' Report
			actions.setValue("ViewGenReport.ReportType", val[3]);
			actions.click("ViewGenReport.SelectDate");
			mcd.Get_future_date(0, "Close", strApplicationDate);
			actions.keyboardEnter("OrderTotalDiscountSet.searchButton");
			mcd.smartsync(180);

			// Click on 'Menu Item Usage' Report generated by checking generated
			// status
			flag = driver.findElement(By.xpath(actions.getLocator("ViewGeneratedReport.DateTimeFltr"))).isEnabled();
			if (flag) {
				do {
					actions.click("ViewGeneratedReport.DateTimeFltr");
					mcd.smartsync(20);
					actions.click("ViewGeneratedReport.DateTimeFltr");
					mcd.smartsync(20);
					strstatus = driver.findElements(By.xpath("//*[@id='col2']")).get(1).getText().trim();
				} while (strstatus.equals("In-Process"));
			} else {
				do {
					actions.click("OrderTotalDiscountSet.searchButton");
					mcd.smartsync(180);
					strstatus = driver.findElements(By.xpath("//*[@id='col2']")).get(1).getText().trim();
				} while (strstatus.equals("In-Process"));
			}

			List<WebElement> rptname = driver
					.findElements(By.xpath(actions.getLocator("ViewGeneratedReport.ReportsName")));
			rptname.get(0).click();
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			// Verify the Price Set name displayed in the report
			actions.click("MenuItemUsageReport.PrStTab");
			mcd.smartsync(180);
			actions.waitForPageToLoad(120);
			Integer rowcount = mcd.GetTableRowCount("AccessControlbyRole(s).ReportTable");
			boolean flag = false;
			for (int i = 1; i <= rowcount; i++) {
				String strPriceSetValue = mcd.GetTableCellValue("AccessControlbyRole(s).ReportTable", i, "Price Set",
						"", "");
				if (strPriceSetValue.equalsIgnoreCase(strNewPSName)) {
					actions.reportCreatePASS("Verify that table contains the updated price set",
							"Table should contain the updated price set", "Table contains the updated price set",
							"Pass");
					flag = true;
					break;
				}
			}
			if (!flag) {
				actions.reportCreateFAIL("Verify that table contains the updated price set",
						"Table should contain the updated price set", "Table does not contain the updated price set",
						"FAIL");
			}

			// Navigate to Menu Item Price by Menu Item(s) Report Screen
			System.out.println("> Navigate to :: " + strNavigateToMI);
			actions.select_menu("RFMHome.Navigation", strNavigateToMI);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			// Assign a menu item from left to right
			actions.keyboardEnter("MenuItemPriceByMI.ViewFullListMI");
			mcd.smartsync(180);
			mcd.select_row("MenuItemPriceByMI.TableLeftMI", 1);
			List<WebElement> GreaterThan = driver
					.findElements(By.xpath(actions.getLocator("MassStatusUpdateRestaurants.AddRight>")));
			GreaterThan.get(0).click();

			// Select the updated price set from left to right
			actions.setValue("MIPBMI.SearchPriceSet", strNewPSName);
			mcd.smartsync(180);
			actions.keyboardEnter("MIPSbyMenuItem.CpSearch");
			mcd.smartsync(180);
			mcd.select_row("SelectNode.Tree", 1);
			List<WebElement> GreaterThan2 = driver
					.findElements(By.xpath(actions.getLocator("MassStatusUpdateRestaurants.AddRight>")));
			GreaterThan2.get(1).click();

			// Generate the Menu Item Price by Menu Item(s) Report
			actions.keyboardEnter("RecipeReport.GenerateReportBtn");
			mcd.smartsync(180);
			Thread.sleep(2000);

			mcd.SwitchToWindow("#Title");
			// verify updated price set is present and validate
			boolean BlnVal = actions.isTextPresence(strNewPSName, false);
			if (BlnVal) {
				actions.reportCreatePASS("Verify the updated price set Name is displayed",
						"The updated price set Name should be displayed",
						"The updated price set Name is displayed in Menu Item Price by Menu Item(s) Report", "Pass");
			} else {
				actions.reportCreateFAIL("Verify the updated price set Name is displayed",
						"The updated price set Name should be displayed",
						"The updated price set Name is not displayed in Menu Item Price by Menu Item(s) Report",
						"Fail");
			}

			// Navigate to Menu Item Price by Price Set(s) Report Screen
			System.out.println("> Navigate to :: " + strNavigateToPS);
			actions.select_menu("RFMHome.Navigation", strNavigateToPS);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			// Search for the updated price set
			actions.WaitForElementPresent("RecipeReport.SearchTextbox", 20);
			actions.setValue("RecipeReport.SearchTextbox", strNewPSName);
			actions.keyboardEnter("OrderTotalDiscountSet.searchButton");
			mcd.smartsync(180);

			// Assign the Updated price set form left to right
			actions.WaitForElementPresent("RemoveComponent.LeftSearchList");
			mcd.select_row("RemoveComponent.LeftSearchList", 0);
			actions.keyboardEnter("MIPSbyPriceSets.CPNext");

			// Generate the Menu Item Price by Price Set(s) Report
			actions.keyboardEnter("RecipeReport.GenerateReportBtn");
			mcd.smartsync(180);
			Thread.sleep(2000);
			// Verify Success Message
			mcd.VerifyOnscreenMessage("MenuItemUsageReport.OnScreenMessage", strMsg, true);

			/** Navigate to View Generated Report */
			System.out.println("> Navigate to :: " + strNavigateToVGR);
			actions.select_menu("RFMHome.Navigation", strNavigateToVGR);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			// Search for the 'Menu Item Price - By Price Set(s)' Report
			// generated
			actions.setValue("ViewGenReport.ReportType", val[1]);
			actions.click("ViewGenReport.SelectDate");
			mcd.Get_future_date(0, "Close", strApplicationDate);
			actions.keyboardEnter("OrderTotalDiscountSet.searchButton");
			mcd.smartsync(180);

			// Check for the generated status and click on the report generated
			flag = driver.findElement(By.xpath(actions.getLocator("ViewGeneratedReport.DateTimeFltr"))).isEnabled();
			if (flag) {
				do {
					actions.click("ViewGeneratedReport.DateTimeFltr");
					mcd.smartsync(20);
					actions.click("ViewGeneratedReport.DateTimeFltr");
					mcd.smartsync(20);
					strstatus = driver.findElements(By.xpath("//*[@id='col2']")).get(1).getText().trim();
				} while (strstatus.equals("In-Process"));
			} else {
				do {
					actions.click("OrderTotalDiscountSet.searchButton");
					mcd.smartsync(180);
					strstatus = driver.findElements(By.xpath("//*[@id='col2']")).get(1).getText().trim();
				} while (strstatus.equals("In-Process"));
			}

			List<WebElement> rptname1 = driver
					.findElements(By.xpath(actions.getLocator("ViewGeneratedReport.ReportsName")));
			rptname1.get(0).click();
			actions.waitForPageToLoad(120);

			mcd.SwitchToWindow("#Title");
			// verify updated price set is present and validate the same
			boolean IsPS = actions.isTextPresence(strNewPSName, false);
			if (IsPS) {
				actions.reportCreatePASS("Verify the updated price set name displayed",
						"Updated price set name should be displayed",
						"Updated price set name is displayed in Menu Item Price by Price Set(s) Report", "Pass");
			} else {
				actions.reportCreateFAIL("Verify the updated price set name displayed",
						"Updated price set name should be displayed",
						"Updated price set name is not displayed in Menu Item Price by Price Set(s) Report", "Fail");
			}

			// Navigate to Tax by Restaurant
			System.out.println("> Navigate to :: " + strNavigateToTBR);
			actions.select_menu("RFMHome.Navigation", strNavigateToTBR);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			// Search for the restaurant on which the price set is created
			actions.setValue("RestaurantUpdt.SearchRestro", strRestNode);
			actions.keyboardEnter("OrderTotalDiscountSet.searchButton");
			mcd.smartsync(180);
			// verify updated price set is present and validate the same
			String strele = mcd.GetTableCellValue("PermissionReportByRole.Table", 1, "Price Sets", "", "");
			if (strele.contains(strNewPSName)) {
				actions.reportCreatePASS("Verify that table contains the updated price set",
						"Table should contain the updated price set", "Table contains the updated price set", "Pass");
			} else {
				actions.reportCreateFAIL("Verify that table contains the updated price set",
						"Table should contain the updated price set", "Table doesnot contain the updated price set",
						"FAIL");
			}

			// Navigate To Set Assignment Report and verify the updated price
			// set name
			System.out.println("> Navigate to :: " + strNavigateToSAR);
			actions.select_menu("RFMHome.Navigation", strNavigateToSAR);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			actions.setValue("SetAssignmentReportSelectSet.Selecttype", val[2]);
			mcd.smartsync(180);
			// Select 'Price Set' in Drop down
			actions.setValue("RecipeReport.SearchTextbox", strNewPSName);
			actions.keyboardEnter("RecipeReport.RestaurantSearchBtn");
			mcd.smartsync(180);
			// verify updated price set is present and validate the same
			String strele1 = mcd.GetTableCellValue("RemoveComponent.LeftSearchList", 1, "Name", "", "");
			if (strele1.contains(strNewPSName)) {
				actions.reportCreatePASS("Verify that table contains the updated price set",
						"Table should contain the updated price set", "Table contains the updated price set", "Pass");
			} else {
				actions.reportCreateFAIL("Verify that table contains the updated price set",
						"Table should contain the updated price set", "Table does not contain the updated price set",
						"FAIL");
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			// reporting the Fail condition
			actions.catchException(e);
		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}
}
