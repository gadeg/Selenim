package xtam.test;

import java.util.List;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import org.openqa.selenium.WebElement;

import crossbrowser.library.Keywords;
import crossbrowser.library.PackageValidation;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.XMLValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class PRC_0112_FuturePrice {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strPriceSet, restNum, Sucessmsg;
	// TODO: Declare test-data variables for other data-parameters

	public PRC_0112_FuturePrice(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		restNum = mcd.GetTestData("DT_RestNum");
		Sucessmsg = mcd.GetTestData("DT_SucessMsg");
		// TODO: GetTestData for other data-parameters
	}

	@Test
	public void test_PRC_0112_FuturePrice() throws InterruptedException {
		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription("Verify Update Price Set Details (Future Price Changes) functionality of Promotional price set");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Create Active price Set
			actions.click("PriceSets.NewPriceSetBtn");
			mcd.waitAndSwitch("New Price Sets");
			strPriceSet = mcd.fn_GetRndName("PriceSet");
			actions.clear("NewPriceSets.TextBox");
			actions.setValue("NewPriceSets.TextBox", strPriceSet);
			actions.click("NewPriceSet.PromRadioBtn");
			actions.click("AddNewDayPartSet.SelectBtn");
			mcd.waitAndSwitch("Select Node");
			actions.WaitForElementPresent("SelectNodeRest.SearchTextField", 180);
			mcd.Selectrestnode_JavaScriptClk("RFMSelectNode.SelectNodeTable", restNum);
			mcd.waitAndSwitch("New Price Sets");

			// ** Selecting the Start & End Date *//
			actions.click("NewPriceSet.StartDate");
			mcd.Get_future_date(0, "Close", strApplicationDate);
			actions.click("NewPriceSet.EndDate");
			mcd.Get_future_date(3, "Close", strApplicationDate);
			actions.click("MassSetAssignment.MASelectRestNextbtn");
			mcd.SwitchToWindow("@Price Sets : Common Menu Item Selector");

			// ** adding the menu item now *//
			if (input.get("_rowId").toString().toUpperCase().contains("US")) {
				actions.WaitForElementPresent("CommonMenuItemSelector.ViewFullListBtn", 180);
				actions.click("CommonMenuItemSelector.ViewFullListBtn");
				actions.smartWait(180);
				actions.setValue("AddRemoveMenu.Availability", "Available");
				actions.smartWait(180);
				actions.setValue("CommonMenuItemSelector.StatusFilterDDL", "Approved");
				actions.smartWait(180);

			} else if (input.get("_rowId").toString().toUpperCase().contains("AP")) {
				actions.WaitForElementPresent("CommonMenuItemSelector.ViewFullListBtn", 180);
				actions.click("CommonMenuItemSelector.ViewFullListBtn");
				actions.smartWait(180);
				actions.setValue("AddRemoveMenu.Availability", "Available");
				actions.smartWait(180);
				actions.setValue("CommonMenuItemSelector.StatusFilterDDL", "Active");
				actions.smartWait(180);
			}

			// ** Selecting the record & saving it *//
			WebElement elem_checkbox = mcd.GetTableCellElement("AddRemoveComponent.webtable", 1, "Add", "input");
			actions.javaScriptClick(elem_checkbox);
			WebElement elem_checkbox1 = mcd.GetTableCellElement("AddRemoveComponent.webtable", 2, "Add", "input");
			actions.javaScriptClick(elem_checkbox1);
			actions.WaitForElementPresent("RFM.SaveBtn", 180);
			actions.click("RFM.SaveBtn");
			actions.smartWait(180);

			// Set price
			actions.clear("RFMMassUpdatePrices.AllPrices");
			actions.setValue("RFMMassUpdatePrices.AllPrices", "2.50");
			actions.keyboardEnter("AddTenderType.ApplyButton");
			actions.smartWait(20);
			actions.keyboardEnter("PriceSet.ApplyButton");
			actions.smartWait(50);
			actions.verifyTextPresence(Sucessmsg, true);

			// back to main page
			actions.click("RFM.CancelButton");
			actions.smartWait(180);

			// Select promotion price set
			actions.clear("PriceSet.SearchBox");
			actions.setValue("PriceSet.SearchBox", strPriceSet);
			actions.keyboardEnter("PriceSet.SearchBtn");
			actions.smartWait(180);
			WebElement BSP_1 = mcd.GetTableCellElement("RFM.WebTable", 1, "Name", "a");
			actions.keyboardEnter(BSP_1);
			mcd.SwitchToWindow("#Title");

			// Set the future Settings
			actions.smartWait(10);
			mcd.SelectDate_OpenCalender_Priceset(strApplicationDate, "next");
			mcd.SelectDate_OpenCalender_Priceset(strApplicationDate, "next");

			// Set price
			actions.clear("RFMMassUpdatePrices.AllPrices");
			actions.setValue("RFMMassUpdatePrices.AllPrices", "3.50");
			actions.keyboardEnter("AddTenderType.ApplyButton");
			actions.smartWait(20);
			actions.keyboardEnter("PriceSet.ApplyButton");
			actions.smartWait(10);
			actions.verifyTextPresence(Sucessmsg, true);

			// back to main page
			actions.click("RFM.CancelButton");
			actions.smartWait(180);

			// Select promotion price set
			actions.clear("PriceSet.SearchBox");
			actions.setValue("PriceSet.SearchBox", strPriceSet);
			actions.keyboardEnter("PriceSet.SearchBtn");
			actions.smartWait(180);
			WebElement BSP = mcd.GetTableCellElement("RFM.WebTable", 1, "Name", "a");
			actions.keyboardEnter(BSP);
			mcd.SwitchToWindow("#Title");

			// back to main page
			actions.click("RFM.CancelButton");
			actions.smartWait(180);

			// Select promotion price set
			actions.clear("PriceSet.SearchBox");
			actions.setValue("PriceSet.SearchBox", strPriceSet);
			actions.keyboardEnter("PriceSet.SearchBtn");
			actions.smartWait(180);
			WebElement PP = mcd.GetTableCellElement("RFM.WebTable", 1, "Name", "a");
			actions.keyboardEnter(PP);
			mcd.SwitchToWindow("#Title");

			// Click on Current date in Future price changes text area
			List<WebElement> future_setting = driver
					.findElements(By.xpath(actions.getLocator("PriceSets.SBFutureSetting")));
			actions.click(future_setting.get(0));
			actions.smartWait(10);

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}
