package xtam.test;

import java.util.List;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class PRC_0113_VerfViewLB {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String PageNo, actualpageno[], Taxtypevls, ExpectTaxVals[], strWM, ExpectWM[];
	// TODO: Declare test-data variables for other data-parameters

	public PRC_0113_VerfViewLB(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		PageNo = mcd.GetTestData("DT_PageNo");
		Taxtypevls = mcd.GetTestData("DT_TaxtypeValues");
		strWM = mcd.GetTestData("DT_WarningMSG");
		// TODO: GetTestData for other data-parameters
		actualpageno = PageNo.split("#");
		ExpectTaxVals = Taxtypevls.split("#");
		ExpectWM = strWM.split("#");
	}

	@Test
	public void test_PRC_0113_VerfViewLB() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription("Verify View Full List functionality and verify the pagination, Sorting");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Verifying 'Search with Type' Filter
			Boolean resultStatus;
			Select selObj = new Select(driver.findElement(By.xpath(actions.getLocator("PriceSets.SearchType"))));
			resultStatus = selObj.getFirstSelectedOption().getText().trim().equalsIgnoreCase("All");
			reporting_Pass_Fail("Verify whether Search with Type All is selected by default for Status DDL",
					"Search with Type All should be selected by default", "Search with Type All is selected by default",
					"Search with Type All is not selected by default", resultStatus);

			// Verify the Search text box is editable
			boolean Pricesetsreachbox = driver.findElement(By.xpath(actions.getLocator("PriceSet.SearchBox")))
					.isEnabled();
			System.out.println(Pricesetsreachbox);
			if (Pricesetsreachbox == true) {
				System.out.println("Price Set Search Text Box is Editable");

				actions.setValue("PriceSet.SearchBox", "TextBox is in Editable State");
				actions.reportCreatePASS("Verify Price Set Search Text Box is Editable",
						"Price Set Search Text Box is should Editable", "Price Set Search Text Box is Editable",
						"Pass");
				actions.clear("PriceSet.SearchBox");
			} else {
				System.out.println("Price Set Search Text Box is not Editable");
				actions.reportCreateFAIL("Verify Price Set Search Text Box is Editable",
						"Price Set Search Text Box is should be Editable", "Price Set Search Text Box is not Editable",
						"Fail");
			}

			// Verifying 'Search within Status' Filter
			Boolean SearchwithinStatus;
			Select SWS = new Select(driver.findElement(By.xpath(actions.getLocator("PriceSet.StatusFilter"))));
			SearchwithinStatus = SWS.getFirstSelectedOption().getText().trim().equalsIgnoreCase("Active/Inactive");
			reporting_Pass_Fail(
					"Verify whether Search Within Status Active/Inactive is selected by default for Status DDL",
					"Search Within Status Active/Inactive should be selected by default",
					"Search Within Status Active/Inactive is selected by default",
					"Search Within Status Active/Inactive is not selected by default", SearchwithinStatus);

			// Verifying presence of 'Search' Button
			Boolean searchbutton;
			searchbutton = actions.isElementPresent("PriceSet.SearchButton");
			reporting_Pass_Fail("Verify whether 'Search' Button is present", "'Search' Button should be present",
					"'Search' Button is present", "'Search' Button is not present", searchbutton);

			// verify Filter List section (Market text box disabled)
			if (!mcd.fn_VerifyWebelementEnableDisable("ReportMIPS.Market")) {
				actions.reportCreatePASS("Filter List section Market text box should be disabled'",
						"Filter List section Market text box should be disabled'",
						"Filter List section Market text box should be disabled'", "Pass");

			} else {
				actions.reportCreateFAIL("Filter List section Market text box should be disabled'",
						"Filter List section Market text box shoulb be disabled'",
						"Filter List section Market text box not disabled'", "Fail");
			}

			// Verifying 'Status' Filter
			Boolean Status;
			Select status = new Select(driver.findElement(By.xpath(actions.getLocator("PricingSets.StatusFilter"))));
			Status = status.getFirstSelectedOption().getText().trim().equalsIgnoreCase("Active/Inactive");
			reporting_Pass_Fail("Verify whether Status Active/Inactive is selected by default for Status DDL",
					"Status Active/Inactive should be selected by default",
					"Status Active/Inactive is selected by default",
					"Status Active/Inactive is not selected by default", Status);

			// Verifying presence of 'Replace' Button
			Boolean Replacebutton;
			Replacebutton = actions.isElementPresent("RFMPriceSets.ReplaceBtn");
			reporting_Pass_Fail("Verify whether 'Replace' Button is present", "'Replace' Button should be present",
					"'Replace' Button is present", "'Replace' Button is not present", Replacebutton);

			// Verifying presence of 'Import' Button
			Boolean Importbutton;
			Importbutton = actions.isElementPresent("PriceSet.ImportBtn");
			reporting_Pass_Fail("Verify whether 'Import' Button is present", "'Import' Button should be present",
					"'Import' Button is present", "'Import' Button is not present", Importbutton);

			// Verifying presence of 'New Price Set' Button
			Boolean NPSbutton;
			NPSbutton = actions.isElementPresent("PriceSets.NewPriceSetBtn");
			reporting_Pass_Fail("Verify whether 'New Price Set' Button is present",
					"'New Price Set' Button should be present", "'New Price Set' Button is present",
					"'New Price Set' Button is not present", NPSbutton);

			// verifying the presence of column headers i.e. name, node,Type,
			// status,
			// delete
			boolean booDisplayed5 = mcd.RFM_VerifyTableColumns("RFMHome.Table", "Name,Node,Type,Status,Delete");
			System.out.println(booDisplayed5);
			if (booDisplayed5 == true) {
				System.out.println("Present");
				actions.reportCreatePASS("Column Headers 'Name,Node,Type,Status,Delete' is Displayed",
						"Column Headers 'Name,Node,Type,Status,Delete' should Displayed",
						"Column Headers 'Name,Node,Type,Status,Delete' is Displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Column Headers 'Name,Node,Type,Status,Delete' is Displayed",
						"Column Headers 'Name,Node,Type,Status,Delete' should Displayed",
						"Column Headers 'Name,Node,Type,Status,Delete' is not Displayed", "Fail");
			}

			// Select a page from the pagination
			if (actions.isElementPresent("PriceSet.PageNoSearchBox")) {
				actions.clear("PriceSet.PageNoSearchBox");
				actions.setValue("PriceSet.PageNoSearchBox", actualpageno[0]);
				driver.findElement(By.xpath(actions.getLocator("PriceSet.PageNoSearchBox"))).sendKeys(Keys.ENTER);
				actions.smartWait(20);
				String expectpageno = driver.findElement(By.xpath(actions.getLocator("PriceSet.PageNoSearchBox")))
						.getAttribute("Value");
				System.out.println(expectpageno);
				if (expectpageno.equals(actualpageno[0])) {
					actions.reportCreatePASS("Verify that The User should be navigated to second page",
							"The User should be navigated to second page",
							"The User should be navigated to second page", "PASS");
				} else {
					actions.reportCreateFAIL("Verify that The User should be navigated to second page",
							"The User should be navigated to second page",
							"The User should not be navigated to second page", "FAIL");
				}

			}

			// Click on Previous page hyperlink
			if (actions.isElementPresent("PriceSet.Previous")) {
				actions.click("PriceSet.Previous");
				actions.smartWait(20);
				String expectpage = driver.findElement(By.xpath(actions.getLocator("PriceSet.PageNoSearchBox")))
						.getAttribute("Value");
				System.out.println(expectpage);

				if (expectpage.equals(actualpageno[1])) {
					actions.reportCreatePASS("Verify that User should be navigated to previous page",
							"User should be navigated to previous page", "User should be navigated to previous page",
							"PASS");
				} else {
					actions.reportCreateFAIL("Verify that User should be navigated to previous page",
							"User should be navigated to previous page",
							"User should not be navigated to previous page", "FAIL");
				}

			}

			// Click on Next page hyperlink
			if (actions.isElementPresent("PriceSet.Next")) {
				actions.click("PriceSet.Next");
				actions.smartWait(20);
			}

			// Click on Last page no hyperlink
			if (actions.isElementPresent("PriceSet.Last")) {
				actions.click("PriceSet.Last");
				actions.smartWait(20);
			}

			// Click on Price Set Name hyperlink
			actions.clear("PriceSet.SearchBox");
			actions.keyboardEnter("PriceSet.SearchButton");
			actions.smartWait(20);
			Verify_Sorting_String("FlavorSet.TableRows", "FlavorSet.NameArrow", "FlavorSet.NameLink", "Name", 1);

			// Click on Search Button
			actions.smartWait(10);
			actions.keyboardEnter("FlavorSet.SearchButton");
			actions.smartWait(20);

			// click on node link
			actions.checkElement(actions.getLocator("FlavorSet.NodeLink"), 30);
			actions.javaScriptClick("FlavorSet.NodeLink");
			actions.smartWait(20);

			// function for sorting the rows of table with respect to node
			Verify_Sorting_String("FlavorSet.TableRows", "FlavorSet.NodeArrow", "FlavorSet.NodeLink", "Node", 2);

			// click on node link
			actions.checkElement(actions.getLocator("FlavorSet.NodeLink"), 30);
			actions.javaScriptClick("FlavorSet.NodeLink");
			actions.smartWait(20);

			// function for sorting the rows of table with respect to node
			Verify_Sorting_String("FlavorSet.TableRows", "FlavorSet.NodeArrow", "FlavorSet.NodeLink", "Node", 2);

			// Verify that red visual indicator appears next to the price set
			Boolean redindicator;
			redindicator = actions.isElementPresent("PriceSet.ImportBtn");
			reporting_Pass_Fail(
					"Verify whether Red indicator should display in front of price set assigned to restaurant",
					"Red indicator should display in front of price set assigned to restaurant",
					"Red indicator should display in front of price set assigned to restaurant",
					"Red indicator should not display in front of price set assigned to restaurant", redindicator);

			// Select any Priced Menu Item, select �Tax Code� = Always, �Tax
			// Rule� = Tax Chain and �Tax Entry� = Default.
			actions.clear("PriceSet.SearchBox");
			actions.keyboardEnter("PriceSet.SearchButton");
			actions.smartWait(20);
			WebElement priceset = mcd.GetTableCellElement("RFMRoutingGroupManagementPage.Table", 1, "Name", "a");
			actions.keyboardEnter(priceset);
			actions.smartWait(20);
			mcd.SwitchToWindow("#Title");
			if (actions.isElementPresent("PriceSets.ViewTaxDetailsButton")) {
				actions.keyboardEnter("PriceSets.ViewTaxDetailsButton");
				actions.smartWait(20);
			}
			actions.setValue("PriceSet.TaxCode", ExpectTaxVals[0]);
			actions.smartWait(20);
			actions.setValue("PriceSet.TaxRule", ExpectTaxVals[1]);
			actions.smartWait(20);

			// Click on �Apply� Button and click OK button on pop-message
			actions.keyboardEnter("PriceSet.ApplyButton");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWM[0], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWM[0] + " 'is Present or not",
						ExpectWM[0] + " should be present", ExpectWM[0] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWM[0] + " 'is Present or not",
						ExpectWM[0] + " should be present", ExpectWM[0] + " is not present", "Fail");
			}

			// Navigate to main menuPRICING >> Pricing >> PriceSet
			actions.keyboardEnter("ManageDeposit.BOcancel");
			if (mcd.VerifyAlertMessageDisplayed("Information", ExpectWM[1], true, AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("Veriyfing the '" + ExpectWM[1] + " 'is Present or not",
						ExpectWM[1] + " should be present", ExpectWM[1] + " is present", "Pass");
			} else {
				actions.reportCreateFAIL("Veriyfing the '" + ExpectWM[1] + " 'is Present or not",
						ExpectWM[1] + " should be present", ExpectWM[1] + " is not present", "Fail");
			}
			actions.smartWait(20);
			mcd.SwitchToWindow("#Title");
			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	// Function for Reporting Pass/Fail
	public void reporting_Pass_Fail(String Desc, String ExpRes, String ActRes_Pass, String ActRes_Fail,
			Boolean status) {
		if (status) {
			actions.reportCreatePASS(Desc, ExpRes, ActRes_Pass, "PASS");
		}

		if (!status) {
			actions.reportCreateFAIL(Desc, ExpRes, ActRes_Fail, "FAIL");
		}
	}

	public void Verify_Sorting_String(String elemTableRow, String elemSortOrder, String elemHeader, String Name,
			int integer) throws InterruptedException {
		String strSortOrderValue = "";
		String TableXpath = actions.getLocator(elemTableRow);
		// Verify SORTING

		List<WebElement> eleRws = driver.findElements(By.xpath(TableXpath));
		int iNewMIRwCnt = eleRws.size();

		// Take 1st two elements for comparison by Name
		String MI_Num1 = eleRws.get(0).findElement(By.xpath("./td[" + integer + "]")).getText();
		String MI_Num2 = eleRws.get(1).findElement(By.xpath("./td[" + integer + "]")).getText();

		String strSortOrder = null;
		strSortOrderValue = driver.findElement(By.xpath(actions.getLocator(elemSortOrder))).getAttribute("src");
		if (strSortOrderValue.contains("up")) {
			strSortOrder = "Ascending";
			int ReturnNumber = MI_Num1.toUpperCase().compareTo(MI_Num2.toUpperCase());
			if (ReturnNumber <= 0) {
				actions.reportCreatePASS("Verify Ascending Sorting according to " + Name,
						"List should be sorted(Ascending)correctly", "List is sorted(Ascending) correctly", "PASS");
				// System.out.println("sorted ascending correct");
			} else {
				actions.reportCreateFAIL("Verify Ascending Sorting according to " + Name,
						"List should be sorted(Ascending) correctly", "List is not sorted(Ascending) correctly",
						"FAIL");
				// System.out.println("sorted ascending incorrect");
			}
		} else {
			actions.reportCreateFAIL("Verify Ascending Sorting according to " + Name,
					"List should be sorted(Ascending) correctly", "List is not sorted(Ascending) correctly", "FAIL");

		}
		Thread.sleep(2000);
		actions.keyboardEnter(elemHeader);
		Thread.sleep(2000);

		List<WebElement> eleRws1 = driver.findElements(By.xpath(TableXpath));
		int iNewMIRwCnt1 = eleRws.size();
		String MI_Num3 = eleRws1.get(0).findElement(By.xpath("./td[" + integer + "]")).getText();
		String MI_Num4 = eleRws1.get(1).findElement(By.xpath("./td[" + integer + "]")).getText();

		strSortOrderValue = driver.findElement(By.xpath(actions.getLocator(elemSortOrder))).getAttribute("src");
		if (strSortOrderValue.contains("down")) {
			strSortOrder = "Descending";
			int ReturnNumber = MI_Num3.toUpperCase().compareTo(MI_Num4.toUpperCase());
			if (ReturnNumber >= 0) {
				actions.reportCreatePASS("Verify Descending Sorting according to " + Name,
						"List should be sorted(Descending) correctly", "List is sorted correctly(Descending)", "PASS");
				// System.out.println("sorted descending correct");
			} else {
				actions.reportCreateFAIL("Verify Descending Sorting according to " + Name,
						"List should be sorted(Descending) correctly", "List is not sorted(Descending) correctly",
						"FAIL");
				// System.out.println("sorted descending incorrect");
			}
		} else {
			actions.reportCreateFAIL("Verify Descending Sorting according to " + Name,
					"List should be sorted(Descending) correctly", "List is not sorted(Descending) correctly", "FAIL");
		}

	}

}
