package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class PRC_20201_VerfyPrcTaxSettings {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters

	private String strTagValue;
	private String strTagName1;
	private String strTagName2, strEatinTO, strEatinTR, taxEntryValue, taxEntryValue1, strmsg;
	private String strNavigateToMF;
	private String FeeName1, FeeName, value, value1;
	private int num1;

	public PRC_20201_VerfyPrcTaxSettings(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);
		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strTagValue = mcd.GetTestData("TAG_VALUE");
		strTagName1 = mcd.GetTestData("TAG_NAME1");
		strTagName2 = mcd.GetTestData("TAG_NAME2");
		strNavigateToMF = mcd.GetTestData("DT_NAVIGATE_TO_MF");
		strEatinTO = mcd.GetTestData("DT_EatinTO");
		strEatinTR = mcd.GetTestData("DT_EatinTR");
		strmsg = mcd.GetTestData("SUCCESS_MSG");

	}

	@Test
	public void test_PRC_20201_VerfyPrcTaxSettings() throws InterruptedException {

		try {

			actions.setTestcaseDescription(
					"Verify that if 'automatically-fill-price-type-attribute-option-price-value'and 'automatically-fill-price-type-attribute-option-tax-value' contains value 3 then user is able to combine 'Eatin', and 'Others'");

			System.out.println(
					"********************************************************************** Test execution starts");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			// Navigate to ADMIN > Application Settings > Update Settings
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Actions specific to test-flow

			// Automate Pre-Requisite
			PriceActions.RFM_Admin_Update_PricingTags(strTagValue, strTagName1, strTagName2);

			// Navigate to Pricing > Price sets.
			System.out.println("> Navigate to :: " + strNavigateToMF);
			actions.select_menu("RFMHome.Pricing", strNavigateToMF);
			Thread.sleep(5000);
			actions.waitForPageToLoad(180);
			mcd.SwitchToWindow("#Title");

			// Click on New Fee button
			actions.keyboardEnter("MasterFee.NewFeeBtn");
			actions.smartWait(180);
			mcd.SwitchToWindow("#Title");
			actions.WaitForElementPresent("FeeSets.FeeName");

			Boolean flag = false;
			do {
				try {

					// Enter mandatory field
					int num2 = mcd.fn_GetRndNumInRange(100, 999);
					actions.clear("MasterFee.FeeId");
					actions.setValue("MasterFee.FeeId", num2);
					FeeName1 = mcd.fn_GetRndName("Auto");
					actions.clear("FeeSets.FeeName");
					actions.setValue("FeeSets.FeeName", FeeName1);
					actions.setValue("MasterFee.FeeType", "Amount");
				
					// Enter Eatin value , Eatin TaxValue & Click on Save Button
					num1 = mcd.fn_GetRndNumInRange(1, 5);
					if (actions.isElementPresent("DepositSet.PlusIcon")) {

						actions.click("DepositSet.PlusIcon");
					}
					actions.clear("FeeSets.EatinValue");
					actions.clear("FeeSet.TkOutPrc");
					actions.clear("FeeSet.OthPrc");
					actions.setValue("FeeSets.EatinValue", num1);
					int num3 = mcd.fn_GetRndNumInRange(1, 5);
					actions.setValue("FeeSet.TkOutPrc", num3);
					if (actions.isElementPresent("DepositSet.TaxPlusIcon")) {

						actions.click("DepositSet.TaxPlusIcon");
					}

					actions.setValue("DepositSet.EatinTaxCode", strEatinTO);
					actions.setValue("DepositSet.EatinTaxRule", strEatinTR);
					Select taxEntry = new Select(
							driver.findElement(By.xpath(actions.getLocator("ManageFee.TaxEntry"))));
					taxEntry.selectByIndex(1);
					taxEntryValue = taxEntry.getFirstSelectedOption().getText();
					actions.keyboardEnter("RFMUpdateLocalizationSet.SaveButton");
					actions.smartWait(20);

				} catch (Exception err) {
					actions.reportCreateFAIL("Creating New Fee", "Should be able to create New Fee",
							"Failed to create New Fee", "FAIL");
				}
			} while (actions.isElementPresent("MasterFee.Header"));

			String strEatinValue =driver.findElement(By.xpath(actions.getLocator("FeeSets.EatinValue"))).getAttribute("value");
			String strOtherValue =driver.findElement(By.xpath(actions.getLocator("FeeSet.OthPrc"))).getAttribute("value");
			String strOtherTaxcode = actions.getValue("DepositSet.OtherTaxCode");
			String strOtherTRule = actions.getValue("DepositSet.OtherTaxRule");
			String strOtherEntry = actions.getValue("ManageFee.OthersTaxEntry");

			//Verify selected Tax Code, Tax Rule, Tax Entry for Eatin should automatically populate in  respective DDL of  Others
			if (strOtherValue.equalsIgnoreCase(strEatinValue)) {
				actions.reportCreatePASS("Verify Other Value is dispalyed",
						"Other Value should be dispalyed as Exepected", "Other Value is dispalyed as Exepected",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify Other Value is dispalyed",
						"Other Value should be dispalyed as Exepected", "Other Value is not dispalyed as Exepected",
						"FAIL");
			}

			if (strOtherTaxcode.equalsIgnoreCase(strEatinTO)) {
				actions.reportCreatePASS("Verify Taxcode for Others is dispalyed",
						"Taxcode for Others should be dispalyed as Exepected",
						"Taxcode for Others is dispalyed as Exepected", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Taxcode for Others is dispalyed",
						"Taxcode for Others should be dispalyed as Exepected",
						"Taxcode for Others is not dispalyed as Exepected", "FAIL");
			}
			if (strOtherTRule.equalsIgnoreCase(strEatinTR)) {
				actions.reportCreatePASS("Verify TaxRule for Others is dispalyed",
						"TaxRule for Others should be dispalyed as Exepected",
						"TaxRule for Others is dispalyed as Exepected", "PASS");
			} else {
				actions.reportCreateFAIL("Verify TaxRule for Others is dispalyed",
						"TaxRule for Others should be dispalyed as Exepected",
						"TaxRule for Others is not dispalyed as Exepected", "FAIL");
			}

			if (taxEntryValue.equalsIgnoreCase(strOtherEntry)) {
				actions.reportCreatePASS("Verify TaxEntry for Others is dispalyed",
						"TaxEntry for Others should be dispalyed as Exepected",
						"TaxEntry for Others is dispalyed as Exepected", "PASS");
			} else {
				actions.reportCreateFAIL("Verify TaxEntry for TakeOut is dispalyed",
						"TaxEntry for TakeOut should be dispalyed as Exepected",
						"TaxEntry for TakeOut is not dispalyed as Exepected", "FAIL");
			}

			actions.verifyTextPresence(strmsg, true);

			// Click on Cancel Button
			actions.click("RestaurantSet.Cancelbtn");
			actions.smartWait(180);

			// Click on Search Button & Select any Master Fee
			actions.click("PriceSet.SearchBtn");
			actions.smartWait(180);
			WebElement tbl = mcd.GetTableCellElement("PermissionReportByRole.Table", 1, "Fee Name", "a");
			actions.keyboardEnter(tbl);
			actions.smartWait(180);

			// Enter Eatin value & Eatin TaxValue
			if (actions.isElementPresent("DepositSet.PlusIcon")) {

				actions.click("DepositSet.PlusIcon");
			}
			actions.clear("FeeSets.EatinValue");
			actions.clear("FeeSet.TkOutPrc");
			actions.clear("FeeSet.OthPrc");
			actions.setValue("FeeSets.EatinValue", num1);
			int num4 = mcd.fn_GetRndNumInRange(1, 5);
			actions.setValue("FeeSet.TkOutPrc", num4);
			if (actions.isElementPresent("DepositSet.TaxPlusIcon")) {

				actions.click("DepositSet.TaxPlusIcon");
			}

			actions.setValue("DepositSet.EatinTaxCode", "Never");
			actions.setValue("DepositSet.EatinTaxCode", strEatinTO);
			actions.setValue("DepositSet.EatinTaxRule", strEatinTR);
			Select taxEntry1 = new Select(driver.findElement(By.xpath(actions.getLocator("ManageFee.TaxEntry"))));
			taxEntry1.selectByIndex(1);
			taxEntryValue1 = taxEntry1.getFirstSelectedOption().getText();

			String strEatinValue1 = driver.findElement(By.xpath(actions.getLocator("FeeSets.EatinValue"))).getAttribute("value");
			String strOtherValue1 = driver.findElement(By.xpath(actions.getLocator("FeeSet.OthPrc"))).getAttribute("value");
			String strOtherTaxcode1 = actions.getValue("DepositSet.OtherTaxCode");
			String strOtherTRule1 = actions.getValue("DepositSet.OtherTaxRule");
			String strOtherEntry1 = actions.getValue("ManageFee.OthersTaxEntry");

			//Verify selected Tax Code, Tax Rule, Tax Entry for Eatin should automatically populate in  respective DDL of  Others
			if (strOtherValue1.equalsIgnoreCase(strEatinValue1)) {
				actions.reportCreatePASS("Verify Other Value is dispalyed",
						"Other Value should be dispalyed as Exepected", "Other Value is dispalyed as Exepected",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify Other Value is dispalyed",
						"Other Value should be dispalyed as Exepected", "Other Value is not dispalyed as Exepected",
						"FAIL");
			}

			if (strOtherTaxcode1.equalsIgnoreCase(strEatinTO)) {
				actions.reportCreatePASS("Verify Taxcode for TakeOut is dispalyed",
						"Taxcode for TakeOut should be dispalyed as Exepected",
						"Taxcode for TakeOut is dispalyed as Exepected", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Taxcode for TakeOut is dispalyed",
						"Taxcode for TakeOut should be dispalyed as Exepected",
						"Taxcode for TakeOut is not dispalyed as Exepected", "FAIL");
			}
			if (strOtherTRule1.equalsIgnoreCase(strEatinTR)) {
				actions.reportCreatePASS("Verify TaxRule for TakeOut is dispalyed",
						"TaxRule for TakeOut should be dispalyed as Exepected",
						"TaxRule for TakeOut is dispalyed as Exepected", "PASS");
			} else {
				actions.reportCreateFAIL("Verify TaxRule for TakeOut is dispalyed",
						"TaxRule for TakeOut should be dispalyed as Exepected",
						"TaxRule for TakeOut is not dispalyed as Exepected", "FAIL");
			}

			if (taxEntryValue.equalsIgnoreCase(strOtherEntry1)) {
				actions.reportCreatePASS("Verify TaxEntry for TakeOut is dispalyed",
						"TaxEntry for TakeOut should be dispalyed as Exepected",
						"TaxEntry for TakeOut is dispalyed as Exepected", "PASS");
			} else {
				actions.reportCreateFAIL("Verify TaxEntry for TakeOut is dispalyed",
						"TaxEntry for TakeOut should be dispalyed as Exepected",
						"TaxEntry for TakeOut is not dispalyed as Exepected", "FAIL");
			}

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (

		Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}