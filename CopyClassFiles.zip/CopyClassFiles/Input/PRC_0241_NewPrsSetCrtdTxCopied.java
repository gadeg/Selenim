package xtam.test;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;

public class PRC_0241_NewPrsSetCrtdTxCopied {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strNavigateToAdmin, strNavigateToMUP, strEatinPriceVal, strMessage;

	public PRC_0241_NewPrsSetCrtdTxCopied(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strNavigateToAdmin = mcd.GetTestData("DT_NAVIGATE_TO_ADMIN");
		strNavigateToMUP = mcd.GetTestData("DT_NAVIGATE_TO_MUP");
		strEatinPriceVal = mcd.GetTestData("DT_EATINPRICE");
		strMessage = mcd.GetTestData("DT_MESSAGE");

	}

	@Test
	public void test_PRC_0241_NewPrsSetCrtdTxCopied() throws InterruptedException {

		try {
			System.out.println("****************** Test execution starts ******************");

			// This test script covers two scenarios
			actions.setTestcaseDescription(
					"Verify If a menu item does not have an existing price setting for the start date specified, the new price setting are created and previous tax settings are copied.");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Navigating to Admin */
			System.out.println("> Navigate to :: " + strNavigateToAdmin);
			actions.select_menu("RFMHome.Navigation", strNavigateToAdmin);
			Thread.sleep(5000);
			actions.waitForPageToLoad(120);

			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// Setting the Pre-Requisites
			rfm.RFM_Admin_Update_PricingTags("false", "Restrict price type attribute from expanding");
			rfm.RFM_Admin_Update_PricingTags("0", "Automatically fill price type attribute option price value");
			rfm.RFM_Admin_Update_PricingTags("0", "Automatically fill price type attribute option tax value");

			// Navigating to Price Sets and getting the First available eatin
			// value
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(5000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");
			WebElement PrcSetLink1 = mcd.GetTableCellElement("Lookups.UpdateTable", 1, 1, "a");
			actions.click(PrcSetLink1);
			mcd.smartsync(180);
			mcd.SwitchToWindow("#Title");
			actions.keyboardEnter("PriceSets.ViewTaxDetailsButton");
			try {
				String AlertText = driver.switchTo().alert().getText();
				if (AlertText.contains("Unsaved")) {
					driver.switchTo().alert().accept();
					mcd.smartsync(180);
				}
			} catch (Exception e) {
			}
			List<WebElement> FutDates1 = driver.findElements(By.xpath(actions.getLocator("PriceSets.SBFutureSetting")));
			FutDates1.get(1).click();
			try {
				String AlertText = driver.switchTo().alert().getText();
				if (AlertText.contains("Unsaved")) {
					driver.switchTo().alert().accept();
					mcd.smartsync(180);
				}
			} catch (Exception e) {
			}
			Select EatInTaxVal = new Select(driver.findElement(By.xpath(actions.getLocator("ManagePS.EatingTaxCode"))));
			String FirstEatinVal = EatInTaxVal.getFirstSelectedOption().getText();
			actions.keyboardEnter("RFM.Cancelbtn");
			try {
				String AlertText = driver.switchTo().alert().getText();
				if (AlertText.contains("Unsaved")) {
					driver.switchTo().alert().accept();
					mcd.smartsync(180);
				}
			} catch (Exception e) {
			}

			/** Navigating to Mass Update Price */
			System.out.println("> Navigate to :: " + strNavigateToMUP);
			actions.select_menu("RFMHome.Navigation", strNavigateToMUP);
			Thread.sleep(5000);
			actions.waitForPageToLoad(120);

			mcd.SwitchToWindow("#Title");
			actions.keyboardEnter("RestaurantSet.Searchbtn");
			mcd.smartsync(180);

			// Adding a Menu Item from left to Right
			mcd.select_row("MenuItemGrp.LeftTable", 0);
			actions.keyboardEnter("AccessControlbyNode(s).NextBtn");
			Thread.sleep(2000);
			actions.keyboardEnter("AddNewParameterSet.next");
			mcd.smartsync(180);
			mcd.SwitchToWindow("#Title");

			// Adding a Price Set from left to Right
			actions.keyboardEnter("RestaurantSet.Searchbtn");
			mcd.smartsync(180);
			String PSName = mcd.GetTableCellElement("MenuItemGrp.LeftTable", 1, 1, "").getText();
			mcd.select_row("MenuItemGrp.LeftTable", 0);
			actions.keyboardEnter("AccessControlbyNode(s).NextBtn");
			Thread.sleep(2000);
			actions.keyboardEnter("AddNewParameterSet.next");
			mcd.smartsync(180);

			// Select Start Date and enter Eatin value and save
			actions.click("NewPriceSet.StartDate");
			mcd.Get_future_date(1, "close", strApplicationDate);
			actions.javaScriptClick("PriceSet.AllPriceTypeRadioBtn");
			actions.setValue("PriceSets.EatinPriceId", strEatinPriceVal);
			actions.keyboardEnter("LocalizationSet.Muapplybtn");
			mcd.smartsync(180);
			Thread.sleep(5000);
			actions.keyboardEnter("PackageSchedule.NBSaveButton");
			try {
				String AlertText = driver.switchTo().alert().getText();
				if (AlertText.contains("dates overlap")) {
					driver.switchTo().alert().accept();
					mcd.smartsync(180);
				}
			} catch (Exception e) {
			}
			mcd.waitAndSwitch("@Mass Update Prices");
			mcd.smartsync(180);
			Thread.sleep(5000);

			// Validate changes made are been saved
			if (actions.isTextPresence(strMessage, true)) {
				actions.reportCreatePASS("Verify " + strMessage, strMessage + " should be displayed",
						strMessage + " is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify " + strMessage, strMessage + " should be displayed",
						strMessage + " is not displayed", "Fail");
			}
			actions.keyboardEnter("RFM_Report.OKButton");
			mcd.SwitchToWindow("#Title");
			mcd.smartsync(180);

			/** Navigating to Price Sets to verify the reflected values */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(5000);
			actions.waitForPageToLoad(120);

			mcd.SwitchToWindow("#Title");

			// Enter the Price Set name for which changes made and search
			actions.WaitForElementPresent("RFMMassUpdatePrice.SearchText", 120);
			actions.clear("RFMMassUpdatePrice.SearchText");
			actions.setValue("RFMMassUpdatePrice.SearchText", PSName);
			actions.keyboardEnter("RestaurantSet.Searchbtn");
			mcd.smartsync(180);

			// Select the Price Set Name and navigate to future settings
			WebElement PrcSetLink = mcd.GetTableCellElement("Lookups.UpdateTable", 1, 1, "a");
			actions.click(PrcSetLink);
			mcd.smartsync(180);
			mcd.SwitchToWindow("#Title");
			List<WebElement> FutDates = driver.findElements(By.xpath(actions.getLocator("PriceSets.SBFutureSetting")));
			FutDates.get(1).click();
			try {
				String AlertText = driver.switchTo().alert().getText();
				if (AlertText.contains("Unsaved")) {
					driver.switchTo().alert().accept();
					mcd.smartsync(180);
				}
			} catch (Exception e) {
			}
			mcd.smartsync(180);
			List<WebElement> PriceTextBoxes = driver
					.findElements(By.xpath(actions.getLocator("ManagePriceSet.PriceTextboxList")));

			// Validate the Eatin price is updated as the changes made in Mass
			// Update Price
			String FutrEatinval = PriceTextBoxes.get(0).getAttribute("value");
			if (FutrEatinval.equals(strEatinPriceVal)) {
				actions.reportCreatePASS("Verify Price Settings are updated", "New Price Settings should be updated",
						"New Price Settings are updated", "Pass");
			} else {
				actions.reportCreateFAIL("Verify Price Settings are updated", "New Price Settings should be updated",
						"New Price Settings are not updated", "Fail");
			}
			Thread.sleep(2000);
			actions.WaitForElementPresent("PriceSets.ViewTaxDetailsButton", 120);
			actions.keyboardEnter("PriceSets.ViewTaxDetailsButton");
			try {
				String AlertText = driver.switchTo().alert().getText();
				if (AlertText.contains("Unsaved")) {
					driver.switchTo().alert().accept();
					mcd.smartsync(180);
				}
			} catch (Exception e) {
			}

			// Validate tax details are copied from previous values
			FutDates = driver.findElements(By.xpath(actions.getLocator("PriceSets.SBFutureSetting")));
			FutDates.get(1).click();
			try {
				String AlertText = driver.switchTo().alert().getText();
				if (AlertText.contains("Unsaved")) {
					driver.switchTo().alert().accept();
					mcd.smartsync(180);
				}
			} catch (Exception e) {
			}
			Select UpdtEatInTaxVal = new Select(
					driver.findElement(By.xpath(actions.getLocator("ManagePS.EatingTaxCode"))));
			String UpdatedEatinVal = UpdtEatInTaxVal.getFirstSelectedOption().getText();
			if (UpdatedEatinVal.equals(FirstEatinVal)) {
				actions.reportCreatePASS("Verify Previous Tax Settings copied",
						"Previous Tax Settings should be copied", "Previous Tax Settings are copied", "Pass");
			} else {
				actions.reportCreatePASS("Verify Previous Tax Settings copied",
						"Previous Tax Settings should be copied", "Previous Tax Settings are not copied", "Fail");
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);
		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}
}
