package xtam.test;

import java.util.Map;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class PRC_20243_MUP_VerifyNonPrcMI {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;

	// TODO: Declare test-data variables for other data-parameters
	private String strApplicationDate;
	private String strMessageBeforeSave;
	private String strResultMessage;

	private String strTaxCode;
	private String strTaxRule;
	private String strTaxEntry;
	private String strTaxType;
	private String strTaxError;

	public PRC_20243_MUP_VerifyNonPrcMI(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters

		strMessageBeforeSave = mcd.GetTestData("MessageBeforeSave");
		strResultMessage = mcd.GetTestData("ResultMessage");

		strTaxCode = mcd.GetTestData("TaxCode");
		strTaxRule = mcd.GetTestData("TaxRule");
		strTaxEntry = mcd.GetTestData("TaxEntry");
		strTaxType = mcd.GetTestData("TaxType");
		strTaxError = mcd.GetTestData("Tax_Error");
	}

	@Test
	public void test_PRC_20243_MUP_VerifyNonPrcMI() throws InterruptedException {
		String strPageTitle = "Update Multiple Menu Items in Multiple Price Sets : Menu Items"; 
		String strPageSubHeading = "Update Multiple Menu Items in Multiple Price Sets : Menu Items"; 
		String strTestDescription = "Verify if a menu item that is not in the price set can be added in the price set on the priced with an effective date from the update multiple menu items/multiple price set view"; // TODO:
		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			/** Get application time */
			actions.setTestcaseDescription(
					"Verify that message is displayed when user tries to update Tax Settings of Menu Item(s) which are not priced.");

			// ------------------------------------------------------------------------
			// Actions specific to test-flow

			RFM_PRC_MUP_Prerquisite();

			// Updating Prices
			Boolean Check1 = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.StartDate")))
					.isDisplayed();
			Boolean Check2 = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.StartDate"))).isEnabled();
			if (Check1) {
				if (Check2) {
					actions.reportCreatePASS("Verify Start Date TextBox", "Should be present & enabled",
							"Present & Enabled", "PASS");
				} else {
					actions.reportCreateFAIL("Verify Start Date TextBox", "Should be present & enabled",
							"Present but disabled", "FAIL");
				}
			} else {
				actions.reportCreateFAIL("Verify Start Date TextBox", "Should be present & enabled", "Not Present",
						"PASS");
			}

			// Selecting Today's date (Today Button)
			Thread.sleep(1000);
			actions.click("UpdtMultipleSet.TodayBtn");

			// Getting today's date in required format
			apptime = mcd.getdate();
			String app_date = apptime.getText();

			String dtForm = mcd.GetTestData("DT_DATE_FORMAT");
			String TodayDt = app_date.substring(0, dtForm.length());

			// Reading date displayed in the application
			String CurrDate = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.StartDate")))
					.getAttribute("value");

			// Verifying date
			if (CurrDate.equals(TodayDt.trim())) {
				actions.reportCreatePASS("Verify Today's date", "Today's date should be correctly updated",
						"Correctly displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Today's date", "Today's date should be correctly updated",
						"Not correctly displayed", "FAIL");
			}

			// Verifying Clear button functionality
			Thread.sleep(1000);
			actions.click("UpdtMultipleSet.Clear");
			Thread.sleep(500);

			// Calendar Icon check
			actions.click("UpdtMultipleSet.CalenderIcon");
			Thread.sleep(500);

			// mcd.Get_future_date(5, "UpdtMultipleSet.CalenderIcon", );
			mcd.Get_future_date(1, "close", strApplicationDate);
			Thread.sleep(500);
			Boolean chk = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.SDateVal")))
					.getAttribute("value").isEmpty();

			if (!chk) {
				actions.reportCreatePASS("Date selection using calender", "Date should be selected", "Date selected",
						"PASS");
			} else {
				actions.reportCreateFAIL("Date selection using calender", "Date should be selected",
						"Date not selected", "FAIL");
			}

			Thread.sleep(1000);

			// Valid input for All Prices Validation(non Numeric data)
			actions.click("UpdtMultipleSet.Clear");
			actions.click("UpdtMultipleSet.TodayBtn");
			Thread.sleep(500);

			actions.clear("UpdtMultipleSet.AllPrc");
			actions.click("UpdtMultipleSet.Apply");
			Thread.sleep(1000);

			actions.smartWait(120);

			String InpStrtDate = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.StartDate")))
					.getAttribute("value");
			String AppliedDate = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewDate")))
					.getAttribute("value");

			if (InpStrtDate.equals(AppliedDate)) {
				actions.reportCreatePASS("Verify Start Date", "Start Date should be updated against for all prices",
						"Start Date entered is updated against for all prices", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Start Date", "Start Date should be updated against for all prices",
						"Start Date entered is not correctly updated against for all prices", "FAIL");
			}

			actions.click("UpdtMultipleSet.UpdtTax");
			Thread.sleep(3000);

			mcd.SwitchToWindow("Mass Update Prices");
			actions.WaitForElementPresent("UpdateTax.TaxCode", 180);

			// Read the already existing tax entry value
			Select select = new Select(driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.MITaxEntry"))));
			String currEntry = select.getFirstSelectedOption().getText().trim();
			System.out.println(currEntry);

			// Select Tax Code Never and verify Tax rule and Tax entry fields
			// should be disabled for the menu items which has assigned 'Never'
			// tax code.
			try {
				actions.setValue("UpdateTax.TaxCode", "Never");
				Thread.sleep(3000);

				if ((actions.isElementEnabled("UpdateTax.TaxRule")) && (actions.isElementEnabled("UpdateTax.TaxEntry")))
					actions.reportCreateFAIL("Verify Tax rule and Tax entry fields should be disabled",
							"Tax rule and Tax entry fields should be disabled for the menu items which has assigned 'Never' tax code",
							"Not Displayed as expected", "FAIL");
				else
					actions.reportCreatePASS("Verify Tax rule and Tax entry fields should be disabled",
							"Tax rule and Tax entry fields should be disabled for the menu items which has assigned 'Never' tax code",
							"Displayed as expected", "Pass");

			} catch (Exception err1) {
				System.out.println("Error to set Tax code Never");
			}

			//// Select Tax Code
			actions.setValue("UpdateTax.TaxCode", strTaxCode);
			Thread.sleep(1000);

			// Select Tax Rule
			// actions.setValue("UpdateTax.TaxRule", strTaxRule);
			Select selectTaxRule = new Select(driver.findElement(By.xpath(actions.getLocator("UpdateTax.TaxRule"))));
			Thread.sleep(1000);
			selectTaxRule.selectByIndex(1);

			// enter different Tax Entry
			select = new Select(driver.findElement(By.xpath(actions.getLocator("UpdateTax.TaxEntry"))));
			for (int i = 0; i < select.getOptions().size(); i++) {
				if ((select.getOptions().get(i).getText().trim().equals(currEntry))
						|| (select.getOptions().get(i).getText().trim().equals("Default"))) {
					// Same as existing, print value
					System.out.println(select.getOptions().get(i).getText().trim());
				} else {
					select.selectByIndex(i);
					break;
				}
			}

			strTaxEntry = actions.getValue("UpdateTax.TaxEntry");
			System.out.println(strTaxEntry);

			// Select Tax Type
			actions.setValue("UpdateTax.TaxType", strTaxType);
			Thread.sleep(1000);

			// Apply Tax
			actions.click("UpdateTax.ApplyTax");
			Thread.sleep(3000);

			// Apply the Tax settings
			actions.click("RFMMassUpdatePrices.Save");
			Thread.sleep(5000);

			// driver.switchTo().window("");
			mcd.SwitchToWindow("@Mass Update Prices");

			// Save & Apply Changes
			actions.click("UpdtMultipleSet.Save");

			try {
				Alert popup = driver.switchTo().alert();
				System.out.println("> Verify the message displayed");
				String strActualMsg = popup.getText().trim();
				String strExptMessage = "Tax code can not applied to the below listed menu items(s) as they are not priced.";

				if (strActualMsg.contains(strExptMessage.trim()))
					actions.reportCreatePASS(
							"Verify that message is displayed when user tries to update Tax Settings of Menu Item(s) which are not priced.",
							"Tax code can not applied to the below listed menu items(s) as they are not priced.",
							"Warning message is displayed as expected", "Pass");
				else
					actions.reportCreateFAIL(
							"Verify that message is displayed when user tries to update Tax Settings of Menu Item(s) which are not priced.",
							"Tax code can not applied to the below listed menu items(s) as they are not priced.",
							"Warning message is not displayed as expected", "FAIL");
				popup.accept();

			} catch (Exception err1) {
				System.out.println("Alert message is not displayed");
			}

			// PriceActions.RFM_PRC_MUP_SaveAndApply(strMessageBeforeSave,
			// strResultMessage);

			// ------------------------------------------------------------------------

			/** Logout the application */
			driver.switchTo().window("");
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	public void RFM_PRC_MUP_Prerquisite() throws InterruptedException {
		// Menu Item
		actions.setValue("UpdateSet.SearchTextBox", "Auto_Choice");
		Thread.sleep(2000);
		actions.keyboardEnter("ManageDimensionGroup.SearchButton");
		Thread.sleep(2000);
		actions.smartWait(180);
		mcd.select_row("UpdateSet.MenuItemTable", 0);
		Thread.sleep(500);
		actions.click("UpdateSet.AddRow");
		Thread.sleep(500);
		actions.click("UpdateSet.NextBtn");
		Thread.sleep(2000);
		actions.smartWait(180);

		// Price Sets
		actions.click("ManageDimensionGroup.SearchButton");
		Thread.sleep(2000);
		actions.smartWait(180);
		mcd.select_row("UpdatePrcSet.PriceSetTable", 0);
		Thread.sleep(500);
		actions.click("UpdatePrcSet.AddRow");
		Thread.sleep(500);
		actions.click("UpdatePrcSet.NextBtn");
		Thread.sleep(2000);
		actions.smartWait(180);
	}
}