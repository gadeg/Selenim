package xtam.test;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

	public class PRC_0141_DltInactPCAuditLog {
		private Keywords actions;
		private WebDriver driver;
		private Map input;
		private UIValidations uiActions;
		private SoftAssert softAssert = new SoftAssert();
		private lib_MCD mcd;
		private lib_RFM2 rfm;
		private String strApplicationDate;

		// Test-Data Variables
		private Object strURL;
		private Object strUserName;
		private Object strPassword;
		private String strMarket;
		private String strNavigateTo;
		private String strStatusIA;
		private boolean blnAudit = false;
		private String strPriceSetName = null;
		private String strLevel;
		private String strLevelNodeName;

		public PRC_0141_DltInactPCAuditLog(WebDriver nodeDriver, Map inputData, Object or) {
			driver = nodeDriver;
			input = inputData;
			actions = new Keywords(driver, or);
			uiActions = new UIValidations();

			mcd = new lib_MCD(driver, actions, uiActions, inputData);
			rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

			// Read input Test-Data
			strURL = mcd.GetTestData("DT_URL");
			strUserName = mcd.GetTestData("DT_USER_NAME");
			strPassword = mcd.GetTestData("DT_PASSWORD");
			strMarket = mcd.GetTestData("DT_MARKET");
			strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
			strStatusIA = mcd.GetTestData("DT_STATUSIA");
			strLevel = mcd.GetTestData("DT_STRLEVEL");
			strLevelNodeName = mcd.GetTestData("DT_LEVELNAME");
		}

		@Test
		public void test_PRC_0141_DltInactPCAuditLog() throws InterruptedException {

			try {
				System.out.println(
						"********************************************************************** Test execution starts");
				actions.setTestcaseDescription(mcd.GetTestData("DT_Description"));
				/** Launch and Login RFM */
				System.out.println("> Launch and Login RFM");
				rfm.LaunchAndLogin(strURL, strUserName, strPassword);

				/** Select Market (Node) */
				System.out.println("> Select Market (Node)");
				rfm.SelectMarket(strMarket);

				/** Select Menu Option */
				System.out.println("> Navigate to :: " + strNavigateTo);
				actions.select_menu("RFMNavigation.Main", strNavigateTo);
				Thread.sleep(2000);
				actions.waitForPageToLoad(120);

				/** Update title of new Page */
				mcd.SwitchToWindow("#Title");

				actions.WaitForElementPresent("PricingSets.StatusFilter", 120);
				// Select Inactive Status from the drop down
				actions.setValue("PricingSets.StatusFilter", strStatusIA);
				mcd.smartsync(180);
				// Deleting inactive price set
				WebElement Element = mcd.GetTableCellElement("FieldPermissions.Table", 1, "Delete", "a/img");
				actions.click(Element);
				mcd.VerifyAlertMessageDisplayed("Warning", "Are you sure you want to delete the selected item?", true,
						AlertPopupButton.OK_BUTTON);
				mcd.smartsync(180);

				// Verify Delete Message successfully Displayed on Page
				boolean blMessage = actions.isTextPresence("Delete has been successfully completed", true);
				if (blMessage) {
					actions.reportCreatePASS("Delete Message should get displayed successfully",
							"Delete Message should get displayed successfully", "Delete Message displayed successfully",
							"PASS");
				} else {
					actions.reportCreateFAIL("Delete Message should get displayed successfully",
							"Delete Message should get displayed successfully", "Delete Message not displayed successfully",
							"FAIL");
				}
				/** Step 5 - Verify Audit Log */
				blnAudit = rfm.VerifyAuditLog_Entry("Price Sets", "Delete", strLevel);
				if (blnAudit) {
					actions.reportCreatePASS("Verify Audit Log Entry for Delete Price Sets",
							"Audit log should be generated for Delete Price Sets",
							"Audit log generated for Delete Price Sets succesfully", "PASS");
				} else {
					actions.reportCreateFAIL("Verify Audit Log Entry for Delete Price Sets",
							"Audit log should be generated for Delete Price Sets",
							"Audit log not generated for Delete Price Sets succesfully", "FAIL");
				}

				blnAudit = rfm.RFM_VerifyAuditLog_Details("RFM2", strUserName.toString(), "Price Sets", "Delete",
						strLevelNodeName, strLevel, "Price Set " + strPriceSetName + " has been deleted.");
				if (blnAudit) {
					actions.reportCreatePASS("Verify Audit Log Details for Delete Price Sets",
							"Audit log should be generated for Delete Price Sets",
							"Audit log generated for Delete Price Sets succesfully", "PASS");
				} else {
					actions.reportCreateFAIL("Verify Audit Log Details for Delete Price Sets",
							"Audit log should be generated for Delete Price Sets",
							"Audit log not generated for Delete Price Sets succesfully", "FAIL");
				}

				/** Logout the application */
				rfm.Logout();

			} catch (Exception e) {
				// reporting the Fail condition
				actions.catchException(e);
			} finally {
				actions.quitBrowser();
				actions.verifyTestCase(this.getClass());
			}
		}
	}
