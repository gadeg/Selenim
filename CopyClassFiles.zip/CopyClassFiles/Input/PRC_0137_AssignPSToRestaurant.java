package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class PRC_0137_AssignPSToRestaurant {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;
	// Variables and Objects for URL,User Name and Market
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	private String strNode;
	private String strParameterSetName;
	private String strNavigateToAnother;
	private String strWarningMsg;

	private Object strpriceset1;
	private Object strpriceset2;
	private String strMethod;
	private String strNewPrcSet;
	private String strResMessage;
	private String strPrcSetType;
	private String strNodeNum;
	private String strNumOfMenuItem1;
	private String strNumOfMenuItem2;
	private String strStatus_Msg;
	private String strNewPrice1;
	private String strNewPrice2;
	private String strStatus_1;
	private String strStatus_2;
	private String[] strMsg;
	private String Msg;
	private String strApplicationDate;

	public PRC_0137_AssignPSToRestaurant(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();
		// Initialize
		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);

		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		strNavigateToAnother = mcd.GetTestData("DT_NAVIGATE_TO_SECONDMENU");
		strNode = mcd.GetTestData("DT_NODE");
		strWarningMsg = mcd.GetTestData("DT_ERROR_MESSAGE");

		strpriceset1 = mcd.GetTestData("PRICESET1");
		strpriceset2 = mcd.GetTestData("PRICESET2");
		strMethod = mcd.GetTestData("Method");
		strNewPrcSet = mcd.GetTestData("PriceSet_Name");
		strResMessage = mcd.GetTestData("Result_Message");
		strPrcSetType = mcd.GetTestData("PriceSetType");
		strNodeNum = mcd.GetTestData("NodeNum");
		strStatus_Msg = mcd.GetTestData("Status_Msg");
		strNumOfMenuItem1 = mcd.GetTestData("NumOfMenuItem1");
		strNumOfMenuItem2 = mcd.GetTestData("NumOfMenuItem2");
		strNewPrice1 = mcd.GetTestData("NewPrice1");
		strNewPrice2 = mcd.GetTestData("NewPrice2");
		strStatus_1 = mcd.GetTestData("Status_1");
		strStatus_2 = mcd.GetTestData("Status_2");
		Msg = mcd.GetTestData("DT_Msg");
		strMsg = Msg.split("#");
	}

	@Test
	public void PRC_0137_AssignPSToRestaurant() throws InterruptedException {
		String strPageTitle = "Parameter Set";
		String strPageSubHeading = "Parameter Set";

		try {
			actions.setTestcaseDescription("Integration Scenario: Verify that only active Price set can be assigned to a Restaurant and can not be Inactivated once assigned to the Restaurant");

			System.out.println(
					"********************************************************************** Test execution starts");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");
			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

		
			strpriceset1 = PriceActions.RFM_PRC_CreatePrcSetWOCpy(strPrcSetType, strStatus_Msg, strNewPrice1,
					strNodeNum, strApplicationDate, strResMessage, strStatus_1);
			System.out.println("> > > > > > strpriceset1 - - - - -" + strpriceset1);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			strpriceset2 = PriceActions.RFM_PRC_CreatePrcSetWOCpy(strPrcSetType, strStatus_Msg, strNewPrice2,
					strNodeNum, strApplicationDate, strResMessage, strStatus_2);

			
			System.out.println("> > > > > > strpriceset2 - - - - - " + strpriceset2);

			mcd.SwitchToWindow("#Title");
			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateToAnother);
			actions.select_menu("RFMHome.Navigation", strNavigateToAnother);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			actions.clear("RestaurantUpdt.SearchRestro");
			actions.setValue("RestaurantUpdt.SearchRestro", strNodeNum);
			actions.click("MenuItemPriceandTaxByRestaurant.NBSearchButton");
			actions.smartWait(120);
			
			int iRestNameCol = mcd.GetTableColumnNumber("RFM.WebTable", "Number");

			// Search & Click Restaurant name
			WebElement eleRestaurant = mcd.GetTableCellElement("RFM.WebTable", 1, iRestNameCol, "a");
			eleRestaurant.sendKeys(Keys.ENTER);

			Thread.sleep(5000);
			actions.waitForPageToLoad(180);

			mcd.SwitchToWindow("#Title");

			actions.WaitForElementPresent("RestaurantProfile.MEnuItemPOSPricing");
			actions.click("RestaurantProfile.MEnuItemPOSPricing");
			actions.smartWait(120);

			actions.setValue("RestaurantProfile.ChooseSetTypeDDL", "Pricing");
			
			actions.smartWait(120);

			actions.setValue("CopyScreenSet.CopySearchTextBox", strpriceset2);
			actions.click("RestaurantUpdt.SearchBtn");
			actions.smartWait(120);

			actions.verifyTextPresence(strMsg[0], true);

			actions.clear("CopyScreenSet.CopySearchTextBox");
			actions.setValue("CopyScreenSet.CopySearchTextBox", strpriceset1);
			actions.click("RestaurantUpdt.SearchBtn");
			actions.smartWait(120);

			WebElement element = mcd.GetTableCellElement("MassAssignmentToSets.LeftTable", 1, 1, "");
			
		    // actions.click(element);
			element.click();
			Thread.sleep(2000);
			
			driver.findElement(By.xpath(actions.getLocator("RFM.RightArrowButton"))).click();
			Thread.sleep(2500);
			actions.keyboardEnter("TaxDefinationSet.Applybtn");
			
            try{
                String popuvalue=driver.switchTo().alert().getText();     
                if(!popuvalue.equalsIgnoreCase("Are you sure you want to save changes to the current settings? These changes will NOT propagate to the future settings.")){
                	try{
                		
            			mcd.SwitchToWindow("Apply Changes Details");
            			actions.click("PackageSchedule.NBSaveButton");
            			mcd.SwitchToWindow("@Restaurant Profile");
            			}catch(Exception e){
            				System.out.println("Apply Changes details window not available");
            			}
            			try {
            				// Switch to window Run Validation Report directly from Main window
            				mcd.SwitchToWindow("Run Validation Report");
            				Thread.sleep(2000);
            				actions.click("RestaurantUpdtFuture.Cancel");
            				Thread.sleep(3000);
            				mcd.SwitchToWindow("Restaurant Profile");

            				// Verify Success message
            				actions.verifyTextPresence("Your changes have been saved.", true);
            				Thread.sleep(1000);
            			} catch (Exception e) {
            				System.out.println(e);
            			}
                		
                }else{
                	try{
            			mcd.SwitchToWindow("Run Validation Report");
					Thread.sleep(2000);
					actions.click("RestaurantUpdtFuture.Cancel");
					Thread.sleep(3000);
					mcd.SwitchToWindow("Restaurant Profile");
					actions.verifyTextPresence("Your changes have been saved.", true);
					Thread.sleep(1000);
        			}catch(Exception e){
        				System.out.println("Run Validation Report not available");
        			}
                }
            }catch(Exception e){
                
            }

			

			/** Select Menu Option */
            
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			
			mcd.SwitchToWindow("#Title");

			actions.clear("TaxChain.SearchTextBox");
			actions.setValue("TaxChain.SearchTextBox", strpriceset1);
			actions.click("MenuItemPriceandTaxByRestaurant.NBSearchButton");
			actions.smartWait(180);


			int iRestNameCol1 = mcd.GetTableColumnNumber("RFM.WebTable", "Name");

			// Search & Click Restaurant name
			
			WebElement eleRestaurant1 = mcd.GetTableCellElement("RFM.WebTable", 1, iRestNameCol1, "a");
			eleRestaurant1.sendKeys(Keys.ENTER);

			Thread.sleep(5000);
			actions.waitForPageToLoad(180);

			mcd.SwitchToWindow("#Title");
			
			//Navigated to price sets page
			

			actions.WaitForElementPresent("ManagePS.Status");
			actions.setValue("ManagePS.Status", strStatus_2);

			actions.click("PriceSet.ApplyButton");
			
			actions.smartWait(50);
			actions.isTextPresence("Price Set can not be deactivated as it is associated with Restaurant(s).", true);
			
		
			/** Logout the application */
			
			rfm.Logout();

		} catch (Exception e) {
			System.out.println("Test Failed :: " + e.getCause() + " - " + e.getMessage());
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}
