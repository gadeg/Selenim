package xtam.test;


import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.lib_MCD.AlertPopupButton;


public class PRC_0239_MPU_AllFieldsVerify {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();
	
	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;
	
	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private String strApplicationDate;
	private String strMessageBeforeSave;
	private String strResultMessage;

	private String strEatingPrc;
	private String strTakeOutPrc;
	private String strOtherPrice;

	
	public PRC_0239_MPU_AllFieldsVerify (WebDriver nodeDriver, Map inputData, Object or){
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();
		
		
		mcd = new lib_MCD (driver, actions, uiActions, inputData);
		rfm = new lib_RFM2 (driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);
		
		// Read input Test-Data
		strURL 			= mcd.GetTestData("DT_URL");
		strUserName 	= mcd.GetTestData("DT_USER_NAME");
		strPassword 	= mcd.GetTestData("DT_PASSWORD");
		strMarket 		= mcd.GetTestData("DT_MARKET");
		strNavigateTo 	= mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters
		
		strMessageBeforeSave	= mcd.GetTestData("MessageBeforeSave");
		strResultMessage 		= mcd.GetTestData("ResultMessage");
		strEatingPrc			= mcd.GetTestData("EatingPrc");
		strTakeOutPrc			= mcd.GetTestData("TakeOutPrc");
		strOtherPrice			= mcd.GetTestData("OtherPrice");
	}
	
	@Test
	public void PRC_0239_MPU_AllFieldsVerify() throws InterruptedException {
		String strTestDescription = "Verify the error messages of  Mass Update Prices functionality when �Eatin Prices�, �Takeout Prices� and �Other Prices� are entered";		// TODO: Test Case Description
		
		try {
			 actions.setTestcaseDescription(strTestDescription);
			System.out.println("********************************************************************** Test execution starts");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);
			
			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);
		
            /** Select Menu Option */
            System.out.println("> Navigate to :: " + strNavigateTo);
            actions.select_menu("RFMHome.Navigation",strNavigateTo);
            Thread.sleep(2000);
            actions.waitForPageToLoad(120);

            /** Update title of new Page  */
            mcd.SwitchToWindow("#Title");
            
            /** Get application time */
            WebElement apptime = mcd.getdate();
            strApplicationDate = apptime.getText();

			 /** Get application time */
			
			
			// ------------------------------------------------------------------------ Actions specific to test-flow
			
			//Verify Eating/Take-out/Other prices
			RFM_MUP_Eating_TO_Other_ErrCheck(strEatingPrc, strTakeOutPrc, strOtherPrice, strMessageBeforeSave, strResultMessage);
			
			
			// ------------------------------------------------------------------------ 
			
			/** Logout the application */
			rfm.Logout();
			

		} catch(Exception e) {
			//Reporter.log("Test Failed :: " + e.getCause() + " - " +  e.getMessage());
			System.out.println("Test Failed :: " + e.getCause() + " - " +  e.getMessage());
			actions.catchException(e);
			
		        } finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
	public boolean RFM_MUP_Eating_TO_Other_ErrCheck(String strEatingPrc, String strTakeOutPrc, String strOtherPrice,
			String strMessageBeforeSave, String strResultMessage) throws Exception {

		Boolean blnResult = false;
		Boolean test_AllStatus;
		String strAll_RadioValue, strRest_Value, strEating_Chkbx, strTO_Chkbx, strOther_Chkbx;

		// Navigate to Mass Update Price Page
		RFM_PRC_MUP_Prerquisite();

		// Selecting Today's date (Today Button)
		
		Thread.sleep(1000);
		actions.click("UpdtMultipleSet.TodayBtn");
		Thread.sleep(1000);

		// Check default values/status of All Prices Fields
		// All - default checked & enabled, Rest - disabled

		strAll_RadioValue = actions.getValue("VerifyFields.AllRadio");
		test_AllStatus = this.get_Field_Status("VerifyFields.AllRadio");
		strRest_Value = actions.getValue("VerifyFields.RestPrcRadio");

		strEating_Chkbx = actions.getValue("VerifyFields.EatingChkBx");
		strTO_Chkbx = actions.getValue("VerifyFields.TkOutChkBx");
		strOther_Chkbx = actions.getValue("VerifyFields.OtherChkBx");

		if ((strAll_RadioValue.equals("true")) && (test_AllStatus)) {
			actions.reportCreatePASS("Verify All Price radio button", "Should be enabled & selected by default",
					"Is enabled & selected by default", "PASS");
			
		} else {
			actions.reportCreateFAIL("Verify All Price radio button", "Should be enabled & selected by default",
					"Is not enabled & selected by default", "FAIL");
			
		}

		if (strRest_Value.equals("false")) {
			actions.reportCreatePASS("Verify rest of the price radio button", "Should be unchecked by default",
					"Not selected by default", "PASS");
			
		} else {
			actions.reportCreateFAIL("Verify rest of the price radio button", "Should be unchecked by default",
					"Selected by default", "FAIL");
			
		}

		// Eating Prc/TO/Other radio button unchecked

		if ((strEating_Chkbx.equals("false")) && (strTO_Chkbx.equals("false")) && (strOther_Chkbx.equals("false"))) {
			actions.reportCreatePASS("Verify Eating Prc/TO/Other price radio button", "Should be unchecked by default",
					"Not selected by default", "PASS");
		
		} else {
			actions.reportCreateFAIL("Verify Eating Prc/TO/Other price radio button", "Should be unchecked by default",
					"Selected by default", "FAIL");
			
		}

		// Eating Prc/TO/Other fields disabled
		if (!((this.get_Field_Status("VerifyFields.EatingPrc")) && this.get_Field_Status("VerifyFields.TkOutPrc")
				&& this.get_Field_Status("VerifyFields.OtherPrc"))) {
			actions.reportCreatePASS("Verify Eating Prc/TO/Other price fields", "Should be disabled by default",
					"Disabled by default", "PASS");
			
		} else {
			actions.reportCreateFAIL("Verify Eating Prc/TO/Other price fields", "Should be disabled by default",
					"Enabled by default", "FAIL");
			
		}

		Thread.sleep(3000);
		// Check Rest Prices RAdio button
		// All Prices - disabled, Other Enabled

		actions.click("VerifyFields.RestPrcRadio");
		Thread.sleep(1000);

		strAll_RadioValue = actions.getValue("VerifyFields.AllRadio");
		test_AllStatus = this.get_Field_Status("VerifyFields.AllRadio");
		strRest_Value = actions.getValue("VerifyFields.RestPrcRadio");

		strEating_Chkbx = actions.getValue("VerifyFields.EatingChkBx");
		strTO_Chkbx = actions.getValue("VerifyFields.TkOutChkBx");
		strOther_Chkbx = actions.getValue("VerifyFields.OtherChkBx");

		if ((strAll_RadioValue.equals("true")) && (test_AllStatus)) {
			actions.reportCreateFAIL("Verify All radio button after, other price radio button is selected",
					"Should get unchecked & disabled", "Not unchecked or disabled", "FAIL");
			
		} else {
			actions.reportCreatePASS("Verify All radio button after, other price radio button is selected",
					"Should get unchecked & disabled", "Gets unchecked & disabled", "PASS");
			
		}

		if (strRest_Value.equals("true")) {
			actions.reportCreatePASS("Verify Rest prices radio button after being selected",
					"Should get checked & enabled", "Gets checked & enabled", "PASS");
			
		} else {
			actions.reportCreateFAIL("Verify Rest prices radio button after being selected",
					"Should get checked & enabled", "Gets unchecked or is disabled", "FAIL");
			
		}

		// Eating Prc/TO/Other radio button checked

		if ((strEating_Chkbx.equals("true")) && (strTO_Chkbx.equals("true")) && (strOther_Chkbx.equals("true"))) {
			actions.reportCreatePASS(
					"Verify Eating Prc/TO/Other price radio button after rest price check box is clicked",
					"Should remain unchecked", "Not yet selected", "PASS");
			
		} else {
			actions.reportCreateFAIL(
					"Verify Eating Prc/TO/Other price radio button after rest price check box is clicked",
					"Should remain unchecked", "Get Checked", "FAIL");
			
		}

		// Eating Prc/TO/Other fields enabled
		if ((this.get_Field_Status("VerifyFields.EatingPrc")) && this.get_Field_Status("VerifyFields.TkOutPrc")
				&& this.get_Field_Status("VerifyFields.OtherPrc")) {
			actions.reportCreatePASS(
					"Verify Eating Prc/TO/Other price text fields after rest price check box is clicked",
					"Should get enabled", "Fields gets enabled", "PASS");
			
		} else {
			actions.reportCreateFAIL(
					"Verify Eating Prc/TO/Other price text fields after rest price check box is clicked",
					"Should get enabled", "Fields remain disabled", "FAIL");
			
		}

		// Validating input in Eating/TO/Other Price fields
		
		actions.setValue("VerifyFields.EatingPrc", "test1");
		actions.setValue("VerifyFields.TkOutPrc", "test2");
		actions.setValue("VerifyFields.OtherPrc", "test3");
		actions.click("UpdtMultipleSet.Apply");
		Thread.sleep(4000);

		Boolean VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", "Please enter a Valid price.", true,
				AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg) {
			actions.reportCreatePASS("Verify numeric validation for Eating/TO/Other Price fields",
					"Only Numeric values should be allowed", "Only numeric values are allowed", "PASS");
			
			blnResult = true;
		} else {
			actions.reportCreateFAIL("Verify numeric validation for Eating/TO/Other Price fields",
					"Only Numeric values should be allowed", "Non-numeric values are allowed", "FAIL");
			
			blnResult = false;
		}
		
		// Clearing all the test values
		actions.clear("VerifyFields.EatingPrc");
		actions.clear("VerifyFields.EatingPrc");
		actions.clear("VerifyFields.TkOutPrc");
		actions.clear("VerifyFields.TkOutPrc");
		actions.clear("VerifyFields.OtherPrc");
		actions.clear("VerifyFields.OtherPrc");
		
		// Enter valid input in Eating/TO/Other Price fields
		

		actions.setValue("VerifyFields.EatingPrc", strEatingPrc);

		actions.setValue("VerifyFields.TkOutPrc", strTakeOutPrc);

		actions.setValue("VerifyFields.OtherPrc", strOtherPrice);

		actions.click("UpdtMultipleSet.Apply");
		Thread.sleep(2000);

		// ------------------------------------------------------------------------------------

		// Save & Apply Changes

		RFM_PRC_MUP_SaveAndApply(strMessageBeforeSave, strResultMessage);

		// Verifying correct prices are saved

		// Thread.sleep(1000);
		// actions.click("UpdtMultipleSet.ExpandImg");
		// Thread.sleep(1000);

		String Eating_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewEatingPrc")))
				.getAttribute("value");
		String TakeOut_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewTkOutPrc")))
				.getAttribute("value");
		String Other_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewOtherPrc")))
				.getAttribute("value");

		if ((Eating_Price.equals(strEatingPrc)) && (TakeOut_Price.equals(strTakeOutPrc))
				&& (Other_Price.equals(strOtherPrice))) {
			actions.reportCreatePASS("Verify Price Update",
					"All Prices/Eating/Take out/Other Prices should be saved correctly", "Updated Correctly", "PASS");
			
		} else {
			actions.reportCreateFAIL("Verify Price Update",
					"All Prices/Eating/Take out/Other Prices should be saved correctly", "Not Updated Correctly",
					"FAIL");
			
		}
		Thread.sleep(1000);

		return blnResult;
	}

	public boolean get_Field_Status(String strLocator) {
		Boolean Field_Status;
		Field_Status = driver.findElement(By.xpath(actions.getLocator(strLocator))).isEnabled();
		return Field_Status;
	}
	public void RFM_PRC_MUP_SaveAndApply(String strMessageBeforeSave, String strResultMessage) throws Exception {
		
		
		//Unchecking activate menu items checkbox
		
		if(driver.findElement(By.xpath(actions.getLocator("RFMMassUpdatePrices.chkActivateAllMI"))).isSelected()){
			actions.click("RFMMassUpdatePrices.chkActivateAllMI");
		}
			
		
		// Click Save
		
		Thread.sleep(2000);
		actions.click("UpdtMultipleSet.Save");
		Thread.sleep(3000);
		

		// Check Alert message
		
		try {
			Boolean VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strMessageBeforeSave, true,
					AlertPopupButton.OK_BUTTON);
			if (VerifyPopUpMsg) {
				actions.reportCreatePASS("Verify Alert message before save", "Alert message should be given",
						"Alert message is given", "PASS");
				
			} else {
				actions.reportCreateFAIL("Verify Alert message before save", "Alert message should be given",
						"Alert message is not given", "FAIL");
				
			}
		} catch (Exception err) {
			System.out.println("No alerts");
		}

		mcd.waitAndSwitch("@Mass Update Prices");
		actions.WaitForElementPresent("OutputWindow.OutputMsg", 180);
		
		
		String Result = driver.findElement(By.xpath(actions.getLocator("OutputWindow.OutputMsg"))).getText();
		if (Result.equals(strResultMessage)) {
			actions.reportCreatePASS("Verify Mass update of prices", "Should be done successfully", "Done successfully",
					"PASS");
		} else {
			actions.reportCreateFAIL("Verify Mass update of prices", "Should be done successfully",
					"Not done successfully", "PASS");
			
		}

		/*// Activating Menu Item case
		 * 
		try {
			String Result_Img = driver.findElement(By.xpath(actions.getLocator("ActivateMISet.DoneImg2")))
					.getAttribute("src");
			if (Result_Img.contains("approve.jpg")) {
				actions.reportCreatePASS("Verify Activate Menu Item", "Activate Menu Item should be done successfully",
						"Activate Menu Item is done successfully", "PASS");
				// Reporter.log("Activate Menu Item is done successfully");
			} else {
				actions.reportCreateFAIL("Verify Activate Menu Item", "Activate Menu Item should be done successfully",
						"Activate Menu Item is not done successfully", "FAIL");
				// Reporter.log("Activate Menu Item is done successfully");
			}
		} catch (Exception e) {
			// Reporter.log("Activating Menu Item is unchecked");
		}*/
		
		
		// Click OK button

		Thread.sleep(2000);
		actions.click("OutputWindow.OkBtn");
		Thread.sleep(5000);

		// Window navigated back to main window
		// System.out.println(driver.getTitle());
		
		if (driver.getTitle().equals("Mass Update Prices")) {
			actions.reportCreatePASS("Verify navigation after final output",
					"Window should be navigated back after updating prices",
					"Window navigated back after updating prices", "PASS");
			} else {
			actions.reportCreateFAIL("Verify navigation after final output",
					"Window should be navigated back after updating prices",
					"Window not navigated back after updating prices", "FAIL");


		}

	}
	public void RFM_PRC_MUP_Prerquisite() throws InterruptedException {
		// Menu Item

		actions.keyboardEnter("UpdateSet.VwFullList");
		Thread.sleep(2000);
		actions.smartWait(180);
		mcd.select_row("UpdateSet.MenuItemTable", 0);
		Thread.sleep(500);
		actions.click("UpdateSet.AddRow");
		Thread.sleep(500);
		actions.click("UpdateSet.NextBtn");
		Thread.sleep(2000);
		actions.smartWait(180);

		// Price Sets
		actions.click("UpdatePrcSet.VwFullList");
		Thread.sleep(2000);
		actions.smartWait(180);
		mcd.select_row("UpdatePrcSet.PriceSetTable", 0);
		Thread.sleep(500);
		actions.click("UpdatePrcSet.AddRow");
		Thread.sleep(500);
		actions.click("UpdatePrcSet.NextBtn");
		Thread.sleep(2000);
		actions.smartWait(180);
	}

	
}
