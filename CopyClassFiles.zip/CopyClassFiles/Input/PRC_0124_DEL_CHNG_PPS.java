package xtam.test;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class PRC_0124_DEL_CHNG_PPS {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters
	private String strSrchType[], srchtype, strSrchText[], srchtext, strValTxt[], Validate_Text,
			strExpectLevelDetails[];
	private String strOperation, strActivity, restNum, strLevel, strUserID, strDBName, strPriceSet, strExpectlevel[],
			strleveldetails;

	public PRC_0124_DEL_CHNG_PPS(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		restNum = mcd.GetTestData("DT_RestNum");
		// TODO: GetTestData for other data-parameters
		srchtype = mcd.GetTestData("DT_SRCHTYPE");
		srchtext = mcd.GetTestData("DT_SRCHDATA");
		Validate_Text = mcd.GetTestData("DT_VALIDATETEXT");
		strOperation = mcd.GetTestData("DT_OPERATION");
		strActivity = mcd.GetTestData("DT_ACTIVITY");
		strLevel = mcd.GetTestData("DT_LEVEL");
		strDBName = mcd.GetTestData("DT_DBNAME");
		strUserID = mcd.GetTestData("DT_USER_NAME");
		strleveldetails = mcd.GetTestData("DT_LevelDetails");

		strValTxt = Validate_Text.split("#");
		strSrchType = srchtype.split("#");
		strSrchText = srchtext.split("#");
		strExpectlevel = strLevel.split("#");
		strExpectLevelDetails = strleveldetails.split("#");
	}

	@Test
	public void test_PRC_0124_DEL_CHNG_PPS() throws InterruptedException {
		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			String strTestDescription = "Verify Update Price Set Details (Changes by Day) "
					+ "functionality of Promotional price set"; // TODO: // Test
																// Case
																// Description`

			// setting the description
			actions.setTestcaseDescription(strTestDescription);

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.WaitForElementPresent("RFMPriceSets.dropdownSearchList", 180);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ----------------------------------- Actions specific to test-flow
			/**
			 * TODO creating the pre-req Promotional Price set & passing it in
			 * the test script
			 */
			/*
			 * strPricesetname = fn_CreateSet("New Price Set",
			 * "RFMSelectNode.SelectNode", mcd.GetGlobalData("Rest_1"), "No",
			 * "Price Sets : Common Menu Item Selector", "New Price Sets");
			 */

			// Create Active price Set
			actions.click("PriceSets.NewPriceSetBtn");
			mcd.waitAndSwitch("New Price Sets");
			strPriceSet = mcd.fn_GetRndName("PriceSet");
			actions.clear("NewPriceSets.TextBox");
			actions.setValue("NewPriceSets.TextBox", strPriceSet);
			actions.click("NewPriceSet.PromRadioBtn");
			actions.click("AddNewDayPartSet.SelectBtn");
			mcd.waitAndSwitch("Select Node");
			actions.WaitForElementPresent("SelectNodeRest.SearchTextField", 180);
			mcd.Selectrestnode_JavaScriptClk("RFMSelectNode.SelectNodeTable", restNum);
			mcd.waitAndSwitch("New Price Sets");

			/** Selecting the Start & End Date */
			actions.click("NewPriceSet.StartDate");
			mcd.sel_current_date("NewPriceSet.StartDate", strApplicationDate);
			actions.click("NewPriceSet.EndDate");
			mcd.select_date("27", "next", "NewPriceSet.EndDate");
			actions.click("MassSetAssignment.MASelectRestNextbtn");
			mcd.SwitchToWindow("@Price Sets : Common Menu Item Selector");

			/** adding the menu item now */
			actions.WaitForElementPresent("CommonMenuItemSelector.ViewFullListBtn", 180);
			actions.click("CommonMenuItemSelector.ViewFullListBtn");
			actions.smartWait(180);
			actions.setValue("AddRemoveMenu.Availability", "Available");
			actions.smartWait(180);
			actions.setValue("AddRemoveMI.FilterStatus", "Active");
			actions.smartWait(180);

			/** adding the menu item now */
			actions.WaitForElementPresent("CommonMenuItemSelector.ViewFullListBtn", 180);
			actions.click("CommonMenuItemSelector.ViewFullListBtn");
			actions.smartWait(180);
			actions.setValue("AddRemoveMenu.Availability", "Available");
			actions.smartWait(180);
			actions.setValue("AddRemoveMI.FilterStatus", "Active");
			actions.smartWait(180);

			/** Selecting the record & saving it */
			WebElement elem_checkbox = mcd.GetTableCellElement("AddRemoveComponent.webtable", 1, "Add", "input");
			actions.javaScriptClick(elem_checkbox);
			actions.WaitForElementPresent("RFM.SaveBtn", 180);
			actions.click("RFM.SaveBtn");
			actions.smartWait(180);
			actions.click("RFM.CancelButton");
			actions.smartWait(180);

			// // setting the value for the search type
			actions.setValue("RFMPriceSets.dropdownSearchList", strSrchType[1].trim());

			// setting the price set name in the search box
			// searching for the valid
			actions.setValue("PriceSet.SearchBox", strPriceSet);

			// clicking on the search button
			actions.keyboardEnter("PriceSet.SearchBtn");
			actions.smartWait(180);

			// Clicking the first record from the list now
			WebElement BSP_1 = mcd.GetTableCellElement("RFM.WebTable", 1, "Name", "a");
			String strRestNode = mcd.GetTableCellValue("RFM.WebTable", 1, "Node", "", "");
			actions.keyboardEnter(BSP_1);
			mcd.SwitchToWindow("#Title");

			// checking the price set is with future setting or not
			List<WebElement> future_setting = driver
					.findElements(By.xpath(actions.getLocator("PriceSets.SBFutureSetting")));

			if (future_setting.size() > 1) {

				// Clicking on the first record for future settings
				future_setting.get(1).click();

				// waiting for the page to load
				actions.smartWait(180);

			} else {

				// Creating the price set with future setting
				mcd.SelectDate_OpenCalender_Priceset(strApplicationDate, "next");

				// selecting the range now
				mcd.SelectDate_OpenCalender_Priceset(strApplicationDate, "next");

				// wating for the page to load
				actions.smartWait(180);

				// creating the price value of 2 digits
				String price = RandomStringUtils.randomNumeric(2);

				// updating the price for the future setting for all the
				// category
				actions.setValue("UpdtMultipleSet.AllPrc", price);
				actions.keyboardEnter("ManagePS.QuickToolApply");

				// waiting for the price to get updated
				Thread.sleep(1000);

				// verifying the pricing the list now
				String allprice = driver.findElement(By.xpath(actions.getLocator("ManagePS.SBAllPriceTxt")))
						.getAttribute("value");
				List<WebElement> Future_price = driver
						.findElements(By.xpath(actions.getLocator("ManagePS.SBPricingTextBoxes")));

				int rows = Future_price.size();
				boolean flag = false;
				if (rows >= 1) {
					for (int i = 0; i < rows; i++) {

						String text = Future_price.get(i).getAttribute("value");
						if (text.equalsIgnoreCase(allprice)) {
							flag = true;
						} else {
							flag = false;
						}

					}
					if (flag == true) {
						actions.reportCreatePASS("Verifying the Price is updated as per All Price field or not",
								"Prices should updated as '" + price + "' as in All Price field",
								"Prices are updated as '" + price + "' as in All Price field", "Pass");
					} else {
						actions.reportCreateFAIL("Verifying the Price is updated as per All Price field or not",
								"Prices should updated as '" + price + "' as in All Price field",
								"Prices are not updated as '" + price + "' as in All Price field", "Fail");
					}
				} else {
					System.out.println("no menu item is present to update the price.");
				}

				// clicking on the apply button
				WebElement elem_savebtn = null;
				try {
					elem_savebtn = driver.findElement(By.xpath(actions.getLocator("ManagePS.ApplyBtn")));
				} catch (Exception er) {
					elem_savebtn = driver.findElement(By.xpath(actions.getLocator("RFM.SaveBtn")));
				}
				actions.click(elem_savebtn);

				try {
					// verify the alert pop up
					mcd.VerifyAlertMessageDisplayed("Confirmation", strValTxt[3].trim(), true,
							AlertPopupButton.OK_BUTTON);
				} catch (Exception e) {

					System.out.println("no pop up alert present");
				}

				// waiting for the page to laod
				actions.smartWait(180);

				// verify the success message
				actions.verifyTextPresence(strValTxt[4].trim(), true);

			}

			// deleting the future setting now
			actions.click("PriceSets.SBDelAllCHng");
			Thread.sleep(1000);

			if (mcd.VerifyAlertMessageDisplayed("Confirmation", strValTxt[5].trim(), true,
					AlertPopupButton.OK_BUTTON)) {
				actions.reportCreatePASS("verify Pop up alert is displayed or not",
						"Pop up alert should be displayed with message '" + strValTxt[5].trim(),
						"Pop up alert is displayed with message '" + strValTxt[5].trim(), "Pass");
			} else {
				actions.reportCreateFAIL("verify Pop up alert is displayed or not",
						"Pop up alert should be displayed with message '" + strValTxt[5].trim(),
						"Pop up alert is displayed with message '" + strValTxt[5].trim(), "Fail");
			}

			// wating for the page to get loaded
			actions.smartWait(180);

			// setting the value for the search type
			actions.setValue("RFMPriceSets.dropdownSearchList", strSrchType[1].trim());

			// setting the price set name in the search box
			// searching for the valid
			actions.clear("PriceSet.SearchBox");
			actions.setValue("PriceSet.SearchBox", strPriceSet);

			// clicking on the search button
			actions.keyboardEnter("PriceSet.SearchBtn");
			actions.smartWait(180);

			// Clicking the first record from the list now
			BSP_1 = mcd.GetTableCellElement("RFM.WebTable", 1, "Name", "a");
			actions.keyboardEnter(BSP_1);
			mcd.SwitchToWindow("#Title");

			// checking the price set is with future setting or not
			future_setting = driver.findElements(By.xpath(actions.getLocator("PriceSets.SBFutureSetting")));

			if (future_setting.size() > 1) {

				actions.reportCreateFAIL("Verifying the Future Setting is displayed or not",
						"Future Setting should not be displayed", "Future Setting is displayed", "Fail");

			} else {

				actions.reportCreatePASS("Verifying the Future Setting is displayed or not",
						"Future Setting should not be displayed", "Future Setting is not displayed", "Pass");

			}

			// Verify Audit log details
			boolean AuditlogCorrectValuesDisplayed = rfm.VerifyAuditLog_Entry(strOperation, strActivity,
					strExpectlevel[0]);

			if (AuditlogCorrectValuesDisplayed) {
				actions.reportCreatePASS("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation," + "ActivityValue,Level",
						"Correct values are displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation," + "ActivityValue,Level",
						"Correct values are not displayed", "Fail");
			}

			String AuditDesc = "Future Settings of Price Set " + strPriceSet + " has been deleted.";

			boolean isAuditlogCorrectValuesDisplayed = rfm.RFM_VerifyAuditLog_Details(strDBName, strUserID,
					strOperation, strActivity, strExpectlevel[1], strExpectLevelDetails[0], AuditDesc);

			if (isAuditlogCorrectValuesDisplayed) {
				actions.reportCreatePASS("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "Activities,Level & description ",
						"Correct values are displayed", "Pass");

			} else {
				actions.reportCreateFAIL("Validating the Audit Log Details",
						"Audit Log details Should display correct values for ID,Operation,"
								+ "Activities,Level & description ",
						"Correct values are not displayed", "Fail");
			}

			// --------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	/** TODO creating the set */
	public String fn_CreateSet(String strAddNewSetName, String strrestlocator, String strrest, String strCopyExisting,
			String WindowName, String PopWinName) {
		String strFeatureSetName = "";
		try {

			/** Click on New Set **/
			// Create Xpath
			String strXPath = "";
			strXPath = "//*[@class='button'][contains(text()," + "'" + strAddNewSetName + "')]";
			WebElement addNewSetButton = driver.findElement(By.xpath(strXPath));
			if (addNewSetButton != null) {
				actions.click(addNewSetButton);
			}

			/** -------Switch window to Add New Day Part Set---- **/
			mcd.SwitchToWindow(PopWinName);

			/** Set Value of Day part Set name and select name **/
			strFeatureSetName = mcd.GetTestData("DT_PREFIX") + "_" + RandomStringUtils.randomAlphabetic(5);
			actions.setValue("RFMAddNewSet.SetName", strFeatureSetName);
			actions.click("NewPriceSet.PromRadioBtn"); // slecting the
														// Promotional Set radio
														// btn
			actions.click("RFM.SBSelectNode");

			// Select Hierarchy from select window
			mcd.waitAndSwitch("Select Node");

			(new WebDriverWait(driver, 1800000)).until(
					ExpectedConditions.elementToBeClickable(By.xpath(actions.getLocator("SelectNode.SearchTextBox"))));

			// searching for the rest id
			actions.setValue("SelectNode.SearchTextBox", strrest);
			Thread.sleep(1000);
			actions.click("SelectARestaurant.SearchRest");
			strXPath = "//*[contains(text(),'" + strrest + "')]";
			(new WebDriverWait(driver, 1800000))
					.until(ExpectedConditions.visibilityOfAllElementsLocatedBy((By.xpath(strXPath))));
			mcd.Selectrestnode(strrestlocator, strrest);

			/** switching to new window */
			mcd.SwitchToWindow("$" + PopWinName);

			/** Selecting the Start & End Date */
			actions.click("NewPriceSet.StartDate");
			mcd.sel_current_date("NewPriceSet.StartDate", strApplicationDate);
			actions.click("NewPriceSet.EndDate");
			mcd.select_date("27", "next", "NewPriceSet.EndDate");

			/** Select Copy Existing **/
			if (strCopyExisting.equalsIgnoreCase("No")) {
				/** Click on Next **/
				actions.click("SelectNode.Next");
				mcd.waitAndSwitch("@" + WindowName);
			}
		} catch (Exception e) {
			System.out.println("Failed Test" + e.getMessage());
		}
		return strFeatureSetName;
	}
}
