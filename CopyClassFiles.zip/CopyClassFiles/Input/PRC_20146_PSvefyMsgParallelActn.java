/**
 * 
 */
package xtam.test;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
/**
 * @author akrani
 *
 */
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class PRC_20146_PSvefyMsgParallelActn {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;

	// TODO: Declare test-data variables for other data-parameters
	private String strAction, strPriceValue, strPriceSetNm, strResultMessage, strPopup, Err, ErrSplit[],
			strPopupSplit[];
	Integer intPricevalue = 0;

	public PRC_20146_PSvefyMsgParallelActn(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");

		// TODO: GetTestData for other data-parameters
		strAction = mcd.GetTestData("DT_ACTION");
		strPopup = mcd.GetTestData("DT_POPUP");
		Err = mcd.GetTestData("DT_ERROR");

	}

	@Test
	public void test_PRC_20146_PSvefyMsgParallelActn() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription(
					"Verify that appropriate message is displayed on Price Set when future setting is deleted from one session and updated in Futures Changes by Menu Item tab through other session.");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// Click on search button for displaying all records of price sets
			actions.keyboardEnter("SetAssignmentReport.SearchButton");
			actions.smartWait(180);
			int rc = mcd.GetTableRowCount("FieldPermissions.Table");
			if (rc > 0) {
				actions.reportCreatePASS("Verify all records", "All record should be display",
						"All records are displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verify all records", "All record should be display",
						"All records are displayed", "FAIL");

			}

			// Taking price set name and click on future change by menu item
			String priceset_Name = driver.findElement(By.xpath(actions.getLocator("MasterMenuItemList.NumberLink")))
					.getText();
			WebElement ElementPriceSetNm = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1, "Name", "a");
			actions.keyboardEnter(ElementPriceSetNm);
			actions.WaitForElementPresent("PriceSets.SBFutureChngMITab", 180);

			//Verifying  Number of future settings for price set
			List<WebElement> FutDates = driver.findElements(By.xpath(actions.getLocator("PriceSets.SBFutureSetting")));
			// Creating future date if not present
			if (FutDates.size() < 2) {
				mcd.SelectDate_OpenCalender("10", "next");
				// mcd.smartsync(180);
				actions.smartWait(180);
				// Enter future price setting
				actions.WaitForElementPresent("ManagePS.AllPrice", 120);
				actions.clear("ManagePS.AllPrice");
				actions.setValue("ManagePS.AllPrice", "10");
				actions.click("AddTenderType.ApplyButton");
				Thread.sleep(2000);
				try {
					if (mcd.GetGlobalData("Instance").trim().toLowerCase().contains("us")) {
						actions.click("FutureSettings.Apply");

						driver.switchTo().alert().accept();
					} else {
						actions.keyboardEnter("DimensionGroup.SaveButton");
					}
				} catch (Exception e1) {
				}
				// mcd.smartsync(120);
				actions.smartWait(180);
			} else {
				actions.click(FutDates.get(1));
				// mcd.smartsync(180);
				actions.smartWait(180);
			}

			actions.keyboardEnter("PriceSets.SBFutureChngMITab");
			actions.smartWait(180);
			Thread.sleep(1000);
			int price = mcd.fn_GetRndNumInRange(1, 10);
			if (actions.isElementPresent("ManageMenuItemPriceSet.PlusButton")) {
				actions.click("ManageMenuItemPriceSet.PlusButton");
			}

			// Changing prices in text boxs and click on save button
			actions.clear("ManageMenuItemPriceSet.Eatin");
			actions.setValue("ManageMenuItemPriceSet.Eatin", price);
			actions.keyboardEnter("PromotionMgmt.ApplyButton");
			actions.smartWait(180);
			actions.verifyTextPresence("Your changes have been saved.", true);
			actions.keyboardEnter("RFM.CancelBtn");
			actions.smartWait(180);

			// Searching for same price set which is having future settings
			actions.clear("ProductionRouting.SearchTextField");
			actions.setValue("ProductionRouting.SearchTextField", priceset_Name);
			actions.keyboardEnter("SetAssignmentReport.SearchButton");
			actions.smartWait(180);
			actions.keyboardEnter("MasterMenuItemList.NumberLink");
			actions.smartWait(180);

			driver.findElement(By.xpath("//*[@id='futureEffectiveDate']//option[2]")).click();

			actions.smartWait(180);

			// Click on delete all changes button
			actions.keyboardEnter("PriceSets.DeleteAllChangesButton");
			boolean mesg = mcd.VerifyAlertMessageDisplayed("Warning",
					"Are you sure you want to delete all future changes of the menu item?", true,
					AlertPopupButton.OK_BUTTON);
			if (mesg) {
				actions.reportCreatePASS("Verifying pop up message", "Pop up message should display",
						"Pop up message is displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Verifying pop up message", "Pop up message should display",
						"Pop up message is NOT displayed", "FAIL");

			}
			actions.smartWait(180);
			actions.verifyTextPresence("Delete has been successfully completed.", true);

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}

	public void Get_future_date(int x, String Calender_Type, String app_date) {
		// adding the calendar instance
		Calendar Date = Calendar.getInstance();
		// creating the date format constructor
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		Date.add(Calendar.DAY_OF_MONTH, x); //// ==adding the number of days in
											//// current app date
		String date = formatter.format(Date.getTime());

		// Converting application current date to date format
		app_date = mcd.DateFormatter(app_date);
		// ----- Added to Handle US Market ----END-----

		String[] future_date = (date).split("/");
		String[] curr_date = (app_date).split("/");
		// comparing the month of the current date and future date to be set

		String MyNewDate = future_date[0] + "/" + future_date[1] + "/" + future_date[2].substring(0, 4);
		System.out.println(MyNewDate);
		System.out.println(
				"selecting the date" + future_date[0] + "/" + future_date[1] + "/" + future_date[2].substring(0, 4));
		Select_SpecificDate(MyNewDate, Calender_Type);
	}

	public void Select_SpecificDate(String DateToSelect, String Calender_Type) {

		String DateDisplayed = null;
		if (Calender_Type.trim().equalsIgnoreCase("close")) {
			WebElement datepicker = null;
			// get the date picker from available matching elements
			List<WebElement> num_datepickers = driver.findElements(By.className("datepicker"));
			for (int a = 0; a < num_datepickers.size(); a++) {
				String is_visible = num_datepickers.get(a).getAttribute("style");
				if (is_visible.contains("visible")) {
					datepicker = num_datepickers.get(a);
					break;
				}
			}
			// set the navigators on datepicker pop up
			WebElement MnthName = datepicker.findElement(By.className("datepickerMonth"));
			DateDisplayed = MnthName.findElement(By.xpath(".//a")).getText();
		} else if (Calender_Type.trim().equalsIgnoreCase("open")) {
			DateDisplayed = driver.findElement(By.xpath("//*[@class = 'datepicker']//th[@class = 'datepickerMonth']/a"))
					.getText();
		} else {
			System.out.println("Enter correct calender type");
		}

		String MnthDisplayed = DateDisplayed.split(",")[0].trim();
		String YearDisplayed = DateDisplayed.split(",")[1].trim();
		int iFromYear = Integer.parseInt(YearDisplayed);
		int iFromMnth = 0;
		System.out.println(MnthDisplayed);

		String Arr_Mnth[] = { "January", "February", "March", "April", "May", "June", "July", "August", "September",
				"October", "November", "December" };

		// Get mnth number for FromDate:
		for (int i = 0; i < Arr_Mnth.length; i++) {
			if ((Arr_Mnth[i].equalsIgnoreCase(MnthDisplayed))) {
				iFromMnth = i + 1;
				break;
			}
		}

		// DateToSelect = "25/08/2015";

		String go_toDt = DateToSelect.split("/")[0].trim();

		int go_Mnth = Integer.parseInt(DateToSelect.split("/")[1].trim());
		String go_Mnth_name = Arr_Mnth[go_Mnth - 1];

		int iTo_Year = Integer.parseInt(DateToSelect.split("/")[2].trim());
		int Yr_Flag = 0;
		int Mnth_Flag = 0;
		String strDirection = null;
		if (iFromYear == iTo_Year) {
			Yr_Flag = 0;
			if (iFromMnth == go_Mnth) {
				strDirection = "current";
			} else if (iFromMnth < go_Mnth) {
				strDirection = "next";
			} else {
				strDirection = "previous";
			}

		} else if (iFromYear < iTo_Year) {
			Yr_Flag = 1;
			strDirection = "next";
		} else {
			Yr_Flag = -1;
			strDirection = "previous";
		}

		WebElement datepicker = null;

		// getting the date picker from available matching elements
		List<WebElement> num_datepickers = driver.findElements(By.xpath("//*[@class='datepicker']"));
		for (int a = 0; a < num_datepickers.size(); a++) {

			String is_visible = num_datepickers.get(a).getAttribute("style");
			datepicker = num_datepickers.get(a);
			break;
		}
		// setting the navigators on datepicker pop up
		WebElement go_next = datepicker.findElement(By.className("datepickerGoNext"));
		WebElement go_next_link = go_next.findElement(By.xpath(".//a")); // go
																			// next
																			// link
		WebElement go_prev = datepicker.findElement(By.className("datepickerGoPrev"));
		WebElement go_prev_link = go_prev.findElement(By.xpath(".//a")); // go
																			// to
																			// prev
																			// link

		Boolean chk1 = false;
		Boolean chk2 = false;
		do {

			if (strDirection.equals("next")) {
				go_next_link.click();
				// Reporter.log("Clicking on the Next month");
			} else if (strDirection.equals("previous")) {
				go_prev_link.click();
				// Reporter.log("Clicking on the prev month");
			} else {
				System.out.println("Need to select date from current month");
			}

			String New_Mnth = null;

			if (Calender_Type.trim().equalsIgnoreCase("close")) {
				datepicker = null;
				// get the date picker from available matching elements
				num_datepickers = driver.findElements(By.className("datepicker"));
				for (int a = 0; a < num_datepickers.size(); a++) {
					String is_visible = num_datepickers.get(a).getAttribute("style");
					if (is_visible.contains("visible")) {
						datepicker = num_datepickers.get(a);
						break;
					}
				}
				// set the navigators on datepicker pop up
				WebElement New_MnthName = datepicker.findElement(By.className("datepickerMonth"));
				New_Mnth = New_MnthName.findElement(By.xpath(".//a")).getText();
			} else if (Calender_Type.trim().equalsIgnoreCase("open")) {
				New_Mnth = driver.findElement(By.xpath("//*[@class = 'datepicker']//th[@class = 'datepickerMonth']/a"))
						.getText();
			} else {
				System.out.println("Enter correct calender type");
			}

			System.out.println(New_Mnth);
			MnthDisplayed = New_Mnth.split(",")[0].trim();
			YearDisplayed = New_Mnth.split(",")[1].trim();
			iFromYear = Integer.parseInt(YearDisplayed);
			chk1 = MnthDisplayed.equalsIgnoreCase(go_Mnth_name);
			chk2 = (iFromYear == iTo_Year);
		} while (!((chk1) && (chk2)));

		if (Calender_Type.trim().equalsIgnoreCase("open")) {
			mcd.SelectDate_OpenCalender(go_toDt, "current");
		} else if (Calender_Type.trim().equalsIgnoreCase("close")) {
			mcd.select_date(go_toDt, "current");
		}
	}

}
