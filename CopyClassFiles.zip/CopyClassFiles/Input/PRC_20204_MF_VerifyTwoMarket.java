package xtam.test;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.Pricing;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_MCD.AlertPopupButton;
import crossbrowser.library.lib_RFM2;

public class PRC_20204_MF_VerifyTwoMarket {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private Pricing PriceActions;

	private String strApplicationDate;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;
	// TODO: Declare test-data variables for other data-parameters

	private String strNamePrefix;
	private String strFeeType;
	private String strSuccessMsg;
	private String strPriceVal;
	private String strTaxCode;
	private String strTaxRule;
	private String[] strFutureSetFlag;
	private String[] strStatus;
	private String strMarket2;
	private String strUpdateMsg;
	private String strWarningMsg;
	private String strDeleteMsg;

	public PRC_20204_MF_VerifyTwoMarket(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		PriceActions = new Pricing(driver, actions, uiActions, input, mcd, rfm, or);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
		// TODO: GetTestData for other data-parameters

		strNamePrefix = mcd.GetTestData("NAME_PREFIX");
		strFeeType = mcd.GetTestData("FEE_TYPE");
		strSuccessMsg = mcd.GetTestData("SUCCESS_MSG");
		strPriceVal = mcd.GetTestData("PRICE_VAL");
		strFutureSetFlag = mcd.GetTestData("FUTURE_FLAG").split("#");
		strTaxCode = mcd.GetTestData("TAX_CODE");
		strTaxRule = mcd.GetTestData("TAX_RULE");
		strStatus = mcd.GetTestData("STATUS").split("#");
		strMarket2 = mcd.GetTestData("DT_MARKET2");
		strWarningMsg = mcd.GetTestData("WARNING_MSG");
		strDeleteMsg = mcd.GetTestData("DELETE_MSG");
	}

	@Test
	public void PRC_20204_MF_VerifyTwoMarket() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			actions.setTestcaseDescription(
					"Verify that when two markets are having fee with same name then deleting fee from first market doesn�t delete it from other market");

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			/** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();

			// ------------------------------------------------------------------------
			// Now in Market 1 & Create a New Fee
			String strInactiveFeeMarket1 = PriceActions.RFM_PRC_CreateFee(strNamePrefix, strFeeType, strSuccessMsg,
					strPriceVal, strTaxCode, strTaxRule, strFutureSetFlag[0].trim(), strApplicationDate,
					strStatus[1].trim());
			System.out.println("strActiveFeeName : " + strInactiveFeeMarket1);

			// Navigate to Home page & Change the Market
			actions.select_menu("RFMHomePage.MainMenu", "HOME");
			mcd.SwitchToWindow("#Title");
			actions.keyboardEnter("RFMHome.ChangeMarket");
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket2);
			
			/** Navigate to Master Fee */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(5000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			// Create a New Fee & Search for newly created Fee
			String strInactiveFeeMarket2 = PriceActions.RFM_PRC_CreateFee(strNamePrefix, strFeeType, strSuccessMsg,
					strPriceVal, strTaxCode, strTaxRule, strFutureSetFlag[0].trim(), strApplicationDate,
					strStatus[1].trim());
			System.out.println("strActiveFeeName : " + strInactiveFeeMarket2);
			actions.clear("MasterFee.SearchBox");
			actions.setValue("MasterFee.SearchBox", strInactiveFeeMarket2);
			actions.click("RFM.SearchBtn");
			actions.smartWait(120);

			// Click on the 1st Fee & Update it with the same name as Fee from
			// Market 1
			WebElement eleFeeName = mcd.GetTableCellElement("RFM.WebTable", 1, "Fee Name", "a");
			eleFeeName.click();
			actions.smartWait(20);
			actions.clear("MasterFee.FeeName");
			actions.setValue("MasterFee.FeeName", strInactiveFeeMarket1);
			actions.click("RFM.Apply");
			actions.smartWait(20);
			actions.click("RFM.CancelBtn");
			actions.smartWait(20);

			// Delete this fee from Market 2 & click Search
			actions.clear("MasterFee.SearchBox");
			actions.setValue("MasterFee.SearchBox", strInactiveFeeMarket1);
			actions.click("RFM.SearchBtn");
			actions.smartWait(120);

			// Click on the 1st Fee & Verify Waring Message
			WebElement eleFeeDeleteIcon = mcd.GetTableCellElement("RFM.WebTable", 1, "Delete", "a");
			eleFeeDeleteIcon.click();
			Boolean VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Warning", strWarningMsg, true,
					AlertPopupButton.OK_BUTTON);
			if (VerifyPopUpMsg) {
				actions.reportCreatePASS("Verify warning message before deleting Fee",
						"Correct Warning messaged should be given", "Correct Warning messaged given", "PASS");
			} else {
				actions.reportCreateFAIL("Verify warning message before deleting Fee",
						"Correct Warning messaged should be given", "Correct Warning messaged not given", "FAIL");
			}

			actions.verifyTextPresence(strDeleteMsg, false);
			actions.reportCreatePASS("Verify delete Fee", "Fee should be deleted", "Fee deleted successfully", "PASS");

			// Navigate to Home page
			actions.select_menu("RFMHomePage.MainMenu", "HOME");
			mcd.SwitchToWindow("#Title");

			// Change the market again to Market 1
			actions.keyboardEnter("RFMHome.ChangeMarket");
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Navigate to Master Fee */
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(5000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			// Search for Fee & Delete this fee from Market 2
			actions.clear("MasterFee.SearchBox");
			actions.setValue("MasterFee.SearchBox", strInactiveFeeMarket1);
			actions.click("RFM.SearchBtn");
			actions.smartWait(120);

			// Click on the 1st Fee & Verify Required fee should display in
			// result grid
			WebElement eleFee = mcd.GetTableCellElement("RFM.WebTable", 1, "Fee Name", "a");
			if (eleFee.getText().trim().equalsIgnoreCase(strInactiveFeeMarket1.trim())) {
				actions.reportCreatePASS("Verify Master Fee in 2 markets",
						"Fee deleted from one market should not delete from 2nd market",
						"Fee deleted from one market not delete from 2nd market", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Master Fee in 2 markets",
						"Fee deleted from one market should not delete from 2nd market",
						"Fee deleted from one market deleted from 2nd market", "FAIL");
			}

			// ------------------------------------------------------------------------

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {

			// reporting the Fail condition
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());

		}
	}
}