package assessment;

import java.util.Scanner;

public class Question2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter�First integer");
		int int1=sc.nextInt();
		System.out.println("Enter�Second integer");
		int int2=sc.nextInt();
		System.out.println("Enter�Operation To Perform");
		String op=sc.next();
		sc.close();
		
		int res = 0;
		switch(op) {
		case "+" :
			res=int1+int2;
			break;
		case "-" :
			res=int1-int2;
			break;
		case "*" :
			res=int1*int2;
			break;
		case "/" :
			res=int1/int2;
			break;
		default :
			System.out.println("Invalid Operator");
		}
		
		System.out.println(int1+op+int2+"="+ res);

	}

}
