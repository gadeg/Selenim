package assessment;


class Class1{
	public String concatTwoStrings(String s1, String s2){
		return s1.concat(s2);
	}
}

class Class2 extends Class1{
	public String concatTwoStrings(String s1, String s2){
		return s1.concat(s2);
	}
	public int logicalAND(int i1, int i2){
		return i1 & i2;
	}
}

public class Question1 {

	public static void main(String[] args) {
		Class2 c2Obj = new Class2();
		System.out.println(c2Obj.concatTwoStrings("Hello", "World"));
		System.out.println(c2Obj.logicalAND(12, 7));
	}

}
