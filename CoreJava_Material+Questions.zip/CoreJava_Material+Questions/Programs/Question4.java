package assessment;

import java.util.ArrayList;
import java.util.Iterator;


class Employee{
	String empName = "";
	int empId = 0;
	int empContactNumber = 0;

}
public class Question4 {

	public static void main(String[] args) {
		Employee emp1 = new Employee();
		emp1.empName = "Mahesh";
		emp1.empId = 1;
		emp1.empContactNumber = 11111;

		Employee emp2 = new Employee();
		emp2.empName = "Ramesh";
		emp2.empId = 2;
		emp2.empContactNumber = 22222;

		Employee emp3 = new Employee();
		emp3.empName = "Suresh";
		emp3.empId = 3;
		emp3.empContactNumber = 33333;

		Employee emp4 = new Employee();
		emp4.empName = "Naresh";
		emp4.empId = 4;
		emp4.empContactNumber = 44444;

		Employee emp5 = new Employee();
		emp5.empName = "Viresh";
		emp5.empId = 5;
		emp5.empContactNumber = 55555;

		ArrayList list = new ArrayList();
		list.add(emp1);
		list.add(emp2);
		list.add(emp3);
		list.add(emp4);
		list.add(emp5);


		//Traversing list through Iterator  
		Iterator itr=list.iterator();  
		while(itr.hasNext()){  
			Employee empObj ;
			empObj = (Employee)itr.next();
			System.out.println(empObj.empName);
			System.out.println(empObj.empId);
			System.out.println(empObj.empContactNumber);
		}  
	}

}
