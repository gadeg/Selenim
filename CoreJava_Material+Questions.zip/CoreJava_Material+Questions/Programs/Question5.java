package assessment;

import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;

public class Question5 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		TreeSet ts = new TreeSet();
		System.out.println("Enter�First integer");
		ts.add(sc.nextInt());
		System.out.println("Enter�Second integer");
		ts.add(sc.nextInt());
		System.out.println("Enter�Third integer");
		ts.add(sc.nextInt());
		System.out.println("Enter�Fourth integer");
		ts.add(sc.nextInt());
		System.out.println("Enter�Fifth integer");
		ts.add(sc.nextInt());
		sc.close();
		Iterator iter = ts.iterator();
		while(iter.hasNext()){
			System.out.println(ts.toString());
		}
	}

}
