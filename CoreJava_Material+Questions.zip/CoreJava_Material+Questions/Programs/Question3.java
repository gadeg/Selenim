package assessment;

public class Question3 {

	public static void main(String[] args) {
		int[] intArr = new int[10];
		intArr[0] = 0;
		intArr[1] = 1;
		intArr[2] = 2;
		intArr[3] = 3;
		intArr[4] = 4;
		intArr[5] = 5;
		intArr[6] = 6;
		intArr[7] = 7;
		intArr[8] = 8;
		intArr[9] = 9;
		System.out.println("Using Normal for statement");
		for(int i=0;i<10;i++){
			System.out.print(intArr[i]);
		}
		System.out.println("\nUsing Enhanced for statement");
		for (int i : intArr) {
			System.out.print(i);
		}
		
		
		String[] strArr = new String[]{"Mahesh","Ramesh","Naresh","Suresh","Viresh"};
		String output = "";
		for (String string : strArr) {
			output = output+string.charAt(0);
		}
		System.out.println("Final String is = "+output);
	}

}
