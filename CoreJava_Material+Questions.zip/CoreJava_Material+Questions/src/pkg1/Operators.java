package pkg1;

public class Operators {

	public static void main(String[] args) {
		System.out.println("***Arithmetic Operations***");

		int a = 20;
		int b = 10;

		//Increment Operator-Post increment
		int a1 = a++;
		System.out.println("(Increment Operator)Value of a = "+a);
		System.out.println("(Increment Operator)Value of a1 = "+a1);
		//Increment Operator-Pre increment
		int a2 = ++a;
		System.out.println("(Increment Operator)Value of a = "+a);
		System.out.println("(Increment Operator)Value of a1 = "+a2);




		a = 20;
		b = 10;
		int sum = a+b;
		System.out.println("(Addition Operator)Value of a+b = "+sum);
		//Addition Assignment Operator
		a += b;
		System.out.println("(Addition Assignment Operator)Value of a = "+a);




		System.out.println("***Bitwise Operations***");
		a = 60;	/* 60 = 0011 1100 */
		b = 13;	/* 13 = 0000 1101 */
		int c = 0;

		c = a & b;        /* 12 = 0000 1100 */
		System.out.println("a & b = " + c );
		
		a = 1;
		b = 0;
		System.out.println(a^a);
		
		
		
		StringBuffer sb = new StringBuffer("Hello");
		sb.append("123");
		System.out.println(sb);
		
	}

}
