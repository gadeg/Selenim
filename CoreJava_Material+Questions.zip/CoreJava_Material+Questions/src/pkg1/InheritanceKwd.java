package pkg1;

public class InheritanceKwd {

	public static void main(String[] args) {
		System.out.println("Program starts here");
		
		String str1 = new String("Welcome");
		System.out.println(str1 instanceof String);
	}

}
