package pkg1;

public class Variables {
	//Instance Variable
	int instanceField = 1;

	//Static or Class Variable
	static String staticField = "Welcome";
	
	void display(){
		//Local Variable
		boolean localVariable = true;
		System.out.println("Value of local variable: "+localVariable);
		
		System.out.println("Value of instance variable: "+instanceField);
		instanceField = 2;
		System.out.println("Value of instance variable: "+instanceField);
		
		System.out.println("Value of static variable: "+staticField);
		staticField = "Hello";
		System.out.println("Value of static variable: "+staticField);
	}
	
	
	public static void main(String[] args) {
		Variables var = new Variables();
		var.display();
	}
}
