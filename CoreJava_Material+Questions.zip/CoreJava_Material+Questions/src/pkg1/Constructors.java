package pkg1;

public class Constructors {
	
	private static String firstName;
	private static String lastName;
	private static int id;
	//Default Constructor
	Constructors(){
		System.out.println("Default constructor has been called");
	}
	
	//Parameterized Constructor
	Constructors(int custId){
		System.out.println("Constructor with Int Argument is called");
		this.id = custId;
	}
	Constructors(String fn, String ln){
		System.out.println("Constructor with Two String Arguments is called");
		this.firstName = fn;
		this.lastName = ln;
	}
	public static void main(String[] args) {
		System.out.println("Program Starts here");
		
		Constructors c1 = new Constructors(110256);
		System.out.println(c1.id);
		
		Constructors c2 = new Constructors("Mahesh","L");
		System.out.println(c2.firstName+" "+c2.lastName);
		System.out.println("Program Ends here");
	}

}
