package pkg1;






public class Abstraction1 {



	public static void main(String[] args) {
		abstract class Animal
		{
			abstract void soundOfAnimal();  // It is just an idea
			void belongTo() {
				System.out.println("I belong to Animal Family");
			}
		}

		class Dog extends Animal
		{
			void soundOfAnimal()
			{
				System.out.println("Bow Bow");
				//Implementation of the idea according to requirements of sub class
			}
			void barking()
			{
				System.out.println("I can bark Very loud");
			}
		}
		class Snake extends Animal
		{
			void soundOfAnimal()
			{
				System.out.println("Hiss Hiss");
				//Implementation of the idea according to requirements of sub class
			}
			void barking()
			{
				System.out.println("I do not bark");
			}
			Integer averageLength(){
				return 5;
			}
		}
		
		
		Dog dog = new Dog();
		Snake snake = new Snake();

		dog.soundOfAnimal();
		dog.barking();
		snake.soundOfAnimal();
		snake.barking();
		System.out.println(snake.averageLength()+"ft");
		dog.belongTo();
		snake.belongTo();
	}
}
