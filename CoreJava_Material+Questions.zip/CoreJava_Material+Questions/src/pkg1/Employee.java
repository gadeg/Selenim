package pkg1;


class Person {
	String name = "Mahesh";
	String proffession = "Agriculture";
	public void showName(){
		System.out.println("I am in Super Class: "+name);
	}
	public void maritalStatus(){
		System.out.println("I am in Super Class: UNMARRIED");
	}
}
class Employee extends Person {
	
	Employee(){
		this.proffession = "IT Sector";
	}
	public void displayName(){
		System.out.println("I am in Sub Class: "+name);
	}
	public static void main(String[] args) {
		Employee emp1 = new Employee();
		emp1.displayName();
		emp1.showName();
		emp1.maritalStatus();
		System.out.println(emp1.proffession);
	}

}
