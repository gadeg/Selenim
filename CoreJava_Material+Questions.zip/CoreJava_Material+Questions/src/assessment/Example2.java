package assessment;

import java.util.*;


public class Example2 {

	static int a = 5;
	static {
		a = a-- * --a;
	}
	public static void main(String[] args) {
		System.out.println(a);
	}


}
