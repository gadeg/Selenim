package assessment;

import java.util.Scanner;

public class Example1 {
	public static void main(String[] args) {
		/*Scanner sc = new Scanner(System.in);
		System.out.println("Enter�First Integer");
		int int1=sc.nextInt();
		System.out.println("Enter�Second Integer");
		int int2=sc.nextInt();
		System.out.println("Enter�Operation to be performed");
		String op=sc.next();
		sc.close();
		
		float res = 0 ;
		switch(op) {
		case "+" :
			res = int1 + int2; 
			break;
		case "-" :
			res = int1 - int2;
			break;
		case "*" :
			res = int1 * int2;
			break;
		case "/" :
			res = int1 / int2;
			break;
		default :
			System.out.println("Invalid grade");
		}
		System.out.println(int1+op+int2+"=" + res);*/
		
		
		String str = "H";
		str = str.concat("E");
		System.out.println(str);
				
		
	}
}
