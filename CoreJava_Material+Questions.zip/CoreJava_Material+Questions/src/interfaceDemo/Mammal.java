package interfaceDemo;

public class Mammal implements Animal, Huge {
	public void eat() {
		System.out.println("Mammal Eats");
	}
	public void travel() {
		System.out.println("Mammal Travel");
	}
	public int noOfLegs() {
		return 0;
	}
	public String size() {
		return "Mammals are huge";
	}
	
	public static void main(String[] args) {
		Mammal m = new Mammal();
		System.out.println(m.name);
		System.out.println(m.noOfLegs());
		System.out.println(m.size());
	}


}
