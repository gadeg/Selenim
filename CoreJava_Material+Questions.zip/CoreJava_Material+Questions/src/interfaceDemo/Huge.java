package interfaceDemo;

interface Huge {
	public String size();
}
