package interfaceDemo;

interface Animal {
	public String name = "Whale";
	public void eat();
	public void travel();
}
