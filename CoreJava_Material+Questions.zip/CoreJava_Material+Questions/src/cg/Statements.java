package cg;

public class Statements {

	public static void main(String[] args) {


		/*//Conditional Statement
		int x = 30;
		if( x == 10 ) {
			System.out.println("Value of X is 10");
		}else if( x == 20 ) {
			System.out.println("Value of X is 20");
		}else if( x == 30 ) {
			System.out.println("Value of X is 30");
		}else {
			System.out.println("This is else statement");
		}*/


		/*//Switch Case
		char rating = '1';
		switch(rating) {
		case '1' :
			System.out.println("OutStanding"); 
			break;
		case '2' :
			System.out.println("Exceeds Expectation");
			break;
		case '3' :
			System.out.println("Meets Expectation");
			break;
		case '4' :
			System.out.println("Needs Improvement");
			break;
		case '5' :
			System.out.println("PIP");
			break;
		default :
			System.out.println("Invalid grade");
		}
		System.out.println("Your Rating is " + rating);*/

		/*//While loop
		int x = 10;
		while( x < 20 ) {
			System.out.print("value of x : " + x );
			x++;
			System.out.print("\n");
		}*/

		/*//for loop
		for(int x = 10; x < 20; x = x + 1) {
			System.out.print("value of x : " + x );
			System.out.print("\n");
		}*/

		//do-while loop
		int x = 10;
		do {
			System.out.print("value of x : " + x );
			x++;
			System.out.print("\n");
		}while( x < 20 );
	}

}
