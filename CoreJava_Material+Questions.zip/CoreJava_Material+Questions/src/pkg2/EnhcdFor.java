package pkg2;

import java.util.ArrayList;

public class EnhcdFor {

	public static void main(String[] args) {
		
		int[] arr1 = {1,2,3,4};
		
		int[] arr2 = new int[]{5,6,7,8};
		
		int[] arr3 = new int[3];
		arr3[0] = 9;
		arr3[1] = 10;
		arr3[2] = 11;
		
		for(int a : arr1){
			System.out.println(a);
		}
		
	}
}
