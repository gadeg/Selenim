package pkg2;

import java.util.*;  
class TestCollection1{  
 public static void main(String args[]){  
  ArrayList<String> list=new ArrayList<String>();//Creating arraylist  
  list.add("Mahesh");//Adding object in arraylist  
  list.add("Ramesh");  
  list.add("Suresh");  
  list.add("Naresh");  
  
  //Traversing list through Iterator  
  Iterator itr=list.iterator();  
  while(itr.hasNext()){  
   System.out.println(itr.next());  
  }
  
  
  
  
  
 }  
	
	
} 
