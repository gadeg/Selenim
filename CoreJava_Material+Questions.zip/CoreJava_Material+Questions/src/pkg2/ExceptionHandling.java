package pkg2;



public class ExceptionHandling {

	private static float divideTwoIntegers(int a, int b){
		float res = 0;
		try {
			res = a/b;
			System.out.println(res);
		}catch(ArithmeticException e){
			System.out.println("Caught Divide-By-Zero Exception");
		}finally {
			System.out.println("Finally block is called");
		}
		return res;
	}

	public static void main(String[] args) {
		divideTwoIntegers(90, 10);
		divideTwoIntegers(90, 0);
	}
}
