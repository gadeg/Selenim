package pkg2;

import java.io.FileInputStream;
import java.io.FileOutputStream; 

public class FileIOStream {

	public static void main(String args[]){    
		/*try{    
			FileOutputStream fout=new FileOutputStream("D:\\Mahesh\\junkFile.txt");    
			fout.write(65);    
			fout.close();    
			System.out.println("File write success");    
		}catch(Exception e){
			System.out.println(e);
		} */  


		try{    
			FileInputStream fin=new FileInputStream("D:\\Mahesh\\junkFile.txt");    
			int i=fin.read();  
			System.out.println((char)i);    
			fin.close();  
			System.out.println("File Read success");   
		}catch(Exception e){
			System.out.println(e);
		}    
		
		
		
	}    
}

