package pkg2;


class Employee  {
	public void setSalary() {
		System.out.println("Inside method:- setSalary()");
		throw new ArrayIndexOutOfBoundsException("ArrayIndexOutOfBounds Exception Occurred");
	}
	public void noOfEmployees() throws  ArithmeticException{
		System.out.println("Inside method:- noOfEmployees()");
		
		int result = 1/0;
	}
}

public class ExceptionThrows {

	public static void main(String[] args)  {
		Employee emp1 = new Employee();
		
		try {
			emp1.noOfEmployees();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		emp1.setSalary();

	}

}
