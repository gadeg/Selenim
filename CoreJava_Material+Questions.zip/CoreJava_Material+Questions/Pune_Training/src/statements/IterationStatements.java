package statements;

public class IterationStatements {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//label
		outer: for (int i = 0; i < 10; i++) {
			System.out.println("In for loop " + i);
			if(i==5){
				continue;
			}
			System.out.println("In for loop after continue " + i);
			// ===============nested loop======================///
			/*for (int j = 100; j < 105; j++) {
				System.out.println("In nested for loop " + j);
				if (i == 5) {
//					 break;
					break outer;
				}

			}*/
			// ===============nested loop======================///

		}

	}
	
/*		int i = 0;
	while(i < 10){
//		while(i<2){
//			nested while loop
//		}
		System.out.println("In while loop "+i);
		i++;
		
	}
	
	do{
		System.out.println("In do while loop "+i);
		
	}while(i<12);
	
	
	
	
	}*/
	

}
