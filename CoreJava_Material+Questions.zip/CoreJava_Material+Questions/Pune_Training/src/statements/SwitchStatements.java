package statements;

public class SwitchStatements {
	static int i = 0;

	public static void main(String args[]) {
		switch (i) {

		case 0:
///////////////=====nested switch case=====================////////////////
			switch (i) {

			case 1:
				System.out.println("I am in nested case 1");
				break;
			case 2:
				System.out.println("I am in nested case 2");
				break;
			case 3:
				System.out.println("I am in nested  case 3");
				break;
			default:
				System.out.println("I am in nested case default");
			}
///////////////=====nested switch case=====================////////////////
			System.out.println("I am in case 0");
			break;
		case 1:
			System.out.println("I am in case 1");
			break;
		case 2:
			System.out.println("I am in case 2");
			break;
		case 3:
			System.out.println("I am in case 3");
			break;
		default:
			System.out.println("I am in case default");
		}

	}

}
