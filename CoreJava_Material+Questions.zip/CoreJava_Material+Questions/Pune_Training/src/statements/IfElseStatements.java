package statements;

public class IfElseStatements {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 0, j = 10;
		/*if-else ladder
		 * if (conition) {

		} else if (condition) {

		}*/
		if (i == 0) {
			/*Nested if-else ladder
			 * if (conition) {

			} else if (condition) {

			}*/
			System.out.println("In first if block");
			System.out.println("In first if block");
			System.out.println("In first if block");
		} else if (i == j) {
			if (j == 10) {

			} else if (true) {

			}
			System.out.println("In first else if block");

		} else {
			if (j == 10) {

			} else if (true) {

			}
			System.out.println("In final else block");
		}

		System.out.println("Outside all blocks");

	}

}
