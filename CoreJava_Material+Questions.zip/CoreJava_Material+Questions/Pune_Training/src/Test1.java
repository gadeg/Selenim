
public class Test1 {

	static int count = 0;

	public Test1() {
		System.out.println("In constructor");
		count++;

	}

	// *************static blocks***********************//
	static {

		System.out.println("I am in static 2");

	}
	static {
		System.out.println("I am in static");
	}
	// *************instance blocks***********************//
	{
		System.out.println("In am in instance block 1");

	}
	{
		System.out.println("In am in instance block 2");

	}

	public static void main(String args[]) {
		System.out.println("I am in main");
		/*
		 * AccessModifiers access=new AccessModifiers(4); AccessModifiers
		 * access1=new AccessModifiers(4);
		 */
		// access=access1;
		Test1 test = new Test1();
		Test1 test1 = new Test1();
		Test1 test2 = new Test1();
		System.out.println(count);
		// test();

	}

	public static void test() {

		/*
		 * AccessModifiers access=new AccessModifiers(4); AccessModifiers
		 * access1=new AccessModifiers(4);
		 */
		// access=access1;
		Test1 test = new Test1();
		Test1 test1 = new Test1();
		Test1 test2 = new Test1();
		System.out.println(count);

	}

}
