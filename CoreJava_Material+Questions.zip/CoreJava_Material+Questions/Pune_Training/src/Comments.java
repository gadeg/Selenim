
public class Comments {

	public static void main(String args[]){
		
	//	System.out.println("Multi Line Comments");
		/*multi line comments
		 * System.out.println("Multi Line Comments");
		 * System.out.println("Multi Line Comments");
		 * 
		 */
		//single line commnts
		
	}
	
	
}
