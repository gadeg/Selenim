
public class HelloWorld {
	
	/**
	 * Simple Program
	 * @param args
	 */

	
	public static void main(String[] args){
		
		System.out.println("Hello World1!!");
		System.out.println("Hello World2!!");
		System.out.println("Hello World3!!");
		System.out.println("Hello World4!!");
		System.out.println("Hello World5!!");
		System.out.println("Hello World6!!");
		System.out.println("Hello World!!"+args[0]);
	}
	
}
