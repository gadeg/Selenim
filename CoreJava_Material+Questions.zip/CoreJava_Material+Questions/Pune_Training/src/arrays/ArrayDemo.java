package arrays;

import java.util.Arrays;

public class ArrayDemo {

	public static void main(String[] args) {
		// *********Declaring arrays*********
		// datatype[] var;
		// datatype var[];
		// datatype []arr;
		// *********Instantiation************
		// var=new datatype[size];
		int[] arr = new int[4];
		arr[0] = 12;
		arr[1] = 34;
		arr[2] = 45;
		arr[3] = 6;
		System.out.println("Length" + arr.length);
		Arrays.sort(arr);
		display(arr);
		getClass(arr);
		int a[][] = { {1,2}, {2,3},{3,4}};
		int a1[] = { 2, 45, 34, 5 };
		int []arr1[] = new int[4][4];
		arr1[0][0]=1;
		arr1[0][1]=2;
		
		
	}

	public static void display(int[] arr) {
	/*	for (int i = 0; i < arr.length; i++) {

			System.out.println(arr[i]);

		}*/
		
		//for(datatype var_name:Collection/array){}
		for(int val:arr){
		//	System.out.println(val);
		
			System.out.println("Sorted Arr: "+val);
			
		}
	}
	public static void getClass(int[] arr) {
		System.out.println(arr.getClass());
		String s="try";
		System.out.println(s.getClass());
	/*	int s=12;
		Integer i=Integer.valueOf(s);//explicit conversion
		Integer j=s;//autoboxing
*/		
	}

}
