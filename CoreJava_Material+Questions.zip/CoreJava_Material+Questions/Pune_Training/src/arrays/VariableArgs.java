package arrays;

public class VariableArgs {

	public static void main(String[] args) {
		displayVarArgs(12, "Vaish");
		displayVarArgs(23, "Vaish", "KK");
		displayVarArgs(3, "Vaish", "ERTYJK", "tuui");
	//	displayVarArgs("shweta");

	}

	public static void displayVarArgs(int arg1, String... str) {
		System.out.println(str);
	}
	
	public static void displayVarArgs(long arg1, String str) {
		System.out.println("No varargs "+str);
	}

}
