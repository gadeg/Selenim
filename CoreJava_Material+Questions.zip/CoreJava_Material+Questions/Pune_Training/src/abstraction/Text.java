package abstraction;

public class Text implements Printable {


	@Override
	public void read() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void write() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void encode() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void decode() {
		// TODO Auto-generated method stub
		System.out.println("I am in decode");
	}
	
	@Override
	public void decode1() {
		// TODO Auto-generated method stub
		System.out.println("I am in decode");
	}

}
