package abstraction;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Animal animal=new Animal();--> complie time error..abstarct class can not be instantiated
		//*****Abstract class demo
		Animal d;
		d=new Pug();
		d.run();
		//*****interface demo
		Text t=new Text();
		t.decode();
		int j=t.i;
	//	t.i=67;
		

	}

}
