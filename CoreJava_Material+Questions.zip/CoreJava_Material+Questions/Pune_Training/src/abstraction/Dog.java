package abstraction;

abstract public class Dog extends Animal {
	
abstract public void createSound();
	

}
