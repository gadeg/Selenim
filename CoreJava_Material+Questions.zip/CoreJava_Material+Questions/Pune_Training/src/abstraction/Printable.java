package abstraction;

public interface Printable extends Printable1{

	public static final int i=1;
	
	abstract public void read();

	void write();

	void encode();

	void decode();

}

