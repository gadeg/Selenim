package abstraction;

public class Pug extends Dog{
	@Override
	protected void run() {
		// TODO Auto-generated method stub
		System.out.println("I am in Pug class");
	}

	@Override
	public void createSound() {
		// TODO Auto-generated method stub
		
	}


}
