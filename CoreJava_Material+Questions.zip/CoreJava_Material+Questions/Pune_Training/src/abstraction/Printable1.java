package abstraction;

public interface Printable1 {


	void decode1();
}
