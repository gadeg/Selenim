package abstraction;

abstract public class Animal {
	
	
	abstract protected void run();
	public void eat(){
		System.out.println("Eat method");
		
	}
	
	
	
	
	

}
