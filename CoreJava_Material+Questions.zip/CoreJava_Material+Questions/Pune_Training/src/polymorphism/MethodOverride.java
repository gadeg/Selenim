package polymorphism;

public class MethodOverride extends MethodOverload {
	int var1=40;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MethodOverride ovr = new MethodOverride();
		ovr.test();
		//int v=ovr.var;
	}

	public void test() {

		MethodOverload ovd=new MethodOverride();
		//ovd.displayMe("Mayank");
		int v=ovd.var1;
		System.out.println(v);
		
		
	}

	public String displayMe(String name) {
		System.out.println("I am overridden");
		return "Neha";
	}
	
	
	/*Compile time error - cannot override final methods
	 *  public String displayMe(int age) {
		return "Neha";
	}*/

}
