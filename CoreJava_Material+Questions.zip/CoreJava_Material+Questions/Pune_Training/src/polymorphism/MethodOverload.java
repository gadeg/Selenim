package polymorphism;

 public class MethodOverload {
	//final public class MethodOverload {-compile time error
	final int var=45;
	int var1=45;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public void displayMe() {
		long b=3;
		byte c=2;
		displayMe(b);
		displayMe(c);
		//displayMe(20,25);-Ambiguity in method overloading************

	}

	public String displayMe(String name) {
		return "Neha";
	}

	final public String displayMe(int age) {
		return "Neha";
	}
	
	public String displayMe(long age) {
		return "Neha";
	}
	/*Ambiguity in method overloading********************** complile time error
	 * public String displayMe(long age,int num) {
		return "Neha";
	}
	public String displayMe(int num,long age) {
		return "Nikita";
	}*/

	public void displayMe(String name, int age) {

	}

	public void displayMe(int age, String name) {

	}

	public void displayMe(String name, int age, String designation) {

	}
	/*
	 * public void displayMe(String name) { return "Neha"; }
	 */

}
