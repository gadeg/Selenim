package inheritance;

public class Developers extends Employee {

	static String name = "Neeti";
	static int age = 12;
	public int salary=36000;
	protected String designation="Senior analyst";
	
	
	public Developers(){
		//super();
		System.out.println("I am in developers constructors");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Developers dev = new Developers();
		dev.displayDetails(name, age);
	}

	public static void develop() {
		
		if(name instanceof String){
			
			System.out.println(true);
		}
		else
			System.out.println(false);

	}
	public void test() {

		System.out.println("I am in test method of developer class");

	}

}

