package inheritance;

public class Employee {
	
	
	public Employee(){
				System.out.println("I am in employee constructors");
	}

	
	public void displayDetails(String name,int age){
		
		System.out.println("Details are:"+name+" "+age);
		
	}
	
	
	 
	

}
