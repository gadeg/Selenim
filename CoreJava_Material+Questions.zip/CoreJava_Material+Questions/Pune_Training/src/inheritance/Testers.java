package inheritance;

class Testers extends Developers {

	public Testers() {
		super();
		System.out.println("I am in Testers constructor");
	}

	public void test() {
/*
		Testers test = new Testers();
		develop();
		test.displayDetails(name, age);
		// test.test1();
*/
		super.test();
		int v=super.salary;
		System.out.println("I am in test method of testers class"+ v);
	
	}

	public static void main(String args[]) {
		Testers d = new Testers();
		d.develop();
		d.test();
		
		d.displayDetails(name, age);
		if (d instanceof Developers) {

			System.out.println("Developers check: " + true);
		} else {
			System.out.println("Developers check: " + false);
		}
		if (d instanceof Employee) {

			System.out.println("Testers check: " + true);
		} else {
			System.out.println("Testers check: " + false);
		}
	}

}