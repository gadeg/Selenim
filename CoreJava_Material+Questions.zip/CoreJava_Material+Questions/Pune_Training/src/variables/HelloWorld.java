package variables;



public class HelloWorld {

	/**
	 * Simple Program
	 * 
	 * @param args
	 */

	public static void main(String[] args) {

		VariableDemo var = new VariableDemo();
		Double d1 = var.d;
		System.out.println(d1);
		VariableDemo var1 = new VariableDemo();
		System.out.println(var1.str);

	}

}
