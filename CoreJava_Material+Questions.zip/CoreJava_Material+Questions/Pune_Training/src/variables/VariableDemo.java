package variables;

public class VariableDemo {

	int i = 12, j = 123, r;
	float f = 1.12f;
	double d = 2.4d;
	long l=45L;
	char c = 'd';
	boolean result = false;
	String str = "Datatypes";
	
	static int res=56;
	
	int t1,_ty,ty_76,y$,$e;
	
	
	public void varDemo(char myChar) {

		int test = 234234;
		System.out.println(test);
		int i = 0;
		r=(int) f;//down-casting in java-explicitly
		f=i;//upcasting=implicitly
		i=c;
		System.out.println(i);
		System.out.println(r);
		System.out.println(myChar);

	}

	public static void main(String[] args) {

		VariableDemo var = new VariableDemo();
		int test = 234234;
		var.varDemo('f');

	}

	/*
	 * Datatypes-primitive nonprimitive-classes,interfaces like String,Arrays
	 * 
	 * 
	 * Primitive-Boolean,Numeric
	 * 
	 */

}
