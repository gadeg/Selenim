
public class AccessModifiers {

	public int i = 435;
	private int r = 34;
	int rt = 67;
	static int count=0;
	static final int var=45;

	/*
	 * public AccessModifiers(){ System.out.println("Default constructor"); }
	 */
	//*********Constructor chaining************///Constructor overload
	public AccessModifiers(int i) {
		this("Neetigya");
		// this();-complie time error
		this.i = i;
		System.out.println("integer constructor" + i);
	}

	public AccessModifiers(String name) {
		this();
		System.out.println("string constructor" + i);
	}

	public AccessModifiers() {

		System.out.println("Default constructor" + i);
	}
	//*********Constructor chaining************///
	private int displaYme() {
		return i;

	}

	public void calculateMe() {
			Test1.test();
			//var=23;
			
	}

	void defaultAccess() {
		display("two");//compiler appends this.display("two")

	}

	public int display(String count) {
		return i;

	}

	public int display() {
		return i;

	}

}
