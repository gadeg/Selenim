
public class OperatorsDemo {

	static int opr4,opr5;
	public static void main(String args[]) {

		int opr1 = 12, opr2 = 100, opr3=50,opr6=13;
		float f=12.12f;
		boolean result=true;
		System.out.println(opr1 + opr2);
		System.out.println(opr2 % opr1);
		System.out.println(opr2 / opr3);
		System.out.println(opr4++);
		System.out.println(opr4++);
		System.out.println(++opr4);
		System.out.println(opr3--);
		System.out.println(opr3--);
		System.out.println(--opr3);
		System.out.println(--f);
		System.out.println(opr5++ + opr5);
		//System.out.println(opr5++ + ++opr5);
		opr1+=1;//opr=opr+1;
		System.out.println(opr1);
		if(opr1==13||opr6==13){
			System.out.println(true);
		}
	System.out.println(!result);
	System.out.println(result?true:false);//ternary operator
	}
	

}
