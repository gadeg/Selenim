package collections;

import java.util.*;


public class ArrayListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LinkedList<Integer> arr = new LinkedList<Integer>();
		//arr.
		ArrayList<String> arr1 = new ArrayList<String>();
		arr1.add("Java");
		arr1.add("PHP");
		arr1.add("HTML");
		arr1.add("JS");
		arr1.add("JS");
		/*
		 * for (String str : arr1) {
		 * 
		 * System.out.println(str); }
		 */

		

		LinkedHashSet<String> arr2 = new LinkedHashSet<String>();
		arr2.add("CSS");
		arr2.add("Angular");
		arr2.add("HTML");
		arr2.add("JS");
		arr2.add("JS");
		//arr1.addAll(arr2);
		//arr1.removeAll(arr2);
		//arr1.retainAll(arr2);
		Iterator itr = arr1.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());

		}
	}
	
}
