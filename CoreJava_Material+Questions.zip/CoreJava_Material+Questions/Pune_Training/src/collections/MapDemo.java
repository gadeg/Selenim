package collections;

import java.util.*;

public class MapDemo {

	static Map<Integer, String> map = new LinkedHashMap<Integer, String>();

	public static void main(String args[]) {
		map.put(4, "abcd");
		map.put(56, "a");
		map.put(2, "ab");
		map.put(3, "abc");
	//	map.put(4, "abcde");//over write oldervalue;
		map.put(null, "er");
		map.put(null, "err");
		//map.isEmpty();
map.remove(56);
		for (Map.Entry m : map.entrySet()) {
			System.out.println(m.getKey()+ "value: "+m.getValue());

		}
	}

}
