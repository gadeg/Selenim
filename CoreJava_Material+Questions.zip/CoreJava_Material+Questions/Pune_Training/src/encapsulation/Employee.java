package encapsulation;

public class Employee {

	private String name;
	private int age;

	public Employee(String name, int age) {
		this.name = name;
		this.age = age;

	}

	public String getName() {
		return name;

	}

	public void setName(String name) {

	}

	public int getAge() {
		if(age>0){
			
			return age;
		}
		else{
					
			System.out.println("Enter valid age");
			return 0;
			
		}
	
		
		

	}

	public void setAge(int age) {
		this.age=age;
		

	}

}
