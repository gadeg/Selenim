package encapsulation;

public class AccessEmployee {
	
	
	public static void main(String args[]){
		Employee emp=new Employee("Mayank", 15);
		emp.setAge(-1);
	int age=	emp.getAge();
	System.out.println(age);
		
		
	}

}
