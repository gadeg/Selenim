package xtam.test;

import java.util.List;
import java.util.Map;

import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.GWCReusable;
import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;


public class GWC_Registration_009 {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();
	private GWCReusable gwc;
	public boolean osState;
	private String strURL;
	private String strDescription;
	
	

	
	public GWC_Registration_009 (WebDriver nodeDriver, Map inputData, Object or){
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver,or);
		uiActions = new UIValidations();
		gwc = new GWCReusable(driver,actions, uiActions, input);
		// Read input Test-Data
		strURL = gwc.GetTestData("DT_URL").toString();
		strDescription = input.get("DESCRIPTION").toString();
		// TODO: GetTestData for other data-parameters
		
	}
	
	@Test
	public void test_GWC_Registration_009() throws InterruptedException {
		try {
			System.out.println("******* Test execution starts *******");
			//To add description
			actions.setTestcaseDescription(strDescription);
			osState = gwc.osCheck();
			
			// to launch the application
			actions.launchApplication(strURL);
			
			//Wait for Register link to be visible
			if ((((RemoteWebDriver) driver).getCapabilities()
					.getPlatform().toString().equalsIgnoreCase(
							"ANDROID"))|| osState==true){
				gwc.navigationMobile("Register");
				Thread.sleep(3000);
			}else{
				actions.WaitForElementPresent("GWCHomePage.Register", 10);
				actions.click("GWCHomePage.Register");
			}
			
			actions.waitForPageToLoad(10);
			//Verify Registration page title			
			gwc.verifyPage(input.get("pageRegistration"), "Click on 'Registration' link at the top of the page", "'Registration' page should be displayed");
			
			//Enter new user details
			actions.setValue("GWCRegisterPage.Firstname", input.get("firstName"));
			actions.setValue("GWCRegisterPage.Lastname", input.get("lastName"));
			actions.setValue("GWCRegisterPage.Email", input.get("emailAddress"));
			actions.setValue("GWCRegisterPage.PostalCode", input.get("postalCode"));
			actions.setValue("GWCRegisterPage.Password", input.get("password"));
			actions.setValue("GWCRegisterPage.ConfirmPassword", input.get("password"));
			
			//To check checkboxes
			if(input.get("offersCheckbox").toString().equalsIgnoreCase("On")){
				actions.click("GWCRegistrationPage.Offers");
			}			
			
			if(input.get("verifyAgeCheckbox").toString().equalsIgnoreCase("On")){
				actions.click("GWCRegistrationPage.Age");
			}			
			
			if(input.get("termsCheckbox").toString().equalsIgnoreCase("On")){
				actions.click("GWCRegistrationPage.Terms");
			}
			
			//Click on Offers link
			if ((((RemoteWebDriver) driver).getCapabilities()
					.getPlatform().toString().equalsIgnoreCase(
							"ANDROID"))|| osState==true){
			actions.click("GWCRegisterPage.CancleMobile");
//			actions.javaScriptClick("GWCRegisterPage.CancleMobile");
			}else{
			actions.click("GWCHomePage.Offers");
			
			gwc.verifyPage(input.get("pageOffers"), "Click on 'Offers' tab at the top of the page", "'Offers' page should be displayed");
			}
			//Verify Registration page title			
			
			
			
			//Click on Register link again
			if ((((RemoteWebDriver) driver).getCapabilities()
					.getPlatform().toString().equalsIgnoreCase(
							"ANDROID"))|| osState==true){
				actions.waitForPageToLoad(20);
				Thread.sleep(2000);
				gwc.navigationMobile("Register");
				actions.waitForPageToLoad(10);
				Thread.sleep(3000);
			}else{
				actions.WaitForElementPresent("GWCHomePage.Register", 10);
				actions.click("GWCHomePage.Register");
			}			
			//Verify Registration page title			
			gwc.verifyPage(input.get("pageRegistration"), "Click on 'Registration' link at the top of the page", "'Registration' page should be displayed");
//			driver.findElement(By.id(input.get("GWCRegisterPage.Firstname").toString())).getText();
			
			//Verify previously entered data is cleared			

			//driver.findElement(By.xpath("//input[@id='firstNameInput']")).getText();
			
			System.out.println(gwc.getAttribute("GWCRegisterPage.Firstname","class"));

			
			if(
					gwc.getAttribute("GWCRegisterPage.Firstname","class").toLowerCase().trim().toString().equals("form-control standard-reg")
					&&gwc.getAttribute("GWCRegisterPage.Lastname","class").toLowerCase().trim().toString().equals("form-control standard-reg")		
					&&gwc.getAttribute("GWCRegisterPage.Email","class").toLowerCase().trim().toString().equals("form-control standard-reg")
					&&gwc.getAttribute("GWCRegisterPage.Password","class").toLowerCase().trim().toString().equals("form-control standard-reg")
					&&gwc.getAttribute("GWCRegisterPage.ConfirmPassword","class").toLowerCase().trim().toString().equals("form-control standard-reg")){
				actions.reportCreatePASS("Verify registration fields are empty", "All the data fields on Registration page should be empty", "All the data fields on Registration page are empty", "Pass");
			}else{
				actions.reportCreateFAIL("Verify registration fields are empty", "All the data fields on Registration page should be empty", "All the data fields on Registration page are NOT empty", "Fail");
			}
			
			//driver.findElement(By.id(input.get("GWCRegisterPage.Firstname").toString())).getAttribute("value");
			System.out.println("Test RUN Finished!!");

		} catch(Exception e) {
			//Reporter.log("Failed Test"+e.getMessage());
			System.out.println("Failed Test: "+e.getMessage());
			actions.catchException(e);
			
		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}
}
