package xtam.test;



import java.util.List;
import java.util.Map;

import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.GWCReusable;
import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;

public class GWC_Offers_108 {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private GWCReusable gwc;
	private boolean osState;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strPostalCode;
	private String strDescription;
	private String strOfferConditon;
	private String strOfferType;
	// TODO: Declare test-data variables for other data-parameters


	public GWC_Offers_108 (WebDriver nodeDriver, Map inputData, Object or){
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver,or);
		uiActions = new UIValidations();
		gwc = new GWCReusable(driver,actions, uiActions, input);

		// Read input Test-Data
		strURL          = gwc.GetTestData("DT_URL");
		strUserName     = gwc.GetTestData("DT_USERNAME");
		strPassword     = gwc.GetTestData("DT_PASSWORD");
		strPostalCode   = gwc.GetTestData("DT_POSTALCODE");
		strDescription  = gwc.GetTestData("DT_DESCRIPTION");
		strOfferConditon= gwc.GetTestData("offerCondition");
		strOfferType=gwc.GetTestData("offerType");
		// TODO: GetTestData for other data-parameters
	}

	@Test
	public void test_GWC_Offers_108() throws InterruptedException {

		try {
			System.out.println("************************* Test execution starts");

			//Setting the Test Case Description
			actions.setTestcaseDescription(strDescription);

			osState = gwc.osCheck();

			// to launch the application
			gwc.LaunchAndLogin(strURL, strUserName, strPassword);

			/** TODO: Step 1 */
			//To click on offers tab
			
			if ((((RemoteWebDriver) driver).getCapabilities()
					.getPlatform().toString().equalsIgnoreCase(
							"ANDROID")) || osState == true ){
				
				actions.click("GWCHomePage.RestaurantsBtn");
				actions.waitForPageToLoad(10);
				actions.WaitForElementPresent("GWCRestaurantPage.ChooseClosestRest", 10);
				actions.click("GWCRestaurantPage.ChooseClosestRest");
				
				actions.WaitForElementPresent("GWCRestaurantPage.SearchBtn", 10);
				actions.clear("GWCRestaurantPage.postalcode");
				actions.setValue("GWCRestaurantPage.postalcode", strPostalCode);
				actions.click("GWCRestaurantPage.SearchBtn");
				
				Thread.sleep(2000);
				
				actions.click("GWCStartOrderAndroid.RestListView");
				actions.waitForPageToLoad(10);
				
				//Entering post code second time for iOS safari
				actions.WaitForElementPresent("GWCRestaurantPage.postalcode", 15);
				actions.clear("GWCRestaurantPage.postalcode");
				actions.setValue("GWCRestaurantPage.postalcode", strPostalCode);
				actions.javaScriptClick("GWCRestaurantPage.SearchAgainBtn");
				Thread.sleep(3000);
				
				gwc.restaurantSelect("GWCRestaurantPage.RestaurantList", input.get("restaurantName"));
				
				actions.waitForPageToLoad(30);
				Thread.sleep(5000);
				/*gwc.navigationMobile("Home");*/
				/*actions.WaitForElementPresent("GWCStartOrderAndroid.TopNav", 10);*/
				
				actions.click("GWCStartOrderAndroid.TopNav");
				actions.WaitForElementPresent("GWCHomePage.HomeTabMobile", 10);
				actions.click("GWCHomePage.HomeTabMobile");
				
				actions.WaitForElementPresent("GWCHomePage.OffersUnderCurrentRest", 10);
				actions.click("GWCHomePage.OffersUnderCurrentRest");
				
				
			}else{
				new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOf(actions.getwebDriverLocator(actions.getLocator("GWCHomePage.Offers"))));
				actions.javaScriptClick("GWCHomePage.Offers");

				actions.WaitForElementPresent("GWCOfferPage.OffersHeading", 10);
				gwc.verifyPage(input.get("offersPage"), "Click on 'Offers' tab at the top of the Home page", "' 'Offers' page should be displayed");
				
			}


			/** TODO: Step 2 */

			String offerName=gwc.selectOffer(strOfferType,strOfferConditon,"normal");
			System.out.println("Offer Name returned : "+offerName);

			/** TODO: Step 3 */
			if (!((((RemoteWebDriver) driver).getCapabilities()
					.getPlatform().toString().equalsIgnoreCase(
							"ANDROID")) || osState == true )){
			gwc.selectOfferRestaurant("GWCRestaurantPage.RestaurantList", input.get("restaurantName"), strPostalCode);
			}

			/** TODO: Step 4 */
			gwc.addAndVerifyOfferToBasket(offerName);

			//---------------------------------------------------------------------------------------------------
			//click on check out button on basket page

			if ((((RemoteWebDriver) driver).getCapabilities()
					.getPlatform().toString().equalsIgnoreCase(
							"ANDROID"))|| osState==true)
			{
				//for Android
//				Thread.sleep(2000);
				actions.WaitForElementPresent("GWCBasketPage.CheckOutMobile", 10);
				actions.click("GWCBasketPage.CheckOutMobile");
				actions.waitForPageToLoad(10);
				actions.WaitForElementPresent("GWCStartOrderAndroid.PlaceOrder", 25);
				
				gwc.verifyPage(input.get("reviewOrderPage"), "Click on 'Checkout' button", "'Review Your Order' page should be displayed");

				actions.click("GWCStartOrderAndroid.PlaceOrder");
				
				actions.waitForPageToLoad(10);
				gwc.jsPageWait(20);
				actions.WaitForElementPresent("GWCStartOrder.addToFavorite", 20);
				
				gwc.verifyPage(input.get("orderPage"), "Click on 'Place an Order'", "Selected Offer :'"+offerName+"' Order should be placed successfully");

			}
			else
			{
				//for desktop browsers
				actions.click("GWCStartOrder.Checkout");
				actions.waitForPageToLoad(10);
				actions.WaitForElementPresent("GWCStartOrder.PlaceOrder", 25);
				gwc.verifyPage(input.get("reviewOrderPage"), "Click on 'Checkout' button", "'Review Your Order' page should be displayed");
				
				//gwc.selectPayment("Cash");
				actions.click("GWCStartOrder.PlaceOrder");
				actions.waitForPageToLoad(10);
				gwc.jsPageWait(20);

				actions.WaitForElementPresent("GWCStartOrder.printOrder", 20);
//				Thread.sleep(2000);
				gwc.verifyPage(input.get("orderPage"), "Click on 'Place an Order'", "Selected Offer :'"+offerName+"' Order should be placed successfully");
			}
			
			
			/** Logout the application */
			gwc.logout();


		} catch(Exception e) {
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass()); 
		}
	}
}
