package xtam.test;

import java.util.List;
import java.util.Map;

import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.gargoylesoftware.htmlunit.javascript.host.Set;

import crossbrowser.library.GWCReusable;
import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;

public class GWC_Registration_TC8 {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();
	private GWCReusable gwc;
	public boolean osState;

	// Test-Data Variables
	private Object strURL;
	private String strDescription;

	public GWC_Registration_TC8(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();
		gwc = new GWCReusable(driver, actions, uiActions, input);

		// Read input Test-Data
		strURL = gwc.GetTestData("DT_URL");
		strDescription = input.get("DESCRIPTION").toString();
		// TODO: GetTestData for other data-parameters

	}

	@Test
	public void test_GWC_Registration_TC8() throws InterruptedException {
		try {
			System.out.println("******* Test execution starts *******");
			// To add description
			actions.setTestcaseDescription(strDescription);
			
			osState = gwc.osCheck();
			
			// to launch the application
			actions.launchApplication(strURL);

			if ((((RemoteWebDriver) driver).getCapabilities().getPlatform().toString().equalsIgnoreCase("ANDROID"))
					|| osState == true) {
				
				// to click on terms and conditions link
				gwc.navigationMobile("Register");
				Thread.sleep(3000);
				WebElement lastElement = driver.findElement(By.xpath("//*[@id='user-registration']/a[2]"));
				try {
					Actions action = new Actions(driver);
					action.moveToElement(lastElement).build().perform();
					action.doubleClick().build().perform();
				} catch (Exception e11) {

				}
				lastElement.click();
				actions.click("GWCRegisterPage.TnClink");
				driver.findElement(By.xpath("//*[@id='user-registration']/a[2]")).click();
				
				Thread.sleep(2000);
				String handle = driver.getWindowHandle();

				for (String handled : driver.getWindowHandles()) {
					System.out.println(handled);
					driver.switchTo().window(handled);
				}
				String tCactualtitle = actions.getPageTitle();
				String tCexptitle = "Terms & Conditions :: McDonalds.co.uk";
				if (tCexptitle.toLowerCase().trim().contains(tCactualtitle.toLowerCase())) {
					actions.reportCreatePASS("Verify Terms and Conditions Page",
							" 'Terms and Conditions Page' should be displayed",
							"'Terms and Conditions Page' is displayed", "Pass");
					driver.close();
					for (String handled : driver.getWindowHandles()) {
						System.out.println(handled);
						driver.switchTo().window(handled);
					}
					
				} else {
					actions.reportCreateFAIL("Verify Terms and Conditions Page",
							" 'Terms and Conditions Page' should be displayed",
							"'Terms and Conditions Page' is not displayed", "Fail");
				}
				
				
				System.out.println(driver.getTitle());
//				driver.findElement(By.linkText("Privacy")).click();
				actions.click("GWCRegisterPage.Privacylink");
				driver.findElement(By.xpath("//*[@id='user-registration']/a[1]")).click();
				Thread.sleep(2000);

				for (String handled : driver.getWindowHandles()) {
					System.out.println(handled);
					driver.switchTo().window(handled);
				}

				String privecy = actions.getPageTitle();
				System.out.println(privecy);
				String priexpStr = "Privacy Policy :: McDonalds.co.uk";

				if (priexpStr.toLowerCase().trim().contains(privecy.toLowerCase())) {
					actions.reportCreatePASS("Verify Privecy Page", "Privecy Page should be displayed",
							"Privecy Page is displayed", "Pass");
				} else {
					actions.reportCreateFAIL("Verify Privecy Page", "Privecy Page should be displayed",
							"Privecy Page is not displayed", "Fail");
				}
				
			} else {

				// to click on terms and conditions link
				driver.findElement(By.xpath("//html/body/div[7]/div[2]/div[2]/a[2]")).click();

				// to switch the window
				String handle = driver.getWindowHandle();

				for (String handled : driver.getWindowHandles()) {
					System.out.println(handled);
					driver.switchTo().window(handled);
				}
				String tCactualtitle = actions.getPageTitle();
				String tCexptitle = "Terms and Conditions :: McDonalds.co.uk";
				if (tCexptitle.toLowerCase().trim().contentEquals(tCactualtitle.toLowerCase())) {
					actions.reportCreatePASS("Verify Terms and Conditions Page",
							" 'Terms and Conditions Page' should be displayed",
							"'Terms and Conditions Page' is displayed", "Pass");
				} else {
					actions.reportCreateFAIL("Verify Terms and Conditions Page",
							" 'Terms and Conditions Page' should be displayed",
							"'Terms and Conditions Page' is not displayed", "Fail");
				}

				System.out.println(driver.getTitle());
				driver.findElement(By.linkText("Privacy")).click();

				for (String handled : driver.getWindowHandles()) {
					System.out.println(handled);
					driver.switchTo().window(handled);
				}

				String privecy = actions.getPageTitle();
				System.out.println(privecy);
				String priexpStr = "Privacy Policy :: McDonalds.co.uk";

				if (priexpStr.toLowerCase().trim().contentEquals(privecy.toLowerCase())) {
					actions.reportCreatePASS("Verify Privecy Page", "Privecy Page should be displayed",
							"Privecy Page is displayed", "Pass");
				} else {
					actions.reportCreateFAIL("Verify Privecy Page", "Privecy Page should be displayed",
							"Privecy Page is not displayed", "Fail");
				}

			}
			System.out.println("Test RUN Finished!!");

		} catch (Exception e) {
			// Reporter.log("Failed Test"+e.getMessage());
			System.out.println("Failed Test: " + e.getMessage());
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}
}
