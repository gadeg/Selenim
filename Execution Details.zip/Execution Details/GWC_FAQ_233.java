package xtam.test;

import java.util.List;
import java.util.Map;

import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.GWCReusable;
import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;

public class GWC_FAQ_233 {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private GWCReusable gwc;
	private boolean osState;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strPostalCode;
	private String strDescription;
	// TODO: Declare test-data variables for other data-parameters

	public GWC_FAQ_233(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();
		gwc = new GWCReusable(driver, actions, uiActions, input);

		// Read input Test-Data
//		strURL = gwc.GetTestData("DT_URL");
		strURL = input.get("DT_URL");
		strDescription = input.get("DT_DESCRIPTION").toString();
//		strUserName = gwc.GetTestData("DT_USERNAME");
//		strPassword = gwc.GetTestData("DT_PASSWORD");
//		strPostalCode = gwc.GetTestData("DT_POSTALCODE");
//		strDescription = gwc.GetTestData("DT_DESCRIPTION");
		// TODO: GetTestData for other data-parameters
	}

	@Test
	public void test_GWC_FAQ_233() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");

			// Setting the Test Case Description
			actions.setTestcaseDescription(strDescription);

			osState = gwc.osCheck();

			// to launch the application
			actions.launchApplication(strURL);
			
		if (driver.findElement(By.linkText("contactus")).isDisplayed()){
			actions.reportCreatePASS("Verify 'Contact Us' link is displayed", "'Contact Us' should be displayed", "'Contact Us' link is displayed", "Pass");
		}else{
			actions.reportCreateFAIL("Verify 'Contact Us' link is displayed", "'Contact Us' should be displayed", "'Contact Us' link is not displayed", "Fail");
		}
		
		actions.verifyPresence("GWCFAQs.laungages", true);

			
			

			
			// ------------------------------------------------------------------------

			/** Logout the application */
			gwc.logout();

		} catch (Exception e) {
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}
}
