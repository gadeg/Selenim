package xtam.test;

import java.util.List;
import java.util.Map;

import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.GWCReusable;
import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;

public class GWC_RestaurantLocator_028 {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private GWCReusable gwc;
	private boolean osState;
	private boolean restaurant;
	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strPostalCode;
	private String strDescription;
	// private String strDescription;
	// TODO: Declare test-data variables for other data-parameters

	public GWC_RestaurantLocator_028(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();
		gwc = new GWCReusable(driver, actions, uiActions, input);

		// Read input Test-Data
		strURL = gwc.GetTestData("DT_URL");
		strUserName = gwc.GetTestData("DT_USERNAME");
		strPassword = gwc.GetTestData("DT_PASSWORD");
		 strPostalCode = gwc.GetTestData("DT_POSTALCODE").toString();
		 strDescription = gwc.GetTestData("DT_DESCRIPTION").toString();
		 
		// TODO: GetTestData for other data-parameters
	}

	@Test
	public void test_GWC_RestaurantLocator_028() throws InterruptedException {

		try {
			System.out.println("Test execution starts");

			// Setting the Test Case Description
			 actions.setTestcaseDescription(strDescription);

			osState = gwc.osCheck();

			// to launch the application
			gwc.LaunchAndLogin(strURL, strUserName, strPassword);

			if ((((RemoteWebDriver) driver).getCapabilities().getPlatform().toString().equalsIgnoreCase("ANDROID"))
					|| osState == true) {
				gwc.navigationMobile("Order");
			} else {
				// to click on Order link
				actions.WaitForElementPresent("GWCStartOrder.Food", 10);
				actions.click("GWCStartOrder.Food");
				actions.waitForPageToLoad(10);
				// Verifying Start Order Page
				gwc.verifyPage("Start an Order - McDonalds", "Click on 'Food' tab at the top of the page",
						"' 'Start an Order' page should be displayed");

			}

			// to enter the postal code
			actions.WaitForElementPresent("GWCStartOrder.Zipcode", 10);
			actions.setValue("GWCStartOrder.Zipcode", strPostalCode);
			actions.waitForPageToLoad(10);

			// to click on 'NEXT' button
			if ((((RemoteWebDriver) driver).getCapabilities().getPlatform().toString().equalsIgnoreCase("ANDROID"))
					|| osState == true) {
				// for android
				actions.click("GWCStartOrderAndroid.NextButton");
			} else {
				// for desktop browsers
				actions.click("GWCStartOrder.NextButton");
			}

			// to verify the whether 'Find a Restaurant' page is displayed
			gwc.waitTillNewPageByTitle(15, input.get("restFindPage"));
			gwc.verifyPage(input.get("restFindPage"), "Enter valid Zip Code e.g.,'SL1 4PN' & click on 'Next' button",
					"'Find a Restaurant' page should be displayed");

			actions.waitForPageToLoad(15);
			// ---------------------------------------------------------------------------------
			// to click on restaurant view
			if ((((RemoteWebDriver) driver).getCapabilities().getPlatform().toString().equalsIgnoreCase("ANDROID"))
					|| osState == true) {
				// For Android (chrome 46)

				actions.javaScriptClick("GWCStartOrderAndroid.RestListView");
				// to click on 'Choose closest restaurant' button
				WebElement button = driver.findElement(By.id("btn-address"));
				if (button.isDisplayed()) {
					button.click();
				}
			} else {

			}

			// to set value of postal code on Find Restaurant page
			actions.WaitForElementPresent("GWCRestaurantPage.postalcode", 15);
			actions.clear("GWCRestaurantPage.postalcode");
			actions.setValue("GWCRestaurantPage.postalcode", input.get("DT_POSTALCODE"));
			actions.javaScriptClick("GWCRestaurantPage.submit");
			actions.waitForPageToLoad(15);
			boolean Textbox_isDisplayed = actions.isPresence("GWCAddItemspage.FilterTextBox", true);

			// to verify the whether 'Menu page' page is displayed
			if (Textbox_isDisplayed) {
				actions.reportCreateFAIL("Verify 'Menu page' is displayed", "'Menu page' should not displayed",
						"Menu page is diplayed", "Fail");
			} else {
				actions.reportCreatePASS("Verify 'Menu page' is displayed", "'Menu page' should not displayed",
						"Menu page is not diplayed", "Pass");
			}

			// to select the restaurant
			gwc.restaurantSelect("GWCRestaurantPage.RestaurantList", input.get("restaurantName"));

			actions.waitForPageToLoad(50);
			
			if ((((RemoteWebDriver) driver).getCapabilities().getPlatform().toString().equalsIgnoreCase("ANDROID"))
					|| osState == true) {
				Thread.sleep(2000);
				gwc.navigationMobile("Home");
				Thread.sleep(2000);			
				String verText = driver
						.findElement(By.xpath("/html/body/div[1]/div[3]/ul/li[4]/div/a/div")).getText();
				
				String text = input.get("restaurantName").toString();

				if (verText.replace("\\n", " ").toLowerCase().contains(text.toLowerCase())) {
					actions.reportCreatePASS("Checking the home page for Current Restaurant",
							"Restaurant should be displayed", " Actual Restaurant is displayed", "Pass");
				} else {
					actions.reportCreateFAIL("Checking the home page for Current Restaurant",
							"Restaurant should be displayed", "Actual Restaurant is not displayed", "Fail");
				}

			} else {
				// clicking on Home link
				actions.click("GWCHomePage.McdImageLink");

				String verText = driver
						.findElement(By.xpath(actions.getLocator("GWCHomePage.CurrentlySelcLocationText"))).getText();

				String text = input.get("restaurantName").toString();

				if (verText.replace("\\n", " ").toLowerCase().contains(text.toLowerCase())) {
					actions.reportCreatePASS("Checking the home page for Current Restaurant",
							"Restaurant should be displayed", " Actual Restaurant is displayed", "Pass");
				} else {
					actions.reportCreateFAIL("Checking the home page for Current Restaurant",
							"Restaurant should be displayed", "Actual Restaurant is not displayed", "Fail");
				}
			}
			/** Logout the application */
			gwc.logout();

		} catch (Exception e) {
			actions.catchException(e);

		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}
}
