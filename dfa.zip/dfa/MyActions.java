package Demo;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import KeywordsLib.ScreenShot;
import crossbrowser.helper.PropertyReader;

public class MyActions
{
	private WebDriver driver;
	private String locator = "";
	private HashMap<String, String> propertyFileData;
	private String uiMap = "";
	private ScreenShot screenshot;

	// ***** This Method Is To Click On Element *****
	public void click(String Element) throws IOException, InterruptedException
	{
		try
		{
			if (getwebDriverLocator(getLocator(Element)) != null)
			{
				getwebDriverLocator(getLocator(Element)).sendKeys(Keys.ENTER);
				// getwebDriverLocator(getLocator(Element)).click();
				Thread.sleep(9000);
				System.out.println("Successfully Clicked On " + Element);
			}
			else
			{
				System.out.println("Failed To Clicked On " + Element);
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	// ***** This Method Is To Set Value In Element *****
	public void setValue(String Element, String value)
	{
		try
		{
			if (getwebDriverLocator(getLocator(Element)) != null)
			{
				getwebDriverLocator(getLocator(Element)).sendKeys(value);
				System.out.println("Successfully Set Value In " + Element);
			}
			else
			{
				System.out.println("Successfully Set Value In " + Element);
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	// ***** This Method Is To Set Value In Element *****
	public void handleAlert()
	{
		try
		{
			driver.switchTo().window("Select Node");
			driver.findElement(By.id("data2")).click();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	// ***** This Method Is To Login Into Application *****
	public WebDriver loginAndLaunch()
	{
		try
		{
			driver = new InternetExplorerDriver();
			driver.get("https://rfm2qaus.mcd.com/rfm2OnlineApp/rfmLogin.action");
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return driver;
	}

	// ***** Read Locator From XLSX *****
	public String getLocator(String Element) throws IOException
	{
		File file = new File("./Assets/ObjectRepository/" + uiMap);
		InputStream ExcelFileToRead = new FileInputStream(file);
		XSSFWorkbook wb = new XSSFWorkbook(ExcelFileToRead);
		XSSFSheet sheet = wb.getSheet("Sheet1");
		XSSFRow row = sheet.getRow(0);
		XSSFRow rowIte;
		for (int i = 0; i < row.getLastCellNum(); i++)
		{
			try
			{
				if (row.getCell(i).getStringCellValue().trim().equalsIgnoreCase("elementName"))
				{
					Iterator rowIte1 = sheet.iterator();
					while (rowIte1.hasNext())
					{
						rowIte = (XSSFRow) rowIte1.next();
						if (rowIte.getCell(i).getStringCellValue().equalsIgnoreCase(Element))
						{
							for (int j = i; j < row.getLastCellNum(); j++)
							{
								try
								{
									if (row.getCell(j).getStringCellValue().trim().equalsIgnoreCase("locator"))
									{
										locator = rowIte.getCell(j).getStringCellValue();
										// System.out.println("The Locator Is " + locator);
									}
								}
								catch (Exception e)
								{
									e.printStackTrace();
								}
							}
						}
					}
				}
				else
				{
					// System.out.println("Cell Not Matched");
				}
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
		return locator;
	}

	// ***** This Method Is Get Locator *****
	public WebElement getwebDriverLocator(String locator)
	{
		WebElement element = null;
		try
		{
			if (locator.startsWith("//"))
			{
				element = driver.findElement(By.xpath(locator));
				System.out.println("Locator Is As Expected " + locator);
			}
			else
			{
				System.out.println("Locator Is Not As Expected " + locator);
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return element;
	}

	// ***** This Method Is To Read Property File *****
	public void readPropertyFile()
	{
		try
		{
			File file = new File("crossbrowser.properties");
			uiMap = PropertyReader.getAllProperty().get("UiMapFile").toString();
			System.out.println("XLSX File Is " + uiMap);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	public void quiteBrowser()
	{
		try
		{
			driver.quit();
			System.out.println("Browser Quite Successfully");
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	// ***** This Method Is To Take Screenshot *****
	public void takeScreenshot() throws IOException
	{
		try
		{
			Date date = new Date();
			SimpleDateFormat fomateDate = new SimpleDateFormat("ddMMMyyyy-HHmmssS-z");
			String formatDate1 = fomateDate.format(date);
			String fileName = "Screenshot" + formatDate1 + ".png";
			String filePath = "./test-output/Screenshot/" + fileName;
			File screenshotFile = null;
			screenshotFile = screenshot(driver);
			File dest = new File(filePath);
			FileUtils.copyFile(screenshotFile, dest);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	// ***** This Method Is To Take Screenshot *****
	public File screenshot(WebDriver driver)
	{
		File screenshot1 = null;
		try
		{
			screenshot1 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return screenshot1;
	}

	// ***** This Method Is To Select Future Date *****
	public void futureDate(int x, String toFrom)
	{
		int index = 0;
		if (toFrom.equalsIgnoreCase("to"))
		{
			index = 0;
		}
		else
		{
			index = 1;
		}
		Calendar Date = Calendar.getInstance();
		SimpleDateFormat formatter = new SimpleDateFormat("MMM dd, yyyy");
		Date.add(Calendar.DAY_OF_MONTH, x);
		String id = Date.get(Calendar.MONTH) + 1 + "" + Date.get(Calendar.DAY_OF_MONTH);
		driver.findElements(By.id(id)).get(index).click();
		String date = formatter.format(Date.getTime());
		System.out.println("Date Is " + date);
	}

	// ***** This Method Is To Switch Window *****
	public void windowSwitch()
	{
		try
		{
			String parentWindow = driver.getWindowHandle();
			Set<String> allWondow = driver.getWindowHandles();
			for (String handler : allWondow)
			{
				if (!handler.contains(parentWindow))
				{
					driver.switchTo().window(handler);
					Thread.sleep(3000);
					System.out.println("Child window is " + handler);
				}
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	// ***** This Method Is To Switch Parent Window *****
	public void paretnWindowSwitch(String title)
	{
		String parentWindow = driver.getWindowHandle();
		Set<String> allWondow = driver.getWindowHandles();
		for (String handler : allWondow)
		{
			try
			{
				if (driver.switchTo().window(handler).getTitle().equalsIgnoreCase(title))
				{
					driver.switchTo().window(handler);
					Thread.sleep(3000);
					System.out.println("Child window is " + handler);
				}
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
	}
}
